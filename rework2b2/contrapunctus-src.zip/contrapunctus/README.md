# Contrapunctus

A deterministic three-voice counterpoint automaton, the rule space it lives in, and the tools to look at both.

    python3 build.py        -> dist/contrapunctus.html           standalone page (open it in a browser)
                               dist/contrapunctus.artifact.html  the same page as a fragment for a page host
                               dist/contrapunctus.js             the script alone
    sh test/run.sh          node suite: theory, rule tables, automaton, analysis, envelopes, tunings,
                            MIDI written and read back by an independent reader, zip, state codes (245 checks)
    python3 test/ui.py      browser suite in headless Chromium via Playwright (83 checks)
                            --nogl  Canvas 2D fallback instead of WebGL
                            CP_SRC=path  run it against another build
    python3 test/looks.py   element screenshots of the plates (--dark for the dark theme)
    python3 test/shot.py    page screenshots (--w --h --dark --full --nogl)

## src/ (concatenated in file-name order into one function scope)

    00-head.html   tokens and CSS            01-body.html  markup
    10-core.js     theory, tunings, state    11-rules.js   cost surface, level-set tables
    12-automaton.js chord and voice walks     13-analysis.js functional graph, orbit classes, basins, sweep
    20-gl.js       painter (WebGL / Canvas 2D), theme, tooltips
    30-notes.js    envelope model and the note list that the score, sequencer, editor and audio all read
    31-lattice.js  rule space: projections, handles, by-cost layout
    32-roll.js     score            33-seq.js  sequencer          34-env.js  envelope editor
    35-readouts.js dynamics, basins, branches, status
    40-audio.js    Web Audio scheduler
    50-io.js       state codes, autosave, MIDI with pitch-bend microtones, zip, downloads
    60-ui.js       controls, history, pointer and keyboard handling
    70-essay.js    the prose in the page   99-boot.js  start-up

Set `window.__CP_DEBUG = true` before the page loads to expose `window.__cp` (state, compose, buildMidi, ...) to tests.

## Microtonal MIDI

A tuning is twelve offsets in cents. The engine still thinks in whole-number pitches; the audio plays the fractional pitch,
and the .mid file writes the nearest key plus a 14-bit pitch bend (+/-2 semitones, set with RPN 0). Bend belongs to a channel,
so each voice has a small channel pool (channel 10 is skipped) and the writer places notes so that a bend change does not
move a note that is still sounding; the cases where it cannot are counted and reported. Equal temperament writes no bend.
