/* =====================================================================
   8 · NOTES AND ENVELOPES
   ---------------------------------------------------------------------
   One place decides what is held, for how long and how loudly. The score,
   the sequencer, the envelope editor, the sounding-aggregate lane and the
   audio scheduler all read the notes built here, so none of them can drift
   from the others (the first version resolved the gate in two places and
   squeezed attack and decay in the audio only, so the editor drew a curve
   nobody heard).

   Envelope: attack and decay are linear, sustain holds until note-off, and
   the release is exponential -- gain falls from where it was when the key
   came up to the floor over r seconds. A key lifted during the attack or the
   decay releases from wherever the level had got to, as it would on a real
   instrument, so a short gate is also a quieter note.
   ===================================================================== */
const ENV_PEAK  = 0.8;      // gain at the top of the attack
const ENV_FLOOR = 0.0008;   // gain at the end of the release
const AUDIBLE   = 0.01;     // a release counts as ringing until it is 40 dB below the peak

// the piecewise-linear part of the envelope, from key-down to note-off
function envSchedule(e, gateSec){
  const a=Math.max(0.001, e.a), d=Math.max(0.001, e.d), s=e.s;
  const pts=[[0,0]];
  if(gateSec<=a) pts.push([gateSec, gateSec/a]);                        // lifted during the attack
  else {
    pts.push([a,1]);
    if(gateSec<=a+d) pts.push([gateSec, 1-(1-s)*(gateSec-a)/d]);        // lifted during the decay
    else { pts.push([a+d, s]); pts.push([gateSec, s]); }
  }
  return pts;
}
// relative level 0..1 at time t after key-down
function envLevel(e, t, gateSec){
  if(t<=0) return 0;
  const pts=envSchedule(e, gateSec), last=pts[pts.length-1];
  if(t<=gateSec){
    for(let i=1;i<pts.length;i++){
      if(t<=pts[i][0]){
        const [t0,v0]=pts[i-1], [t1,v1]=pts[i];
        return t1>t0 ? v0+(v1-v0)*(t-t0)/(t1-t0) : v1;
      }
    }
    return last[1];
  }
  const g0=ENV_PEAK*last[1];
  if(g0<=ENV_FLOOR) return 0;
  const x=Math.min(1,(t-gateSec)/Math.max(0.005,e.r));
  return g0*Math.pow(ENV_FLOOR/g0, x)/ENV_PEAK;
}
// seconds of release that are actually audible from a given starting level
function audibleRelease(e, L0){
  const g0=ENV_PEAK*L0, thr=ENV_PEAK*AUDIBLE;
  if(g0<=thr) return 0;
  return Math.max(0.005,e.r) * Math.log(thr/g0)/Math.log(ENV_FLOOR/g0);
}

function resolveEnv(base, over, span, sps){
  const e={a:base.a, d:base.d, s:base.s, r:base.r, gate:span*base.gateRatio, custom:false};
  if(over) for(const k of ['a','d','s','r','gate']) if(over[k]!=null){ e[k]=over[k]; e.custom=true; }
  e.gate=Math.max(0.03, e.gate);
  e.gateSec=e.gate*sps;
  const pts=envSchedule(e, e.gateSec);
  e.L0=pts[pts.length-1][1];
  e.tail=audibleRelease(e, e.L0);
  return e;
}

function buildNotes(c){
  const sps=secondsPerStep(), total=c.total;
  const notes=[[],[],[]];
  for(let v=0; v<3; v++){
    const nextOn=new Int32Array(total); let nx=total;
    for(let s=total-1;s>=0;s--){ nextOn[s]=nx; if(STATE.onsets[v][s]) nx=s; }
    const base=STATE.voiceEnv[v];
    for(let s=0;s<total;s++){
      const p=c.pitches[v][s]; if(p==null) continue;
      const span=Math.max(1, nextOn[s]-s);
      const e=resolveEnv(base, STATE.noteEnv[v+':'+s], span, sps);
      const cents=tuningCents(pcOf(p));
      notes[v].push({v, step:s, pitch:p, cents, fpitch:p+cents/100, e, span, tailSteps:e.tail/sps,
        deco:c.deco[v][s], fell:c.fell[v][s], anchored: v===0 && STATE.anchors[s]!=null});
    }
  }
  // what is actually ringing at the start of each step, release tails included
  const sounding=new Array(total);
  for(let s=0;s<total;s++){
    const pcs=[]; let tail=0, n=0;
    for(let v=0;v<3;v++) for(const nt of notes[v]){
      if(nt.step>s) break;
      if(s < nt.step + nt.e.gate + nt.tailSteps){ pcs.push(pcOf(nt.pitch)); n++; if(s >= nt.step+nt.e.gate) tail++; }
    }
    const set=[...new Set(pcs)];
    const g=Math.min(segOfStep(s), c.chords.length-1);
    const chordPCs=c.chords[g].tones.map(pcOf);
    sounding[s]={pcs:set, tension:chordTension(set), voices:n, tails:tail,
      foreign:set.filter(p=>!chordPCs.includes(p)).length};
  }
  const byStep=new Array(total);
  for(let v=0;v<3;v++) for(const nt of notes[v]){ (byStep[nt.step]||(byStep[nt.step]=[])).push(nt); }
  return {notes, sounding, byStep};
}
function attachNotes(c){ Object.assign(c, buildNotes(c)); return c; }
