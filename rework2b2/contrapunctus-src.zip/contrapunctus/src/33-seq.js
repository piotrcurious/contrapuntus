/* =====================================================================
   11 · SEQUENCER
   ---------------------------------------------------------------------
   Three lanes. In each, the upper strip switches a note on or off and the
   thin strip under it is that note's envelope: its bar runs from the onset to
   note-off, and the fainter run after it is the release that is still audible.
   Where the bar runs past the next onset the gate is longer than the space to
   the next note, which is how a held voice rubs against the next harmony.
   ===================================================================== */
const SEQ={ruler:22, lane:44, onset:28, env:16, minStep:7, cursor:{v:0, step:0}};

function seqLayout(){
  const sc=$('seqScroll'), total=STATE.bars*STATE.stepsPerBar;
  const avail=(sc&&sc.clientWidth)||600, w=Math.max(avail, total*SEQ.minStep);
  return {w, total, stepW:w/total, h:SEQ.ruler+3*SEQ.lane, scrolls:w>avail+1};
}
function sizeSeq(){
  const L=seqLayout();
  $('seqInner').style.width=L.w+'px';
  $('seqCanvas').style.height=L.h+'px';
  return L;
}
function renderSeqGutter(){
  const host=$('seqGutter'); if(!host) return;
  const L=seqLayout();
  host.textContent=''; host.style.height=L.h+'px';
  const mkBtn=(label,top,h,lane,color)=>{
    const b=mk('button','lane'); b.type='button'; b.style.top=top+'px'; b.style.height=h+'px';
    if(color){ const i=mk('i'); i.style.background=color; b.appendChild(i); }
    b.appendChild(document.createTextNode(label));
    b.setAttribute('aria-pressed', String(STATE.lane===lane));
    b.title = lane==='all' ? 'The rhythm presets apply to every lane' : 'The rhythm presets apply to the '+label+' lane';
    b.addEventListener('click', ()=>{ STATE.lane=lane; renderSeqGutter(); drawSeq(); });
    host.appendChild(b);
  };
  const rh=SEQ.ruler;
  const b=mk('button','lane'); b.type='button'; b.style.top='0px'; b.style.height=rh+'px'; b.textContent='all lanes';
  b.style.fontSize='10px'; b.setAttribute('aria-pressed', String(STATE.lane==='all'));
  b.title='The rhythm presets apply to every lane';
  b.addEventListener('click', ()=>{ STATE.lane='all'; renderSeqGutter(); drawSeq(); });
  host.appendChild(b);
  for(let v=0;v<3;v++) mkBtn(VOICE_NAMES[v], SEQ.ruler+v*SEQ.lane, SEQ.lane-2, v, THEME.str.voice[v]);
}

function drawSeq(){
  const c=STATE.composed; if(!c||!c.notes) return;
  const L=sizeSeq(), cv=$('seqCanvas');
  const {g,w,h}=ctx2d(cv);
  const total=L.total, stepW=L.stepW, spb=STATE.stepsPerBar, S=THEME.str;
  g.font='10px '+THEME.font.mono; g.textBaseline='middle';

  // ruler: bar numbers, and a dot for a bar that has its own scale or tension aim
  for(let b=0;b<STATE.bars;b++){
    const x=b*spb*stepW;
    if(b===STATE.selectedBar){ g.fillStyle=css(THEME.grid,0.22); g.fillRect(x,0,spb*stepW,SEQ.ruler); }
    g.fillStyle=S.faint; g.textAlign='left'; g.fillText(String(b+1), x+4, SEQ.ruler/2);
    const ov=STATE.barOverrides[b];
    if(ov && (ov.scale||typeof ov.tension==='number')){ g.fillStyle=S.hand; g.beginPath(); g.arc(x+Math.min(22,spb*stepW-8),SEQ.ruler/2,2.8,0,7); g.fill(); }
  }
  g.strokeStyle=css(THEME.grid,0.4); g.lineWidth=1;
  g.beginPath(); g.moveTo(0,SEQ.ruler+0.5); g.lineTo(w,SEQ.ruler+0.5); g.stroke();

  const beat=Math.max(1,spb/4);
  for(let v=0; v<3; v++){
    const top=SEQ.ruler+v*SEQ.lane, col=S.voice[v];
    if(STATE.lane===v){ g.fillStyle=css(THEME.ink,0.05); g.fillRect(0,top,w,SEQ.lane); }
    for(let s=0;s<total;s++){
      const x=s*stepW, on=STATE.onsets[v][s];
      g.fillStyle = on ? col : css(THEME.grid, s%spb===0?0.20:(s%beat===0?0.13:0.07));
      g.fillRect(x+0.5, top+3, Math.max(1,stepW-1), SEQ.onset-6);
      if(v===0 && STATE.anchors[s]!=null && on){ g.fillStyle=S.hand; g.fillRect(x+0.5, top+3, Math.max(1,stepW-1), 3); }
    }
    const eTop=top+SEQ.onset;
    g.fillStyle=css(THEME.grid,0.09); g.fillRect(0,eTop,w,SEQ.env);
    const sel=STATE.selectedNote;
    for(const nt of c.notes[v]){
      const x=nt.step*stepW, gw=nt.e.gate*stepW, tw=nt.tailSteps*stepW;
      g.fillStyle = nt.e.custom ? S.hand : css(THEME.dim, 0.8);
      g.fillRect(x+0.5, eTop+5, Math.max(1.5,gw-1), 5);
      if(tw>1){ g.fillStyle = css(nt.e.custom?THEME.hand:THEME.dim, 0.3); g.fillRect(x+0.5+gw, eTop+6, tw, 3); }
      if(nt.e.gate > nt.span + 0.02){ g.fillStyle=S.ink; g.fillRect(x+gw-1.5, eTop+2, 2, 11); }
      if(sel && sel.v===v && sel.step===nt.step){
        g.strokeStyle=S.ink; g.lineWidth=1.4; g.strokeRect(x+0.5, eTop+1.5, Math.max(4,gw+tw*0), SEQ.env-3);
      }
    }
    g.strokeStyle=css(THEME.grid,0.28); g.lineWidth=1;
    g.beginPath(); g.moveTo(0,eTop+SEQ.env+1.5); g.lineTo(w,eTop+SEQ.env+1.5); g.stroke();
  }
  for(let b=0;b<=STATE.bars;b++){
    const x=b*spb*stepW;
    g.strokeStyle=css(THEME.grid, b%4===0?0.5:0.3); g.lineWidth=1;
    g.beginPath(); g.moveTo(x+0.5,SEQ.ruler); g.lineTo(x+0.5,h); g.stroke();
  }
  // the keyboard cursor, only while the canvas has focus
  if(document.activeElement===cv){
    const k=SEQ.cursor, x=Math.min(k.step,total-1)*stepW, y=SEQ.ruler+k.v*SEQ.lane;
    g.strokeStyle=S.ink; g.lineWidth=2; g.strokeRect(x+0.5, y+1.5, Math.max(3,stepW-1), SEQ.onset-3);
  }
}
function seqHit(e){
  const cv=$('seqCanvas'), rect=cv.getBoundingClientRect();
  const x=e.clientX-rect.left, y=e.clientY-rect.top;
  const total=STATE.bars*STATE.stepsPerBar, stepW=rect.width/total;
  const s=Math.floor(x/stepW);
  if(s<0||s>=total) return null;
  if(y<SEQ.ruler) return {kind:'bar', bar:Math.floor(s/STATE.stepsPerBar), step:s};
  const v=Math.floor((y-SEQ.ruler)/SEQ.lane);
  if(v<0||v>2) return null;
  const within=(y-SEQ.ruler)-v*SEQ.lane;
  return {kind: within<SEQ.onset ? 'onset' : 'env', v, step:s};
}

/* ---- rhythm presets and per-bar settings ---------------------------------- */
const SEQ_PRESETS = [
  ['fill',  'every step',                 (t)=>new Array(t).fill(true)],
  ['clear', 'no notes',                   (t)=>new Array(t).fill(false)],
  ['3 / bar','three evenly spread onsets per bar',(t)=>{ const o=euclid(STATE.stepsPerBar,3); return Array.from({length:t},(_,i)=>o[i%STATE.stepsPerBar]); }],
  ['5 / bar','five evenly spread onsets per bar', (t)=>{ const o=euclid(STATE.stepsPerBar,5); return Array.from({length:t},(_,i)=>o[i%STATE.stepsPerBar]); }],
];
function laneList(){ return STATE.lane==='all' ? [0,1,2] : [STATE.lane]; }
function applyRhythm(fn){
  const total=STATE.bars*STATE.stepsPerBar;
  for(const v of laneList()){
    if(fn===null){ STATE.touched[v]=false; continue; }          // back to following the chord rhythm
    STATE.onsets[v]=fn(total); STATE.touched[v]=true;
    for(let s=0;s<total;s++) if(!STATE.onsets[v][s]){ delete STATE.noteEnv[v+':'+s]; if(v===0) delete STATE.anchors[s]; }
  }
}
