/* =====================================================================
   3 · RULE TABLES AS LEVEL SETS OF A COST SURFACE
   ---------------------------------------------------------------------
   The first version filled the table in one fixed hand-written order, so
   lambda traced a single curve through a space of 2^540 tables. Here the
   composer shapes a separable cost surface

       cost(c) = SUM over axes of  w_axis * (1 - affinity_axis[c_axis])

   and lambda picks a sublevel set of it. lambda still means exactly
   "fraction of cells legal", so the old readings still hold; what is new
   is that the *order* cells unlock in is now an editable object with one
   weight and one profile per axis. Raising w on an axis makes that axis
   dominate the filtration; flattening its profile makes it inert.
   ===================================================================== */

function cellList(dims){
  const key = dims.join('x');
  let L = cellList.cache[key];
  if(L) return L;
  const total = dims.reduce((a,b)=>a*b,1);
  L = new Array(total);
  for(let f=0; f<total; f++){
    const c = new Array(dims.length); let rem=f;
    for(let i=dims.length-1;i>=0;i--){ c[i]=rem%dims[i]; rem=(rem-c[i])/dims[i]; }
    L[f]=c;
  }
  cellList.cache[key]=L;
  return L;
}
cellList.cache = {};

function cellCost(coords, axes, prof){
  let s=0;
  for(let i=0;i<axes.length;i++){
    const p = prof[axes[i].key];
    s += p.w * (1 - p.aff[coords[i]]);
  }
  return s;
}
function profileSig(axes, prof){
  let s='';
  for(const a of axes){ const p=prof[a.key]; s += a.key+':'+p.w.toFixed(3)+':'+p.aff.map(x=>x.toFixed(3)).join(',')+'|'; }
  return s;
}
function flipSig(flips){
  const ks = Object.keys(flips).sort();
  let s='';
  for(const k of ks) s += k+'='+flips[k]+';';
  return s;
}

// Ascending cost order, ties broken by flat index so the result is a pure
// function of the profile — no hidden dependence on iteration order.
const ORDER_CACHE = new Map();
function costOrder(axes, dims, prof){
  const sig = dims.join('x')+'#'+profileSig(axes, prof);
  let hit = ORDER_CACHE.get(sig);
  if(hit) return hit;
  const cells = cellList(dims);
  const costs = new Float64Array(cells.length);
  for(let f=0;f<cells.length;f++) costs[f]=cellCost(cells[f], axes, prof);
  const order = new Int32Array(cells.length);
  for(let f=0;f<cells.length;f++) order[f]=f;
  const arr = Array.from(order);
  arr.sort((a,b)=> (costs[a]-costs[b]) || (a-b));
  const rank = new Int32Array(arr.length);
  for(let i=0;i<arr.length;i++){ order[i]=arr[i]; rank[arr[i]]=i; }
  hit = {order, costs, rank};
  if(ORDER_CACHE.size>64) ORDER_CACHE.clear();
  ORDER_CACHE.set(sig, hit);
  return hit;
}

const TABLE_CACHE = new Map();
function buildTable(axes, dims, strides, prof, lambda, flips){
  const sig = dims.join('x')+'#'+profileSig(axes,prof)+'#'+lambda.toFixed(4)+'#'+flipSig(flips);
  let hit = TABLE_CACHE.get(sig);
  if(hit) return hit;
  const {order, costs, rank} = costOrder(axes, dims, prof);
  const t = new Uint8Array(order.length);
  const n = Math.round(clamp01(lambda)*order.length);
  for(let i=0;i<n;i++) t[order[i]]=1;
  for(const k in flips){
    const v = flips[k];
    if(v==null) continue;
    const c = k.split(',').map(Number);
    let f=0; for(let i=0;i<c.length;i++) f += c[i]*strides[i];
    t[f]=v;
  }
  // legalCount is what is really legal, hand flips included; cut is how many cells fall
  // under the threshold before any flip (the first version reported only the latter).
  let legal=0; for(let i=0;i<t.length;i++) legal+=t[i];
  hit = {t, costs, order, rank, legalCount:legal, cut:n, size:t.length};
  if(TABLE_CACHE.size>48) TABLE_CACHE.clear();
  TABLE_CACHE.set(sig, hit);
  return hit;
}

function chordTable(lambda, flips, prof){
  return buildTable(CHORD_AXES, CHORD_DIMS, CHORD_STR.strides,
    prof||STATE.profiles.chord,
    lambda==null?STATE.lamC:lambda,
    flips||STATE.cellFlips.chord);
}
function voiceTable(lambda, flips, prof){
  return buildTable(VOICE_AXES, VOICE_DIMS, VOICE_STR.strides,
    prof||STATE.profiles.voice,
    lambda==null?STATE.lamV:lambda,
    flips||STATE.cellFlips.voice);
}
const CS = CHORD_STR.strides, VS = VOICE_STR.strides;
function cIdx(d,tau,rho,eta){ return d*CS[0]+tau*CS[1]+rho*CS[2]+eta*CS[3]; }
function vIdx(k,mu,phi,sg,gm){ return k*VS[0]+mu*VS[1]+phi*VS[2]+sg*VS[3]+gm*VS[4]; }

// Momentum class now reads the composer's own d-profile, so reshaping which
// root motions count as strong also reshapes what the memory axis remembers.
// (The first version mislabelled this: index 0 was documented as "weak" but
// returned for the strongest motions. Fixed here — 2 is strong.)
function etaOf(d){
  const a = STATE.profiles.chord.d.aff[d];
  return a>=0.72 ? 2 : a>=0.34 ? 1 : 0;
}

/* ---- statistics over a table: this is what "statistical control" means ---- */
function marginals(axes, dims, strides, table){
  const cells = cellList(dims);
  const out = axes.map(a=>new Array(a.n).fill(0));
  const tot = axes.map(a=>new Array(a.n).fill(0));
  for(let f=0; f<cells.length; f++){
    const c=cells[f];
    for(let i=0;i<axes.length;i++){ tot[i][c[i]]++; if(table[f]) out[i][c[i]]++; }
  }
  return out.map((row,i)=>row.map((v,j)=>v/Math.max(1,tot[i][j])));
}
function chordMarginals(tbl){ return marginals(CHORD_AXES, CHORD_DIMS, CHORD_STR.strides, tbl.t); }
function voiceMarginals(tbl){ return marginals(VOICE_AXES, VOICE_DIMS, VOICE_STR.strides, tbl.t); }

// Branching statistics of the induced chord graph: how many moves are legal
// from each (chord, momentum) state, how uneven that is, and how often the
// rule leaves the automaton with no move at all or exactly one.
function chordBranching(tbl, vocab, target){
  const V=vocab.length; let sum=0, dead=0, forced=0, n=0;
  const hist=new Array(Math.min(V,24)+1).fill(0);
  const counts=[];
  for(let i=0;i<V;i++) for(let e=0;e<3;e++){
    let k=0;
    for(let j=0;j<V;j++){
      const c=vocab[j];
      if(tbl.t[cIdx(rootFall(vocab[i].rootPc,c.rootPc), tensionBucket(c.tensionVal-target), c.ring, e)]) k++;
    }
    counts.push(k); sum+=k; n++;
    if(k===0) dead++; else if(k===1) forced++;
    hist[Math.min(k,hist.length-1)]++;
  }
  let H=0;
  const p = hist.map(h=>h/Math.max(1,n));
  for(const q of p) if(q>0) H -= q*Math.log2(q);
  return {mean:sum/Math.max(1,n), dead:dead/Math.max(1,n), forced:forced/Math.max(1,n), hist, entropy:H, states:n};
}
function tensionBucket(delta){
  if(delta<=-0.15) return 0;
  if(delta<=-0.05) return 1;
  if(delta<= 0.05) return 2;
  if(delta<= 0.15) return 3;
  return 4;
}
