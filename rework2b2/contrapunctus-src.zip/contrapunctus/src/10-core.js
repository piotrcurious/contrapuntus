/* =====================================================================
   1 · THEORY CORE
   ===================================================================== */
const NOTE_NAMES = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];

const SCALES = {
  Ionian:[0,2,4,5,7,9,11], Dorian:[0,2,3,5,7,9,10], Phrygian:[0,1,3,5,7,8,10],
  Lydian:[0,2,4,6,7,9,11], Mixolydian:[0,2,4,5,7,9,10], Aeolian:[0,2,3,5,7,8,10],
  Locrian:[0,1,3,5,6,8,10], HarmonicMinor:[0,2,3,5,7,8,11], MelodicMinor:[0,2,3,5,7,9,11],
  WholeTone:[0,2,4,6,8,10], OctatonicHW:[0,1,3,4,6,7,9,10], OctatonicWH:[0,2,3,5,6,8,9,11],
  MajorPentatonic:[0,2,4,7,9], MinorPentatonic:[0,3,5,7,10], Blues:[0,3,5,6,7,10],
};
const SCALE_LABELS = {
  Ionian:'Ionian (major)', Dorian:'Dorian', Phrygian:'Phrygian', Lydian:'Lydian',
  Mixolydian:'Mixolydian', Aeolian:'Aeolian (minor)', Locrian:'Locrian',
  HarmonicMinor:'Harmonic minor', MelodicMinor:'Melodic minor', WholeTone:'Whole tone',
  OctatonicHW:'Octatonic (H–W)', OctatonicWH:'Octatonic (W–H)',
  MajorPentatonic:'Major pentatonic', MinorPentatonic:'Minor pentatonic', Blues:'Blues',
};
const SCALE_ORDER = Object.keys(SCALES);

const CHORD_TEMPLATES = {
  '0':'1','0,7':'5','0,4,7':'maj','0,3,7':'min','0,3,6':'dim','0,4,8':'aug',
  '0,2,7':'sus2','0,5,7':'sus4','0,4,7,11':'maj7','0,4,7,10':'dom7','0,3,7,10':'min7',
  '0,3,6,10':'m7b5','0,3,6,9':'dim7','0,3,7,11':'minMaj7','0,4,8,10':'aug7','0,4,8,11':'augMaj7',
  '0,2,4,7':'add9',
};
const ROMAN = ['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'];

function midiToFreq(m){ return 440*Math.pow(2,(m-69)/12); }
function midiName(m){ const pc=((Math.round(m)%12)+12)%12; return NOTE_NAMES[pc]+(Math.floor(m/12)-1); }
function pcOf(x){ return ((Math.round(x)%12)+12)%12; }
function clamp01(x){ return x<0?0:x>1?1:x; }
function ic(x){ const s=((Math.round(x)%12)+12)%12; return Math.min(s,12-s); }

const CONSONANCE_BY_IC = [1.0,0.05,0.25,0.65,0.75,0.9,0.15];
const CONSONANT_ICS = new Set([0,3,4,5]);

function chordTension(tones){
  const pcs=[...new Set(tones.map(pcOf))];
  if(pcs.length<2) return 0;
  let sum=0,n=0;
  for(let i=0;i<pcs.length;i++) for(let j=i+1;j<pcs.length;j++){ sum += 1-CONSONANCE_BY_IC[ic(pcs[j]-pcs[i])]; n++; }
  return sum/n;
}
function chordQuality(tones){
  const root=tones[0];
  const iv=[...new Set(tones.map(t=>((t-root+120)%12)))].sort((a,b)=>a-b);
  return CHORD_TEMPLATES[iv.join(',')] || 'other';
}
function romanNumeral(degree, quality){
  if(degree<0) return '?';
  const b = ROMAN[degree] || ('d'+degree);
  switch(quality){
    case 'dim': return b.toLowerCase()+'\u00b0';
    case 'dim7': return b.toLowerCase()+'\u00b07';
    case 'm7b5': return b.toLowerCase()+'\u00f87';
    case 'min': return b.toLowerCase();
    case 'min7': return b.toLowerCase()+'7';
    case 'minMaj7': return b.toLowerCase()+'\u25b37';
    case 'maj7': return b+'\u25b37';
    case 'dom7': return b+'7';
    case 'aug': case 'aug7': case 'augMaj7': return b+'+';
    case 'sus2': return b+'sus2';
    case 'sus4': return b+'sus4';
    case '5': return b+'5';
    case '1': return b;
    default: return b+'*';
  }
}
function annotate(c){
  c.quality = chordQuality(c.tones);
  if(c.applied==='dom') c.roman = 'V7/'+c.of;
  else if(c.applied==='lt') c.roman = 'vii\u00b07/'+c.of;
  else c.roman = romanNumeral(c.degree, c.quality);
  c.tensionVal = chordTension(c.tones);
  c.key = c.rootPc+':'+c.quality+':'+(c.applied||'-');
  return c;
}
function buildDiatonic(rootPc, steps, size){
  size = size||4;
  const n=steps.length, out=[];
  for(let deg=0;deg<n;deg++){
    const tones=[];
    for(let k=0;k<size;k++) tones.push((rootPc+steps[(deg+2*k)%n])%12);
    const uniq=[...new Set(tones)];
    out.push(annotate({degree:deg, rootPc:uniq[0], tones:uniq, ring:0}));
  }
  return out;
}
function buildExtended(rootPc, steps){
  const dia = buildDiatonic(rootPc, steps);
  const out = dia.slice(), seen = new Set(dia.map(c=>c.key));
  const add = (c)=>{ if(!seen.has(c.key)){ seen.add(c.key); out.push(c); } };
  for(const t of dia){
    if(t.degree!==0){
      const r=(t.rootPc+7)%12;
      add(annotate({degree:-1, rootPc:r, tones:[r,(r+4)%12,(r+7)%12,(r+10)%12], applied:'dom', of:t.roman, ring:1}));
    }
    const l=(t.rootPc+11)%12;
    add(annotate({degree:-1, rootPc:l, tones:[l,(l+3)%12,(l+6)%12,(l+9)%12], applied:'lt', of:t.roman, ring:2}));
  }
  out.forEach((c,i)=>{ c.idx=i; if(c.ring==null) c.ring=0; });
  return out;
}
const VOCAB_CACHE = new Map();
function vocabularyFor(rootPc, steps, extended){
  const k = rootPc+':'+steps.join(',')+':'+(extended?1:0);
  let v = VOCAB_CACHE.get(k);
  if(!v){
    v = extended ? buildExtended(rootPc, steps) : buildDiatonic(rootPc, steps);
    v.forEach((c,i)=>{ c.idx=i; });
    VOCAB_CACHE.set(k,v);
  }
  return v;
}
function voiceLeadingDistance(a, b){
  const A=[...new Set(a.map(pcOf))], B=[...new Set(b.map(pcOf))];
  let t=0;
  for(const x of A){ let best=12; for(const y of B){ const d=ic(x-y); if(d<best) best=d; } t+=best; }
  return t;
}
// How far the root falls going from chord A to chord B, in semitones mod 12.
// 7 is the classic descending fifth (V-I, ii-V), 3 is I-vi, 10 is a step up (IV-V).
// (The first version called this "directed fifths" and labelled it "in fifths"; it never was.)
function rootFall(rootA, rootB){ return ((rootA-rootB)+12)%12; }
// Position of a root-fall value around a circle of fifths: consecutive positions differ
// by a fifth, so a ring laid out in this order really is the circle of fifths.
function fifthsPos(d){ return (7*d)%12; }

/* ---- tunings ---------------------------------------------------------------
   The engine thinks in twelve pitch classes. A tuning says how far each of them sits from
   its equal-tempered pitch, in cents, so a note is a whole number (what the rules see) plus
   a small offset (what you hear). Offsets that are measured from the root follow the root
   around; a well temperament is fixed to C, because the unevenness between keys is the
   point of one. The sounding pitch of a note is therefore fractional, which is what the
   audio engine plays and what the MIDI export has to encode (as pitch bend). */
function ratioCents(n,d){ return 1200*Math.log2(n/d); }
function fifthChain(fifth){            // twelve notes from a chain of equal fifths, wolf above the sixth step
  const o=[];
  for(let k=0;k<12;k++){
    let j=(7*k)%12; if(j>8) j-=12;     // position on the chain, -3 .. 8 fifths from the root
    const c=((j*fifth)%1200+1200)%1200;
    o.push(c-100*k);
  }
  return o.map(x=>Math.abs(x)>600 ? x-1200*Math.sign(x) : x);
}
const TUNINGS = {
  equal:       {label:'Equal temperament',            fixed:false, cents:new Array(12).fill(0)},
  just:        {label:'Just intonation, 5-limit',     fixed:false,
                cents:[[1,1],[16,15],[9,8],[6,5],[5,4],[4,3],[45,32],[3,2],[8,5],[5,3],[9,5],[15,8]].map((r,k)=>ratioCents(r[0],r[1])-100*k)},
  pythagorean: {label:'Pythagorean',                  fixed:false, cents:fifthChain(ratioCents(3,2))},
  meantone:    {label:'Quarter-comma meantone',       fixed:false, cents:fifthChain(1200*Math.log2(5)/4)},
  werckmeister:{label:'Werckmeister III (from C)',    fixed:true,
                cents:[0,90.225,192.18,294.135,390.225,498.045,588.27,696.09,792.18,888.27,996.09,1092.18].map((c,k)=>c-100*k)},
};
const TUNING_ORDER = ['equal','just','pythagorean','meantone','werckmeister'];
// the offset, in cents, of a pitch class under the tuning in force (the root matters for the relative ones)
function tuningCents(pc, tuning, root){
  const T=TUNINGS[tuning==null?STATE.tuning:tuning]||TUNINGS.equal, r=root==null?STATE.root:root;
  return T.fixed ? T.cents[((pc%12)+12)%12] : T.cents[(((pc-r)%12)+12)%12];
}
// the pitch a whole-number note actually sounds at, as a fractional MIDI note number
function soundingPitch(m){ return m + tuningCents(pcOf(m))/100; }

/* =====================================================================
   2 · STATE
   ===================================================================== */
const REGISTERS = [{lo:60,hi:84},{lo:48,hi:72},{lo:36,hi:60}];
const VOICE_NAMES = ['melody','middle','bass'];

// Cost surfaces are separable: cost(cell) = sum over axes of w * (1 - affinity[value]).
// Defaults reproduce the classical ranking the first version hard-coded, but every
// number here is now a handle rather than a constant.
const FUNCTIONAL_RANK = [3,7,6,1,1,4,7,0,5,5,2,7]; // by root fall d (semitones), 0 = strongest
const DEF_AFF_D = FUNCTIONAL_RANK.map(r=>1-r/7);

const CHORD_AXES = [
  {key:'d',    n:12, label:'d',   what:'root fall, in semitones', tick:i=>String(i), ringOrder:fifthsPos},
  {key:'tau',  n:5,  label:'\u03c4', what:'tension against the aim', tick:i=>['--','-','0','+','++'][i]},
  {key:'rho',  n:3,  label:'\u03c1', what:'kind of chord', tick:i=>['dia','V7','vii\u00b0'][i]},
  {key:'eta',  n:3,  label:'\u03b7', what:'momentum coming in', tick:i=>['weak','mid','str'][i]},
];
const VOICE_AXES = [
  {key:'kappa',n:3, label:'\u03ba', what:'voices it agrees with', tick:i=>String(i)},
  {key:'mu',   n:5, label:'\u03bc', what:'its own leap or step',  tick:i=>['\u2193\u2193','\u2193','=','\u2191','\u2191\u2191'][i]},
  {key:'phi',  n:3, label:'\u03c6', what:'chromatic / scale / chord tone', tick:i=>['chr','scl','chd'][i]},
  {key:'sigma',n:2, label:'\u03c3', what:'structural or passing', tick:i=>['struct','pass'][i]},
  {key:'gamma',n:3, label:'\u03b3', what:'against the other voices', tick:i=>['sim','obl','con'][i]},
];
function axisDims(axes){ return axes.map(a=>a.n); }
function axisStrides(dims){
  const s=new Array(dims.length); let acc=1;
  for(let i=dims.length-1;i>=0;i--){ s[i]=acc; acc*=dims[i]; }
  return {strides:s, size:acc};
}
const CHORD_DIMS = axisDims(CHORD_AXES), CHORD_STR = axisStrides(CHORD_DIMS);
const VOICE_DIMS = axisDims(VOICE_AXES), VOICE_STR = axisStrides(VOICE_DIMS);

function defaultProfiles(){
  return {
    chord:{
      d:    {w:1.00, aff:DEF_AFF_D.slice()},
      tau:  {w:0.45, aff:[0,0.5,1,0.5,0]},
      rho:  {w:0.45, aff:[1,0.5,0]},
      eta:  {w:0.25, aff:[0.5,1,0.5]},
    },
    voice:{
      kappa:{w:0.45, aff:[0,0.5,1]},
      mu:   {w:0.35, aff:[0,0.5,1,0.5,0]},
      phi:  {w:1.00, aff:[0,0.5,1]},
      sigma:{w:0.20, aff:[1,0.55]},
      gamma:{w:0.30, aff:[0,0.5,1]},
    },
  };
}
function defaultVoiceEnv(v){
  return [
    {a:0.010, d:0.085, s:0.55, r:0.30, gateRatio:0.92},
    {a:0.022, d:0.120, s:0.66, r:0.42, gateRatio:0.98},
    {a:0.016, d:0.160, s:0.72, r:0.55, gateRatio:0.90},
  ][v];
}

const STATE = {
  root:0, scaleName:'Ionian',
  bars:8, stepsPerBar:8, lastStepsPerBar:8, harmonic:'bar',
  tempo:96, tension:0.30,
  lamC:0.38, lamV:0.46,
  profiles: defaultProfiles(),
  cellFlips:{ chord:{}, voice:{} },   // "i0,i1,.." -> 0|1
  extended:false, walkingBass:false, arp:'none',
  take:'bold',   // which legal move to take: smooth | strong | bold
  tuning:'equal',// how the twelve pitch classes are tuned: see TUNINGS
  seed:{ chordIdx:0, eta:1, prev2Idx:-1, voice:[null,null,null] },
  anchors:{},                          // step -> midi (melody)
  pins:{},                             // segIdx -> chord.key
  barOverrides:{},                     // bar -> {scale?, tension?}
  touched:[false,false,false],         // a lane the composer has painted stops following the defaults
  onsets:null,
  voiceEnv:[defaultVoiceEnv(0), defaultVoiceEnv(1), defaultVoiceEnv(2)],
  noteEnv:{},                          // "v:step" -> partial env
  selectedNote:null,                   // {v, step}
  selectedSeg:1, selectedBar:null, lane:'all',
  show:{ tails:true, ghosts:true, sounding:false },
  lattice:{ set:'chord' },
  life:{w:18,h:10,grid:null},
  composed:null,
  audio:null, playing:false, step:0, stepFloat:0, nextTime:0, startTime:0, timer:null, raf:null,
};

// How the rule table is laid out on screen. 'grid' and 'hyper' are linear: every axis owns a
// direction (a basis vector) that you can drag, and a cell sits at the sum of its coordinates'
// vectors; an axis can also be wrapped into a ring. 'cycle' and 'cost' are not linear: the first
// puts the root fall d on a circle of fifths with tension as the radius, the second puts every
// cell at its cost, so the legal set is everything left of a vertical line.
// The grid presets nest the axes like digits of a number, so no two cells ever coincide; the
// oblique ones were found by search for the arrangement that keeps all cells apart while giving
// every axis a long enough reach to read.
const PROJ = {
  chord:{ preset:'grid', basis:{d:[46,0], tau:[0,-64], rho:[14,0], eta:[0,13]}, cyclic:{}, rows:'d' },
  voice:{ preset:'grid', basis:{kappa:[200,0], mu:[0,-80], phi:[60,0], sigma:[0,-30], gamma:[20,0]}, cyclic:{}, rows:'mu' },
};
const PROJ_BASES = {
  chord:{ grid:{d:[46,0], tau:[0,-64], rho:[14,0], eta:[0,13]},
          hyper:{d:[-9,-5], tau:[19,0], rho:[-98,3], eta:[-11,72]} },
  voice:{ grid:{kappa:[200,0], mu:[0,-80], phi:[60,0], sigma:[0,-30], gamma:[20,0]},
          hyper:{kappa:[-42,-47], mu:[-24,-50], phi:[-16,-34], sigma:[-240,-44], gamma:[56,-8]} },
};
