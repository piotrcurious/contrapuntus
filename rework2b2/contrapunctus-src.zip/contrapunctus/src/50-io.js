/* =====================================================================
   12 · KEEPING THE PIECE
   ---------------------------------------------------------------------
   state  <->  a plain object  <->  a code you can paste, a file, this browser
   piece  ->   a standard MIDI file (format 1), zipped where the host only
               accepts certain extensions

   Everything that comes back in through restoreState() is checked and
   clamped before any of it is applied, so a damaged or hostile code
   cannot leave the instrument half-loaded.
   ===================================================================== */

/* ---- small validators ------------------------------------------------------ */
function vNum(raw, lo, hi, d){ return (typeof raw==='number' && isFinite(raw)) ? Math.min(hi, Math.max(lo, raw)) : d; }
function vInt(raw, lo, hi, d){ const x=vNum(raw, lo, hi, d); return x===null ? null : Math.round(x); }
function vChoice(raw, list, d){ if(typeof raw!=='number'||!isFinite(raw)) return d; let best=list[0]; for(const x of list) if(Math.abs(x-raw)<Math.abs(best-raw)) best=x; return best; }
function vBool(raw, d){ return typeof raw==='boolean' ? raw : d; }
function vEnum(raw, list, d){ return (typeof raw==='string' && list.indexOf(raw)>=0) ? raw : d; }
function isPlain(o){ return o!==null && typeof o==='object' && !Array.isArray(o); }
function r3(x){ return Math.round(x*1000)/1000; }
function r4(x){ return Math.round(x*10000)/10000; }

const ENV_LIMITS = { a:[0.001,2], d:[0.001,3], s:[0,1], r:[0.005,8], gate:[0.03,64], gateRatio:[0.02,3] };
const PIN_RE  = /^(?:\d|1[01]):[A-Za-z0-9]{1,10}:(?:dom|lt|-)$/;
const FLIP_RE = /^\d{1,2}(?:,\d{1,2}){2,4}$/;
const NOTE_RE = /^[0-2]:\d{1,4}$/;

/* ---- state <-> object ---------------------------------------------------------- */
function serializeState(opts){
  opts = opts||{};
  const prof={chord:{}, voice:{}};
  for(const set of ['chord','voice']){
    const axes = set==='chord'?CHORD_AXES:VOICE_AXES;
    for(const a of axes){ const p=STATE.profiles[set][a.key]; prof[set][a.key]={w:r3(p.w), aff:p.aff.map(r3)}; }
  }
  const o = {
    app:'contrapunctus', v:1,
    root:STATE.root, scale:STATE.scaleName, bars:STATE.bars, stepsPerBar:STATE.stepsPerBar, harmonic:STATE.harmonic,
    tempo:STATE.tempo, tension:r4(STATE.tension), lamC:r4(STATE.lamC), lamV:r4(STATE.lamV), take:STATE.take,
    extended:!!STATE.extended, walkingBass:!!STATE.walkingBass, arp:STATE.arp, tuning:STATE.tuning,
    profiles:prof,
    cellFlips:{chord:sortedCopy(STATE.cellFlips.chord), voice:sortedCopy(STATE.cellFlips.voice)},
    seed:{chordIdx:STATE.seed.chordIdx, eta:STATE.seed.eta, prev2Idx:STATE.seed.prev2Idx, voice:STATE.seed.voice.slice()},
    anchors:Object.assign({},STATE.anchors), pins:Object.assign({},STATE.pins),
    barOverrides:canonOverrides(STATE.barOverrides),
    touched:STATE.touched.slice(),
    onsets:STATE.touched.map((t,v)=> t && STATE.onsets ? STATE.onsets[v].map(b=>b?1:0).join('') : null),
    voiceEnv:STATE.voiceEnv.map(e=>({a:r4(e.a), d:r4(e.d), s:r4(e.s), r:r4(e.r), gateRatio:r4(e.gateRatio)})),
    noteEnv:canonNoteEnv(STATE.noteEnv),
  };
  if(opts.view){
    o.view = { set:STATE.lattice.set, show:Object.assign({},STATE.show),
      proj:{chord:JSON.parse(JSON.stringify(PROJ.chord)), voice:JSON.parse(JSON.stringify(PROJ.voice))} };
  }
  return o;
}
function sortedCopy(src){ const o={}; for(const k of Object.keys(src).sort()) o[k]=src[k]; return o; }
function canonOverrides(src){
  const o={}; for(const k of Object.keys(src).sort((a,b)=>a-b)){ const s=src[k], d={}; if(s.scale) d.scale=s.scale; if(typeof s.tension==='number') d.tension=r4(s.tension); if(d.scale||d.tension!==undefined) o[k]=d; }
  return o;
}
function canonNoteEnv(src){
  const keys=Object.keys(src).sort((a,b)=>{ const [v1,s1]=a.split(':').map(Number), [v2,s2]=b.split(':').map(Number); return (v1-v2)||(s1-s2); });
  const o={}; for(const k of keys){ const s=src[k], d={}; for(const f of ['a','d','s','r','gate']) if(typeof s[f]==='number') d[f]=r4(s[f]); if(Object.keys(d).length) o[k]=d; }
  return o;
}
function snapshot(){ return JSON.stringify(serializeState()); }

// Returns {ok:true, warnings} after applying, or {ok:false, error} having changed nothing.
function restoreState(o){
  if(!isPlain(o)) return {ok:false, error:'this is not a Contrapunctus state'};
  if(o.app!=='contrapunctus') return {ok:false, error:'this is not a Contrapunctus state'};
  if(o.v!==1) return {ok:false, error:'this state is from a version this page does not know'};
  const warn=[], N={};
  N.root = vInt(o.root,0,11,0);
  N.scaleName = vEnum(o.scale, SCALE_ORDER, 'Ionian');
  N.bars = vChoice(o.bars,[4,8,12,16],8);
  N.stepsPerBar = vChoice(o.stepsPerBar,[4,8,16],8);
  N.harmonic = vEnum(o.harmonic, ['bar','half'], 'bar');
  N.tempo = vInt(o.tempo,40,200,96);
  N.tension = vNum(o.tension,0,1,0.3); N.lamC=vNum(o.lamC,0,1,0.38); N.lamV=vNum(o.lamV,0,1,0.46);
  N.take = vEnum(o.take, ['smooth','strong','bold'], 'bold');
  N.extended = vBool(o.extended,false); N.walkingBass = vBool(o.walkingBass,false);
  N.arp = vEnum(o.arp, ['none','up','down','updown','downup','scramble'], 'none');
  N.tuning = vEnum(o.tuning, TUNING_ORDER, 'equal');
  const total = N.bars*N.stepsPerBar, segs = Math.ceil(total/(N.harmonic==='bar'?N.stepsPerBar:Math.max(1,Math.floor(N.stepsPerBar/2))));

  N.profiles = defaultProfiles();
  if(isPlain(o.profiles)) for(const set of ['chord','voice']){
    const axes = set==='chord'?CHORD_AXES:VOICE_AXES, src=o.profiles[set];
    if(!isPlain(src)) continue;
    for(const a of axes){
      const p=src[a.key]; if(!isPlain(p)) continue;
      const dst=N.profiles[set][a.key];
      dst.w = vNum(p.w,0,1.5,dst.w);
      if(Array.isArray(p.aff) && p.aff.length===a.n) dst.aff = p.aff.map((x,i)=>vNum(x,0,1,dst.aff[i]));
      else if(p.aff!==undefined) warn.push('profile '+a.key+' ignored');
    }
  }
  N.cellFlips={chord:{}, voice:{}};
  if(isPlain(o.cellFlips)) for(const set of ['chord','voice']){
    const dims = set==='chord'?CHORD_DIMS:VOICE_DIMS, src=o.cellFlips[set]; if(!isPlain(src)) continue;
    let n=0;
    for(const k of Object.keys(src)){
      if(!FLIP_RE.test(k) || (src[k]!==0 && src[k]!==1)){ continue; }
      const c=k.split(',').map(Number);
      if(c.length!==dims.length || c.some((x,i)=>x>=dims[i])) continue;
      if(++n>dims.reduce((a,b)=>a*b,1)) break;
      N.cellFlips[set][k]=src[k];
    }
  }
  const sd = isPlain(o.seed)?o.seed:{};
  N.seed={ chordIdx:vInt(sd.chordIdx,0,63,0), eta:vInt(sd.eta,0,2,1), prev2Idx:vInt(sd.prev2Idx,-1,63,-1),
           voice:[0,1,2].map(i=> Array.isArray(sd.voice) ? (typeof sd.voice[i]==='number' ? vInt(sd.voice[i],21,108,null) : null) : null) };
  N.anchors={};
  if(isPlain(o.anchors)){ let n=0; for(const k of Object.keys(o.anchors)){
    const m=o.anchors[k];
    if(!/^\d{1,4}$/.test(k) || +k>=total || !Number.isInteger(m) || m<21 || m>108) continue;
    if(++n>512) break; N.anchors[k]=m; } }
  N.pins={};
  if(isPlain(o.pins)) for(const k of Object.keys(o.pins)){
    if(!/^\d{1,3}$/.test(k) || +k>=segs || typeof o.pins[k]!=='string' || !PIN_RE.test(o.pins[k])) continue;
    N.pins[k]=o.pins[k];
  }
  N.barOverrides={};
  if(isPlain(o.barOverrides)) for(const k of Object.keys(o.barOverrides)){
    if(!/^\d{1,2}$/.test(k) || +k>=N.bars || !isPlain(o.barOverrides[k])) continue;
    const s=o.barOverrides[k], d={};
    if(typeof s.scale==='string' && SCALES[s.scale] && Object.prototype.hasOwnProperty.call(SCALES,s.scale)) d.scale=s.scale;
    if(typeof s.tension==='number') d.tension=vNum(s.tension,0,1,N.tension);
    if(d.scale||d.tension!==undefined) N.barOverrides[k]=d;
  }
  N.touched=[0,1,2].map(v=>Array.isArray(o.touched) && o.touched[v]===true);
  N.onsets=[0,1,2].map(v=>{
    const def=defaultOnsets(v,total,N.stepsPerBar,N.harmonic,N.walkingBass);
    const src=Array.isArray(o.onsets)?o.onsets[v]:null;
    if(N.touched[v] && typeof src==='string' && src.length===total && /^[01]+$/.test(src)) return Array.from(src,ch=>ch==='1');
    N.touched[v]=false; return def;
  });
  N.voiceEnv=[0,1,2].map(v=>{
    const d=defaultVoiceEnv(v), s=Array.isArray(o.voiceEnv)&&isPlain(o.voiceEnv[v])?o.voiceEnv[v]:{};
    const L=ENV_LIMITS;
    return {a:vNum(s.a,L.a[0],L.a[1],d.a), d:vNum(s.d,L.d[0],L.d[1],d.d), s:vNum(s.s,L.s[0],L.s[1],d.s),
            r:vNum(s.r,L.r[0],L.r[1],d.r), gateRatio:vNum(s.gateRatio,L.gateRatio[0],L.gateRatio[1],d.gateRatio)};
  });
  N.noteEnv={};
  if(isPlain(o.noteEnv)){ let n=0; for(const k of Object.keys(o.noteEnv)){
    if(!NOTE_RE.test(k) || !isPlain(o.noteEnv[k])) continue;
    const st=+k.split(':')[1]; if(st>=total) continue;
    const s=o.noteEnv[k], d={};
    for(const f of ['a','d','s','r','gate']){ const x=s[f]; if(typeof x==='number' && isFinite(x) && x>=ENV_LIMITS[f][0] && x<=ENV_LIMITS[f][1]) d[f]=x; }
    if(Object.keys(d).length){ if(++n>1024) break; N.noteEnv[k]=d; }
  } }
  // the view (projection, which table, toggles) is optional and never blocks a load
  let view=null;
  if(isPlain(o.view)){
    view={set:vEnum(o.view.set,['chord','voice'],'chord'), show:{}, proj:{}};
    for(const k of ['tails','ghosts','sounding']) view.show[k]=isPlain(o.view.show)?vBool(o.view.show[k],STATE.show[k]):STATE.show[k];
    for(const set of ['chord','voice']){
      const src=isPlain(o.view.proj)?o.view.proj[set]:null; if(!isPlain(src)) continue;
      const axes=set==='chord'?CHORD_AXES:VOICE_AXES, P={basis:{}, cyclic:{}};
      P.preset=vEnum(src.preset, set==='chord'?['grid','hyper','cycle','cost']:['grid','hyper','cost'], 'grid');
      let okBasis=isPlain(src.basis);
      if(okBasis) for(const a of axes){
        const b=src.basis[a.key];
        if(!Array.isArray(b)||b.length!==2||!isFinite(b[0])||!isFinite(b[1])||typeof b[0]!=='number'||typeof b[1]!=='number'){ okBasis=false; break; }
        P.basis[a.key]=[vNum(b[0],-3000,3000,0), vNum(b[1],-3000,3000,0)];
        if(isPlain(src.cyclic) && src.cyclic[a.key]===true) P.cyclic[a.key]=true;
      }
      if(!okBasis) continue;
      P.rows = typeof src.rows==='string' && axes.some(a=>a.key===src.rows) ? src.rows : '';
      view.proj[set]=P;
    }
  }
  // all checks passed: apply in one go
  STATE.root=N.root; STATE.scaleName=N.scaleName; STATE.bars=N.bars; STATE.stepsPerBar=N.stepsPerBar; STATE.lastStepsPerBar=N.stepsPerBar;
  STATE.harmonic=N.harmonic; STATE.tempo=N.tempo; STATE.tension=N.tension; STATE.lamC=N.lamC; STATE.lamV=N.lamV; STATE.take=N.take;
  STATE.extended=N.extended; STATE.walkingBass=N.walkingBass; STATE.arp=N.arp; STATE.tuning=N.tuning;
  STATE.profiles=N.profiles; STATE.cellFlips=N.cellFlips; STATE.seed=N.seed; STATE.anchors=N.anchors; STATE.pins=N.pins;
  STATE.barOverrides=N.barOverrides; STATE.touched=N.touched; STATE.onsets=N.onsets; STATE.voiceEnv=N.voiceEnv; STATE.noteEnv=N.noteEnv;
  STATE.selectedNote=null; STATE.selectedBar=null; STATE.selectedSeg=1; STATE.composed=null;
  if(view){
    STATE.lattice.set=view.set; Object.assign(STATE.show, view.show);
    for(const set of Object.keys(view.proj)) PROJ[set]=view.proj[set];
  }
  return {ok:true, warnings:warn};
}

/* ---- a code you can paste:  CP1.<base64url of the JSON>.<checksum> ------------------- */
function b64uEncode(u8){
  let s=''; for(let i=0;i<u8.length;i+=0x8000) s+=String.fromCharCode.apply(null, u8.subarray(i,i+0x8000));
  return btoa(s).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
}
function b64uDecode(str){
  str=str.replace(/-/g,'+').replace(/_/g,'/'); while(str.length%4) str+='=';
  const s=atob(str), u=new Uint8Array(s.length); for(let i=0;i<s.length;i++) u[i]=s.charCodeAt(i); return u;
}
function fnv1a(u8){ let h=0x811c9dc5; for(let i=0;i<u8.length;i++){ h^=u8[i]; h=Math.imul(h,16777619)>>>0; } return h>>>0; }
function hex8(n){ return ('00000000'+(n>>>0).toString(16)).slice(-8); }
function stateToCode(){
  const bytes=new TextEncoder().encode(JSON.stringify(serializeState({view:true})));
  return 'CP1.'+b64uEncode(bytes)+'.'+hex8(fnv1a(bytes));
}
// accepts a code, or the JSON of a saved state; returns {obj} or {error}
function parseStateText(text){
  text=String(text==null?'':text).trim();
  if(text.length>600000) return {error:'that is far too long to be a state'};
  try{
    if(text.charAt(0)==='{') return {obj:JSON.parse(text)};
    const m=/^CP1\.([A-Za-z0-9_-]+)\.([0-9a-f]{8})$/.exec(text.replace(/\s+/g,''));
    if(!m) return {error:'this is not a Contrapunctus code'};
    const bytes=b64uDecode(m[1]);
    if(hex8(fnv1a(bytes))!==m[2]) return {error:'the code is damaged or has been cut short'};
    return {obj:JSON.parse(new TextDecoder().decode(bytes))};
  }catch(e){ return {error:'this is not a Contrapunctus code'}; }
}

/* ---- this browser ------------------------------------------------------------------- */
const AUTOSAVE_KEY='contrapunctus.state.1';
let AUTOSAVE_T=null;
function autosaveSoon(){
  clearTimeout(AUTOSAVE_T);
  AUTOSAVE_T=setTimeout(()=>{ try{ localStorage.setItem(AUTOSAVE_KEY, JSON.stringify(serializeState({view:true}))); }catch(e){} }, 500);
}
function loadAutosave(){
  try{
    const raw=localStorage.getItem(AUTOSAVE_KEY); if(!raw) return false;
    const r=restoreState(JSON.parse(raw)); return r.ok;
  }catch(e){ return false; }
}
function clearAutosave(){ try{ localStorage.removeItem(AUTOSAVE_KEY); }catch(e){} }

/* =====================================================================
   MIDI
   ---------------------------------------------------------------------
   Standard file, format 1: a conductor track (tempo, 4/4, one marker per
   chord) and one track per voice. A step is 1920/stepsPerBar ticks at 480
   per quarter note, so every grid lands on whole ticks. A note is on for its
   gate; the release is the receiving instrument's business, so a long
   gate that runs into the next note is a held note that overlaps it.

   Microtonal pitch. The twelve-tone numbering of MIDI has no room for a
   pitch between two keys, so a note under a tuning is sent as the nearest
   key plus a pitch bend, the simplest of the usual methods. The bend is a
   property of the CHANNEL, not of the note, and that is where the trouble is:
     - a bend change moves every note still sounding on that channel, release
       tails included, so a new note with a different bend must not share a
       channel with one that is still ringing;
     - two notes of one voice that overlap need different channels anyway,
       when their bends differ;
     - the receiving instrument must use the bend range we assume, +-2
       semitones, which is the default and which we also set with RPN 0.
   So each voice gets a small pool of channels. A note takes a channel that is
   already at its bend (nothing to send); failing that, one whose last note and
   its release have finished; failing that, the one that frees up soonest, and
   that last case is counted and reported. Channel 10 is left alone. A file in
   equal temperament uses one channel per voice and no bend at all.
   ===================================================================== */
const MIDI = { PPQ:480, RANGE:2, CENTRE:8192, PER_SEMI:4096, VEL:[96,80,92],
  POOLS:[[0,3,4,5,6],[1,7,8,10,11],[2,12,13,14,15]] };

function midiVlq(n){ const o=[n&0x7f]; n>>>=7; while(n>0){ o.unshift((n&0x7f)|0x80); n>>>=7; } return o; }
function midiAscii(s){ return Array.from(String(s), ch=>{ const k=ch.charCodeAt(0); return (k>=32&&k<127)?k:63; }); }
function midiMeta(type, text){ const b=midiAscii(text); return [0xFF, type].concat(midiVlq(b.length), b); }
function romanAscii(r){ return String(r).replace(/△/g,'maj').replace(/°/g,'dim').replace(/ø/g,'hdim'); }
function u32be(n){ return [(n>>>24)&255,(n>>>16)&255,(n>>>8)&255,n&255]; }
function u16be(n){ return [(n>>>8)&255, n&255]; }
function keySignature(){          // only the two modes that have one
  const m = STATE.scaleName==='Ionian' ? 0 : STATE.scaleName==='Aeolian' ? 1 : -1; if(m<0) return null;
  const major=[0,-5,2,-3,4,-1,6,1,-4,3,-2,5];                  // sharps (+) or flats (-) of the major key on each pitch class
  const sf = m===0 ? major[STATE.root] : major[(STATE.root+3)%12];
  return [0xFF,0x59,2,(sf+256)&255,m];
}
// fractional key number -> {key, bend}, the bend as a 14-bit value
function midiKeyBend(fp){
  let key=Math.round(fp); key=Math.max(0,Math.min(127,key));
  const bend=Math.max(0,Math.min(16383, MIDI.CENTRE+Math.round((fp-key)*MIDI.PER_SEMI)));
  return {key, bend};
}
function midiBendBytes(ch, bend){ return [0xE0|ch, bend&0x7f, (bend>>7)&0x7f]; }

// choose a channel for every note of one voice and list the events (without the setup)
function planVoice(v, notes, tps){
  const pool=MIDI.POOLS[v].map(ch=>({ch, bend:MIDI.CENTRE, busy:-1, held:new Map(), used:false}));
  const ev=[]; let bent=0, glitches=0, maxCents=0;
  for(const nt of notes){
    const start=Math.round(nt.step*tps), dur=Math.max(1,Math.round(nt.e.gate*tps)), tail=Math.round(nt.tailSteps*tps);
    const kb=midiKeyBend(nt.fpitch);
    if(kb.bend!==MIDI.CENTRE){ bent++; maxCents=Math.max(maxCents, Math.abs(nt.fpitch-kb.key)*100); }
    let same=null, free=null, soon=null, clash=null;
    for(const s of pool){
      const held=s.held.get(kb.key);
      if(held && held.tick>start){ if(!clash || held.tick<clash.held.tick) clash=Object.assign({}, s, {held}); continue; }
      if(s.bend===kb.bend){ if(!same) same=s; }
      else if(s.busy<=start){ if(!free) free=s; }
      if(!soon || s.busy<soon.busy) soon=s;
    }
    let s=same||free||soon, forced=false;
    if(!s){ s=pool.find(x=>x.ch===clash.ch); forced=true; }
    if(forced){ const prev=s.held.get(kb.key); prev.tick=Math.min(prev.tick,start); }
    if(s.bend!==kb.bend){
      if(s.busy>start) glitches++;          // a note on this channel is still releasing and will be bent
      ev.push({tick:start, ord:2, b:midiBendBytes(s.ch, kb.bend)});
      s.bend=kb.bend;
    }
    let vel=MIDI.VEL[v]; if(nt.deco) vel-=12; if(nt.fell) vel-=8; vel=Math.max(1,Math.min(127,vel));
    const off={tick:start+dur, ord:1, b:[0x80|s.ch, kb.key, 0]};
    ev.push({tick:start, ord:3, b:[0x90|s.ch, kb.key, vel]}, off);
    s.held.set(kb.key, off);
    s.busy=Math.max(s.busy, start+dur+tail);
    s.used=true;
  }
  return {events:ev, channels:pool.filter(s=>s.used).map(s=>s.ch), bent, glitches, maxCents};
}

function encodeTrack(events, endTick){
  events.sort((x,y)=> (x.tick-y.tick) || (x.ord-y.ord) || ((x.seq||0)-(y.seq||0)));
  const out=[]; let last=0;
  for(const e of events){ out.push.apply(out, midiVlq(e.tick-last)); out.push.apply(out, e.b); last=e.tick; }
  out.push.apply(out, midiVlq(Math.max(0,endTick-last))); out.push(0xFF,0x2F,0);
  return [0x4D,0x54,0x72,0x6B].concat(u32be(out.length), out);
}

function buildMidi(c){
  c=c||STATE.composed; if(!c||!c.notes) return null;
  const spb=STATE.stepsPerBar, tps=(MIDI.PPQ*4)/spb, total=c.total, endTick=Math.round(total*tps);
  const plans=[0,1,2].map(v=>planVoice(v, c.notes[v], tps));
  const anyBend=plans.some(p=>p.bent>0);
  const tuning=TUNINGS[STATE.tuning]||TUNINGS.equal;

  const cond=[{tick:0,ord:-2,b:midiMeta(0x03,'Contrapunctus')}];
  cond.push({tick:0,ord:-2,b:[0xFF,0x58,4,4,2,24,8]});
  cond.push({tick:0,ord:-2,b:[0xFF,0x51,3].concat(u32be(Math.round(6e7/STATE.tempo)).slice(1))});
  const ks=keySignature(); if(ks) cond.push({tick:0,ord:-2,b:ks});
  cond.push({tick:0,ord:-1,b:midiMeta(0x01,'root '+NOTE_NAMES[STATE.root]+', '+STATE.scaleName+', tuning: '+tuning.label
    +(anyBend?'. Notes carry pitch bend, range +-2 semitones (RPN 0). Do not drop bend messages.':'')+'.')});
  for(let g=0; g<c.segments; g++) cond.push({tick:Math.round(g*c.L*tps), ord:0, b:midiMeta(0x06, romanAscii(c.chords[g].roman))});
  const tracks=[encodeTrack(cond,endTick)];

  let ends=endTick;
  for(let v=0; v<3; v++){
    const p=plans[v], ev=[{tick:0,ord:-3,b:midiMeta(0x03,VOICE_NAMES[v])}];
    if(anyBend){
      for(const ch of p.channels){                       // bend range = 2 semitones, then centre the bend
        for(const [cc,val] of [[101,0],[100,0],[6,MIDI.RANGE],[38,0],[101,127],[100,127]]) ev.push({tick:0,ord:-1,b:[0xB0|ch,cc,val]});
        ev.push({tick:0,ord:-1,b:midiBendBytes(ch, MIDI.CENTRE)});
      }
    }
    for(const e of p.events) if(e.tick>ends) ends=e.tick;
    tracks.push({ev:ev.concat(p.events)});
  }
  const bytes=[0x4D,0x54,0x68,0x64].concat(u32be(6), u16be(1), u16be(4), u16be(MIDI.PPQ));
  bytes.push.apply(bytes, tracks[0]);
  for(let v=0; v<3; v++) bytes.push.apply(bytes, encodeTrack(tracks[v+1].ev, ends));
  let n=0; for(let v=0;v<3;v++) n+=c.notes[v].length;
  return { bytes:Uint8Array.from(bytes),
    info:{ notes:n, bent:plans.reduce((a,p)=>a+p.bent,0), channels:plans.map(p=>p.channels.length), glitches:plans.reduce((a,p)=>a+p.glitches,0),
           maxCents:plans.reduce((a,p)=>Math.max(a,p.maxCents),0), ticks:ends, tuning:STATE.tuning, anyBend} };
}

/* ---- a store-only zip, for hosts that accept a .zip and not a .mid ----------------------- */
const CRC_TABLE=(()=>{ const t=new Uint32Array(256); for(let n=0;n<256;n++){ let c=n; for(let k=0;k<8;k++) c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1); t[n]=c>>>0; } return t; })();
function crc32(u8){ let c=0xFFFFFFFF; for(let i=0;i<u8.length;i++) c=CRC_TABLE[(c^u8[i])&255]^(c>>>8); return (c^0xFFFFFFFF)>>>0; }
function le16(n){ return [n&255,(n>>>8)&255]; }
function le32(n){ return [n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]; }
function makeZip(files, when){
  const d=when||new Date(), enc=new TextEncoder();
  const dosTime=((d.getHours()<<11)|(d.getMinutes()<<5)|(d.getSeconds()>>1))&0xFFFF;
  const dosDate=(((Math.max(1980,d.getFullYear())-1980)<<9)|((d.getMonth()+1)<<5)|d.getDate())&0xFFFF;
  const parts=[], central=[]; let offset=0;
  for(const f of files){
    const name=enc.encode(f.name), data=f.data, crc=crc32(data);
    const head=[0x50,0x4B,3,4].concat(le16(20),le16(0x0800),le16(0),le16(dosTime),le16(dosDate),le32(crc),le32(data.length),le32(data.length),le16(name.length),le16(0));
    parts.push(Uint8Array.from(head), name, data);
    central.push(Uint8Array.from([0x50,0x4B,1,2].concat(le16(20),le16(20),le16(0x0800),le16(0),le16(dosTime),le16(dosDate),le32(crc),le32(data.length),le32(data.length),
      le16(name.length),le16(0),le16(0),le16(0),le16(0),le32(0),le32(offset))), name);
    offset+=head.length+name.length+data.length;
  }
  let cdSize=0; for(const p of central) cdSize+=p.length;
  const end=Uint8Array.from([0x50,0x4B,5,6].concat(le16(0),le16(0),le16(files.length),le16(files.length),le32(cdSize),le32(offset),le16(0)));
  const all=parts.concat(central,[end]); let n=0; for(const p of all) n+=p.length;
  const out=new Uint8Array(n); let o=0; for(const p of all){ out.set(p,o); o+=p.length; }
  return out;
}

/* ---- handing a file to the person ------------------------------------------------------- */
const IO = { dl:undefined, p:null };
// The viewer may answer after the page has started, and a late answer still counts, so the question is asked once
// and its answer kept; ioReady only limits how long a caller is willing to wait for it.
function ioStart(){
  if(IO.p) return IO.p;
  IO.p=new Promise(resolve=>{
    const fin=v=>{ IO.dl=v||null; resolve(IO.dl); };
    try{
      if(window.claude && typeof window.claude.use==='function') window.claude.use('downloads').then(fin, ()=>fin(null));
      else fin(null);
    }catch(e){ fin(null); }
  });
  return IO.p;
}
function ioReady(ms){
  if(IO.dl!==undefined) return Promise.resolve(IO.dl);
  const wait=new Promise(r=>setTimeout(()=>r(IO.dl===undefined?null:IO.dl), ms==null?1500:ms));
  return Promise.race([ioStart(), wait]);
}
function fileBase(){
  const nm=NOTE_NAMES[STATE.root].replace('#','s');
  return 'contrapunctus-'+nm+'-'+STATE.scaleName.toLowerCase()+(STATE.tuning==='equal'?'':'-'+STATE.tuning);
}
function blobDownload(filename, data, mime){
  const blob=new Blob([data], {type:mime||'application/octet-stream'}), url=URL.createObjectURL(blob);
  const a=document.createElement('a'); a.href=url; a.download=filename; a.rel='noopener'; a.style.display='none';
  document.body.appendChild(a); a.click();
  setTimeout(()=>{ a.remove(); URL.revokeObjectURL(url); }, 4000);
}
// resolves true when the file was handed over, false when it was declined or could not be
async function deliverFile(filename, data, mime){
  const dl=await ioReady(6000);
  if(dl){
    try{ await dl.save({filename, data}); return true; }
    catch(e){
      const code=e && e.code;
      if(code==='declined') return false;
      if(code==='rate_limited'){ toast('Another save is still waiting for your answer.', 3800); return false; }
      if(code==='too_large' || code==='bad_request' || code==='transform_error' || code==='rejected_extension' || code==='extension_not_enabled'){ toast('This view would not save '+filename+'.', 4200); return false; }
      IO.dl=null;                  // unavailable, not granted and the like: this view cannot save, so try the plain way below
    }
  }
  try{ blobDownload(filename, data, mime); return true; }catch(e){ toast('Saving did not work here.', 4200); return false; }
}
async function saveMidi(){
  const m=buildMidi(); if(!m) return;
  const base=fileBase(), dl=await ioReady(6000);
  let ok;
  if(dl){        // the viewer lists the extensions it takes, and .mid is not among them: send the file with its state in a .zip
    const state=new TextEncoder().encode(JSON.stringify(serializeState({view:true}), null, 1));
    ok=await deliverFile(base+'.zip', makeZip([{name:base+'.mid', data:m.bytes},{name:base+'.json', data:state}]), 'application/zip');
  } else ok=await deliverFile(base+'.mid', m.bytes, 'audio/midi');
  if(ok){
    const i=m.info;
    toast('Saved '+i.notes+' notes'+(i.bent?', '+i.bent+' with a pitch bend':'')+(i.glitches?'; '+i.glitches+' share a channel with a release still sounding':'')+'.', 4200);
  }
}
async function saveState(){
  const txt=JSON.stringify(serializeState({view:true}), null, 1);
  if(await deliverFile(fileBase()+'.json', txt, 'application/json')) toast('State saved.');
}
// the live export summary shown under the buttons
function midiSummary(){
  const m=buildMidi(); if(!m) return '';
  const i=m.info, T=TUNINGS[i.tuning];
  if(!i.anyBend) return i.notes+' notes on three tracks, one channel each, no pitch bend.';
  return i.notes+' notes on three tracks. Tuning: '+T.label+'. '+i.bent+' notes carry a pitch bend (up to '+i.maxCents.toFixed(1)
    +' cents, range ±2 semitones), over '+i.channels.join(' + ')+' channels. '
    +(i.glitches?i.glitches+' notes share a channel with a release still sounding.':'No release is bent by a later note.');
}
