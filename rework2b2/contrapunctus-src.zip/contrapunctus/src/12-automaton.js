/* =====================================================================
   4 · THE AUTOMATON
   ===================================================================== */
function segLen(){ return STATE.harmonic==='bar' ? STATE.stepsPerBar : Math.max(1,Math.floor(STATE.stepsPerBar/2)); }
function segOfStep(s){ return Math.floor(s/segLen()); }
function barOfSeg(g){ return Math.floor(g/(STATE.harmonic==='bar'?1:2)); }
function scaleForSeg(g){ const o=STATE.barOverrides[barOfSeg(g)]; return (o&&o.scale)||STATE.scaleName; }
function targetForSeg(g){
  const o=STATE.barOverrides[barOfSeg(g)];
  return (o && typeof o.tension==='number') ? o.tension : STATE.tension;
}

function tieBreak(current, prev2){
  // Three tiers first: real motion, backtracking to two chords ago, standing
  // still. Without them the ranking below has two degenerate attractors once
  // lambda stops constraining anything.
  const tier = (c)=>{
    if(c.rootPc===current.rootPc && c.quality===current.quality) return 2;
    if(prev2 && c.rootPc===prev2.rootPc && c.quality===prev2.quality) return 1;
    return 0;
  };
  const mode = STATE.take;
  return (a,b)=>{
    const ta=tier(a.c), tb=tier(b.c);
    if(ta!==tb) return ta-tb;
    const va=voiceLeadingDistance(current.tones,a.c.tones), vb=voiceLeadingDistance(current.tones,b.c.tones);
    if(mode==='strong'){ if(a.cost!==b.cost) return a.cost-b.cost; }
    else if(mode==='bold'){ if(a.cost!==b.cost) return b.cost-a.cost; }
    if(va!==vb) return va-vb;
    if(a.cost!==b.cost) return a.cost-b.cost;
    return a.c.rootPc-b.c.rootPc;
  };
}

// The reference successor function: used by the piece, the what-if forks and the
// tests. The rule table only says what is allowed; the same cost surface also
// ranks the survivors, and which end of that ranking is played is a control.
// (The first version always took the smoothest, which made most of the 2^540
// tables produce the same music.)
function chordStep(current, prev2, eta, tbl, vocab, target){
  const cands=[];
  for(let j=0;j<vocab.length;j++){
    const c=vocab[j];
    const f=cIdx(rootFall(current.rootPc,c.rootPc), tensionBucket(c.tensionVal-target), c.ring, eta);
    if(tbl.t[f]) cands.push({c, cost:tbl.costs[f], f});
  }
  let fellBack=false;
  if(cands.length===0){
    fellBack=true;
    for(let j=0;j<vocab.length;j++){
      const c=vocab[j];
      const f=cIdx(rootFall(current.rootPc,c.rootPc), tensionBucket(c.tensionVal-target), c.ring, eta);
      cands.push({c, cost:tbl.costs[f], f});
    }
  }
  cands.sort(tieBreak(current, prev2));
  return {legal:cands.map(x=>x.c), cands, fellBack};
}

/* ---- the fast path ---------------------------------------------------
   The analysis asks for the successor of every one of up to ~1700 states, at
   each of 29 values of lambda. chordNext() answers the same question as
   chordStep(...).legal[0] without sorting, allocating or recomputing a
   voice-leading distance: those are tabulated once per vocabulary. It is
   *defined* to agree with chordStep; the test suite checks that on thousands
   of random states, tables, modes and vocabularies. */
const KIT_CACHE = new WeakMap();
function vocabKit(vocab, target){
  let k = KIT_CACHE.get(vocab);
  if(!k){
    const V=vocab.length, vl=new Int16Array(V*V), fall=new Uint8Array(V*V), same=new Uint8Array(V*V);
    for(let i=0;i<V;i++) for(let j=0;j<V;j++){
      vl[i*V+j]   = voiceLeadingDistance(vocab[i].tones, vocab[j].tones);
      fall[i*V+j] = rootFall(vocab[i].rootPc, vocab[j].rootPc);
      same[i*V+j] = (vocab[i].rootPc===vocab[j].rootPc && vocab[i].quality===vocab[j].quality) ? 1 : 0;
    }
    k = {V, vl, fall, same, root:Int8Array.from(vocab.map(c=>c.rootPc)), byTarget:new Map()};
    KIT_CACHE.set(vocab, k);
  }
  const tk = target.toFixed(4);
  let t = k.byTarget.get(tk);
  if(!t){
    const V=k.V, tb=new Uint8Array(V), fidx=new Int32Array(V*V);
    for(let j=0;j<V;j++) tb[j]=tensionBucket(vocab[j].tensionVal-target);
    for(let i=0;i<V;i++) for(let j=0;j<V;j++) fidx[i*V+j] = cIdx(k.fall[i*V+j], tb[j], vocab[j].ring, 0);
    t = {fidx};
    if(k.byTarget.size>8) k.byTarget.clear();
    k.byTarget.set(tk, t);
  }
  return {V:k.V, vl:k.vl, same:k.same, fall:k.fall, root:k.root, fidx:t.fidx};
}
// index of the move the rule plays from (cur, prev2, eta); prev2 = -1 for none
function chordNext(cur, prev2, eta, tbl, kit, mode){
  const V=kit.V, vl=kit.vl, same=kit.same, fidx=kit.fidx, root=kit.root, tt=tbl.t, cs=tbl.costs;
  const eo=eta*CS[3], row=cur*V, prow=prev2>=0 ? prev2*V : -1;
  let best=-1, bT=0, bV=0, bC=0, bR=0;
  for(let pass=0; pass<2 && best<0; pass++){        // pass 1 is the total-rule fallback: everything
    for(let j=0;j<V;j++){
      const f=fidx[row+j]+eo;
      if(pass===0 && !tt[f]) continue;
      const tier = same[row+j] ? 2 : (prow>=0 && same[prow+j]) ? 1 : 0;
      const v=vl[row+j], c=cs[f], r=root[j];
      if(best>=0){
        let cmp;
        if(tier!==bT) cmp = tier<bT ? -1 : 1;
        else {
          cmp = 0;
          if(mode==='strong'){ if(c!==bC) cmp = c<bC ? -1 : 1; }
          else if(mode==='bold'){ if(c!==bC) cmp = c>bC ? -1 : 1; }
          if(cmp===0 && v!==bV) cmp = v<bV ? -1 : 1;
          if(cmp===0 && c!==bC) cmp = c<bC ? -1 : 1;
          if(cmp===0 && r!==bR) cmp = r<bR ? -1 : 1;
        }
        if(cmp>=0) continue;                          // ties keep the earlier index, as a stable sort does
      }
      best=j; bT=tier; bV=v; bC=c; bR=r;
    }
  }
  return best;
}

function cellOfMove(from, to, target, eta){
  return {d:rootFall(from.rootPc,to.rootPc), tau:tensionBucket(to.tensionVal-target), rho:to.ring, eta};
}

function seedState(){
  const v = vocabularyFor(STATE.root, SCALES[scaleForSeg(0)], STATE.extended);
  const i = Math.min(Math.max(0,STATE.seed.chordIdx), v.length-1);
  const p = STATE.seed.prev2Idx;
  return {vocab:v, chord:v[i], prev2:(p>=0&&p<v.length)?v[p]:null, eta:Math.min(2,Math.max(0,STATE.seed.eta))};
}

function runChordWalk(totalSegments){
  const tbl = chordTable();
  const cache = {};
  const vocabAt = (g)=>{ const n=scaleForSeg(g); return cache[n] || (cache[n]=vocabularyFor(STATE.root, SCALES[n], STATE.extended)); };
  const s0 = seedState();
  let current=s0.chord, prev2=s0.prev2, eta=s0.eta;
  const out=[{chord:current, segIdx:0, fellBack:false, legal:[current], nLegal:1, pinned:false, pinMissed:false, cell:null}];
  for(let g=1; g<totalSegments; g++){
    const vocab = vocabAt(g), target = targetForSeg(g);
    const {legal, fellBack} = chordStep(current, prev2, eta, tbl, vocab, target);
    let chosen = legal[0], pinned=false;
    const pin = STATE.pins[g];
    if(pin){ const f = legal.find(c=>c.key===pin); if(f){ chosen=f; pinned=true; } }
    const pinMissed = !!pin && !pinned;       // a pin the rule no longer allows is kept, but does nothing
    const cell = cellOfMove(current, chosen, target, eta);
    const from = current;
    eta = etaOf(cell.d);
    prev2 = current; current = chosen;
    out.push({chord:current, segIdx:g, fellBack, legal:legal.slice(0,8), nLegal:legal.length, pinned, pinMissed,
              cell, from, target, etaIn:cell.eta});
  }
  return out;
}

// Fork: take an alternative at one segment and let the same rule finish it.
// Returns the chords *and* the rule cells they travel through, so a road not
// taken can be drawn in the score and in the rule space at the same time.
function forkFrom(walk, segIdx, alt, horizon){
  const tbl = chordTable();
  const cache = {};
  const vocabAt = (g)=>{ const n=scaleForSeg(g); return cache[n] || (cache[n]=vocabularyFor(STATE.root, SCALES[n], STATE.extended)); };
  const w = walk[segIdx];
  if(!w || !w.from) return {chords:[], cells:[]};
  let current = alt, prev2 = w.from;
  const firstCell = cellOfMove(w.from, alt, w.target, w.etaIn);
  let eta = etaOf(firstCell.d);
  const chords=[alt], cells=[firstCell];
  for(let g=segIdx+1; g<Math.min(walk.length, segIdx+1+horizon); g++){
    const vocab = vocabAt(g), target = targetForSeg(g);
    const {legal} = chordStep(current, prev2, eta, tbl, vocab, target);
    let chosen = legal[0];
    const pin = STATE.pins[g];
    if(pin){ const f = legal.find(c=>c.key===pin); if(f) chosen=f; }
    cells.push(cellOfMove(current, chosen, target, eta));
    eta = etaOf(rootFall(current.rootPc, chosen.rootPc));
    prev2 = current; current = chosen;
    chords.push(chosen);
  }
  return {chords, cells};
}

/* ---- voices ---- */
function motionClass(delta){ return delta<=-3?0 : delta<=-1?1 : delta===0?2 : delta<=2?3 : 4; }
function fitClass(pc, chordPCs, scalePCs){ return chordPCs.includes(pc)?2 : scalePCs.includes(pc)?1 : 0; }
function consonanceCount(m, others){
  let n=0;
  for(const o of others){ if(o.pitch==null) continue; if(CONSONANT_ICS.has(ic(m-o.pitch))) n++; }
  return n;
}
function relativeMotion(delta, others){
  if(delta===0) return 1;
  let same=0, opp=0;
  for(const o of others){
    if(o.pitch==null||o.prevPitch==null) continue;
    const dv=o.pitch-o.prevPitch;
    if(dv===0) continue;
    if(Math.sign(dv)===Math.sign(delta)) same++; else opp++;
  }
  if(!same && !opp) return 1;
  return opp>same ? 2 : same>opp ? 0 : 1;
}
// Parallel perfect fifths and octaves only. (The first version also forbade
// parallel fourths, which are not a fault, because it tested the interval class
// 5 -- a fourth -- instead of the fifth.)
function filterParallels(cands, prevPitch, others){
  if(!others.length || prevPitch==null) return cands;
  const f = cands.filter(c=>{
    for(const o of others){
      if(o.pitch==null||o.prevPitch==null) continue;
      const before=Math.abs(prevPitch-o.prevPitch)%12, after=Math.abs(c-o.pitch)%12;
      const mine=c-prevPitch, theirs=o.pitch-o.prevPitch;
      if(mine!==0 && theirs!==0 && Math.sign(mine)===Math.sign(theirs) && before===after && (after===0||after===7)) return false;
    }
    return true;
  });
  return f.length?f:cands;
}
// keep candidates inside [lo,hi]; if that would leave nothing, the constraint yields
function bounded(cands, lo, hi){ const f=cands.filter(m=>m>=lo&&m<=hi); return f.length?f:cands; }
function pcDist(a,b){ const d=(((a-b)%12)+12)%12; return Math.min(d,12-d); }
function rangeAll(lo,hi){ const o=[]; for(let m=lo;m<=hi;m++) o.push(m); return o; }
function chordTonesIn(tones, lo, hi){
  const pcs=[...new Set(tones.map(pcOf))], o=[];
  for(let m=lo;m<=hi;m++) if(pcs.includes(pcOf(m))) o.push(m);
  return o;
}
function firstOnsetOfSeg(v, step, g){
  const L=segLen(), s0=g*L;
  for(let s=s0;s<step;s++) if(STATE.onsets[v][s]) return false;
  return true;
}
function lastOnsetOfSeg(v, step, g){
  const end=Math.min(STATE.onsets[v].length, (g+1)*segLen());
  for(let s=step+1;s<end;s++) if(STATE.onsets[v][s]) return false;
  return true;
}
function pickNote(cands, ctx){
  const {prevPitch, others, chordTones, scalePCs, tbl, preferRoot, structural, approachPc} = ctx;
  const chordPCs = chordTones.map(pcOf);
  const sigma = structural?0:1;
  const cls = (m)=>{
    const dv = prevPitch==null?0:(m-prevPitch);
    return { kappa:Math.min(2,consonanceCount(m,others)), mu:prevPitch==null?2:motionClass(dv),
             phi:fitClass(pcOf(m),chordPCs,scalePCs), sigma, gamma:relativeMotion(dv,others) };
  };
  const memo = new Map();
  const cl = (m)=>{ let v=memo.get(m); if(!v){ v=cls(m); memo.set(m,v); } return v; };
  const costOf = (m)=>{ const c=cl(m); return tbl.costs[vIdx(c.kappa,c.mu,c.phi,c.sigma,c.gamma)]; };
  let legal = cands.filter(m=>{ const c=cl(m); return tbl.t[vIdx(c.kappa,c.mu,c.phi,c.sigma,c.gamma)]===1; });
  let fellBack=false;
  if(!legal.length){ legal=cands.slice(); fellBack=true; }
  // A walking bass leads into the next root from a half step or a whole step away,
  // not by sounding the next root early.
  const approachScore = (m)=>{ const d=pcDist(pcOf(m), approachPc); return d===1?0 : d===2?1 : 2; };
  const mode = STATE.take;
  legal.sort((a,b)=>{
    if(preferRoot!=null){
      const ra=pcOf(a)===preferRoot?0:1, rb=pcOf(b)===preferRoot?0:1;
      if(ra!==rb) return ra-rb;
    }
    if(approachPc!=null){
      const sa=approachScore(a), sb=approachScore(b);
      if(sa!==sb) return sa-sb;
    }
    const ca=costOf(a), cb=costOf(b);
    if(mode==='strong' && ca!==cb) return ca-cb;
    if(mode==='bold'   && ca!==cb) return cb-ca;
    const da=prevPitch==null?0:Math.abs(a-prevPitch), db=prevPitch==null?0:Math.abs(b-prevPitch);
    const ra=prevPitch!=null&&da===0, rb=prevPitch!=null&&db===0;
    if(ra!==rb) return ra?1:-1;
    if(da!==db) return da-db;
    if(ca!==cb) return ca-cb;
    return a-b;
  });
  const chosen=legal[0];
  return {pitch:chosen, cls:cls(chosen), fellBack};
}
function deterministicShuffle(arr, seed){
  const o=arr.slice(); let h=seed>>>0;
  for(let i=o.length-1;i>0;i--){ h=(Math.imul(h,2654435761)+i)>>>0; const j=h%(i+1); const t=o[i]; o[i]=o[j]; o[j]=t; }
  return o;
}
function arpSequence(tones, pattern, seed){
  const s=[...new Set(tones)].sort((a,b)=>a-b);
  if(!s.length) return [72];
  switch(pattern){
    case 'up': return s;
    case 'down': return s.slice().reverse();
    case 'updown': return s.concat(s.slice().reverse().slice(1,-1));
    case 'downup': return s.slice().reverse().concat(s.slice(1,-1));
    case 'scramble': return deterministicShuffle(s, seed);
    default: return s;
  }
}

// Every voice hears every other voice: at its new pitch if it attacks on this
// step, at the pitch it is still holding if not. (The first version let the
// melody hear nobody, so two of the five voice axes were constant for it, and
// let the middle and bass hear only voices that happened to attack on the same
// step.) Voices are also kept from crossing: the middle sits between bass and
// melody, the melody above whatever is held beneath it. A constraint that would
// leave no candidate at all yields.
function runVoiceWalk(chords){
  const tbl = voiceTable();
  const total = STATE.onsets[0].length;
  const held=[null,null,null];
  for(let v=0;v<3;v++) if(STATE.seed.voice[v]!=null) held[v]=STATE.seed.voice[v];
  let arpGen=null, arpSeg=-1, arpI=0;
  const res=[];
  for(let step=0; step<total; step++){
    const g = Math.min(segOfStep(step), chords.length-1);
    const chord = chords[g], next = chords[Math.min(g+1, chords.length-1)];
    const scalePCs = SCALES[scaleForSeg(g)].map(o=>(STATE.root+o)%12);
    const before = held.slice();
    const pitches=[null,null,null], deco=[false,false,false], fb=[false,false,false], cells=[null,null,null];
    const hears=(v)=>{
      const o=[];
      for(let u=0;u<3;u++){
        if(u===v) continue;
        const now=pitches[u], p = now!=null ? now : held[u];
        if(p==null) continue;
        o.push({pitch:p, prevPitch: now!=null ? before[u] : p});
      }
      return o;
    };
    const cur=(u)=> pitches[u]!=null ? pitches[u] : held[u];
    const put=(v, r)=>{ pitches[v]=r.pitch; deco[v]=r.cls.phi<2; fb[v]=r.fellBack; cells[v]=r.cls; held[v]=r.pitch; };

    if(STATE.onsets[0][step]){
      if(STATE.anchors[step]!=null){
        pitches[0]=STATE.anchors[step]; held[0]=pitches[0];
      } else if(STATE.arp!=='none'){
        if(arpSeg!==g){ const t=chordTonesIn(chord.tones,REGISTERS[0].lo,REGISTERS[0].hi);
          arpGen=arpSequence(t.length?t:[72], STATE.arp, chord.rootPc*17+g); arpSeg=g; arpI=0; }
        pitches[0]=arpGen[arpI++%arpGen.length]; held[0]=pitches[0];
      } else {
        const beneath=[held[1],held[2]].filter(x=>x!=null);
        const lo = beneath.length ? Math.max.apply(null, beneath)+1 : 0;
        const ear=hears(0);
        const cands=filterParallels(bounded(rangeAll(REGISTERS[0].lo,REGISTERS[0].hi), lo, 127), held[0], ear);
        put(0, pickNote(cands, {prevPitch:held[0], others:ear, chordTones:chord.tones, scalePCs, tbl,
          structural:firstOnsetOfSeg(0,step,g)}));
      }
    }
    if(STATE.onsets[2][step]){
      const first=firstOnsetOfSeg(2,step,g);
      const above=[cur(0),held[1]].filter(x=>x!=null);
      const hi = above.length ? Math.min.apply(null, above)-1 : 127;
      const ear=hears(2);
      const cands=filterParallels(bounded(rangeAll(REGISTERS[2].lo,REGISTERS[2].hi), 0, hi), held[2], ear);
      const walk = STATE.walkingBass && !first && lastOnsetOfSeg(2,step,g);
      put(2, pickNote(cands, {prevPitch:held[2], others:ear, chordTones:chord.tones, scalePCs, tbl,
        preferRoot:first?chord.rootPc:null, structural:first, approachPc:walk?next.rootPc:null}));
    }
    if(STATE.onsets[1][step]){
      const lo = cur(2)!=null ? cur(2)+1 : 0, hi = cur(0)!=null ? cur(0)-1 : 127;
      const ear=hears(1);
      const cands=filterParallels(bounded(rangeAll(REGISTERS[1].lo,REGISTERS[1].hi), lo, hi), held[1], ear);
      put(1, pickNote(cands, {prevPitch:held[1], others:ear, chordTones:chord.tones, scalePCs, tbl,
        structural:firstOnsetOfSeg(1,step,g)}));
    }
    res.push({step, pitches, deco, fellBack:fb, cells, g});
  }
  return res;
}

function secondsPerStep(){ return (60/STATE.tempo)*(4/STATE.stepsPerBar); }

/* ---- rhythm ---- */
// A walking bass sounds on every beat; otherwise the bass sounds once per chord.
function defaultOnsets(v, total, spb, harm, walk){
  const g=new Array(total).fill(false);
  if(v===0){ const p=Math.max(1,Math.floor(spb/4)); for(let s=0;s<total;s+=p) g[s]=true; }
  else if(v===1){ const p=Math.max(1,Math.floor(spb/2)); for(let s=0;s<total;s+=p) g[s]=true; }
  else {
    const L = walk ? Math.max(1,Math.floor(spb/4)) : (harm==='bar' ? spb : Math.max(1,Math.floor(spb/2)));
    for(let s=0;s<total;s+=L) g[s]=true;
  }
  return g;
}
function euclid(steps,pulses){
  const p=new Array(steps).fill(false); let b=0;
  for(let i=0;i<steps;i++){ b+=pulses; if(b>=steps){ b-=steps; p[i]=true; } }
  return p;
}
// A lane the composer has not touched follows the defaults (so it re-flows when the
// grid, the chord rhythm or the walking bass changes); a lane they have painted keeps
// what they painted.
function ensureGrids(){
  const total = STATE.bars*STATE.stepsPerBar, walk=STATE.walkingBass;
  const fresh = (v)=>defaultOnsets(v,total,STATE.stepsPerBar,STATE.harmonic,walk);
  if(!STATE.onsets || STATE.stepsPerBar!==STATE.lastStepsPerBar){
    const changed = STATE.onsets && STATE.stepsPerBar!==STATE.lastStepsPerBar;
    STATE.onsets=[0,1,2].map(fresh);
    STATE.touched=[false,false,false];
    if(changed){ STATE.anchors={}; STATE.noteEnv={}; STATE.selectedNote=null; }
    STATE.lastStepsPerBar=STATE.stepsPerBar;
    return;
  }
  STATE.onsets = STATE.onsets.map((old,v)=>{
    const def=fresh(v);
    if(!STATE.touched[v]) return def;
    const out=new Array(total);
    for(let s=0;s<total;s++) out[s] = s<old.length ? old[s] : def[s];
    return out;
  });
}
