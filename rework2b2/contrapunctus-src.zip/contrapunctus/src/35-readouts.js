/* =====================================================================
   13 · READOUTS
   ---------------------------------------------------------------------
   Everything here reads the composed piece and its analysis (13-analysis.js)
   and says what they say. The wording keeps to what was measured: the chord
   automaton is a deterministic map on a few hundred states, so what can be
   reported is where a seed goes, how long it takes, what cycle it ends in,
   and how much the answer depends on the seed and on the rule's cells.
   ===================================================================== */
const ONE_PLATE_H = 78;

function popcount(a){ let n=0; for(let i=0;i<a.length;i++) if(a[i]) n++; return n; }
function esc(s){ return String(s).replace(/[&<>"']/g, ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
function pct(x){ return Math.round(x*100)+'%'; }
function handCount(){
  return Object.keys(STATE.cellFlips.chord).length+Object.keys(STATE.cellFlips.voice).length
    +Object.keys(STATE.pins).length+Object.keys(STATE.anchors).length+Object.keys(STATE.noteEnv).length
    +Object.keys(STATE.barOverrides).length+STATE.touched.filter(Boolean).length;
}

/* ---- selection ------------------------------------------------------------------ */
function ensureSelectedNote(){
  const c=STATE.composed, n=STATE.selectedNote; if(!c||!c.notes) return;
  if(n && c.notes[n.v] && c.notes[n.v].some(x=>x.step===n.step)) return;
  const first=c.notes[0][0]||c.notes[1][0]||c.notes[2][0];
  STATE.selectedNote = first ? {v:first.v, step:first.step} : null;
}
function selectNote(v, step, reveal){
  STATE.selectedNote={v,step};
  drawRoll(); drawSeq(); drawEnv();
  if(reveal){
    const el=$('envCanvas');
    if(el && el.scrollIntoView) try{ el.scrollIntoView({block:'nearest', behavior:REDUCED_MOTION()?'auto':'smooth'}); }catch(e){}
  }
}
function selectSeg(s){
  const c=STATE.composed; if(!c) return;
  STATE.selectedSeg=Math.max(0,Math.min(c.segments-1,s)); HOVER.branch=null;
  renderBranches(); drawRoll(); drawLattice();
}

/* ---- status line -------------------------------------------------------------------- */
function renderStatus(){
  const c=STATE.composed, el=$('statusline'); if(!c||!el) return;
  const d=c.dyn, o=d.orbit, hand=handCount();
  const items=[
    ['λ chord', fmt2(STATE.lamC)], ['λ voice', fmt2(STATE.lamV)],
    ['seed', c.chords[0].roman+' · η '+ETA_NAMES[Math.min(2,Math.max(0,STATE.seed.eta))]],
    ['orbit', o.cls+', period '+o.period], ['attractors', String(d.attractors)],
    ['cells asked', popcount(c.reach)+'/'+CHORD_STR.size], ['take', STATE.take],
  ];
  if(STATE.tuning!=='equal') items.push(['tuning', TUNINGS[STATE.tuning].label]);
  el.textContent='';
  for(const [k,v] of items){ const s=mk('span'); s.appendChild(document.createTextNode(k+' ')); s.appendChild(mk('b',null,v)); el.appendChild(s); }
  if(hand){ const s=mk('span','hand'); s.appendChild(document.createTextNode('by hand ')); s.appendChild(mk('b',null,String(hand))); el.appendChild(s); }
  fitHeader();
}
function fitHeader(){
  const h=$('masthead'), s=$('statusline'), r=document.documentElement.style;
  if(h) r.setProperty('--hdr', h.offsetHeight+'px');
  if(s) r.setProperty('--stat', s.offsetHeight+'px');
}

/* ---- the sweep ------------------------------------------------------------------------- */
const CLASS_WORDS = {
  fixed:'stands still: period 1',
  loop:'loops: goes round at least twice within the piece',
  tour:'tours: the piece ends before the orbit has closed twice',
};
function sweepTip(p, n){
  const cls=orbitClass(p.period,n);
  return ['λ '+fmt2(p.lam)+' · '+cls,
    'period '+p.period+' of '+p.V+' chords · wanders '+p.transient,
    p.A+' attractor'+(p.A===1?'':'s')+' in the whole graph',
    'seed memory '+pct(p.S)+' · '+p.H.toFixed(2)+' bits'];
}
function renderSweep(){
  const c=STATE.composed, el=$('sweep'); if(!c||!el) return;
  const sw=c.sweep, n=c.segments, maxP=Math.max(n, Math.max.apply(null, sw.map(p=>p.period))), H=ONE_PLATE_H-6;
  el.textContent='';
  const here=sw.reduce((b,p,i)=>Math.abs(p.lam-STATE.lamC)<Math.abs(sw[b].lam-STATE.lamC)?i:b, 0);
  sw.forEach((p,i)=>{
    const cls=orbitClass(p.period,n), b=mk('button','c'+(i===here?' here':''));
    b.type='button'; b.style.height=Math.max(5,Math.round(H*p.period/maxP))+'px'; b.style.background='var(--cls-'+cls+')';
    b.tabIndex = i===here?0:-1; b.dataset.i=i;
    b.setAttribute('aria-label','lambda '+p.lam.toFixed(2)+', '+cls+', period '+p.period+'. Set the chord rule to this value.');
    const tip=(e)=>{ const r=b.getBoundingClientRect(); showTip(e&&e.clientX!=null?e.clientX:r.left+r.width/2, e&&e.clientY!=null?e.clientY:r.top, sweepTip(p,n)); };
    b.addEventListener('mouseenter', tip); b.addEventListener('mousemove', tip);
    b.addEventListener('mouseleave', hideTip); b.addEventListener('focus', ()=>tip(null)); b.addEventListener('blur', hideTip);
    b.addEventListener('click', ()=>setLambdaC(p.lam));
    el.appendChild(b);
  });
  // the line at half the piece: a cycle longer than this cannot go round twice
  const box=el.parentNode; let line=$('sweepLine');
  if(!line){ line=mk('div'); line.id='sweepLine'; line.appendChild(mk('span')); box.insertBefore(line, el.nextSibling); }
  line.style.top=(ONE_PLATE_H-Math.round(H*(n/2)/maxP)-1)+'px';
  line.firstChild.textContent='half the piece ('+(n/2)+')';
  line.hidden = (n/2)/maxP>0.97;
  const mem=$('memrow'); mem.textContent='';
  for(const p of sw){ const i=mk('i'); i.style.height=Math.max(1,Math.round(22*p.S))+'px'; mem.appendChild(i); }
  // the table that carries the same numbers
  const tb=$('sweepTable'); tb.textContent='';
  const t=mk('table','tbl'), hd=mk('tr');
  for(const h of ['λ','class','period','wanders','attractors','seed memory','bits','longest']) hd.appendChild(mk('th',null,h));
  t.appendChild(mk('thead')).appendChild(hd);
  const body=mk('tbody');
  sw.forEach((p,i)=>{ const r=mk('tr', i===here?'here':null);
    for(const x of [fmt2(p.lam), orbitClass(p.period,n), p.period, p.transient, p.A, pct(p.S), p.H.toFixed(2), p.longest]) r.appendChild(mk('td',null,String(x)));
    body.appendChild(r); });
  t.appendChild(body); tb.appendChild(t);
  renderSweepKey();
}
function renderSweepKey(){
  const el=$('sweepKey'); if(!el) return; el.textContent='';
  for(const k of ['fixed','loop','tour']){ const s=mk('span'); const i=mk('i','sw'); i.style.background='var(--cls-'+k+')'; s.appendChild(i); s.appendChild(document.createTextNode(CLASS_WORDS[k])); el.appendChild(s); }
}
function sweepKeys(e){
  const items=[...$('sweep').querySelectorAll('button.c')]; const i=items.indexOf(document.activeElement); if(i<0) return;
  let j=i; if(e.key==='ArrowRight') j=Math.min(items.length-1,i+1); else if(e.key==='ArrowLeft') j=Math.max(0,i-1); else if(e.key==='Home') j=0; else if(e.key==='End') j=items.length-1; else return;
  e.preventDefault(); items.forEach((b,k)=>b.tabIndex=k===j?0:-1); items[j].focus();
}

function renderDyn(){
  const c=STATE.composed, el=$('dynRead'); if(!c||!el) return;
  const d=c.dyn, o=d.orbit, n=c.segments, names=o.chords.map(x=>x.roman);
  const cyc = names.length>8 ? names.slice(0,8).join(' ')+' …' : names.join(' ');
  let l1;
  if(o.cls==='fixed') l1='From this seed the chords settle on <b>'+esc(names[0])+'</b> after <b>'+o.transient+'</b> step'+(o.transient===1?'':'s')+' and stay there.';
  else if(o.cls==='loop') l1='From this seed the chords wander <b>'+o.transient+'</b> step'+(o.transient===1?'':'s')+', then repeat <b>'+esc(cyc)+'</b> (period '+o.period+'): about '+(n/o.period).toFixed(1)+' laps in a piece of '+n+' chords.';
  else l1='The cycle this seed ends in, <b>'+esc(cyc)+'</b>, has period <b>'+o.period+'</b>, longer than half of the '+n+' chords, so the piece ends before it has gone round twice.';
  if(o.transient>=n-1 && o.cls!=='fixed') l1+=' The piece ends before the walk has reached that cycle.';
  const l2='The whole graph has <b>'+d.N+'</b> states ('+d.V+' chords × 3 momenta × '+(d.V+1)+' choices of the chord two back) and <b>'+d.attractors+'</b> attractor'+(d.attractors===1?'':'s')
    +'. This seed’s basin holds <b>'+o.basin+'</b>. Changing one seed control lands in a different attractor <b>'+pct(d.memory)+'</b> of the time.';
  const reach=popcount(c.reach), dep=c.dep;
  const l3='This vocabulary can ask <b>'+reach+'</b> of the '+CHORD_STR.size+' rule cells. Flipping any single cell changes the first '+n+' chords in <b>'+dep.changed+'</b> case'+(dep.changed===1?'':'s')
    +(dep.changed? ' (earliest at chord '+(dep.first+1)+')':'')+'.';
  const l4=c.sequence ? 'A run of '+c.sequence.k+' root motions occurs twice in a row from chord '+(c.sequence.i+1)+': a sequence, in the musical sense.' : '';
  el.innerHTML=l1+'<br>'+l2+'<br>'+l3+(l4?'<br>'+l4:'');
}

/* ---- basins ------------------------------------------------------------------------------ */
let BASIN_GEO=null;
function basinColor(rank){ return rank===0?THEME.att[0] : rank===1?THEME.att[1] : THEME.att[2]; }
function drawBasin(){
  const c=STATE.composed, cv=$('basinCanvas'); if(!c||!c.basin||!cv) return;
  const b=c.basin, {g,w,h}=ctx2d(cv), S=THEME.str;
  const L=48, T=18, pw=w-L-4, ph=h-T-4, cols=b.V*3, rows=b.P, cw=pw/cols, ch=ph/rows;
  g.font='9px '+THEME.font.mono; g.textBaseline='middle';
  for(let i=0;i<b.V;i++) for(let e=0;e<3;e++) for(let p=-1;p<b.V;p++){
    const s=b.enc(i,e,p), rank=b.rank.get(b.attr[s]), t=b.trans[s]/Math.max(1,b.maxT);
    const col=mix(basinColor(rank), THEME.bg, t*0.62);
    g.fillStyle=css(col,1);
    const x=L+(i*3+e)*cw, y=T+(p+1)*ch;
    g.fillRect(x, y, Math.max(0.6,cw-(e===2?1.8:0.5)), Math.max(0.6,ch-0.5));
    if(b.trans[s]===0 && cw>5 && ch>5){ g.fillStyle=css(THEME.dark?[1,1,1]:[0,0,0],0.7); g.beginPath(); g.arc(x+cw/2-0.4,y+ch/2,1.2,0,7); g.fill(); }
  }
  // labels: the chord of each column group, the chord two back of each row
  g.fillStyle=S.dim; g.textAlign='center';
  const fitsCol=cw*3>34;
  for(let i=0;i<b.V;i++) if(fitsCol || i%2===0) g.fillText(b.vocab[i].roman, L+(i*3+1.5)*cw, T-8);
  g.textAlign='right';
  const rowEvery=ch>=10?1:2;
  for(let p=-1;p<b.V;p++) if((p+1)%rowEvery===0) g.fillText(p<0?'none':b.vocab[p].roman, L-5, T+(p+1.5)*ch);
  // the seed
  const sd=seedIdx(b.vocab);
  g.strokeStyle=S.ink; g.lineWidth=2; g.strokeRect(L+(sd.i*3+sd.e)*cw-1, T+(sd.p+1)*ch-1, cw+1.4, ch+1.4);
  BASIN_GEO={L,T,cw,ch,V:b.V,P:b.P};

  const leg=$('basinLegend'); leg.textContent='';
  const row=(rank,color,html)=>{ const d=mk('div','attr'); const i=mk('i','sw'); i.style.background=color; d.appendChild(i); const t=mk('span'); t.innerHTML=html; d.appendChild(t); leg.appendChild(d); };
  const list=b.list;
  list.slice(0,2).forEach((a,r)=>{
    const names=a.chords.map(x=>x.roman), shown=names.length>6?names.slice(0,6).join(' ')+' …':names.join(' ');
    row(r, css(THEME.att[r]), '<b>'+(r===0?'largest':'second')+'</b>: period <b>'+a.period+'</b> · '+pct(a.size/b.N)+' of states · '+esc(shown));
  });
  if(list.length>2){ const rest=list.slice(2), sz=rest.reduce((s,a)=>s+a.size,0);
    row(2, css(THEME.att[2]), '<b>'+rest.length+' other</b> attractor'+(rest.length===1?'':'s')+' · '+pct(sz/b.N)+' of states'); }
  if(list.length===1) row(0, css(THEME.att[0]), 'every state ends in this one cycle');
  $('basinStat').innerHTML='<b>'+b.N+'</b> states · <b>'+list.length+'</b> attractor'+(list.length===1?'':'s')+' · longest wander <b>'+b.maxT+'</b>';
}
function basinPick(clientX, clientY){
  const cv=$('basinCanvas'), G=BASIN_GEO; if(!cv||!G) return null;
  const r=cv.getBoundingClientRect(), x=clientX-r.left-G.L, y=clientY-r.top-G.T;
  const col=Math.floor(x/G.cw), row=Math.floor(y/G.ch);
  if(col<0||col>=G.V*3||row<0||row>=G.P) return null;
  return {chordIdx:Math.floor(col/3), eta:col%3, prev2Idx:row-1};
}
function basinTip(clientX, clientY, s){
  const c=STATE.composed; if(!c||!c.basin||!s) return hideTip();
  const b=c.basin, st=b.enc(s.chordIdx,s.eta,s.prev2Idx), rank=b.rank.get(b.attr[st]), a=b.list[rank];
  showTip(clientX, clientY, [b.vocab[s.chordIdx].roman+' · η '+ETA_NAMES[s.eta]+' · after '+(s.prev2Idx<0?'nothing':b.vocab[s.prev2Idx].roman),
    'wanders '+b.trans[st]+', then cycles with period '+a.period, (rank===0?'the largest attractor':rank===1?'the second largest':'one of '+(b.list.length-2)+' smaller ones')+' · click to start here']);
}

/* ---- roads not taken ------------------------------------------------------------------------- */
function renderBranches(){
  const c=STATE.composed, head=$('branchHead'), list=$('branches'), hint=$('branchHint'); if(!c||!head) return;
  list.textContent=''; hint.textContent='';
  const g=STATE.selectedSeg, w=c.walk[g];
  if(g<=0 || !w || !w.from){
    head.textContent='The first chord is the seed. Choose it under Initial state, or select a later chord in the score to see what else the rule allowed there.';
    return;
  }
  const n=w.nLegal, tbl=chordTable(), costMax=Math.max(1e-9, Math.max.apply(null, Array.from(tbl.costs)));
  head.innerHTML='at chord <b>'+(g+1)+'</b>, after <b>'+esc(w.from.roman)+'</b>: <b>'+n+'</b> move'+(n===1?'':'s')+' allowed'
    +(w.fellBack?' <span class="hand">(none was legal: the rule fell back to every chord)</span>':'')
    +(w.pinMissed?'<br><span class="hand">your pin on this chord is no longer legal here, so it does nothing</span>':'');
  const taken=c.chords[g];
  w.legal.slice(0,6).forEach(alt=>{
    const fork=forkFrom(c.walk, g, alt, 5), cell=cellOfMove(w.from, alt, w.target, w.etaIn);
    const isTaken=alt.key===taken.key, isPin=STATE.pins[g]===alt.key;
    const btn=mk('button','branch'+(isTaken?' taken':'')+(isPin?' pinned':'')); btn.type='button';
    btn.setAttribute('aria-pressed', isPin?'true':'false');
    btn.appendChild(mk('span','rn',alt.roman));
    const fut=mk('span','fut');
    fork.chords.slice(1).forEach((x,i)=>{ const base=c.chords[g+1+i]; const same=base&&base.key===x.key; fut.appendChild(same?document.createTextNode(x.roman+' '):mk('em',null,x.roman+' ')); });
    btn.appendChild(fut);
    btn.appendChild(mk('span','cost', fmt2(tbl.costs[cIdx(cell.d,cell.tau,cell.rho,cell.eta)]/costMax)));
    btn.title=(isTaken?'the rule takes this one':'the rule did not take this one')+'. Cost '+fmt2(tbl.costs[cIdx(cell.d,cell.tau,cell.rho,cell.eta)]/costMax)+'. Click to '+(isPin?'release it':'hold the piece to it')+'.';
    const on=()=>{ HOVER.branch={chords:fork.chords, cells:fork.cells, alt}; drawLattice(); drawRoll(); };
    const off=()=>{ HOVER.branch=null; drawLattice(); drawRoll(); };
    btn.addEventListener('mouseenter',on); btn.addEventListener('mouseleave',off); btn.addEventListener('focus',on); btn.addEventListener('blur',off);
    btn.addEventListener('click', ()=>{ if(STATE.pins[g]===alt.key) delete STATE.pins[g]; else STATE.pins[g]=alt.key; HOVER.branch=null; regenerate(); histCommit(); });
    list.appendChild(btn);
  });
  if(n>6){ const m=mk('div','aside', 'and '+(n-6)+' more, ranked below these'); list.appendChild(m); }
  hint.textContent='Hover or focus a move to see where it would have led, in the score and through the rule space. Click to hold the piece to it. A changed chord in a future is underlined; the future is what the same rule would have played from there.';
}

/* ---- the rail: statistics, hand edits, bar settings, export summary ------------------------------ */
function renderStats(){
  const c=STATE.composed; if(!c) return;
  const vocab=baseVocab(), tc=chordTable(), tv=voiceTable();
  const br=chordBranching(tc, vocab, STATE.tension);
  const reach=c.reach; let rl=0; for(let i=0;i<tc.t.length;i++) if(reach[i] && tc.t[i]) rl++;
  const flips=Object.keys(STATE.cellFlips.chord).length;
  $('statC').innerHTML=
    '<b>'+tc.legalCount+'</b> of '+tc.size+' cells legal'+(flips?' (λ alone admits '+tc.cut+')':'')
    +'<br>this vocabulary can ask <b>'+popcount(reach)+'</b> of them, <b>'+rl+'</b> legal'
    +'<br>from a state, <b>'+br.mean.toFixed(1)+'</b> of '+vocab.length+' moves are legal · <b>'+pct(br.forced)+'</b> forced · <b>'+pct(br.dead)+'</b> none';
  $('statV').innerHTML='<b>'+tv.legalCount+'</b> of '+tv.size+' cells legal'+(Object.keys(STATE.cellFlips.voice).length?' (λ alone admits '+tv.cut+')':'');
  const mc=chordMarginals(tc), mv=voiceMarginals(tv);
  document.querySelectorAll('.axis').forEach(wrap=>{
    const set=wrap.dataset.set, key=wrap.dataset.key, axes=set==='chord'?CHORD_AXES:VOICE_AXES, marg=set==='chord'?mc:mv;
    const ai=axes.findIndex(a=>a.key===key);
    wrap.querySelectorAll('.marg i u').forEach((u,i)=>{ u.style.height=Math.round(marg[ai][i]*100)+'%'; });
  });
}
function renderHandStat(){
  const el=$('handStat'); if(!el) return;
  const nC=Object.keys(STATE.cellFlips.chord).length, nV=Object.keys(STATE.cellFlips.voice).length, nP=Object.keys(STATE.pins).length;
  const nE=Object.keys(STATE.noteEnv).length, nA=Object.keys(STATE.anchors).length, nB=Object.keys(STATE.barOverrides).length, nL=STATE.touched.filter(Boolean).length;
  const bits=[];
  if(nC+nV) bits.push('<b>'+(nC+nV)+'</b> rule cell'+(nC+nV===1?'':'s')+' flipped');
  if(nP) bits.push('<b>'+nP+'</b> chord'+(nP===1?'':'s')+' pinned');
  if(nA) bits.push('<b>'+nA+'</b> pitch'+(nA===1?'':'es')+' anchored');
  if(nE) bits.push('<b>'+nE+'</b> note'+(nE===1?'':'s')+' with its own envelope');
  if(nB) bits.push('<b>'+nB+'</b> bar'+(nB===1?'':'s')+' with its own scale or aim');
  if(nL) bits.push('<b>'+nL+'</b> lane'+(nL===1?'':'s')+' with painted rhythm');
  el.innerHTML = bits.length ? bits.join('<br>') : 'Nothing yet. Anything you change by hand is marked in magenta wherever it shows up.';
}
function renderSeqTools(){
  const host=$('seqTools'); if(!host) return; host.textContent='';
  const lane = STATE.lane==='all' ? 'all lanes' : VOICE_NAMES[STATE.lane];
  const lab=mk('span','aside','rhythm for '+lane+':'); lab.style.margin='0 2px 0 0'; host.appendChild(lab);
  for(const [id,title,fn] of SEQ_PRESETS){
    const b=mk('button','tiny',id); b.type='button'; b.title=title;
    b.addEventListener('click', ()=>{ applyRhythm(fn); regenerate(); histCommit(); });
    host.appendChild(b);
  }
  const d=mk('button','tiny','chord rhythm'); d.type='button'; d.title='Go back to the rhythm that follows the chords and the grid';
  d.addEventListener('click', ()=>{ applyRhythm(null); regenerate(); histCommit(); }); host.appendChild(d);

  if(STATE.selectedBar!=null){
    const b=STATE.selectedBar, ov=STATE.barOverrides[b]||{};
    const box=mk('span'); box.style.display='inline-flex'; box.style.gap='6px'; box.style.alignItems='center'; box.style.flexWrap='wrap';
    box.appendChild(mk('label',null,'bar '+(b+1)));
    const sc=mk('select'); sc.setAttribute('aria-label','Scale for bar '+(b+1));
    fill(sc, [['','same scale']].concat(SCALE_ORDER.map(k=>[k,SCALE_LABELS[k]])), ov.scale||'');
    sc.addEventListener('change', ()=>{
      const cur=Object.assign({}, STATE.barOverrides[b]); if(sc.value) cur.scale=sc.value; else delete cur.scale;
      if(cur.scale||typeof cur.tension==='number') STATE.barOverrides[b]=cur; else delete STATE.barOverrides[b];
      regenerate(); histCommit();
    });
    box.appendChild(sc);
    const tn=mk('input'); tn.type='range'; tn.min='0'; tn.max='100'; tn.style.width='84px'; tn.setAttribute('aria-label','Tension aim for bar '+(b+1));
    tn.value=String(Math.round((typeof ov.tension==='number'?ov.tension:STATE.tension)*100));
    tn.title='tension aim for this bar: '+tn.value;
    tn.addEventListener('input', ()=>{ STATE.barOverrides[b]=Object.assign({}, STATE.barOverrides[b], {tension:(+tn.value)/100}); tn.title='tension aim for this bar: '+tn.value; scheduleRegenerate(); });
    tn.addEventListener('change', ()=>{ regenerate(); histCommit(); });
    box.appendChild(tn);
    const cl=mk('button','tiny','reset bar'); cl.type='button'; cl.addEventListener('click', ()=>{ delete STATE.barOverrides[b]; regenerate(); histCommit(); });
    box.appendChild(cl);
    host.appendChild(box);
  }
}
function renderKeep(){ const el=$('midiInfo'); if(el) el.textContent=midiSummary(); }

/* ---- everything ------------------------------------------------------------------------------------- */
function renderAll(){
  const c=STATE.composed; if(!c) return;
  ensureSelectedNote();
  renderRollGutter();
  renderStatus(); renderStats(); renderHandStat(); renderSeqTools(); renderKeep();
  drawLattice(); latticeReadout(HOVER.cell);
  drawRoll(); drawSeq(); drawEnv(); noteReadout(HOVER_NOTE.nt && c.notes[HOVER_NOTE.nt.v].find(x=>x.step===HOVER_NOTE.nt.step) || null);
  renderSweep(); renderDyn(); drawBasin(); renderBranches();
}
