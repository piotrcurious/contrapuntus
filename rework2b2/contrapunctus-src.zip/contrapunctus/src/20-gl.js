/* =====================================================================
   7 · DRAWING LAYER
   ---------------------------------------------------------------------
   One small painter interface -- rect, disc (optionally a ring), line,
   dash -- with two back ends: WebGL, which batches a whole frame into one
   triangle list, and Canvas 2D, which draws the same calls immediately.
   The rule space and the score are written against the interface, so a
   browser without WebGL (or a lost context) still gets the same picture.
   ===================================================================== */
const VERT = `
attribute vec2 aPos; attribute vec4 aCol; attribute vec2 aLocal;
attribute float aCircle; attribute float aInner;
uniform vec2 uRes;
varying vec4 vCol; varying vec2 vLocal; varying float vCircle; varying float vInner;
void main(){
  gl_Position = vec4((aPos.x/uRes.x)*2.0-1.0, 1.0-(aPos.y/uRes.y)*2.0, 0.0, 1.0);
  vCol=aCol; vLocal=aLocal; vCircle=aCircle; vInner=aInner;
}`;
const FRAG = `
precision mediump float;
varying vec4 vCol; varying vec2 vLocal; varying float vCircle; varying float vInner;
void main(){
  if(vCircle>0.5){
    float d=length(vLocal);
    if(d>1.0) discard;
    float a=1.0-smoothstep(0.80,1.0,d);
    if(vInner>0.001){ if(d<vInner) discard; a*=smoothstep(vInner-0.16,vInner+0.06,d); }
    gl_FragColor=vec4(vCol.rgb*vCol.a*a, vCol.a*a);
  } else gl_FragColor=vec4(vCol.rgb*vCol.a, vCol.a);
}`;
const STRIDE = 10;

/* ---- colour ------------------------------------------------------------ */
function hexToRGB(h){
  h=(h||'').trim();
  if(h[0]==='#'){
    if(h.length===4) return [parseInt(h[1]+h[1],16)/255, parseInt(h[2]+h[2],16)/255, parseInt(h[3]+h[3],16)/255];
    return [parseInt(h.slice(1,3),16)/255, parseInt(h.slice(3,5),16)/255, parseInt(h.slice(5,7),16)/255];
  }
  const m=h.match(/-?[\d.]+/g);
  return m && m.length>=3 ? [(+m[0])/255,(+m[1])/255,(+m[2])/255] : [0.5,0.5,0.5];
}
function rgba(c,a){ return [c[0],c[1],c[2],a]; }
function mix(a,b,t){ return [a[0]+(b[0]-a[0])*t, a[1]+(b[1]-a[1])*t, a[2]+(b[2]-a[2])*t]; }
function css(c,a){ return 'rgba('+Math.round(c[0]*255)+','+Math.round(c[1]*255)+','+Math.round(c[2]*255)+','+(a==null?(c.length>3?c[3]:1):a)+')'; }

// Colours are read from the stylesheet once per theme change and cached here, as
// [r,g,b] for the GL back end and as strings for 2D canvas and DOM use. (The first
// version asked the browser for a computed style once per note per frame.)
const THEME = {};
function readTheme(){
  const cs=getComputedStyle(document.documentElement);
  const v=(n)=>cs.getPropertyValue(n).trim();
  const T=(n)=>hexToRGB(v(n));
  THEME.bg=T('--gl-bg'); THEME.plate=T('--plate'); THEME.ground=T('--ground');
  THEME.ink=T('--ink'); THEME.dim=T('--ink-dim'); THEME.faint=T('--ink-faint'); THEME.grid=T('--ink-grid');
  THEME.permit=T('--permit'); THEME.forbid=T('--forbid'); THEME.hand=T('--hand');
  THEME.voice=[T('--melody'),T('--mid'),T('--bass')];
  THEME.att=[T('--att1'),T('--att2'),T('--att3')];
  THEME.cls={fixed:T('--cls-fixed'), loop:T('--cls-loop'), tour:T('--cls-tour')};
  THEME.rule=T('--rule'); THEME.ruleSoft=T('--rule-soft');
  THEME.dark=(THEME.bg[0]+THEME.bg[1]+THEME.bg[2])/3 < 0.5;
  THEME.str={ ink:v('--ink'), dim:v('--ink-dim'), faint:v('--ink-faint'), hand:v('--hand'),
    permit:v('--permit'), forbid:v('--forbid'), plate:v('--plate'), bg:v('--gl-bg'),
    voice:[v('--melody'),v('--mid'),v('--bass')] };
  const f=(n,d)=> (v(n)||d).split(',')[0].replace(/['"]/g,'').trim();
  THEME.font={ sans:f('--sans','sans-serif')+', sans-serif', mono:f('--mono','monospace')+', monospace' };
}

/* ---- the painter ------------------------------------------------------- */
function glShader(gl,t,src){
  const s=gl.createShader(t); gl.shaderSource(s,src); gl.compileShader(s);
  if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)){ console.error(gl.getShaderInfoLog(s)); return null; }
  return s;
}
function glProgram(gl){
  const vs=glShader(gl,gl.VERTEX_SHADER,VERT), fs=glShader(gl,gl.FRAGMENT_SHADER,FRAG);
  if(!vs||!fs) return null;
  const p=gl.createProgram();
  gl.attachShader(p,vs); gl.attachShader(p,fs); gl.linkProgram(p);
  if(!gl.getProgramParameter(p,gl.LINK_STATUS)){ console.error(gl.getProgramInfoLog(p)); return null; }
  return p;
}
function canvasPixels(canvas){
  const r=canvas.getBoundingClientRect(), dpr=Math.min(window.devicePixelRatio||1, 2);
  const w=Math.max(2,Math.round(r.width*dpr)), h=Math.max(2,Math.round(r.height*dpr));
  if(canvas.width!==w) canvas.width=w;
  if(canvas.height!==h) canvas.height=h;
  return {w:r.width, h:r.height, dpr};
}

function makePainter(canvas, opts){
  opts = opts||{};
  const P = { canvas, w:0, h:0, kind:'2d', lost:false, onRestore:null };
  let gl=null, prog=null, buf=null, loc=null, arr=[];

  function initGL(){
    try{ gl = canvas.getContext('webgl',{antialias:true, alpha:false, premultipliedAlpha:true}) || canvas.getContext('experimental-webgl'); }catch(e){ gl=null; }
    if(!gl) return false;
    prog = glProgram(gl);
    if(!prog){ gl=null; return false; }
    gl.useProgram(prog);
    buf = gl.createBuffer();
    loc = { pos:gl.getAttribLocation(prog,'aPos'), col:gl.getAttribLocation(prog,'aCol'),
            local:gl.getAttribLocation(prog,'aLocal'), circle:gl.getAttribLocation(prog,'aCircle'),
            inner:gl.getAttribLocation(prog,'aInner'), res:gl.getUniformLocation(prog,'uRes') };
    return true;
  }

  if(!window.__CP_NOGL && !opts.force2d && initGL()){
    P.kind='gl';
    canvas.addEventListener('webglcontextlost', (e)=>{ e.preventDefault(); P.lost=true; });
    canvas.addEventListener('webglcontextrestored', ()=>{
      P.lost = !initGL();
      if(!P.lost && P.onRestore) P.onRestore();
    });
    P.begin = function(){
      if(P.lost || (gl.isContextLost && gl.isContextLost())) return false;
      const px=canvasPixels(canvas); P.w=px.w; P.h=px.h;
      gl.viewport(0,0,canvas.width,canvas.height);
      arr=[];
      return true;
    };
    P.end = function(){
      if(P.lost) return;
      const bg=THEME.bg;
      gl.clearColor(bg[0],bg[1],bg[2],1); gl.clear(gl.COLOR_BUFFER_BIT);
      if(!arr.length) return;
      gl.bindBuffer(gl.ARRAY_BUFFER, buf);
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(arr), gl.DYNAMIC_DRAW);
      const S=STRIDE*4;
      gl.enableVertexAttribArray(loc.pos);    gl.vertexAttribPointer(loc.pos,2,gl.FLOAT,false,S,0);
      gl.enableVertexAttribArray(loc.col);    gl.vertexAttribPointer(loc.col,4,gl.FLOAT,false,S,8);
      gl.enableVertexAttribArray(loc.local);  gl.vertexAttribPointer(loc.local,2,gl.FLOAT,false,S,24);
      gl.enableVertexAttribArray(loc.circle); gl.vertexAttribPointer(loc.circle,1,gl.FLOAT,false,S,32);
      gl.enableVertexAttribArray(loc.inner);  gl.vertexAttribPointer(loc.inner,1,gl.FLOAT,false,S,36);
      gl.uniform2f(loc.res, P.w, P.h);
      gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);   // the shader premultiplies
      gl.drawArrays(gl.TRIANGLES,0,arr.length/STRIDE);
      arr=[];
    };
    P.rect = function(x,y,w,h,c){
      if(w<=0||h<=0) return;
      const r=c[0], g=c[1], b=c[2], al=c[3], x1=x+w, y1=y+h;
      arr.push(x,y,r,g,b,al,0,0,0,0, x1,y,r,g,b,al,0,0,0,0, x,y1,r,g,b,al,0,0,0,0,
               x1,y,r,g,b,al,0,0,0,0, x1,y1,r,g,b,al,0,0,0,0, x,y1,r,g,b,al,0,0,0,0);
    };
    P.disc = function(cx,cy,rad,c,inner){
      const r=c[0], g=c[1], b=c[2], al=c[3], x0=cx-rad, y0=cy-rad, x1=cx+rad, y1=cy+rad, i=inner||0;
      arr.push(x0,y0,r,g,b,al,-1,-1,1,i, x1,y0,r,g,b,al,1,-1,1,i, x0,y1,r,g,b,al,-1,1,1,i,
               x1,y0,r,g,b,al,1,-1,1,i, x1,y1,r,g,b,al,1,1,1,i, x0,y1,r,g,b,al,-1,1,1,i);
    };
    P.line = function(x0,y0,x1,y1,w,c){
      const dx=x1-x0, dy=y1-y0, L=Math.hypot(dx,dy)||1;
      const nx=-dy/L*w/2, ny=dx/L*w/2, r=c[0], g=c[1], b=c[2], al=c[3];
      arr.push(x0+nx,y0+ny,r,g,b,al,0,0,0,0, x1+nx,y1+ny,r,g,b,al,0,0,0,0, x1-nx,y1-ny,r,g,b,al,0,0,0,0,
               x0+nx,y0+ny,r,g,b,al,0,0,0,0, x1-nx,y1-ny,r,g,b,al,0,0,0,0, x0-nx,y0-ny,r,g,b,al,0,0,0,0);
    };
  } else {
    let g=null, dpr=1;
    P.begin = function(){
      const px=canvasPixels(canvas); P.w=px.w; P.h=px.h; dpr=px.dpr;
      g=canvas.getContext('2d');
      g.setTransform(dpr,0,0,dpr,0,0);
      g.fillStyle=css(THEME.bg,1); g.fillRect(0,0,P.w,P.h);
      return true;
    };
    P.end = function(){};
    P.rect = function(x,y,w,h,c){ if(w<=0||h<=0) return; g.fillStyle=css(c); g.fillRect(x,y,w,h); };
    P.disc = function(cx,cy,rad,c,inner){
      g.fillStyle=css(c); g.beginPath(); g.arc(cx,cy,rad*0.94,0,6.2832);
      if(inner>0.001) g.arc(cx,cy,rad*inner,0,6.2832,true);
      g.fill('evenodd');
    };
    P.line = function(x0,y0,x1,y1,w,c){ g.strokeStyle=css(c); g.lineWidth=w; g.beginPath(); g.moveTo(x0,y0); g.lineTo(x1,y1); g.stroke(); };
  }
  P.dash = function(x0,y0,x1,y1,w,c,dash){
    const L=Math.hypot(x1-x0,y1-y0)||1, n=Math.max(1,Math.floor(L/dash));
    for(let i=0;i<n;i+=2){
      const t0=i/n, t1=Math.min(1,(i+1)/n);
      P.line(x0+(x1-x0)*t0, y0+(y1-y0)*t0, x0+(x1-x0)*t1, y0+(y1-y0)*t1, w, c);
    }
  };
  return P;
}

// a 2D canvas, sized for the screen, cleared and ready (used by the sequencer, the
// envelope editor and the maps, which are text- and edge-heavy)
function ctx2d(canvas){
  const px=canvasPixels(canvas);
  const g=canvas.getContext('2d');
  g.setTransform(px.dpr,0,0,px.dpr,0,0);
  g.clearRect(0,0,px.w,px.h);
  return {g, w:px.w, h:px.h};
}

/* ---- one floating tooltip for every chart ------------------------------ */
const TIP = { el:null };
function tipEl(){
  if(!TIP.el){
    const d=document.createElement('div'); d.id='tip'; d.setAttribute('role','tooltip'); d.hidden=true;
    document.body.appendChild(d); TIP.el=d;
  }
  return TIP.el;
}
// lines: array of strings (textContent only: nothing here is ever parsed as markup)
function showTip(clientX, clientY, lines){
  const el=tipEl();
  el.textContent='';
  lines.forEach((t,i)=>{ const d=document.createElement(i===0?'b':'span'); d.textContent=t; el.appendChild(d); });
  el.hidden=false;
  const r=el.getBoundingClientRect(), vw=document.documentElement.clientWidth, vh=window.innerHeight;
  let x=clientX+14, y=clientY+16;
  if(x+r.width>vw-6) x=Math.max(6, clientX-r.width-14);
  if(y+r.height>vh-6) y=Math.max(6, clientY-r.height-14);
  el.style.transform='translate('+Math.round(x)+'px,'+Math.round(y)+'px)';
}
function hideTip(){ if(TIP.el) TIP.el.hidden=true; }

/* ---- small DOM helpers ---------------------------------------------------- */
function $(id){ return document.getElementById(id); }
function fmt2(x){ return x.toFixed(2).replace(/^0\./,'.').replace(/^-0\./,'-.'); }
function fill(sel, entries, value){
  sel.textContent='';
  for(const [v,l] of entries){ const o=document.createElement('option'); o.value=v; o.textContent=l; sel.appendChild(o); }
  if(value!=null) sel.value=String(value);
}
function mk(tag, cls, text){
  const e=document.createElement(tag);
  if(cls) e.className=cls;
  if(text!=null) e.textContent=text;
  return e;
}
const REDUCED_MOTION = ()=> !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);
let TOAST_T=null;
function toast(msg, ms){
  const t=$('toast'); if(!t) return;
  t.textContent=msg; t.hidden=false;
  clearTimeout(TOAST_T); TOAST_T=setTimeout(()=>{ t.hidden=true; }, ms||2600);
}
