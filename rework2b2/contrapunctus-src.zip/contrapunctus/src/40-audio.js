/* =====================================================================
   14 · SOUND
   ---------------------------------------------------------------------
   Each note is scheduled from the note list of 30-notes.js: the gain
   follows envSchedule() up to note-off and then falls exponentially from
   the level it had reached, which is the curve the editor draws. The
   pitch is the fractional one of the tuning in force.

   A play run owns one gain bus per voice, so Stop can fade everything that
   is ringing, stop the oscillators and cut the bus, instead of leaving the
   release tails to finish by themselves. The scheduler looks 0.2 s ahead
   (1.5 s when the tab is hidden, because timers are throttled there) and
   keeps a short list of (time, step) marks, so the playhead follows the
   audio clock through a tempo change.
   ===================================================================== */
const AUD = { ctx:null, master:null, comp:null, conv:null, ret:null, pans:[], run:null, raf:0 };
const RETURN_LEVEL = 0.3;
const NOW = { seg:-1 };

// a fixed noise sequence, so the room sounds the same every time
function seededNoise(seed){
  let a=seed|0;
  return function(){ a=(a+0x6D2B79F5)|0; let t=Math.imul(a^(a>>>15),1|a); t=(t+Math.imul(t^(t>>>7),61|t))^t; return ((t^(t>>>14))>>>0)/4294967296; };
}
function impulse(ctx, sec, decay){
  const rnd=seededNoise(0x5eed1234), n=Math.max(1,Math.floor(ctx.sampleRate*sec)), b=ctx.createBuffer(2,n,ctx.sampleRate);
  for(let ch=0;ch<2;ch++){ const d=b.getChannelData(ch); for(let i=0;i<n;i++) d[i]=(rnd()*2-1)*Math.pow(1-i/n, decay); }
  return b;
}
function ensureAudio(){
  if(AUD.ctx) return AUD;
  const AC=window.AudioContext||window.webkitAudioContext; if(!AC) return null;
  let ctx; try{ ctx=new AC(); }catch(e){ return null; }
  const master=ctx.createGain(); master.gain.value=0.72;
  const comp=ctx.createDynamicsCompressor(); master.connect(comp); comp.connect(ctx.destination);
  const conv=ctx.createConvolver(); try{ conv.buffer=impulse(ctx,2.2,2.6); }catch(e){}
  const ret=ctx.createGain(); ret.gain.value=RETURN_LEVEL; conv.connect(ret); ret.connect(comp);
  const pans=[], pv=[0.3,0,-0.3];
  for(let v=0;v<3;v++){
    let p;
    if(ctx.createStereoPanner){ p=ctx.createStereoPanner(); p.pan.value=pv[v]; }
    else { p=ctx.createPanner(); p.setPosition(pv[v],0,1-Math.abs(pv[v])); }
    p.connect(master);
    const send=ctx.createGain(); send.gain.value=0.2; p.connect(send); send.connect(conv);
    pans.push(p);
  }
  Object.assign(AUD,{ctx,master,comp,conv,ret,pans});
  return AUD;
}

const WAVES=['triangle','sawtooth','sine'];
function playNote(R, nt, t0){
  const ctx=AUD.ctx, e=nt.e, v=nt.v, gate=Math.max(0.02, e.gate*secondsPerStep()), off=t0+gate, rel=Math.max(0.005, e.r);
  const o1=ctx.createOscillator(), o2=ctx.createOscillator();
  o1.type=WAVES[v]; o2.type=WAVES[v];
  const f=midiToFreq(nt.fpitch);
  o1.frequency.setValueAtTime(f,t0); o2.frequency.setValueAtTime(f,t0); o2.detune.setValueAtTime(7,t0);
  const g1=ctx.createGain(); g1.gain.value=0.55;
  const g2=ctx.createGain(); g2.gain.value=0.15;
  const flt=ctx.createBiquadFilter(); flt.type='lowpass';
  const base=900+(v===0?1500:v===1?750:320);
  flt.frequency.setValueAtTime(base,t0); flt.frequency.linearRampToValueAtTime(Math.max(220,base*0.5), off); flt.Q.value=1.05;
  const env=ctx.createGain(), pts=envSchedule(e, gate);
  env.gain.setValueAtTime(0,t0);
  for(let i=1;i<pts.length;i++) env.gain.linearRampToValueAtTime(ENV_PEAK*pts[i][1], t0+pts[i][0]);
  const g0=ENV_PEAK*pts[pts.length-1][1];
  if(g0>ENV_FLOOR){ env.gain.setValueAtTime(g0, off); env.gain.exponentialRampToValueAtTime(ENV_FLOOR, off+rel); }
  else env.gain.setValueAtTime(0, off);
  o1.connect(g1); o2.connect(g2); g1.connect(flt); g2.connect(flt); flt.connect(env); env.connect(R.bus[v]);
  const rec={o1,o2,env}; R.active.add(rec);
  o1.onended=()=>{ R.active.delete(rec); try{ env.disconnect(); }catch(err){} };
  o1.start(t0); o2.start(t0);
  o1.stop(off+rel+0.04); o2.stop(off+rel+0.04);
}
function scheduleStep(R, step, when){
  const c=STATE.composed, arr=c&&c.byStep&&c.byStep[step]; if(!arr) return;
  for(const nt of arr) playNote(R, nt, when);
}
function schedulerTick(){
  const R=AUD.run; if(!R) return;
  const ctx=AUD.ctx, c=STATE.composed, now=ctx.currentTime;
  if(c && c.byStep){
    const ahead=document.hidden ? 1.5 : 0.2;
    if(R.nextTime<now) R.nextTime=now+0.03;          // the page was starved: skip ahead instead of firing a burst
    let guard=0;
    while(R.nextTime<now+ahead && guard++<512){
      if(R.nextStep>=c.total) R.nextStep=0;
      const sps=secondsPerStep();
      scheduleStep(R, R.nextStep, R.nextTime);
      R.marks.push({t:R.nextTime, step:R.nextStep, sps});
      R.nextTime+=sps; R.nextStep++;
    }
    while(R.marks.length>8 && R.marks[1].t<now-1) R.marks.shift();
  }
  R.timer=setTimeout(schedulerTick, 25);
}
// where the audio clock is, in steps (fractional), or null when nothing plays
function playPos(){
  const R=AUD.run; if(!R||!R.marks.length) return null;
  const now=AUD.ctx.currentTime; let m=null;
  for(let i=R.marks.length-1;i>=0;i--) if(R.marks[i].t<=now){ m=R.marks[i]; break; }
  if(!m) return 0;
  return m.step+Math.min(1,(now-m.t)/m.sps);
}
function frame(){
  if(!AUD.run) return;
  const p=playPos();
  if(p!=null){
    STATE.stepFloat=p; setPlayhead(p);
    const c=STATE.composed;
    if(c){
      const g=Math.min(c.segments-1, segOfStep(Math.floor(p)));
      if(g!==NOW.seg){ NOW.seg=g; const bs=$('rollLabels').querySelectorAll('.seg:not(.ghost)'); bs.forEach((b,i)=>b.classList.toggle('now', i===g)); }
      const sc=$('seqScroll'), L=seqLayout();
      if(L.scrolls && sc){ const x=p/c.total*L.w; if(x<sc.scrollLeft+16 || x>sc.scrollLeft+sc.clientWidth-48) sc.scrollLeft=Math.max(0,x-sc.clientWidth*0.2); }
    }
  }
  AUD.raf=requestAnimationFrame(frame);
}
function play(){
  const A=ensureAudio();
  if(!A){ toast('This browser has no Web Audio, so there is nothing to play through.', 4200); return false; }
  if(A.ctx.state==='suspended'){ try{ A.ctx.resume(); }catch(e){} }
  if(AUD.run) stopSound();
  if(!STATE.composed) regenerate();
  const ctx=A.ctx, now=ctx.currentTime;
  const bus=[0,1,2].map(v=>{ const g=ctx.createGain(); g.gain.value=1; g.connect(A.pans[v]); return g; });
  A.ret.gain.cancelScheduledValues(now); A.ret.gain.setValueAtTime(RETURN_LEVEL, now);
  AUD.run={bus, active:new Set(), nextStep:0, nextTime:now+0.08, marks:[], timer:0};
  STATE.playing=true; NOW.seg=-1;
  schedulerTick(); frame(); updatePlayButton();
  return true;
}
// silence what is ringing: fade the buses and the room, stop every oscillator, then cut the buses
function stopSound(){
  const R=AUD.run; if(!R) return;
  AUD.run=null; clearTimeout(R.timer); cancelAnimationFrame(AUD.raf);
  const ctx=AUD.ctx, now=ctx.currentTime;
  for(const g of R.bus){ g.gain.cancelScheduledValues(now); g.gain.setTargetAtTime(0, now, 0.012); }
  AUD.ret.gain.cancelScheduledValues(now); AUD.ret.gain.setTargetAtTime(0, now, 0.03);
  for(const rec of R.active){ try{ rec.o1.stop(now+0.08); rec.o2.stop(now+0.08); }catch(e){} }
  setTimeout(()=>{ for(const g of R.bus){ try{ g.disconnect(); }catch(e){} } R.active.clear(); }, 160);
}
function stop(){
  stopSound(); STATE.playing=false; STATE.stepFloat=0; NOW.seg=-1;
  setPlayhead(null);
  const host=$('rollLabels'); if(host) host.querySelectorAll('.seg.now').forEach(b=>b.classList.remove('now'));
  updatePlayButton();
}
function togglePlay(){ if(STATE.playing) stop(); else play(); }
