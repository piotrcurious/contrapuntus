/* =====================================================================
   8 · RENDERING
   ===================================================================== */
let GL_LAT=null, GL_ROLL=null;
const HOVER = {lattice:null, branch:null, seq:null};
const DRAG = {axis:null};

/* ---- notes: gates resolved once, so the score, the audio and the
       sounding-aggregate lane can never disagree ---- */
function buildNotes(c){
  const sps = secondsPerStep(), total=c.total;
  const notes=[[],[],[]];
  for(let v=0; v<3; v++){
    const nextOn=new Int32Array(total); let nx=total;
    for(let s=total-1;s>=0;s--){ nextOn[s]=nx; if(STATE.onsets[v][s]) nx=s; }
    const base=STATE.voiceEnv[v];
    for(let s=0;s<total;s++){
      const p=c.pitches[v][s]; if(p==null) continue;
      const span=Math.max(1, nextOn[s]-s);
      const o=STATE.noteEnv[v+':'+s];
      const e={a:base.a, d:base.d, s:base.s, r:base.r, gate:span*base.gateRatio, custom:false};
      if(o){ for(const k of ['a','d','s','r','gate']) if(o[k]!=null){ e[k]=o[k]; e.custom=true; } }
      e.gate=Math.max(0.03,e.gate);
      notes[v].push({v, step:s, pitch:p, e, span, tailSteps:e.r/sps,
        deco:c.deco[v][s], fell:c.fell[v][s], anchored: v===0 && STATE.anchors[s]!=null});
    }
  }
  // what is actually ringing at each step, tails included
  const sounding=new Array(total);
  for(let s=0;s<total;s++){
    const pcs=[]; let tail=0, n=0;
    for(let v=0;v<3;v++) for(const nt of notes[v]){
      if(nt.step>s) break;
      const end = nt.step + nt.e.gate + nt.tailSteps;
      if(s < end){ pcs.push(pcOf(nt.pitch)); n++; if(s >= nt.step+nt.e.gate) tail++; }
    }
    const set=[...new Set(pcs)];
    const g=Math.min(segOfStep(s), c.chords.length-1);
    const chordPCs=c.chords[g].tones.map(pcOf);
    sounding[s]={pcs:set, tension:chordTension(set), voices:n, tails:tail,
      foreign:set.filter(p=>!chordPCs.includes(p)).length};
  }
  const byStep=new Array(total);
  for(let v=0;v<3;v++) for(const nt of notes[v]){ (byStep[nt.step]||(byStep[nt.step]=[])).push(nt); }
  c.notes=notes; c.sounding=sounding; c.byStep=byStep;
  return c;
}

/* =========== rule lattice ============================================ */
function latticeSpec(){
  const set=STATE.lattice.set;
  return set==='chord'
    ? {axes:CHORD_AXES, dims:CHORD_DIMS, strides:CHORD_STR.strides, tbl:chordTable(),
       used:STATE.composed&&STATE.composed.chordCells, seq:STATE.composed&&STATE.composed.chordCellSeq,
       flips:STATE.cellFlips.chord, proj:PROJ.chord}
    : {axes:VOICE_AXES, dims:VOICE_DIMS, strides:VOICE_STR.strides, tbl:voiceTable(),
       used:STATE.composed&&STATE.composed.voiceCells, seq:STATE.composed&&STATE.composed.voiceCellSeq,
       flips:STATE.cellFlips.voice, proj:PROJ.voice};
}
let LAYOUT=null;
function layoutLattice(){
  const sp=latticeSpec();
  const cv=document.getElementById('latticeCanvas'), rect=cv.getBoundingClientRect();
  const W=rect.width||600, H=rect.height||420;
  const cells=cellList(sp.dims), P=sp.proj;
  const raw=new Float64Array(cells.length*2);
  const vecOf=(key,val,n)=>{
    const b=P.basis[key];
    if(P.cyclic[key]){
      const R=Math.hypot(b[0],b[1]), th=Math.atan2(b[1],b[0]) + 2*Math.PI*val/n;
      return [Math.cos(th)*R, Math.sin(th)*R];
    }
    return [b[0]*val, b[1]*val];
  };
  let minX=1e9,maxX=-1e9,minY=1e9,maxY=-1e9;
  for(let f=0;f<cells.length;f++){
    let x=0,y=0;
    for(let i=0;i<sp.axes.length;i++){
      const a=sp.axes[i], v=vecOf(a.key, cells[f][i], a.n);
      x+=v[0]; y+=v[1];
    }
    raw[f*2]=x; raw[f*2+1]=y;
    if(x<minX)minX=x; if(x>maxX)maxX=x; if(y<minY)minY=y; if(y>maxY)maxY=y;
  }
  const pad=26;
  const sx=(W-2*pad)/Math.max(1e-6,maxX-minX), sy=(H-2*pad)/Math.max(1e-6,maxY-minY);
  const sc=Math.min(sx,sy);
  const ox=pad+(W-2*pad-(maxX-minX)*sc)/2-minX*sc;
  const oy=pad+(H-2*pad-(maxY-minY)*sc)/2-minY*sc;
  const pts=new Float64Array(cells.length*2);
  for(let f=0;f<cells.length;f++){ pts[f*2]=ox+raw[f*2]*sc; pts[f*2+1]=oy+raw[f*2+1]*sc; }
  // origin of the coordinate frame + a handle per axis
  let ox0=0, oy0=0;
  for(let i=0;i<sp.axes.length;i++){ const a=sp.axes[i], v=vecOf(a.key,0,a.n); ox0+=v[0]; oy0+=v[1]; }
  const org=[ox+ox0*sc, oy+oy0*sc];
  const handles=sp.axes.map(a=>{
    const b=P.basis[a.key];
    const n = P.cyclic[a.key] ? 1 : Math.max(1, a.n-1);
    return {key:a.key, label:a.label, what:a.what, cyclic:!!P.cyclic[a.key],
      x:org[0]+b[0]*n*sc, y:org[1]+b[1]*n*sc, n};
  });
  LAYOUT={sp, cells, pts, sc, org, handles, W, H};
  return LAYOUT;
}
function drawLattice(){
  if(!GL_LAT) return;
  const L=layoutLattice(), sp=L.sp, cells=L.cells, pts=L.pts;
  const a=[];
  const maxCost = Math.max(1e-6, Math.max.apply(null, Array.from(sp.tbl.costs)));

  // lattice edges along the two most extended axes — the mesh makes the
  // projection legible without drawing all 4·|L| of them
  const mag = sp.axes.map(ax=>{ const b=sp.proj.basis[ax.key]; return Math.hypot(b[0],b[1])*(sp.proj.cyclic[ax.key]?1:ax.n); });
  const rank = sp.axes.map((ax,i)=>i).sort((x,y)=>mag[y]-mag[x]).slice(0,2);
  const edgeCol = rgba(THEME.faint, THEME.dark?0.26:0.34);
  for(const ai of rank){
    const st=sp.strides[ai], n=sp.axes[ai].n;
    for(let f=0; f<cells.length; f++){
      if(cells[f][ai] >= n-1) continue;
      const g=f+st;
      pushLine(a, pts[f*2],pts[f*2+1], pts[g*2],pts[g*2+1], 1, edgeCol);
    }
  }
  // cells: fill = legal, hue = cost surface
  for(let f=0; f<cells.length; f++){
    const legal=sp.tbl.t[f], cost=sp.tbl.costs[f]/maxCost;
    const col=coolWarm(cost);
    const x=pts[f*2], y=pts[f*2+1];
    if(legal) pushDisc(a,x,y,3.6, rgba(col,0.92));
    else pushDisc(a,x,y,1.7, rgba(col,THEME.dark?0.34:0.3));
  }
  // cells the piece leans on
  if(sp.used) for(const f of sp.used) pushDisc(a, pts[f*2], pts[f*2+1], 7.2, rgba(THEME.ink,0.85), 0.72);
  // the order it used them
  if(sp.seq && sp.seq.length>1){
    for(let i=1;i<sp.seq.length;i++){
      const p=sp.seq[i-1], q=sp.seq[i];
      if(p===q) continue;
      pushLine(a, pts[p*2],pts[p*2+1], pts[q*2],pts[q*2+1], 1.5, rgba(THEME.ink,0.42));
    }
  }
  // hand-flipped cells
  for(const k in sp.flips){
    if(sp.flips[k]==null) continue;
    const c=k.split(',').map(Number);
    let f=0; for(let i=0;i<c.length;i++) f+=c[i]*sp.strides[i];
    pushDisc(a, pts[f*2], pts[f*2+1], 9, rgba(THEME.hand,0.95), 0.76);
  }
  // a road not taken, through the same space
  const gh=ghostCells();
  if(gh && gh.length>1){
    for(let i=1;i<gh.length;i++){
      const p=gh[i-1], q=gh[i];
      if(p===q) continue;
      pushDash(a, pts[p*2],pts[p*2+1], pts[q*2],pts[q*2+1], 1.5, rgba(THEME.hand,0.8), 7);
    }
    for(const f of gh) pushDisc(a, pts[f*2], pts[f*2+1], 4.6, rgba(THEME.hand,0.55), 0.55);
  }
  // hover
  if(HOVER.lattice!=null){
    const f=HOVER.lattice;
    pushDisc(a, pts[f*2], pts[f*2+1], 10, rgba(THEME.ink,0.9), 0.85);
  }
  // the projection frame itself
  for(const h of L.handles){
    pushLine(a, L.org[0], L.org[1], h.x, h.y, 1.2, rgba(THEME.ink, DRAG.axis===h.key?0.9:0.4));
    pushDisc(a, h.x, h.y, DRAG.axis===h.key?6:4.6, rgba(THEME.ink, DRAG.axis===h.key?1:0.72));
  }
  pushDisc(a, L.org[0], L.org[1], 2.6, rgba(THEME.ink,0.7));
  drawGL(GL_LAT, a);

  const el=document.getElementById('latticeLabels');
  el.innerHTML='';
  for(const h of L.handles){
    const d=document.createElement('div');
    d.className='tag';
    d.style.left=h.x+'px'; d.style.top=(h.y-13)+'px'; d.style.color=cssVar('--ink');
    d.textContent=h.label + (h.cyclic?'\u21bb':'');
    el.appendChild(d);
  }
}
function ghostCells(){
  const c=STATE.composed; if(!c||!STATE.show.ghosts) return null;
  const b=HOVER.branch;
  if(!b) return null;
  if(STATE.lattice.set!=='chord') return null;
  return b.cells.map(x=>cIdx(x.d,x.tau,x.rho,x.eta));
}
function latticePick(mx,my){
  if(!LAYOUT) return {};
  for(const h of LAYOUT.handles) if(Math.hypot(mx-h.x,my-h.y)<11) return {handle:h};
  let best=-1, bd=13;
  const pts=LAYOUT.pts;
  for(let f=0;f<pts.length/2;f++){
    const d=Math.hypot(mx-pts[f*2], my-pts[f*2+1]);
    if(d<bd){ bd=d; best=f; }
  }
  return best>=0 ? {cell:best} : {};
}
function latticeReadout(f){
  const el=document.getElementById('latticeRead');
  if(f==null){ el.innerHTML='&nbsp;'; return; }
  const sp=latticeSpec(), c=cellList(sp.dims)[f];
  const parts=sp.axes.map((a,i)=>a.label+' '+a.tick(c[i]));
  const maxCost=Math.max.apply(null, Array.from(sp.tbl.costs));
  const legal=sp.tbl.t[f];
  const k=c.join(',');
  const flipped=sp.flips[k]!=null;
  const used=sp.used && sp.used.has(f);
  el.innerHTML = parts.join('  ') + '   \u00b7   cost <b>'+(sp.tbl.costs[f]/maxCost).toFixed(2)+'</b>'
    + '   \u00b7   <b>'+(legal?'legal':'not legal')+'</b>'
    + (used?'   \u00b7   <b>used by the piece</b>':'')
    + (flipped?'   \u00b7   <span class="hand">flipped by you</span>':'');
}

/* =========== score ==================================================== */
const ROLL_LO=33, ROLL_HI=88;
function drawRoll(playhead){
  const c=STATE.composed; if(!c) return;
  const cv=document.getElementById('rollCanvas'), rect=cv.getBoundingClientRect();
  const W=rect.width||600, H=rect.height||322;
  const soundH = STATE.show.sounding ? 26 : 0;
  const rollH = H - soundH;
  const stepW=W/c.total;
  const yOf=(m)=> rollH*(1-(m-ROLL_LO)/(ROLL_HI-ROLL_LO));
  const a=[];
  const scalePCs=SCALES[STATE.scaleName].map(o=>(STATE.root+o)%12);
  for(let m=REGISTERS[2].lo;m<=REGISTERS[0].hi;m++){
    if(!scalePCs.includes(pcOf(m))) continue;
    pushRect(a,0,yOf(m)-0.5,W,1, rgba(THEME.faint, pcOf(m)===STATE.root?0.30:0.13));
  }
  for(let b=0;b<=c.bars||b<=STATE.bars;b++){
    if(b>STATE.bars) break;
    pushRect(a, b*STATE.stepsPerBar*stepW-0.5, 0, 1, rollH, rgba(THEME.faint, b%4===0?0.5:0.22));
  }
  const segW=c.L*stepW;
  for(let g=1; g<c.segments; g++) pushRect(a, g*segW-0.5, 0, 1, rollH, rgba(THEME.faint,0.16));

  for(let v=0; v<3; v++){
    const col=THEME.voice[v];
    for(const nt of c.notes[v]){
      const x=nt.step*stepW, y=yOf(nt.pitch);
      const w=Math.max(2, nt.e.gate*stepW);
      const alpha = nt.fell ? 0.34 : (nt.deco ? 0.66 : 0.96);
      pushRect(a, x+0.5, y-3.5, w, 7, rgba(col,alpha));
      pushRect(a, x+0.5, y-4.5, 1.8, 9, rgba(col,Math.min(1,alpha+0.2)));
      if(STATE.show.tails && nt.tailSteps>0.02){
        const tw=nt.tailSteps*stepW, n=8;
        for(let i=0;i<n;i++){
          const t0=i/n, t1=(i+1)/n;
          pushRect(a, x+w+tw*t0, y-2, tw*(t1-t0)+0.6, 4, rgba(col, alpha*0.5*(1-t1)));
        }
      }
      if(nt.anchored) pushDisc(a, x+1.5, y, 4.4, rgba(THEME.hand,0.95), 0.5);
    }
  }
  if(STATE.show.sounding){
    pushRect(a,0,rollH,W,soundH, rgba(THEME.faint,0.08));
    for(let s=0;s<c.total;s++){
      const sd=c.sounding[s];
      const h=4+18*clamp01(sd.voices/5);
      pushRect(a, s*stepW+0.5, rollH+soundH-h-2, Math.max(1,stepW-1), h, rgba(coolWarm(sd.tension/0.55), 0.8));
      if(sd.foreign>0) pushRect(a, s*stepW+0.5, rollH+1, Math.max(1,stepW-1), 2, rgba(THEME.hand,0.85));
    }
  }
  if(playhead!=null && playhead>=0) pushRect(a, playhead*stepW-1, 0, 2, rollH, rgba(THEME.ink,0.8));
  drawGL(GL_ROLL, a);
  drawRollLabels(c, stepW, rollH);
}
function drawRollLabels(c, stepW, rollH){
  const el=document.getElementById('rollLabels'); el.innerHTML='';
  const gh = (STATE.show.ghosts && HOVER.branch) ? HOVER.branch : null;
  for(let g=0; g<c.chords.length; g++){
    const x=g*c.L*stepW, w=c.L*stepW;
    const d=document.createElement('div');
    d.className='seg';
    d.style.left=(x+2)+'px'; d.style.width=Math.max(0,w-4)+'px';
    const t=c.chords[g].tensionVal;
    d.style.color=css(coolWarm(t/0.55));
    if(STATE.pins[g]) d.style.color=cssVar('--hand');
    if(g===STATE.selectedSeg) d.style.background=css(THEME.faint,0.16);
    d.textContent=(STATE.pins[g]?'\u25c6':'')+c.chords[g].roman;
    el.appendChild(d);
    if(gh && g>=STATE.selectedSeg && (g-STATE.selectedSeg)<gh.chords.length){
      const alt=gh.chords[g-STATE.selectedSeg];
      if(alt.key!==c.chords[g].key){
        const e=document.createElement('div');
        e.className='seg';
        e.style.left=(x+2)+'px'; e.style.width=Math.max(0,w-4)+'px';
        e.style.top='15px'; e.style.color=cssVar('--hand'); e.style.opacity='0.9';
        e.textContent=alt.roman;
        el.appendChild(e);
      }
    }
  }
  if(STATE.show.sounding){
    const d=document.createElement('div');
    d.className='seg'; d.style.top=(rollH+2)+'px'; d.style.left='4px'; d.style.color=cssVar('--ink-faint');
    d.textContent='what is actually ringing';
    el.appendChild(d);
  }
}
function rollSeedFromClick(e){
  const c=STATE.composed; if(!c) return;
  const cv=document.getElementById('rollCanvas'), rect=cv.getBoundingClientRect();
  const lx=e.clientX-rect.left, ly=e.clientY-rect.top;
  const soundH=STATE.show.sounding?26:0, rollH=rect.height-soundH;
  if(ly>rollH) return;
  const stepW=rect.width/c.total, step=Math.floor(lx/stepW);
  if(step<0||step>=c.total) return;
  const approx=ROLL_LO+(1-ly/rollH)*(ROLL_HI-ROLL_LO);
  if(approx < REGISTERS[0].lo-4){ STATE.selectedSeg=Math.min(c.segments-1, Math.max(1,segOfStep(step))); renderAll(); return; }
  const scalePCs=SCALES[STATE.scaleName].map(o=>(STATE.root+o)%12);
  let best=null,bd=1e9;
  for(let m=REGISTERS[0].lo;m<=REGISTERS[0].hi;m++){
    if(!scalePCs.includes(pcOf(m))) continue;
    const d=Math.abs(m-approx); if(d<bd){ bd=d; best=m; }
  }
  if(best==null) return;
  if(STATE.anchors[step]===best){ delete STATE.anchors[step]; }
  else { STATE.anchors[step]=best; STATE.onsets[0][step]=true; }
  if(step < STATE.stepsPerBar) STATE.seed.voice[0]=STATE.anchors[0]!=null?STATE.anchors[0]:STATE.seed.voice[0];
  regenerate();
}

/* =========== sequencer ================================================ */
const SEQ={ruler:20, lane:43, onset:28, env:15};
function seqGeom(){
  const cv=document.getElementById('seqCanvas');
  const rect=cv.getBoundingClientRect();
  const total=STATE.bars*STATE.stepsPerBar;
  return {rect, total, stepW:rect.width/total};
}
function drawSeq(){
  const c=STATE.composed; if(!c) return;
  const cv=document.getElementById('seqCanvas');
  const {g,w,h}=ctx2d(cv);
  const total=c.total, stepW=w/total;
  const inkDim=cssVar('--ink-dim'), faint=cssVar('--ink-faint');
  g.font='10px '+cssVar('--mono').split(',')[0].replace(/'/g,'')+', monospace';
  g.textBaseline='middle';

  // ruler
  for(let b=0;b<STATE.bars;b++){
    const x=b*STATE.stepsPerBar*stepW;
    g.fillStyle = b===STATE.selectedBar ? css(THEME.faint,0.18) : 'transparent';
    if(b===STATE.selectedBar) g.fillRect(x,0,STATE.stepsPerBar*stepW,SEQ.ruler);
    g.fillStyle=faint; g.fillText(String(b+1), x+4, SEQ.ruler/2);
    const ov=STATE.barOverrides[b];
    if(ov && (ov.scale||typeof ov.tension==='number')){
      g.fillStyle=cssVar('--hand'); g.beginPath(); g.arc(x+18,SEQ.ruler/2,2.6,0,7); g.fill();
    }
  }
  g.strokeStyle=css(THEME.faint,0.35); g.lineWidth=1;
  g.beginPath(); g.moveTo(0,SEQ.ruler+0.5); g.lineTo(w,SEQ.ruler+0.5); g.stroke();

  for(let v=0; v<3; v++){
    const top=SEQ.ruler + v*SEQ.lane;
    const col=cssVar(['--melody','--mid','--bass'][v]);
    for(let s=0;s<total;s++){
      const x=s*stepW;
      const on=STATE.onsets[v][s];
      g.fillStyle = on ? col : css(THEME.faint, s%STATE.stepsPerBar===0?0.16:0.08);
      g.fillRect(x+0.5, top+3, Math.max(1,stepW-1), SEQ.onset-6);
      if(v===0 && STATE.anchors[s]!=null && on){
        g.fillStyle=cssVar('--hand'); g.fillRect(x+0.5, top+3, Math.max(1,stepW-1), 3);
      }
    }
    // envelope band: bar width shows the gate against the distance to the next note
    const eTop=top+SEQ.onset;
    g.fillStyle=css(THEME.faint,0.07); g.fillRect(0,eTop,w,SEQ.env);
    for(const nt of c.notes[v]){
      const x=nt.step*stepW;
      const gw=nt.e.gate*stepW, tw=nt.tailSteps*stepW;
      const sel = STATE.selectedNote && STATE.selectedNote.v===v && STATE.selectedNote.step===nt.step;
      g.fillStyle = nt.e.custom ? cssVar('--hand') : css(THEME.dim, 0.75);
      g.fillRect(x+0.5, eTop+5, Math.max(1.5,gw-1), 5);
      if(tw>1){ g.fillStyle = css(nt.e.custom?THEME.hand:THEME.dim, 0.26); g.fillRect(x+0.5+gw, eTop+6, tw, 3); }
      if(nt.e.gate > nt.span + 0.02){ g.fillStyle=cssVar('--hand'); g.fillRect(x+gw-1.5, eTop+2, 2, 11); }
      if(sel){ g.strokeStyle=cssVar('--ink'); g.lineWidth=1;
        g.strokeRect(x+0.5, eTop+1.5, Math.max(3,gw), SEQ.env-3); }
    }
    g.strokeStyle=css(THEME.faint,0.22);
    g.beginPath(); g.moveTo(0,eTop+SEQ.env+0.5); g.lineTo(w,eTop+SEQ.env+0.5); g.stroke();
    g.fillStyle=inkDim;
    g.font='10px '+cssVar('--sans').split(',')[0].replace(/'/g,'')+', sans-serif';
    g.fillText(VOICE_NAMES[v], 4, top+SEQ.onset/2);
  }
  for(let b=0;b<=STATE.bars;b++){
    const x=b*STATE.stepsPerBar*stepW;
    g.strokeStyle=css(THEME.faint, b%4===0?0.45:0.2); g.lineWidth=1;
    g.beginPath(); g.moveTo(x+0.5,SEQ.ruler); g.lineTo(x+0.5,h); g.stroke();
  }
  if(STATE.playing){
    const x=STATE.stepFloat*stepW;
    g.strokeStyle=cssVar('--ink'); g.lineWidth=1.5;
    g.beginPath(); g.moveTo(x,SEQ.ruler); g.lineTo(x,h); g.stroke();
  }
}
function seqHit(e){
  const cv=document.getElementById('seqCanvas'), rect=cv.getBoundingClientRect();
  const x=e.clientX-rect.left, y=e.clientY-rect.top;
  const total=STATE.bars*STATE.stepsPerBar, stepW=rect.width/total;
  const s=Math.floor(x/stepW);
  if(s<0||s>=total) return null;
  if(y<SEQ.ruler) return {kind:'bar', bar:Math.floor(s/STATE.stepsPerBar)};
  const v=Math.floor((y-SEQ.ruler)/SEQ.lane);
  if(v<0||v>2) return null;
  const within=(y-SEQ.ruler)-v*SEQ.lane;
  return {kind: within<SEQ.onset ? 'onset' : 'env', v, step:s};
}

/* =========== envelope ================================================= */
const ENV={pad:{l:34,r:14,t:14,b:22}};
let ENV_GEO=null;
function envTarget(){
  const n=STATE.selectedNote;
  if(!n) return null;
  const c=STATE.composed;
  if(!c||!c.notes) return null;
  const nt=c.notes[n.v].find(x=>x.step===n.step);
  return nt||null;
}
function drawEnv(){
  const cv=document.getElementById('envCanvas');
  const {g,w,h}=ctx2d(cv);
  const nt=envTarget();
  const el=document.getElementById('envRead');
  if(!nt){
    g.fillStyle=cssVar('--ink-faint');
    g.font='13px '+cssVar('--sans').split(',')[0].replace(/'/g,'')+', sans-serif';
    g.textAlign='center'; g.textBaseline='middle';
    g.fillText('Click the narrow band under a note to shape it.', w/2, h/2);
    el.innerHTML='&nbsp;';
    ENV_GEO=null; return;
  }
  const sps=secondsPerStep(), e=nt.e;
  const span = Math.max(e.a+e.d+0.05, e.gate*sps) + e.r + 0.12;
  const X=(t)=> ENV.pad.l + (t/span)*(w-ENV.pad.l-ENV.pad.r);
  const Y=(a)=> h-ENV.pad.b - a*(h-ENV.pad.t-ENV.pad.b);
  const off=e.gate*sps;

  // step grid, so musical time and envelope time are visible against each other
  g.strokeStyle=css(THEME.faint,0.22); g.lineWidth=1;
  for(let k=0; k*sps<span; k++){
    const x=X(k*sps);
    g.beginPath(); g.moveTo(x,ENV.pad.t); g.lineTo(x,h-ENV.pad.b); g.stroke();
  }
  // the next note in this lane
  const nextT=nt.span*sps;
  if(nextT<span){
    g.strokeStyle=css(THEME.voice[nt.v],0.8); g.setLineDash([3,3]);
    g.beginPath(); g.moveTo(X(nextT),ENV.pad.t-4); g.lineTo(X(nextT),h-ENV.pad.b); g.stroke();
    g.setLineDash([]);
  }
  // tail region
  g.fillStyle=css(THEME.faint,0.10);
  g.fillRect(X(off), ENV.pad.t, X(off+e.r)-X(off), h-ENV.pad.t-ENV.pad.b);

  // curve
  const pk=1;
  const pts=[[0,0],[e.a,pk],[e.a+e.d,e.s],[Math.max(e.a+e.d,off),e.s],[Math.max(e.a+e.d,off)+e.r,0]];
  g.beginPath();
  g.moveTo(X(pts[0][0]),Y(pts[0][1]));
  for(let i=1;i<pts.length;i++) g.lineTo(X(pts[i][0]),Y(pts[i][1]));
  g.lineTo(X(pts[pts.length-1][0]), Y(0)); g.lineTo(X(0),Y(0)); g.closePath();
  g.fillStyle=css(THEME.voice[nt.v],0.20); g.fill();
  g.beginPath(); g.moveTo(X(pts[0][0]),Y(pts[0][1]));
  for(let i=1;i<pts.length;i++) g.lineTo(X(pts[i][0]),Y(pts[i][1]));
  g.strokeStyle=css(THEME.voice[nt.v],1); g.lineWidth=1.8; g.stroke();

  // note off
  g.strokeStyle=cssVar('--ink'); g.lineWidth=2;
  g.beginPath(); g.moveTo(X(off),ENV.pad.t-6); g.lineTo(X(off),h-ENV.pad.b); g.stroke();
  g.fillStyle=cssVar('--ink');
  g.font='10px '+cssVar('--mono').split(',')[0].replace(/'/g,'')+', monospace';
  g.textAlign='left'; g.textBaseline='alphabetic';
  g.fillText('note off', X(off)+5, ENV.pad.t+2);

  // baseline + handles
  g.strokeStyle=css(THEME.faint,0.5); g.lineWidth=1;
  g.beginPath(); g.moveTo(ENV.pad.l, Y(0)+0.5); g.lineTo(w-ENV.pad.r, Y(0)+0.5); g.stroke();
  const handles=[
    {id:'a', x:X(e.a), y:Y(pk)},
    {id:'d', x:X(e.a+e.d), y:Y(e.s)},
    {id:'s', x:X((e.a+e.d+Math.max(e.a+e.d,off))/2), y:Y(e.s)},
    {id:'gate', x:X(off), y:ENV.pad.t+10},
    {id:'r', x:X(Math.max(e.a+e.d,off)+e.r), y:Y(0)},
  ];
  for(const hd of handles){
    g.beginPath(); g.arc(hd.x,hd.y,4.6,0,7);
    g.fillStyle=cssVar('--plate'); g.fill();
    g.strokeStyle=cssVar('--ink'); g.lineWidth=1.6; g.stroke();
  }
  g.fillStyle=cssVar('--ink-faint');
  g.textAlign='right';
  g.fillText('1', ENV.pad.l-6, Y(1)+3);
  g.fillText('0', ENV.pad.l-6, Y(0)+3);
  g.textAlign='left';
  ENV_GEO={X,Y,span,h,w,nt,handles,off};

  const over = e.gate - nt.span;
  el.innerHTML =
    'lane <b>'+VOICE_NAMES[nt.v]+'</b>  step <b>'+(nt.step+1)+'</b>  '+midiName(nt.pitch)+
    '   \u00b7   A <b>'+Math.round(e.a*1000)+'</b>ms  D <b>'+Math.round(e.d*1000)+'</b>ms  S <b>'+e.s.toFixed(2)+
    '</b>  R <b>'+Math.round(e.r*1000)+'</b>ms'+
    '<br>note off at <b>'+e.gate.toFixed(2)+'</b> steps ('+Math.round(e.gate*sps*1000)+' ms)'+
    '   \u00b7   next note in this lane at <b>'+nt.span+'</b> steps'+
    '   \u00b7   ' + (over>0.03 ? '<span class="hand">overlaps the next by '+over.toFixed(2)+' steps</span>'
                   : over<-0.03 ? 'silent for '+(-over).toFixed(2)+' steps before it' : 'exactly abutting') +
    (e.custom ? '   \u00b7   <span class="hand">shaped by you</span>' : '   \u00b7   lane default');
}
function envPick(mx,my){
  if(!ENV_GEO) return null;
  let best=null,bd=14;
  for(const hd of ENV_GEO.handles){
    const d=Math.hypot(mx-hd.x, my-hd.y);
    if(d<bd){ bd=d; best=hd.id; }
  }
  return best;
}
function envDrag(id, mx, my){
  const nt=envTarget(); if(!nt||!ENV_GEO) return;
  const sps=secondsPerStep();
  const t=Math.max(0, (mx-ENV.pad.l)/(ENV_GEO.w-ENV.pad.l-ENV.pad.r)*ENV_GEO.span);
  const amp=clamp01((ENV_GEO.h-ENV.pad.b-my)/(ENV_GEO.h-ENV.pad.t-ENV.pad.b));
  const e=nt.e;
  const key=nt.v+':'+nt.step;
  const cur=Object.assign({}, STATE.noteEnv[key]||{});
  if(id==='a') cur.a=Math.min(1.2, Math.max(0.002, t));
  else if(id==='d') cur.d=Math.min(2, Math.max(0.005, t-(cur.a!=null?cur.a:e.a)));
  else if(id==='s') cur.s=amp;
  else if(id==='gate') cur.gate=Math.min(32, Math.max(0.03, t/sps));
  else if(id==='r'){
    const off=(cur.gate!=null?cur.gate:e.gate)*sps;
    cur.r=Math.min(4, Math.max(0.01, t-Math.max((cur.a!=null?cur.a:e.a)+(cur.d!=null?cur.d:e.d), off)));
  }
  STATE.noteEnv[key]=cur;
  refreshNotes();
  drawEnv(); drawSeq(); drawRoll(STATE.playing?STATE.stepFloat:-1);
}

/* =========== basin map ================================================ */
let BASIN_GEO=null;
function attrColor(rank, total){
  if(total<=1) return THEME.permit;
  const hue=(rank*137.508)%360;
  const s=THEME.dark?0.42:0.5, l=THEME.dark?0.62:0.44;
  return hslToRgb(hue/360, s, l);
}
function hslToRgb(h,s,l){
  const f=(n)=>{ const k=(n+h*12)%12; const a=s*Math.min(l,1-l);
    return l-a*Math.max(-1,Math.min(Math.min(k-3,9-k),1)); };
  return [f(0),f(8),f(4)];
}
function drawBasin(){
  const c=STATE.composed; if(!c||!c.basin) return;
  const b=c.basin;
  const cv=document.getElementById('basinCanvas');
  const {g,w,h}=ctx2d(cv);
  const cols=b.V*3, rows=b.P;
  const cw=w/cols, ch=h/rows;
  const seedP = STATE.seed.prev2Idx;
  for(let i=0;i<b.V;i++) for(let e=0;e<3;e++) for(let p=-1;p<b.V;p++){
    const s=b.enc(i,e,p);
    const rank=b.rank.get(b.attr[s]);
    const col=attrColor(rank, b.list.length);
    const t=b.trans[s]/Math.max(1,b.maxT);
    const shade = THEME.dark ? mix(col, [0.05,0.07,0.1], t*0.72) : mix(col, [1,1,1], t*0.7);
    g.fillStyle=css(shade, 1);
    const x=(i*3+e)*cw, y=(p+1)*ch;
    g.fillRect(x, y, Math.max(0.5,cw-0.5), Math.max(0.5,ch-0.5));
    if(b.trans[s]===0){ g.fillStyle=css(THEME.dark?[1,1,1]:[0,0,0],0.55); g.fillRect(x+cw/2-0.7, y+ch/2-0.7, 1.4, 1.4); }
  }
  const si=Math.min(STATE.seed.chordIdx,b.V-1), se=STATE.seed.eta;
  g.strokeStyle=cssVar('--ink'); g.lineWidth=1.6;
  g.strokeRect((si*3+se)*cw-0.5, (seedP+1)*ch-0.5, cw+1, ch+1);
  BASIN_GEO={cw,ch,V:b.V,P:b.P,w,h};

  const leg=document.getElementById('basinLegend');
  leg.innerHTML = b.list.map((a,i)=>{
    const col=css(attrColor(i,b.list.length));
    const names=[...new Set(a.chords.map(x=>x.roman))].slice(0,6).join(' ');
    return '<div class="attr"><i class="sw" style="background:'+col+'"></i>'
      + 'period <b>'+a.period+'</b> \u00b7 '+Math.round(100*a.size/b.N)+'% of seeds \u00b7 '+names+'</div>';
  }).join('');
  document.getElementById('basinStat').innerHTML =
    '<b>'+b.N+'</b> seeds \u00b7 <b>'+b.list.length+'</b> cycle'+(b.list.length===1?'':'s')+
    ' \u00b7 longest wander <b>'+b.maxT+'</b>';
}
function basinPick(e){
  const c=STATE.composed; if(!c||!c.basin||!BASIN_GEO) return null;
  const cv=document.getElementById('basinCanvas'), rect=cv.getBoundingClientRect();
  const x=e.clientX-rect.left, y=e.clientY-rect.top;
  const col=Math.floor(x/BASIN_GEO.cw), row=Math.floor(y/BASIN_GEO.ch);
  if(col<0||col>=BASIN_GEO.V*3||row<0||row>=BASIN_GEO.P) return null;
  return {chordIdx:Math.floor(col/3), eta:col%3, prev2Idx:row-1};
}

/* =========== readouts ================================================= */
function renderSweep(){
  const c=STATE.composed; if(!c) return;
  const el=document.getElementById('sweep'); el.innerHTML='';
  const pal = THEME.dark?CLASS_COLOR_DARK:CLASS_COLOR;
  for(const p of c.sweep){
    const d=document.createElement('div');
    d.className='c'+(Math.abs(p.lam-STATE.lamC)<0.5/c.sweep.length?' here':'');
    d.style.background=pal[p.cls];
    d.title='λ '+p.lam.toFixed(2)+' — '+p.cls+' — period '+(p.period||'—')+' of '+p.vocabSize
      +' chords — '+Math.round(p.sens*100)+'% average shift per rule flip';
    d.addEventListener('click', ()=>{
      STATE.lamC=p.lam;
      document.getElementById('sLamC').value=Math.round(p.lam*100);
      document.getElementById('nLamC').textContent=p.lam.toFixed(2).replace('0.','.');
      regenerate();
    });
    el.appendChild(d);
  }
  for(const [id,k] of [['kFrozen','frozen'],['kLoop','loop'],['kComplex','complex'],['kChaotic','chaotic']]){
    const n=document.getElementById(id); if(n) n.style.background=pal[k];
  }
  const d=c.dyn, s=c.sens;
  document.getElementById('dynRead').innerHTML =
    'this rule is <b>'+c.cls+'</b>'
    + (d.cycled ? '  \u00b7  wanders <b>'+d.transient+'</b> chords, then cycles with period <b>'+d.period+'</b> of '+d.vocabSize+' reachable'
                : '  \u00b7  no cycle inside the horizon')
    + '<br>of the <b>'+s.tested+'</b> cells the piece leans on, <b>'+Math.round(s.moved*100)+'%</b> change it when flipped'
    + ', by <b>'+Math.round(s.fraction*100)+'%</b> of its chords on average'
    + (s.first>=0 ? '  \u00b7  earliest at chord '+(s.first+1) : '')
    + '<br>' + (c.sequence
        ? 'a <b>'+c.sequence.k+'</b>-chord motion repeats transposed from chord '+(c.sequence.i+1)+' \u2014 the sequence, which is this domain\u2019s glider'
        : 'no transposed repeat found in this piece');
}
function renderStatus(){
  const c=STATE.composed; if(!c) return;
  const flips=Object.keys(STATE.cellFlips.chord).length+Object.keys(STATE.cellFlips.voice).length;
  const parts=[
    'λ chord <b>'+STATE.lamC.toFixed(2)+'</b>',
    'λ voice <b>'+STATE.lamV.toFixed(2)+'</b>',
    'vocabulary <b>'+(c.chords.length?vocabularyFor(STATE.root,SCALES[STATE.scaleName],STATE.extended).length:0)+'</b>',
    'seed <b>'+c.chords[0].roman+'</b> η'+STATE.seed.eta,
    '<b>'+c.cls+'</b>',
    'period <b>'+(c.dyn.period||'—')+'</b>',
  ];
  if(flips) parts.push('<b>'+flips+'</b> flipped');
  if(Object.keys(STATE.pins).length) parts.push('<b>'+Object.keys(STATE.pins).length+'</b> pinned');
  document.getElementById('statusline').innerHTML = parts.map(p=>'<span>'+p+'</span>').join('');
}
function renderBranches(){
  const c=STATE.composed; if(!c) return;
  const g=Math.max(1, Math.min(STATE.selectedSeg, c.segments-1));
  const w=c.walk[g];
  const head=document.getElementById('branchHead');
  const list=document.getElementById('branches');
  list.innerHTML='';
  if(!w || !w.legal || !w.from){ head.textContent='Select a chord in the score.'; return; }
  head.innerHTML='at chord <b>'+(g+1)+'</b>, after '+w.from.roman+' \u2014 <b>'+w.legal.length+'</b> move'
    +(w.legal.length===1?'':'s')+' the rule allows'+(w.fellBack?' <span class="hand">(none: fallback)</span>':'');
  const taken=c.chords[g];
  w.legal.slice(0,6).forEach(alt=>{
    const fork=forkFrom(c.walk, g, alt, 5);
    const btn=document.createElement('button');
    const isTaken = alt.key===taken.key;
    const isPinned = STATE.pins[g]===alt.key;
    btn.className='branch'+(isTaken?' taken':'')+(isPinned?' pinned':'');
    const fut=fork.chords.slice(1).map((x,i)=>{
      const base=c.chords[g+1+i];
      const same = base && base.key===x.key;
      return same? x.roman : '<em>'+x.roman+'</em>';
    }).join(' ');
    const cell=cellOfMove(w.from, alt, w.target, w.etaIn);
    btn.innerHTML='<span class="rn">'+alt.roman+'</span><span class="fut">'+fut+'</span>'
      +'<span class="cost">d'+cell.d+'</span>';
    btn.addEventListener('mouseenter', ()=>{ HOVER.branch={chords:fork.chords, cells:fork.cells, alt};
      drawLattice(); drawRoll(STATE.playing?STATE.stepFloat:-1); });
    btn.addEventListener('mouseleave', ()=>{ HOVER.branch=null; drawLattice(); drawRoll(STATE.playing?STATE.stepFloat:-1); });
    btn.addEventListener('click', ()=>{
      if(STATE.pins[g]===alt.key) delete STATE.pins[g]; else STATE.pins[g]=alt.key;
      HOVER.branch=null; regenerate();
    });
    list.appendChild(btn);
  });
  document.getElementById('branchHint').innerHTML =
    'Hover to see where a move would have gone, in the score and through the rule space. Click to hold the piece to it.';
}
function renderHandStat(){
  const nC=Object.keys(STATE.cellFlips.chord).length, nV=Object.keys(STATE.cellFlips.voice).length;
  const nP=Object.keys(STATE.pins).length, nE=Object.keys(STATE.noteEnv).length, nA=Object.keys(STATE.anchors).length;
  const bits=[];
  if(nC||nV) bits.push('<b>'+(nC+nV)+'</b> rule cell'+(nC+nV===1?'':'s')+' flipped');
  if(nP) bits.push('<b>'+nP+'</b> chord'+(nP===1?'':'s')+' pinned');
  if(nE) bits.push('<b>'+nE+'</b> note'+(nE===1?'':'s')+' shaped');
  if(nA) bits.push('<b>'+nA+'</b> pitch'+(nA===1?'':'es')+' anchored');
  document.getElementById('handStat').innerHTML = bits.length
    ? bits.join('<br>')
    : 'Nothing yet. Anything you change by hand is marked in magenta wherever it shows up.';
}
function renderAll(){
  drawLattice();
  drawRoll(STATE.playing?STATE.stepFloat:-1);
  drawSeq();
  drawEnv();
  drawBasin();
  renderSweep();
  renderStatus();
  renderBranches();
  renderStats();
  renderHandStat();
}
function refreshNotes(){ if(STATE.composed) buildNotes(STATE.composed); }
