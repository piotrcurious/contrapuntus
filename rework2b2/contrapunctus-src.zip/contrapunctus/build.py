#!/usr/bin/env python3
"""Concatenate src/ pieces into the shippable files.

  dist/contrapunctus.html           a complete standalone document (what the person downloads)
  dist/contrapunctus.artifact.html  the same page as a fragment: <title>, <style>, markup, <script>
                                    (the Artifact tool wraps a fragment in its own skeleton)
  dist/contrapunctus.js             the script alone, for `node --check`

usage: build.py
"""
import sys, os, glob
here = os.path.dirname(os.path.abspath(__file__))
dist = os.path.join(here, 'dist')
os.makedirs(dist, exist_ok=True)
rd = lambda p: open(os.path.join(here, 'src', p), encoding='utf-8').read()
mods = sorted(os.path.basename(p) for p in glob.glob(os.path.join(here, 'src', '[0-9][0-9]-*.js')))
js = '(function(){\n"use strict";\n' + '\n'.join(rd(m) for m in mods) + '\n})();\n'
open(os.path.join(dist, 'contrapunctus.js'), 'w', encoding='utf-8').write(js)

head, body = rd('00-head.html'), rd('01-body.html')
script = '<script>\n' + js + '</script>\n'

fragment = head + body + script
open(os.path.join(dist, 'contrapunctus.artifact.html'), 'w', encoding='utf-8').write(fragment)

doc = ('<!DOCTYPE html>\n<html lang="en">\n<head>\n<meta charset="UTF-8">\n'
       '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
       + head + '</head>\n<body>\n' + body + script + '</body>\n</html>\n')
open(os.path.join(dist, 'contrapunctus.html'), 'w', encoding='utf-8').write(doc)
print('built', len(doc), 'bytes (standalone),', len(fragment), 'bytes (fragment),', len(mods), 'modules')
