import {validate, validateOrdinal, contrast} from './validate_palette.mjs';
const LS='#fbfaf6', DS='#161e2a';
const O=(name,pal,mode,surface)=>{ const r=validateOrdinal(pal,{mode,surface}); console.log((r.ok?'OK  ':'FAIL')+' '+name.padEnd(14)+pal.join(',')+'  '+r.report.map(x=>String(x[1]).toUpperCase()+':'+x[2]).join(' ; ')); };
for (const p of [['#a3a8b3','#6b7382','#191c22'],['#9ca2ae','#646c7a','#191c22'],['#989eaa','#5e6674','#191c22'],['#8f96a3','#59616f','#191c22'],['#9aa1ad','#626a78','#20242c']]) O('ink light',p,'light',LS);
for (const p of [['#4c586d','#8190a5','#e4e7ec'],['#505c72','#8a98ad','#f1f3f6'],['#475368','#7d8ba0','#e4e7ec'],['#53607a','#8e9cb2','#e4e7ec']]) O('ink dark',p,'dark',DS);
const r=validate(['#3987e5','#c98500'],{mode:'dark',surface:DS,pairs:'all'}); console.log('dark blue/yellow', r.report.map(x=>String(x[1]).toUpperCase()+' '+x[2].slice(0,80)).join(' | '));
const r2=validate(['#2a78d6','#eda100'],{mode:'light',surface:LS,pairs:'all'}); console.log('light blue/yellow', r2.report.map(x=>String(x[1]).toUpperCase()+' '+x[2].slice(0,80)).join(' | '));
