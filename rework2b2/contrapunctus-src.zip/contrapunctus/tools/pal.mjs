import {validate, validateOrdinal, contrast} from './validate_palette.mjs';
const rep = (r)=> r.report.map(x=>`${String(x[1]).replace('true','PASS').replace('false','FAIL')}:${x[0]}`).join(' | ');
const O=(name,pal,mode,surface)=>{ const r=validateOrdinal(pal,{mode,surface}); console.log((r.ok?'OK  ':'FAIL')+' '+name.padEnd(22)+pal.join(',')+'  '+r.report.map(x=>x[2]).join(' ; ')); };
// light-mode ink ramps (fixed < loop < tour), surface = plate
for (const p of [['#a3a8b3','#6b7382','#191c22'],['#9ca2ae','#646c7a','#191c22'],['#a0a6b1','#5e6674','#191c22']]) O('ink light',p,'light','#fbfaf6');
// dark-mode ramps: lighter = more
for (const p of [['#4c586d','#8190a5','#e4e7ec'],['#505c72','#8a98ad','#f1f3f6'],['#475368','#7d8ba0','#e4e7ec']]) O('ink dark',p,'dark','#161e2a');
// AA text contrast of faint ink tokens on the surfaces they sit on
const T=(n,fg,bg)=>console.log(n.padEnd(34),fg,'on',bg,contrast(fg,bg).toFixed(2));
T('ink-faint light (current)','#8b93a1','#fbfaf6'); T('ink-faint light (cand)','#6b7382','#fbfaf6'); T('ink-faint light (cand2)','#68707e','#fbfaf6');
T('ink-faint dark (current)','#5c6779','#161e2a'); T('ink-faint dark (cand)','#8190a5','#161e2a'); T('ink-faint dark (cand2)','#7b8aa0','#161e2a');
T('ink-dim light','#5e6674','#fbfaf6'); T('ink-dim dark','#8e99aa','#161e2a');
T('ink-faint light on ground','#6b7382','#f3f1ea'); T('ink-faint dark on ground','#8190a5','#101722');
T('hand light on plate','#b2418f','#fbfaf6'); T('hand dark on plate','#d96ab8','#161e2a');
T('permit light on plate','#2b7f95','#fbfaf6'); T('forbid light on plate','#b8463d','#fbfaf6');
T('permit dark','#4fb3c9','#161e2a'); T('forbid dark','#d2574e','#161e2a');
