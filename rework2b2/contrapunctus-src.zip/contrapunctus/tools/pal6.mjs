import {contrast} from './validate_palette.mjs';
for (const c of ['#656d7b','#626a78','#606876']) console.log(c, ['#fbfaf6','#f3f1ea','#f7f5ef','#ffffff'].map(b=>contrast(c,b).toFixed(2)).join(' '));
