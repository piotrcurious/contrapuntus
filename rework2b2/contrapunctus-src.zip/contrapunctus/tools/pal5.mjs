import {contrast} from './validate_palette.mjs';
const T=(n,fg,bg)=>console.log(n.padEnd(34),fg,'on',bg,contrast(fg,bg).toFixed(2));
T('ink-faint light on plate','#6b7382','#fbfaf6'); T('ink-faint light on ground','#6b7382','#f3f1ea'); T('ink-faint light on gl-bg','#6b7382','#f7f5ef'); T('ink-faint light on plate-lift','#6b7382','#ffffff');
T('ink-faint dark on plate','#8190a5','#161e2a'); T('ink-faint dark on ground','#8190a5','#101722'); T('ink-faint dark on gl-bg','#8190a5','#0c121b'); T('ink-faint dark on plate-lift','#8190a5','#1c2634');
T('ink-dim light','#5e6674','#fbfaf6'); T('ink-dim light on gl-bg','#5e6674','#f7f5ef'); T('ink-dim dark','#8e99aa','#161e2a'); T('ink-dim dark on gl-bg','#8e99aa','#0c121b');
T('hand text light','#b2418f','#fbfaf6'); T('hand text dark','#d96ab8','#161e2a'); T('hand dark on gl-bg','#d96ab8','#0c121b');
T('permit text light','#2b7f95','#fbfaf6'); T('forbid text light','#b8463d','#fbfaf6'); T('permit dark','#4fb3c9','#161e2a'); T('forbid dark','#d2574e','#161e2a');
T('melody light on plate','#d8642f','#fbfaf6'); T('mid light','#1f8f74','#fbfaf6'); T('bass light','#5b55c9','#fbfaf6');
T('melody dark','#d95926','#161e2a'); T('mid dark','#199e70','#161e2a'); T('bass dark','#9085e9','#161e2a');
T('melody dark on gl-bg','#d95926','#0c121b'); T('mid dark on gl-bg','#199e70','#0c121b'); T('bass dark on gl-bg','#9085e9','#0c121b');
T('melody light on gl-bg','#d8642f','#f7f5ef'); T('mid light on gl-bg','#1f8f74','#f7f5ef'); T('bass light on gl-bg','#5b55c9','#f7f5ef');
T('ink on ground dark','#e4e7ec','#101722');
// text color tokens for tooltips etc
T('btn on state (ink on ground)','#f3f1ea','#191c22');
