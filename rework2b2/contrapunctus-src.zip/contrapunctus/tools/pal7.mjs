import {contrast} from './validate_palette.mjs';
const L={ground:'#eceff1', plate:'#f7f9fa', lift:'#ffffff', gl:'#f3f6f7'};
const D={ground:'#101722', plate:'#161e2a', lift:'#1c2634', gl:'#0c121b'};
function row(name,fgs,S){ console.log(name.padEnd(12), fgs.map(([n,c])=>n+' '+Object.entries(S).map(([k,b])=>contrast(c,b).toFixed(2)).join('/')).join('  |  ')); }
console.log('order of surfaces: ground/plate/lift/gl');
for (const c of ['#4b5663','#505b68','#455060']) console.log('dim light',c,Object.values(L).map(b=>contrast(c,b).toFixed(2)).join(' '));
for (const c of ['#627080','#5d6b7a','#5a6878']) console.log('faint light',c,Object.values(L).map(b=>contrast(c,b).toFixed(2)).join(' '));
for (const c of ['#a3adbc','#9aa6b6']) console.log('dim dark',c,Object.values(D).map(b=>contrast(c,b).toFixed(2)).join(' '));
for (const c of ['#8190a5','#8795a9']) console.log('faint dark',c,Object.values(D).map(b=>contrast(c,b).toFixed(2)).join(' '));
for (const [n,c] of [['permit','#2b7f95'],['forbid','#b8463d'],['hand','#b2418f'],['melody','#d8642f'],['mid','#1f8f74'],['bass','#5b55c9'],['att1','#2a78d6'],['att2','#eda100'],['cls-fixed','#9ca2ae'],['cls-loop','#646c7a'],['cls-tour','#191c22']])
  console.log(n.padEnd(10),c,'light',Object.values(L).map(b=>contrast(c,b).toFixed(2)).join(' '));
for (const [n,c] of [['permit','#4fb3c9'],['forbid','#d2574e'],['hand','#d96ab8'],['melody','#d95926'],['mid','#199e70'],['bass','#9085e9'],['att1','#3987e5'],['att2','#c98500'],['cls-fixed','#4c586d'],['cls-loop','#8190a5'],['cls-tour','#e4e7ec']])
  console.log(n.padEnd(10),c,'dark ',Object.values(D).map(b=>contrast(c,b).toFixed(2)).join(' '));
console.log('btn on: ground on ink', contrast('#eceff1','#14191f').toFixed(2), contrast('#101722','#e4e7ec').toFixed(2));
