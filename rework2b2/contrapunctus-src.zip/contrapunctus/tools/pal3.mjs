import {validate, contrast} from './validate_palette.mjs';
const DS='#161e2a', LS='#fbfaf6';
const greens=['#008300','#0ca30c','#2e9a3a','#3aa14f','#1f9d55','#4aa83a','#5aa02c','#2f8f2f','#3c9d3c','#27a35c'];
for(const g of greens){
  const r=validate(['#3987e5','#c98500',g],{mode:'dark',surface:DS,pairs:'all'});
  console.log(g.padEnd(9), r.report.filter(x=>/CVD|Normal|Lightness|Chroma/.test(x[0])).map(x=>String(x[1]).toUpperCase()+' '+x[2].slice(0,70)).join(' | '));
}
console.log('--- light');
for(const g of greens){
  const r=validate(['#2a78d6','#eda100',g],{mode:'light',surface:LS,pairs:'all'});
  console.log(g.padEnd(9), r.report.filter(x=>/CVD|Normal|Lightness|Chroma/.test(x[0])).map(x=>String(x[1]).toUpperCase()+' '+x[2].slice(0,70)).join(' | '));
}
