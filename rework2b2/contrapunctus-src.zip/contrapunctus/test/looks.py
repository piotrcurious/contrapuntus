#!/usr/bin/env python3
"""Element screenshots of the plates, for looking at.   usage: looks.py [--dark] [--nogl] [--w 1440]"""
import sys, os
src=open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'ui.py')).read().replace("\nmain()\n","\n")
sys.argv_backup=list(sys.argv)
ns={'__name__':'x','__file__':os.path.join(os.path.dirname(os.path.abspath(__file__)),'ui.py')}
exec(compile(src,'ui.py','exec'),ns)
from playwright.sync_api import sync_playwright
dark='--dark' in sys.argv; W=1440
if '--w' in sys.argv: W=int(sys.argv[sys.argv.index('--w')+1])
tag=('_dark' if dark else '')+('_nogl' if ns['NOGL'] else '')+('_w%d'%W if W!=1440 else '')
out=os.path.join(ns['here'],'out')
with sync_playwright() as p:
    b,ctx,pg,errs=ns['launch'](p, w=W, h=1000, dark=dark)
    plates=pg.query_selector_all('section.plate')
    def shot(i,name):
        el=plates[i]; el.scroll_into_view_if_needed(); ns['settle'](pg); el.screenshot(path=os.path.join(out,name+tag+'.png'))
    shot(0,'plate_rule')
    pg.click('#btnProjPot'); pg.wait_for_timeout(900); shot(0,'plate_rule_cost')
    pg.click('#btnProjCycle'); pg.wait_for_timeout(900); shot(0,'plate_rule_ring')
    pg.click('#btnProjGrid'); pg.wait_for_timeout(900)
    # select a note near another so the labels of the envelope editor can be checked
    pg.evaluate("__cp.selectNote(1,8,false)"); pg.wait_for_timeout(200)
    shot(1,'plate_score'); shot(2,'plate_seq')
    env=pg.query_selector('#envCanvas').evaluate_handle("e=>e.closest('section.plate')")
    env.as_element().scroll_into_view_if_needed(); ns['settle'](pg); env.as_element().screenshot(path=os.path.join(out,'plate_env'+tag+'.png'))
    # a note whose gate runs right up to the next onset
    pg.evaluate("(()=>{ const n=__cp.STATE.composed.notes[1][1]; __cp.selectNote(n.v,n.step,false); })()"); pg.wait_for_timeout(200)
    env.as_element().screenshot(path=os.path.join(out,'plate_env2'+tag+'.png'))
    print('errors', errs)
    b.close()
