#!/bin/sh
# usage: sh test/run.sh   -- concatenates the DOM-free modules in front of the suites and runs them in node
cd "$(dirname "$0")/.." || exit 1
OUT=${TMPDIR:-/tmp}/cp_logic_$$.js
MODS="src/10-core.js src/11-rules.js src/12-automaton.js src/13-analysis.js"
for extra in src/30-notes.js src/50-io.js; do [ -f "$extra" ] && MODS="$MODS $extra"; done
TESTS="test/logic.js"
for t in test/io.js; do [ -f "$t" ] && TESTS="$TESTS $t"; done
cat $MODS $TESTS test/summary.js > "$OUT" && node "$OUT"; RC=$?; rm -f "$OUT"; exit $RC
