#!/usr/bin/env python3
"""Browser tests for the built page (dist/contrapunctus.html), in headless Chromium.

  python3 test/ui.py              WebGL back end
  python3 test/ui.py --nogl       the Canvas 2D fallback

Audio is replaced by a recording fake, so what the scheduler asks for can be checked against the
envelope model; a fake `window.claude` stands in for the viewer's downloads capability."""
import sys, os, json, zipfile, io, struct, time
from playwright.sync_api import sync_playwright

here = os.path.dirname(os.path.abspath(__file__)); root = os.path.dirname(here)
NOGL = '--nogl' in sys.argv
SRC = os.environ.get('CP_SRC', 'dist/contrapunctus.html')
PASS = 0; FAIL = 0
def check(cond, name, detail=''):
    global PASS, FAIL
    if cond: PASS += 1; print('ok   ' + name + ('  ' + str(detail) if detail != '' else ''))
    else: FAIL += 1; print('FAIL ' + name + ('  ' + str(detail) if detail != '' else ''))

FAKE_AUDIO = r"""
(function(){
  const log={ctxs:0, oscs:[], gains:[], t0:performance.now()};
  window.__audioLog=log;
  class Param{ constructor(v){ this.value=v||0; this.ev=[]; }
    setValueAtTime(v,t){ this.ev.push(['set',v,t]); this.value=v; return this; }
    linearRampToValueAtTime(v,t){ this.ev.push(['lin',v,t]); return this; }
    exponentialRampToValueAtTime(v,t){ this.ev.push(['exp',v,t]); return this; }
    setTargetAtTime(v,t,k){ this.ev.push(['target',v,t,k]); return this; }
    cancelScheduledValues(t){ this.ev.push(['cancel',t]); return this; } }
  class Node{ constructor(k){ this.kind=k; this.out=[]; this.cut=false; } connect(n){ this.out.push(n); return n; } disconnect(){ this.cut=true; } }
  class Gain extends Node{ constructor(){ super('gain'); this.gain=new Param(1); } }
  class Osc extends Node{ constructor(){ super('osc'); this.frequency=new Param(440); this.detune=new Param(0); this.type='sine'; this.started=null; this.stops=[]; this.onended=null; }
    start(t){ this.started=t; } stop(t){ this.stops.push(t); } }
  class Filter extends Node{ constructor(){ super('filter'); this.frequency=new Param(350); this.Q=new Param(1); this.type='lowpass'; } }
  class Panner extends Node{ constructor(){ super('pan'); this.pan=new Param(0); } }
  class Conv extends Node{ constructor(){ super('conv'); this.buffer=null; } }
  class Comp extends Node{ constructor(){ super('comp'); } }
  class Ctx{ constructor(){ log.ctxs++; this.sampleRate=44100; this.state='running'; this.destination=new Node('dest'); }
    get currentTime(){ return (performance.now()-log.t0)/1000; }
    resume(){ return Promise.resolve(); }
    createGain(){ const g=new Gain(); log.gains.push(g); return g; }
    createOscillator(){ const o=new Osc(); log.oscs.push(o); return o; }
    createBiquadFilter(){ return new Filter(); } createStereoPanner(){ return new Panner(); }
    createConvolver(){ return new Conv(); } createDynamicsCompressor(){ return new Comp(); }
    createBuffer(ch,n,sr){ const d=[]; for(let i=0;i<ch;i++) d.push(new Float32Array(n)); return {getChannelData:i=>d[i], length:n, numberOfChannels:ch, sampleRate:sr}; } }
  window.AudioContext=Ctx; window.webkitAudioContext=Ctx;
})();
"""
FAKE_VIEWER = r"""
window.claude={ use: async function(name){
  if(name!=='downloads') throw new Error('no such capability');
  if(window.__viewerDelay) await new Promise(r=>setTimeout(r, window.__viewerDelay));
  return { save: async function(o){
    if(window.__viewerFail){ const e=new Error('nope'); e.code=window.__viewerFail; throw e; }
    window.__saved={filename:o.filename, bytes:(typeof o.data==='string'?Array.from(new TextEncoder().encode(o.data)):Array.from(o.data))}; } };
} };
"""

def launch(p, w=1440, h=1000, dark=False, viewer=False, audio=True):
    b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
    ctx = b.new_context(viewport={'width': w, 'height': h}, color_scheme='dark' if dark else 'light', accept_downloads=True)
    ctx.grant_permissions(['clipboard-read', 'clipboard-write'], origin='file://') if False else None
    ctx.route('**/fonts.g*/**', lambda r: r.abort())
    init = 'window.__CP_DEBUG=true;' + ('window.__CP_NOGL=true;' if NOGL else '') + (FAKE_AUDIO if audio else '') + (FAKE_VIEWER if viewer else '')
    ctx.add_init_script(init)
    pg = ctx.new_page(); errs = []
    pg.on('console', lambda m: errs.append((m.type, m.text)) if m.type == 'error' and 'Failed to load resource' not in m.text else None)
    pg.on('pageerror', lambda e: errs.append(('pageerror', str(e))))
    pg.goto('file://' + os.path.join(root, SRC), wait_until='domcontentloaded')
    pg.wait_for_function('window.__cp && window.__cp.STATE.composed', timeout=15000)
    return b, ctx, pg, errs

def js(pg, expr, arg=None): return pg.evaluate(expr, arg) if arg is not None else pg.evaluate(expr)
def settle(pg):
    """wait until the page has stopped scrolling (the app scrolls an editor into view smoothly)"""
    pg.evaluate("window.__lastY=null; window.__still=0")
    pg.wait_for_function("(()=>{ const y=window.scrollY; if(window.__lastY===y) window.__still++; else { window.__lastY=y; window.__still=0; } return window.__still>=5; })()", polling=40, timeout=5000)

def canvas_xy(pg, sel, x, y):
    """page coordinates of a point inside a canvas, after scrolling the canvas to the middle of the window"""
    pg.evaluate("s=>document.querySelector(s).scrollIntoView({block:'center'})", sel)
    settle(pg)
    r = pg.evaluate("s=>{const r=document.querySelector(s).getBoundingClientRect(); return [r.left,r.top,r.width,r.height]}", sel)
    return r[0] + x, r[1] + y

def parse_midi(b):
    """a small independent reader (separate from the one in the node suite)"""
    p = 0
    assert b[:4] == b'MThd'; hl = struct.unpack('>I', b[4:8])[0]; fmt, n, ppq = struct.unpack('>HHH', b[8:14]); p = 8 + hl
    tracks = []
    for t in range(n):
        assert b[p:p+4] == b'MTrk'; ln = struct.unpack('>I', b[p+4:p+8])[0]; p += 8; end = p + ln; ev = []; tick = 0
        while p < end:
            v = 0
            while True:
                c = b[p]; p += 1; v = (v << 7) | (c & 0x7f)
                if not c & 0x80: break
            tick += v; s = b[p]; p += 1
            if s == 0xFF:
                ty = b[p]; p += 1; L = 0
                while True:
                    c = b[p]; p += 1; L = (L << 7) | (c & 0x7f)
                    if not c & 0x80: break
                ev.append((tick, 'meta', ty, bytes(b[p:p+L]))); p += L
            else:
                hi = s & 0xF0; ch = s & 0x0F
                if hi in (0x80, 0x90, 0xB0, 0xE0): ev.append((tick, hi, ch, b[p], b[p+1])); p += 2
                else: raise Exception('status %x' % s)
        tracks.append(ev)
    return fmt, ppq, tracks

def main():
    with sync_playwright() as p:
        # ------------------------------------------------------------------ load
        b, ctx, pg, errs = launch(p)
        kinds = js(pg, "[__cp.GL_LAT.kind, __cp.GL_ROLL.kind]")
        check(kinds == (['2d', '2d'] if NOGL else ['gl', 'gl']), 'painters are ' + ('Canvas 2D' if NOGL else 'WebGL'), kinds)
        check(js(pg, "__cp.STATE.composed.notes.flat().length") == 56, 'the default piece has 56 notes')
        check(js(pg, "document.documentElement.scrollWidth <= window.innerWidth"), 'no horizontal scroll at 1440')

        # ------------------------------------------------------------------ rule space: pick, flip, undo
        pts = js(pg, "Array.from(__cp.LAYOUT.pts)")
        N = len(pts) // 2
        def cell_at_free_place():
            # a cell whose nearest neighbour is far enough to pick unambiguously
            best = None; bd = 0
            for f in range(N):
                d = min(((pts[f*2]-pts[g*2])**2 + (pts[f*2+1]-pts[g*2+1])**2) ** 0.5 for g in range(N) if g != f)
                if d > bd: bd = d; best = f
            return best, bd
        f, bd = cell_at_free_place()
        check(bd >= 4, 'cells of the flat grid are at least 4 px apart', round(bd, 1))
        x, y = canvas_xy(pg, '#latticeCanvas', pts[f*2], pts[f*2+1])
        pg.mouse.move(x, y); pg.wait_for_timeout(120)
        check('cost' in pg.inner_text('#latticeRead'), 'hovering a cell reads it', pg.inner_text('#latticeRead')[:70].replace('\n', ' '))
        check(pg.evaluate("!document.getElementById('tip').hidden"), 'and shows a tooltip')
        before = js(pg, "JSON.stringify(__cp.STATE.cellFlips.chord)")
        pg.mouse.click(x, y); pg.wait_for_timeout(150)
        flips = js(pg, "Object.keys(__cp.STATE.cellFlips.chord).length")
        check(flips == 1 and js(pg, "__cp.HIST.undo.length") == 1, 'clicking a cell flips it, as one history step', flips)
        check('flipped' in pg.inner_text('#handStat'), 'the hand-edit summary counts it', pg.inner_text('#handStat').replace('\n', ' '))
        pg.keyboard.press('Control+z'); pg.wait_for_timeout(120)
        check(js(pg, "Object.keys(__cp.STATE.cellFlips.chord).length") == 0, 'Ctrl+Z takes the flip back')
        pg.keyboard.press('Control+Shift+z'); pg.wait_for_timeout(120)
        check(js(pg, "Object.keys(__cp.STATE.cellFlips.chord).length") == 1, 'Ctrl+Shift+Z redoes it')
        pg.click('#btnClearCells'); pg.wait_for_timeout(100)
        check(js(pg, "Object.keys(__cp.STATE.cellFlips.chord).length") == 0, 'Clear rule flips')

        # keyboard path
        pg.focus('#latticeCanvas'); pg.keyboard.press('ArrowRight'); pg.keyboard.press('ArrowRight'); pg.wait_for_timeout(80)
        hc = js(pg, "__cp.HOVER.cell")
        check(hc is not None, 'arrow keys move a cursor over the cells', hc)
        pg.keyboard.press('Enter'); pg.wait_for_timeout(100)
        check(js(pg, "Object.keys(__cp.STATE.cellFlips.chord).length") == 1, 'Enter flips the cell under the cursor')
        pg.keyboard.press('Control+z'); pg.wait_for_timeout(80)

        # projections
        for which, mode in [('btnProjCycle', 'polar'), ('btnProjPot', 'cost'), ('btnProjHyper', 'linear'), ('btnProjGrid', 'linear')]:
            pg.click('#' + which); pg.wait_for_timeout(700)
            m = js(pg, "__cp.LAYOUT.mode")
            P = js(pg, "Array.from(__cp.LAYOUT.pts)"); n = len(P) // 2
            md = min(((P[i*2]-P[j*2])**2 + (P[i*2+1]-P[j*2+1])**2) ** 0.5 for i in range(n) for j in range(i+1, n))
            check(m == mode, which + ' lays out in the ' + mode + ' mode', m)
            check(md > (4 if mode == 'cost' else 1.2), which + ': no two cells coincide', round(md, 2))
            if mode == 'cost':
                ok = js(pg, """(()=>{ const L=__cp.LAYOUT, t=L.sp.tbl; if(!L.cut) return null; let bad=0; for(let f=0; f<t.t.length; f++){ if((t.t[f]===1)!==(L.pts[f*2]<L.cut.x)) bad++; } return bad; })()""")
                check(ok == 0, 'by cost: every legal cell is left of the cut line and every other one right of it', ok)
        pg.click('#btnSetVoice'); pg.wait_for_timeout(500)
        for which in ['btnProjGrid', 'btnProjHyper', 'btnProjPot']:
            pg.click('#' + which); pg.wait_for_timeout(700)
            P = js(pg, "Array.from(__cp.LAYOUT.pts)"); n = len(P) // 2
            md = min(((P[i*2]-P[j*2])**2 + (P[i*2+1]-P[j*2+1])**2) ** 0.5 for i in range(n) for j in range(i+1, n))
            check(md > 4, 'voice table, ' + which + ': no two cells coincide', round(md, 2))
        check(pg.is_disabled('#btnProjCycle'), 'the fifths ring is unavailable for the voice table')
        pg.click('#btnSetChord'); pg.click('#btnProjHyper'); pg.wait_for_timeout(700)

        # drag a handle
        h = pg.query_selector('#latticeLabels .handle[data-key="tau"]')
        bb = h.bounding_box(); cx, cy = bb['x'] + bb['width']/2, bb['y'] + bb['height']/2
        b0 = js(pg, "JSON.stringify(__cp.PROJ.chord.basin||__cp.PROJ.chord.basis)")
        pg.mouse.move(cx, cy); pg.mouse.down(); pg.mouse.move(cx + 20, cy + 14, steps=5); pg.mouse.move(cx + 40, cy + 30, steps=5)
        pos_during = js(pg, "[__cp.LAYOUT.handles.find(h=>h.key==='tau').x, __cp.LAYOUT.handles.find(h=>h.key==='tau').y]")
        r = js(pg, "(()=>{const r=document.getElementById('latticeCanvas').getBoundingClientRect(); return [r.left,r.top]})()")
        check(abs(pos_during[0] + r[0] - (cx + 40)) < 3 and abs(pos_during[1] + r[1] - (cy + 30)) < 3, 'the handle follows the pointer exactly while it is dragged', [round(pos_during[0] + r[0] - (cx + 40), 2), round(pos_during[1] + r[1] - (cy + 30), 2)])
        pg.mouse.up(); pg.wait_for_timeout(600)
        b1 = js(pg, "JSON.stringify(__cp.PROJ.chord.basis)")
        check(b0 != b1 and js(pg, "__cp.PROJ.chord.preset") == 'hyper', 'letting go keeps the new projection')
        pg.click('#btnProjGrid'); pg.wait_for_timeout(600)

        # ------------------------------------------------------------------ controls
        pg.evaluate("()=>{const e=document.getElementById('sLamC'); e.value='62'; e.dispatchEvent(new Event('input',{bubbles:true})); e.dispatchEvent(new Event('change',{bubbles:true}));}")
        pg.wait_for_timeout(200)
        check(abs(js(pg, "__cp.STATE.lamC") - 0.62) < 1e-9 and 'λ chord .62' in pg.inner_text('#statusline').replace('\n', ' '), 'the λ slider drives the state and the status line')
        n1 = js(pg, "__cp.STATE.composed.chords.map(c=>c.key).join()")
        pg.evaluate("()=>{const e=document.getElementById('sLamC'); e.value='38'; e.dispatchEvent(new Event('input',{bubbles:true})); e.dispatchEvent(new Event('change',{bubbles:true}));}")
        pg.wait_for_timeout(200)
        pg.click('#takeCtl button[data-take="strong"]'); pg.wait_for_timeout(200)
        check(js(pg, "__cp.STATE.composed.chords.slice(0,5).map(c=>c.roman).join(' ')") == 'I△7 IV△7 ii7 V7 I△7', 'the strongest take plays I IV ii V')
        pg.click('#takeCtl button[data-take="bold"]'); pg.wait_for_timeout(150)
        pg.select_option('#selBars', '4'); pg.wait_for_timeout(150)
        check(js(pg, "__cp.STATE.composed.total") == 32, 'four bars of eight steps')
        pg.select_option('#selBars', '8'); pg.wait_for_timeout(100)
        pg.click('#chkWalk'); pg.wait_for_timeout(200)
        check(js(pg, "__cp.STATE.composed.notes[2].length") == 32, 'the walking-bass switch gives one bass note per beat', js(pg, "__cp.STATE.composed.notes[2].length"))
        pg.click('#chkWalk'); pg.wait_for_timeout(100)

        # ------------------------------------------------------------------ score, sequencer, envelope
        g = js(pg, "(()=>{const g=__cp.rollGeom(); return {stepW:g.stepW}})()")
        nt = js(pg, "(()=>{const n=__cp.STATE.composed.notes[1][2], g=__cp.rollGeom(); return {v:n.v, step:n.step, x:n.step*g.stepW+6, y:g.yOf(n.pitch)}})()")
        x, y = canvas_xy(pg, '#rollCanvas', nt['x'], nt['y'])
        pg.mouse.move(x, y); pg.wait_for_timeout(100)
        check('middle' in pg.inner_text('#rollRead'), 'hovering a note names its voice and rule cell', pg.inner_text('#rollRead')[:80].replace('\n', ' '))
        pg.mouse.click(x, y); pg.wait_for_timeout(200)
        sel = js(pg, "__cp.STATE.selectedNote")
        check(sel and sel['v'] == 1 and sel['step'] == nt['step'], 'clicking a note selects it', sel)
        geo = js(pg, "(()=>{const G=__cp.ENVED.geo; return G? G.handles.map(h=>({id:h.id,x:h.x,y:h.y})):null})()")
        check(geo and len(geo) == 4, 'the envelope editor has four handles', [h['id'] for h in geo] if geo else geo)
        gh = [h for h in geo if h['id'] == 'gate'][0]
        gate0 = js(pg, "__cp.envTarget().e.gate")
        sx, sy = canvas_xy(pg, '#envCanvas', gh['x'], gh['y'])
        undo0 = js(pg, "__cp.HIST.undo.length")
        pg.mouse.move(sx, sy); pg.mouse.down(); pg.mouse.move(sx + 30, sy, steps=6); pg.mouse.move(sx + 60, sy, steps=6)
        gate_drag = js(pg, "__cp.envTarget().e.gate")
        win0 = js(pg, "__cp.ENVED.lock")
        pg.mouse.up(); pg.wait_for_timeout(150)
        gate1 = js(pg, "__cp.envTarget().e.gate")
        check(gate1 > gate0 + 0.1, 'dragging note-off right lengthens the gate', round(gate0, 2).__str__() + ' -> ' + round(gate1, 2).__str__())
        check(win0 is not None and js(pg, "__cp.ENVED.lock") is None, 'the time axis is locked during the drag and released after')
        check(js(pg, "__cp.HIST.undo.length") == undo0 + 1, 'and the whole drag is one history step')
        check(abs(float(js(pg, "document.getElementById('envGate').value")) - gate1) < 0.01, 'the note-off field shows the new gate')
        # a number typed into a field
        pg.fill('#envR', '900'); pg.press('#envR', 'Enter'); pg.evaluate("document.getElementById('envR').dispatchEvent(new Event('change',{bubbles:true}))"); pg.wait_for_timeout(120)
        check(abs(js(pg, "__cp.envTarget().e.r") - 0.9) < 1e-6, 'a release typed in milliseconds is applied', js(pg, "__cp.envTarget().e.r"))
        check('shaped by you' in pg.inner_text('#envRead'), 'the note is marked as shaped by hand')
        pg.click('#btnEnvReset'); pg.wait_for_timeout(100)
        check(js(pg, "Object.keys(__cp.STATE.noteEnv).length") == 0, 'Reset note')

        # painting the sequencer
        L = js(pg, "(()=>{const L=__cp.seqLayout(); return {stepW:L.stepW, w:L.w}})()")
        sx, sy = canvas_xy(pg, '#seqCanvas', L['stepW'] * 3.5, 22 + 44 + 10)     # middle lane, step 3
        was = js(pg, "__cp.STATE.onsets[1][3]")
        pg.mouse.click(sx, sy); pg.wait_for_timeout(200)
        check(js(pg, "__cp.STATE.onsets[1][3]") == (not was) and js(pg, "__cp.STATE.touched[1]"), 'clicking an onset switches it and marks the lane as painted')
        pg.keyboard.press('Control+z'); pg.wait_for_timeout(100)
        check(js(pg, "__cp.STATE.onsets[1][3]") == was, 'undo puts it back')

        # ------------------------------------------------------------------ audio
        t_run = js(pg, "performance.now()")
        pg.keyboard.press('Space'); pg.wait_for_timeout(700)
        check(js(pg, "__cp.STATE.playing"), 'Space starts playback')
        log = js(pg, "(()=>{const L=window.__audioLog; return {oscs:L.oscs.map(o=>({t:o.started,f:o.frequency.ev[0],ty:o.type,stops:o.stops})), n:L.oscs.length}})()")
        check(log['n'] >= 6, 'notes are being scheduled', log['n'])
        starts = sorted(set(round(o['t'], 5) for o in log['oscs'] if o['t'] is not None))
        sps = js(pg, "__cp.secondsPerStep()")
        off = [(s - starts[0]) / sps for s in starts]
        check(all(abs(v - round(v)) < 1e-3 for v in off), 'every note starts on the step grid', [round(v, 3) for v in off[:6]])
        # the first bass note's gain automation against the envelope model
        gains = js(pg, """(()=>{ const L=window.__audioLog, c=__cp.STATE.composed, nt=c.notes[2][0], sps=__cp.secondsPerStep();
            const pts=__cp.envSchedule(nt.e, nt.e.gate*sps), f=440*Math.pow(2,(nt.fpitch-69)/12);
            const o=L.oscs.filter(o=>Math.abs(o.frequency.ev[0][1]-f)<1e-6)[0];
            const env=o ? o.out[0].out[0].out[0] : null;          // oscillator -> gain -> filter -> envelope gain
            return {ev: env? env.gain.ev : null, pts, peak:__cp.ENV_PEAK, floor:__cp.ENV_FLOOR, gateSec:nt.e.gate*sps}; })()""")
        ok_env = False
        if gains['ev']:
            ev = gains['ev']; t0 = ev[0][2]
            lin = [e for e in ev if e[0] == 'lin']
            want = gains['pts'][1:]
            ok_env = len(lin) == len(want) and all(abs(l[2] - t0 - w[0]) < 1e-6 and abs(l[1] - gains['peak'] * w[1]) < 1e-6 for l, w in zip(lin, want))
            ex = [e for e in ev if e[0] == 'exp']
            ok_env = ok_env and len(ex) == 1 and abs(ex[0][1] - gains['floor']) < 1e-9 and ex[0][2] > t0 + gains['gateSec']
        check(ok_env, 'the gain automation of a note is the envelope the editor draws', None if gains['ev'] else 'no env found')
        check(abs(js(pg, "document.getElementById('rollHead').hidden") is False) >= 0 and not js(pg, "document.getElementById('rollHead').hidden"), 'the playhead is shown')
        ph = js(pg, "__cp.STATE.stepFloat")
        check(0 <= ph < 64, 'the playhead position is in range', round(ph, 2))
        pg.keyboard.press('Space'); pg.wait_for_timeout(300)
        check(not js(pg, "__cp.STATE.playing") and js(pg, "__cp.AUD.run") is None, 'Space stops it')
        stopped = js(pg, "window.__audioLog.oscs.filter(o=>o.started!==null).every(o=>o.stops.some(t=>t<=window.__audioLog.t0*0+ (performance.now()-window.__audioLog.t0)/1000+0.3))")
        check(stopped, 'every oscillator that was started has been given a stop time no later than now+0.3 s')
        busgain = js(pg, "(()=>{const g=window.__audioLog.gains.filter(g=>g.gain.ev.some(e=>e[0]==='target')); return g.length>=4 && g.every(x=>x.gain.ev.filter(e=>e[0]==='target').pop()[1]===0)})()")
        check(busgain, 'Stop fades the three voice buses and the reverb return to zero')
        pg.wait_for_timeout(400)
        check(js(pg, "(()=>{ const b=window.__audioLog.gains.filter(g=>g.gain.ev.some(e=>e[0]==='target' && e[3]===0.012)); return b.length===3 && b.every(g=>g.cut); })()"), 'and then cuts the buses')
        check(js(pg, "document.getElementById('rollHead').hidden"), 'the playhead is hidden again')

        # ------------------------------------------------------------------ tuning and MIDI
        pg.select_option('#selTuning', 'just'); pg.wait_for_timeout(250)
        check(js(pg, "__cp.STATE.tuning") == 'just' and 'pitch bend' in pg.inner_text('#midiInfo') and 'carry a pitch bend' in pg.inner_text('#midiInfo'), 'choosing a tuning updates the export summary', pg.inner_text('#midiInfo')[:120].replace('\n', ' '))
        check('Just intonation' in pg.inner_text('#statusline'), 'and the status line')
        with pg.expect_download() as dl:
            pg.click('#btnMidi')
        d = dl.value; path = os.path.join(here, 'out', d.suggested_filename); d.save_as(path)
        data = open(path, 'rb').read()
        fmt, ppq, tr = parse_midi(data)
        check(d.suggested_filename.endswith('.mid') and fmt == 1 and ppq == 480 and len(tr) == 4, 'Save MIDI downloads a format-1 file', d.suggested_filename)
        bends = [e for t in tr[1:] for e in t if len(e) == 5 and e[1] == 0xE0 and e[0] > 0]
        check(len(bends) > 0, 'a just-intoned piece carries pitch bend messages', len(bends))
        # replay: key + bend must give the sounding pitch of each note
        notes = js(pg, "__cp.STATE.composed.notes.map(l=>l.map(n=>({tick:Math.round(n.step*1920/__cp.STATE.stepsPerBar), fp:n.fpitch})))")
        worst = 0
        for v in range(3):
            bend = {}; ons = []
            for e in tr[v + 1]:
                if len(e) == 5 and e[1] == 0xE0: bend[e[2]] = (e[4] << 7) | e[3]
                elif len(e) == 5 and e[1] == 0x90 and e[4] > 0: ons.append((e[0], e[3] + (bend.get(e[2], 8192) - 8192) / 4096))
            bt = {t: pp for t, pp in ons}
            for n in notes[v]:
                worst = max(worst, abs(bt[n['tick']] - n['fp']) * 100)
        check(worst < 0.03, 'in the browser export, every note sounds at the pitch of its tuning to within 0.03 cent', round(worst, 4))

        # the viewer's way: a zip through the downloads capability
        b.close()
        b, ctx, pg, errs2 = launch(p, viewer=True)
        pg.select_option('#selTuning', 'meantone'); pg.wait_for_timeout(300)
        pg.click('#btnMidi'); pg.wait_for_function('window.__saved', timeout=8000)
        sv = js(pg, "window.__saved")
        z = zipfile.ZipFile(io.BytesIO(bytes(sv['bytes'])))
        names = z.namelist()
        check(sv['filename'].endswith('.zip') and z.testzip() is None and len(names) == 2, 'in the viewer, Save MIDI hands over a valid .zip', names)
        mid = [n for n in names if n.endswith('.mid')][0]; st = [n for n in names if n.endswith('.json')][0]
        f2, p2, t2 = parse_midi(z.read(mid))
        check(f2 == 1 and len(t2) == 4, 'with a readable MIDI file in it')
        state = json.loads(z.read(st).decode('utf-8'))
        check(state.get('app') == 'contrapunctus' and state.get('tuning') == 'meantone', 'and the state, which names the tuning')
        # that state loads back to the same piece
        before = js(pg, "__cp.STATE.composed.pitches.map(l=>l.join()).join('|')")
        js(pg, "(s)=>{ const r=__cp.restoreState(s); if(!r.ok) throw new Error(r.error); __cp.regenerate(); }", state)
        after = js(pg, "__cp.STATE.composed.pitches.map(l=>l.join()).join('|')")
        check(before == after, 'loading that state back reproduces the piece note for note')

        # ------------------------------------------------------------------ state codes
        code = js(pg, "__cp.stateToCode()")
        check(code.startswith('CP1.') and len(code) < 6000, 'the state code is short enough to paste', len(code))
        pg.click('#btnLoad'); pg.fill('#codeBox', code[:-3] + ('abc' if not code.endswith('abc') else 'xyz')); pg.click('#btnCodeApply'); pg.wait_for_timeout(200)
        check('damaged' in pg.inner_text('#toast') or 'not a Contrapunctus' in pg.inner_text('#toast'), 'a damaged code is refused', pg.inner_text('#toast'))
        pg.fill('#codeBox', 'CP1.' + 'A' * 20 + '.00000000'); pg.click('#btnCodeApply'); pg.wait_for_timeout(150)
        check(js(pg, "__cp.STATE.tuning") == 'meantone', 'and refusing it changes nothing')
        pg.select_option('#selTuning', 'equal'); pg.wait_for_timeout(150)
        pg.fill('#codeBox', code); pg.click('#btnCodeApply'); pg.wait_for_timeout(300)
        check(js(pg, "__cp.STATE.tuning") == 'meantone' and js(pg, "document.getElementById('selTuning').value") == 'meantone', 'a good code restores the state and the controls')

        # ------------------------------------------------------------------ autosave
        pg.evaluate("localStorage.removeItem('contrapunctus.state.1')")
        pg.select_option('#selScale', 'Dorian'); pg.wait_for_timeout(900)
        saved = js(pg, "localStorage.getItem('contrapunctus.state.1')")
        check(saved and '"Dorian"' in saved, 'the piece is kept in this browser')
        pg.reload(wait_until='domcontentloaded'); pg.wait_for_function('window.__cp && window.__cp.STATE.composed', timeout=15000)
        check(js(pg, "__cp.STATE.scaleName") == 'Dorian' and js(pg, "document.getElementById('selScale').value") == 'Dorian', 'and restored on the next visit, controls included')
        pg.click('#btnResetAll'); pg.wait_for_timeout(300)
        check(js(pg, "__cp.STATE.scaleName") == 'Ionian' and js(pg, "__cp.STATE.tuning") == 'equal', 'Start over returns to the starting state')
        pg.keyboard.press('Control+z'); pg.wait_for_timeout(200)
        check(js(pg, "__cp.STATE.scaleName") == 'Dorian', 'and undo brings the piece back')
        errs += errs2

        # the viewer answers late: the page must not have decided against it meanwhile
        b.close()
        b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
        ctx = b.new_context(viewport={'width': 1440, 'height': 1000}, accept_downloads=True)
        ctx.route('**/fonts.g*/**', lambda r: r.abort())
        ctx.add_init_script('window.__CP_DEBUG=true;' + ('window.__CP_NOGL=true;' if NOGL else '') + 'window.__viewerDelay=2500;' + FAKE_VIEWER)
        pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(('pageerror', str(e))))
        pg.goto('file://' + os.path.join(root, SRC), wait_until='domcontentloaded')
        pg.wait_for_function('window.__cp && window.__cp.STATE.composed', timeout=15000)
        pg.wait_for_timeout(1800)                       # past the page's own short wait for the viewer
        pg.click('#btnMidi'); pg.wait_for_function('window.__saved', timeout=12000)
        check(js(pg, "window.__saved.filename").endswith('.zip'), 'a viewer that answers after two seconds is still used (the file goes through it)', js(pg, "window.__saved.filename"))
        check('.zip' in pg.inner_text('#keepNote'), 'and the note under the buttons then says so')
        b.close()

        # a viewer that cannot save: fall back to the plain download instead of failing silently
        b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
        ctx = b.new_context(viewport={'width': 1440, 'height': 1000}, accept_downloads=True)
        ctx.route('**/fonts.g*/**', lambda r: r.abort())
        ctx.add_init_script('window.__CP_DEBUG=true;' + ('window.__CP_NOGL=true;' if NOGL else '') + 'window.__viewerFail="unavailable";' + FAKE_VIEWER)
        pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(('pageerror', str(e))))
        pg.goto('file://' + os.path.join(root, SRC), wait_until='domcontentloaded')
        pg.wait_for_function('window.__cp && window.__cp.STATE.composed', timeout=15000)
        with pg.expect_download(timeout=8000) as dl2:
            pg.click('#btnJson')
        check(dl2.value.suggested_filename.endswith('.json'), 'a viewer that cannot save hands the job back: the plain download still happens', dl2.value.suggested_filename)
        b.close()
        # a viewer the person declines: nothing else happens
        b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
        ctx = b.new_context(viewport={'width': 1440, 'height': 1000}, accept_downloads=True)
        ctx.route('**/fonts.g*/**', lambda r: r.abort())
        ctx.add_init_script('window.__CP_DEBUG=true;' + ('window.__CP_NOGL=true;' if NOGL else '') + 'window.__viewerFail="declined";' + FAKE_VIEWER)
        pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(('pageerror', str(e))))
        pg.goto('file://' + os.path.join(root, SRC), wait_until='domcontentloaded')
        pg.wait_for_function('window.__cp && window.__cp.STATE.composed', timeout=15000)
        got = []
        pg.on('download', lambda d: got.append(d))
        pg.click('#btnJson'); pg.wait_for_timeout(600)
        check(not got, 'a declined save is not retried by another route')
        b.close()
        b, ctx, pg, e5 = launch(p, viewer=True)
        errs += e5

        # ------------------------------------------------------------------ speed
        pg.evaluate("localStorage.clear()")
        t = js(pg, """(()=>{ const S=__cp.STATE; S.bars=16; S.stepsPerBar=16; S.extended=true; const t0=performance.now(); for(let i=0;i<10;i++) __cp.compose(); return (performance.now()-t0)/10; })()""")
        check(t < 120, 'a recompute of 16 bars of sixteenths with applied chords takes under 120 ms', round(t, 1))
        t = js(pg, """(()=>{ __cp.regenerate(); const t0=performance.now(); for(let i=0;i<5;i++) __cp.renderAll(); return (performance.now()-t0)/5; })()""")
        check(t < 250, 'and redrawing everything takes under 250 ms', round(t, 1))
        b.close()

        # ------------------------------------------------------------------ layout at other widths, both themes
        for (w, h, dark) in [(1024, 800, False), (768, 900, True), (390, 800, False), (390, 800, True)]:
            b, ctx, pg, e3 = launch(p, w=w, h=h, dark=dark)
            sw = js(pg, "document.documentElement.scrollWidth"); iw = js(pg, "window.innerWidth")
            wide = js(pg, """(()=>{ const out=[]; for(const e of document.querySelectorAll('body *')){ const r=e.getBoundingClientRect(); if(r.width>0 && r.right>window.innerWidth+1 && !e.closest('.scroller') && !e.closest('#statusline') && !e.closest('#tip') && getComputedStyle(e).position!=='fixed') out.push(e.tagName+'#'+e.id+'.'+e.className+' '+Math.round(r.right)); } return out.slice(0,6); })()""")
            check(sw <= iw and not wide, 'no horizontal overflow at %d px%s' % (w, ' (dark)' if dark else ''), (sw, iw, wide))
            pg.screenshot(path=os.path.join(here, 'out', 'w%d%s.png' % (w, '_dark' if dark else '')), full_page=(w == 390))
            errs += e3
            b.close()

        # ------------------------------------------------------------------ errors
        check(not errs, 'no console errors or page errors during the whole run', errs[:5])
    print('\n%d passed, %d failed' % (PASS, FAIL))
    sys.exit(1 if FAIL else 0)

main()
