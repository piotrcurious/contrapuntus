/* ---------------------------------------------------------------- tunings and fractional pitch */
resetState();
{ const T=(k,pc,root)=>tuningCents(pc,k,root);
  ok(TUNING_ORDER.every(k=>TUNINGS[k].cents.length===12 && TUNINGS[k].cents.every(Number.isFinite)), 'every tuning has twelve finite offsets');
  ok(TUNINGS.equal.cents.every(x=>x===0), 'equal temperament is zero everywhere');
  ok(Math.abs(T('just',4,0)-(1200*Math.log2(5/4)-400))<1e-9 && Math.abs(T('just',7,0)-(1200*Math.log2(3/2)-700))<1e-9, 'just: the major third is 13.7 cents flat and the fifth 2.0 sharp', T('just',4,0).toFixed(2)+' / '+T('just',7,0).toFixed(2));
  ok(Math.abs(T('just',6,2)-T('just',4,0))<1e-9, 'a tonic-relative tuning follows the root: F# over D is the major third');
  ok(T('werckmeister',1,0)===T('werckmeister',1,7) && Math.abs(T('werckmeister',1,0)+9.775)<1e-9, 'a well temperament is fixed to C and ignores the root');
  ok(Math.abs(T('meantone',4,0)+13.6863)<1e-3 && Math.abs(T('meantone',7,0)+3.4216)<1e-3, 'quarter-comma meantone: pure major third, fifth 3.4 cents flat');
  ok(Math.abs(T('pythagorean',4,0)-7.8200)<1e-3 && Math.abs(T('pythagorean',7,0)-1.955)<1e-3, 'Pythagorean: ditone 7.8 cents sharp, pure fifth');
  const worst=Math.max.apply(null, TUNING_ORDER.map(k=>Math.max.apply(null, TUNINGS[k].cents.map(Math.abs))));
  ok(worst<50, 'no tuning moves a pitch class more than a quarter-tone, so the nearest key is always the right one', worst.toFixed(1)+' cents');
  STATE.tuning='just'; STATE.root=0;
  ok(Math.abs(soundingPitch(64)-(64-0.13686))<1e-4, 'soundingPitch adds the offset to the key number', soundingPitch(64).toFixed(4));
  STATE.tuning='equal'; }

/* ---------------------------------------------------------------- a small MIDI reader for checking the writer */
function readMidi(u8){
  let p=0;
  const r8=()=>u8[p++], r16=()=>{ const v=(u8[p]<<8)|u8[p+1]; p+=2; return v; }, r32=()=>{ const v=((u8[p]<<24)|(u8[p+1]<<16)|(u8[p+2]<<8)|u8[p+3])>>>0; p+=4; return v; };
  const tag=()=>{ const s=String.fromCharCode(u8[p],u8[p+1],u8[p+2],u8[p+3]); p+=4; return s; };
  const vlq=()=>{ let v=0,b; do{ b=r8(); v=(v<<7)|(b&0x7f); }while(b&0x80); return v; };
  if(tag()!=='MThd') throw new Error('no MThd');
  if(r32()!==6) throw new Error('bad header length');
  const fmt=r16(), ntrk=r16(), ppq=r16(), tracks=[];
  for(let t=0;t<ntrk;t++){
    if(tag()!=='MTrk') throw new Error('no MTrk '+t);
    const len=r32(), end=p+len; let tick=0, status=0; const ev=[]; let ended=false;
    while(p<end){
      tick+=vlq(); let b=r8();
      if(b===0xFF){ const type=r8(), n=vlq(), data=Array.from(u8.subarray(p,p+n)); p+=n; ev.push({tick,kind:'meta',type,data}); if(type===0x2F){ ended=true; if(p!==end) throw new Error('data after end of track'); } continue; }
      if(b&0x80){ status=b; b=r8(); } // running status never written, but be fair
      const hi=status&0xF0, ch=status&0x0F;
      if(hi===0x90||hi===0x80){ const key=b, vel=r8(); ev.push({tick,kind:(hi===0x90&&vel>0)?'on':'off',ch,key,vel}); }
      else if(hi===0xE0){ const lsb=b, msb=r8(); ev.push({tick,kind:'bend',ch,value:(msb<<7)|lsb}); }
      else if(hi===0xB0){ const val=r8(); ev.push({tick,kind:'cc',ch,cc:b,val}); }
      else throw new Error('unexpected status '+status.toString(16));
    }
    if(!ended) throw new Error('track '+t+' has no end');
    tracks.push(ev);
  }
  if(p!==u8.length) throw new Error('trailing bytes');
  return {fmt, ntrk, ppq, tracks};
}
// replay a voice track: the pitch each note-on sounds at (key + the channel's bend then), and whether any held note was bent
function replayVoice(ev, range){
  const bend={}, rpn={}, notes=[], open={}; let bentWhileHeld=0, bendRangeOk=true;
  const seenCC={};
  for(const e of ev){
    if(e.kind==='cc'){ (seenCC[e.ch]=seenCC[e.ch]||[]).push([e.cc,e.val]); }
    if(e.kind==='bend'){
      const k=e.ch; if(Object.keys(open).some(s=>s.split('/')[0]==k)) bentWhileHeld++;
      bend[k]=e.value;
    }
    if(e.kind==='on'){
      const b=bend[e.ch]==null?8192:bend[e.ch];
      const rec={tick:e.tick, ch:e.ch, key:e.key, vel:e.vel, bend:b, pitch:e.key+(b-8192)/(8192/range)};
      notes.push(rec); open[e.ch+'/'+e.key]=rec;
    }
    if(e.kind==='off'){ const rec=open[e.ch+'/'+e.key]; if(rec){ rec.off=e.tick; delete open[e.ch+'/'+e.key]; } }
  }
  return {notes, bentWhileHeld, openLeft:Object.keys(open).length, seenCC};
}

/* ---------------------------------------------------------------- the MIDI writer */
function midiCheck(label){
  const c=STATE.composed, m=buildMidi(c), f=readMidi(m.bytes);
  ok(f.fmt===1 && f.ntrk===4 && f.ppq===480, label+': format 1, four tracks, 480 per quarter');
  const tps=1920/STATE.stepsPerBar, names=f.tracks.map(t=>{ const e=t.find(x=>x.kind==='meta'&&x.type===3); return e?String.fromCharCode.apply(null,e.data):''; });
  eq(names, ['Contrapunctus','melody','middle','bass'], label+': tracks are named');
  const tempo=f.tracks[0].find(x=>x.kind==='meta'&&x.type===0x51), us=(tempo.data[0]<<16)|(tempo.data[1]<<8)|tempo.data[2];
  ok(us===Math.round(6e7/STATE.tempo), label+': tempo meta matches', us+' us');
  ok(f.tracks[0].filter(x=>x.kind==='meta'&&x.type===6).length===c.segments, label+': one marker per chord');
  let allNotes=0, wrong=0, offBad=0, tickBad=0, held=0, open=0, worst=0;
  for(let v=0; v<3; v++){
    const R=replayVoice(f.tracks[v+1], 2), mine=c.notes[v];
    allNotes+=mine.length; held+=R.bentWhileHeld; open+=R.openLeft;
    ok(R.notes.length===mine.length, label+': '+VOICE_NAMES[v]+' has every note', R.notes.length+' of '+mine.length);
    // pair by onset tick; a voice sounds at most one note per step
    const byTick=new Map(R.notes.map(n=>[n.tick,n]));
    for(const nt of mine){
      const r=byTick.get(Math.round(nt.step*tps)); if(!r){ tickBad++; continue; }
      const d=Math.abs(r.pitch-nt.fpitch); if(d>worst) worst=d; if(d>1/4096+1e-9) wrong++;
      if(r.off-r.tick!==Math.max(1,Math.round(nt.e.gate*tps)) && !(r.off<r.tick+Math.max(1,Math.round(nt.e.gate*tps)))) offBad++;
    }
  }
  ok(wrong===0, label+': every note sounds at the pitch the tuning asks for (key plus bend)', 'worst error '+(worst*100).toFixed(4)+' cents over '+allNotes+' notes');
  ok(tickBad===0 && offBad===0, label+': every onset is on its tick and every note-off is at its gate or earlier');
  ok(held===0, label+': no bend ever moves a note that is being held');
  ok(open===0, label+': every note is closed');
  return {m,f};
}
resetState();
{ const c=compose(); attachNotes(c);
  const {m}=midiCheck('equal');
  ok(!m.info.anyBend && m.info.bent===0 && m.info.channels.every(n=>n===1), 'equal temperament: no bend, one channel per voice', JSON.stringify(m.info.channels));
  const f=readMidi(m.bytes); ok(f.tracks.slice(1).every(t=>t.every(e=>e.kind!=='bend'&&e.kind!=='cc')), 'and no controller messages at all'); }
for(const tn of ['just','pythagorean','meantone','werckmeister']){
  resetState(); STATE.tuning=tn; const c=compose(); attachNotes(c);
  const {m,f}=midiCheck(tn);
  ok(m.info.anyBend && m.info.bent>0, tn+': notes carry a bend', m.info.bent+' of '+m.info.notes);
  ok(m.info.glitches===0, tn+': no release is bent by a later note', 'channels '+JSON.stringify(m.info.channels));
  // every used channel was told the bend range before its first note
  let setup=true;
  for(let v=1; v<4; v++){ const used=new Set(f.tracks[v].filter(e=>e.kind==='on').map(e=>e.ch));
    for(const ch of used){ const cc=f.tracks[v].filter(e=>e.kind==='cc'&&e.ch===ch&&e.tick===0).map(e=>e.cc+'='+e.val).join(',');
      if(cc!=='101=0,100=0,6=2,38=0,101=127,100=127') setup=false;
      const b0=f.tracks[v].find(e=>e.kind==='bend'&&e.ch===ch); if(!b0||b0.tick!==0||b0.value!==8192) setup=false; } }
  ok(setup, tn+': every channel gets RPN 0 = 2 semitones, then a centred bend, at tick 0');
}
{ // overlapping gates and long tails force the channel pool to rotate, and the pitches must stay right
  resetState(); STATE.tuning='just'; STATE.voiceEnv[0].gateRatio=2.4; STATE.voiceEnv[0].r=0.9;
  STATE.onsets=null; const c=compose(); attachNotes(c);
  const {m}=midiCheck('overlapping');
  ok(m.info.channels[0]>1, 'overlapping melody notes with different bends are spread over several channels', JSON.stringify(m.info.channels));
  ok(m.info.glitches===0, 'and the pool is large enough that no release is bent', String(m.info.glitches));
}
{ // same key held twice: the earlier note is cut at the later one, never left dangling
  resetState(); STATE.tuning='equal'; STATE.arp='up'; STATE.voiceEnv[0].gateRatio=6;
  const c=compose(); attachNotes(c); midiCheck('long gates');
}
{ // exhaust the pool: the file stays valid, the count of bent releases is reported
  resetState(); STATE.tuning='meantone'; STATE.stepsPerBar=16; STATE.lastStepsPerBar=16; STATE.onsets=null;
  STATE.voiceEnv[0].gateRatio=3; STATE.voiceEnv[0].r=7.5; STATE.voiceEnv[0].a=0.001;
  STATE.tempo=60; STATE.take='strong';
  const c=compose(); attachNotes(c); const {m}=midiCheck('exhausted pool');
  ok(m.info.glitches>0, 'with every channel still ringing the export counts the notes whose channel is bent under a release', m.info.glitches+' notes');
  ok(/share a channel with a release still sounding/.test(midiSummary()), 'and the summary says so in words'); }
{ resetState(); STATE.tempo=137; STATE.stepsPerBar=4; STATE.lastStepsPerBar=4; STATE.onsets=null; STATE.harmonic='half'; STATE.tuning='just';
  const c=compose(); attachNotes(c); midiCheck('four steps a bar, twice a bar');
  resetState(); STATE.stepsPerBar=16; STATE.lastStepsPerBar=16; STATE.onsets=null; STATE.bars=16; STATE.tuning='werckmeister';
  const c2=compose(); attachNotes(c2); midiCheck('sixteenths, sixteen bars'); }
{ // the writer never emits a byte above 127 where a data byte belongs, and variable-length quantities round-trip
  const enc=(n)=>midiVlq(n), dec=(a)=>{ let v=0; for(const b of a) v=(v<<7)|(b&0x7f); return v; };
  ok([0,1,127,128,8192,16383,16384,2097151,268435455].every(n=>dec(enc(n))===n), 'variable-length quantities round-trip up to 28 bits'); }

/* ---------------------------------------------------------------- zip */
{ const fs=require('fs'), os=require('os'), path=require('path'), cp=require('child_process');
  const dir=fs.mkdtempSync(path.join(process.env.TMPDIR||os.tmpdir(),'cpzip-'));
  resetState(); STATE.tuning='just'; const c=compose(); attachNotes(c); const m=buildMidi(c);
  const state=new TextEncoder().encode(JSON.stringify(serializeState({view:true}),null,1));
  const zip=makeZip([{name:'a.mid',data:m.bytes},{name:'a.json',data:state},{name:'empty.txt',data:new Uint8Array(0)}], new Date(2026,9,9,12,30,10));
  fs.writeFileSync(path.join(dir,'t.zip'), zip);
  const py="import zipfile,sys,hashlib\nz=zipfile.ZipFile(sys.argv[1])\nprint('bad' if z.testzip() else 'good')\nprint(','.join(z.namelist()))\nprint(hashlib.sha1(z.read('a.mid')).hexdigest())\nprint(len(z.read('a.json')))\nprint(len(z.read('empty.txt')))\nprint(z.infolist()[0].date_time)\n";
  let out=''; try{ out=cp.execFileSync('python3',['-I','-c',py,path.join(dir,'t.zip')]).toString().trim().split('\n'); }catch(e){ out=['error '+e.message]; }
  ok(out[0]==='good', 'zip: python reads it and every CRC matches', out[0]);
  ok(out[1]==='a.mid,a.json,empty.txt', 'zip: the three names', out[1]);
  const sha=require('crypto').createHash('sha1').update(Buffer.from(m.bytes)).digest('hex');
  ok(out[2]===sha, 'zip: the MIDI file comes out byte for byte');
  ok(+out[3]===state.length && +out[4]===0, 'zip: sizes agree');
  ok(out[5]==='(2026, 10, 9, 12, 30, 10)', 'zip: the timestamp is stored', out[5]);
  fs.rmSync(dir,{recursive:true,force:true}); }

/* ---------------------------------------------------------------- state: round trip, code, hostile input */
{ resetState();
  STATE.root=5; STATE.scaleName='Dorian'; STATE.bars=12; STATE.stepsPerBar=16; STATE.lastStepsPerBar=16; STATE.harmonic='half'; STATE.tempo=111;
  STATE.tension=0.55; STATE.lamC=0.61; STATE.lamV=0.27; STATE.take='strong'; STATE.extended=true; STATE.walkingBass=true; STATE.arp='updown'; STATE.tuning='meantone';
  STATE.profiles.chord.d.w=0.7; STATE.profiles.chord.tau.aff=[0.1,0.2,0.9,0.4,0]; STATE.profiles.voice.phi.aff=[0,1,0.5];
  STATE.cellFlips.chord['3,2,0,1']=1; STATE.cellFlips.chord['7,2,1,0']=0; STATE.cellFlips.voice['1,2,2,0,1']=1;
  STATE.seed={chordIdx:2,eta:2,prev2Idx:3,voice:[72,null,45]};
  STATE.onsets=null; ensureGrids(); STATE.touched=[true,false,true]; STATE.onsets[0][5]=false; STATE.onsets[2][7]=true; STATE.onsets[0][8]=true;
  STATE.anchors={8:76}; STATE.pins={3:'7:dom7:-'}; STATE.barOverrides={2:{scale:'Aeolian',tension:0.8},4:{tension:0.1}};
  STATE.voiceEnv[1]={a:0.05,d:0.2,s:0.4,r:1.1,gateRatio:1.4}; STATE.noteEnv={'0:8':{gate:3.5,r:0.9},'2:0':{a:0.2}};
  const before=compose(); attachNotes(before);
  const sig=(c)=>JSON.stringify([c.chords.map(x=>x.key), c.pitches, c.notes.map(l=>l.map(n=>[n.step,n.fpitch.toFixed(4),n.e.gate.toFixed(4),n.e.r.toFixed(4)]))]);
  const s0=sig(before), snap0=snapshot(), code=stateToCode();
  ok(/^CP1\.[A-Za-z0-9_-]+\.[0-9a-f]{8}$/.test(code), 'the code is CP1.<payload>.<checksum>', code.length+' characters');
  resetState(); compose();
  const parsed=parseStateText(code); ok(!!parsed.obj, 'the code parses', parsed.error);
  const r=restoreState(parsed.obj); ok(r.ok, 'the code restores', r.error);
  const after=compose(); attachNotes(after);
  ok(sig(after)===s0, 'the restored piece is note for note the same piece, envelopes and tuning included');
  { const a=JSON.parse(snap0), b=JSON.parse(snapshot()); const diff=Object.keys(a).filter(k=>JSON.stringify(a[k])!==JSON.stringify(b[k]));
    ok(diff.length===0, 'and serialises to the same thing again', diff.length?('differs in '+diff.join(',')+': '+JSON.stringify(a[diff[0]]).slice(0,160)+' vs '+JSON.stringify(b[diff[0]]).slice(0,160)):''); }
  const p2=parseStateText(JSON.stringify(serializeState({view:true}),null,1)); ok(!!p2.obj && restoreState(p2.obj).ok, 'the saved JSON file loads as well');
  const bad=code.slice(0,-12)+'AAAA'+code.slice(-8); ok(!!parseStateText(bad).error, 'a code with its payload altered is refused', parseStateText(bad).error);
  ok(!!parseStateText(code.slice(0,code.length-30)).error, 'a code cut short is refused');
  ok(!!parseStateText('hello').error && !!parseStateText('').error && !!parseStateText('{not json').error, 'rubbish is refused');
  ok(parseStateText(' \n'+code.slice(0,40)+'\n  '+code.slice(40)+'  \n').obj!==undefined, 'a code that was wrapped across lines still reads');
}
{ resetState(); compose();
  const before=snapshot();
  const refuse=(o)=>{ const r=restoreState(o); return !r.ok && snapshot()===before; };
  ok(refuse(null) && refuse(5) && refuse([]) && refuse({}) && refuse({app:'other',v:1}) && refuse({app:'contrapunctus',v:2}), 'structurally wrong states are refused and change nothing');
  const hostile=JSON.parse('{"app":"contrapunctus","v":1,"__proto__":{"polluted":1},"root":"7","scale":"constructor","bars":9999,"stepsPerBar":3,"tempo":1e99,"tension":"x",'
    +'"lamC":-4,"take":"toString","tuning":"__proto__","cellFlips":{"chord":{"__proto__":1,"constructor":0,"3,2,0,1":1,"99,99,99,99":1,"3,2,0,1,1":1},"voice":5},'
    +'"seed":{"chordIdx":1e9,"eta":-5,"prev2Idx":"a","voice":[1e9,"x",60]},"anchors":{"__proto__":60,"5":1e9,"7":"a","9999":60,"3":64},'
    +'"pins":{"0":"<script>","1":"7:dom7:-","constructor":"7:dom7:-"},"barOverrides":{"0":{"scale":"__proto__","tension":9},"99":{"tension":0.5},"__proto__":{"tension":1}},'
    +'"touched":[true,"yes",true],"onsets":["101","x",null],"profiles":{"chord":{"d":{"w":"big","aff":[1,2,3]},"tau":{"w":9,"aff":[2,-1,0.5,0.5,null]},"__proto__":{"w":1}},"voice":7},'
    +'"voiceEnv":[{"a":-1,"d":1e9,"s":5,"r":0,"gateRatio":"x"},null,5],"noteEnv":{"0:3":{"gate":-5,"a":"q","evil":1},"9:9":{"a":1},"__proto__":{"a":1},"1:2":5}}');
  const r=restoreState(hostile);
  ok(r.ok, 'a hostile state is cleaned rather than trusted', r.error);
  ok(({}).polluted===undefined && ({}).a===undefined && Object.prototype.tension===undefined, 'and nothing leaks onto Object.prototype');
  ok(STATE.root===7 || STATE.root===0, 'root is a clamped integer', String(STATE.root));
  ok(STATE.scaleName==='Ionian' && STATE.take==='bold' && STATE.tuning==='equal', 'unknown names fall back to defaults');
  ok(STATE.bars===16 && STATE.stepsPerBar===4 && STATE.tempo===200 && STATE.tension===0.3 && STATE.lamC===0, 'numbers are clamped, wrong types default', [STATE.bars,STATE.stepsPerBar,STATE.tempo,STATE.tension,STATE.lamC].join(','));
  ok(Object.keys(STATE.cellFlips.chord).join('|')==='3,2,0,1' && Object.keys(STATE.cellFlips.voice).length===0, 'only well-formed in-range cell flips survive', JSON.stringify(STATE.cellFlips));
  ok(STATE.seed.chordIdx===63 && STATE.seed.eta===0 && STATE.seed.prev2Idx===-1 && STATE.seed.voice[0]===108 && STATE.seed.voice[1]===null && STATE.seed.voice[2]===60, 'seed values are clamped', JSON.stringify(STATE.seed));
  ok(JSON.stringify(STATE.anchors)==='{"3":64}', 'only anchors inside the piece survive', JSON.stringify(STATE.anchors));
  ok(JSON.stringify(STATE.pins)==='{"1":"7:dom7:-"}', 'only well-formed pins survive', JSON.stringify(STATE.pins));
  ok(Object.keys(STATE.barOverrides).join()==='0' && STATE.barOverrides[0].tension===1 && STATE.barOverrides[0].scale===undefined, 'bar overrides are cleaned', JSON.stringify(STATE.barOverrides));
  ok(STATE.touched.every(t=>t===false), 'lanes whose onsets do not fit are not trusted', JSON.stringify(STATE.touched));
  ok(STATE.profiles.chord.d.w===1 && STATE.profiles.chord.tau.w===1.5 && STATE.profiles.chord.tau.aff.every(x=>x>=0&&x<=1), 'profiles are clamped', JSON.stringify(STATE.profiles.chord.tau));
  ok(STATE.voiceEnv.every(e=>e.a>=0.001&&e.d<=3&&e.s<=1&&e.r>=0.005&&e.gateRatio>0), 'envelopes are clamped');
  ok(JSON.stringify(STATE.noteEnv)==='{}', 'only well-formed note envelopes survive', JSON.stringify(STATE.noteEnv));
  let finite=true; try{ const c=compose(); attachNotes(c); buildMidi(c); }catch(e){ finite=false; }
  ok(finite, 'and the cleaned state composes and exports');
}
