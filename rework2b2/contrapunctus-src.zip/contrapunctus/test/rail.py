import sys, os
from playwright.sync_api import sync_playwright
here=os.path.dirname(os.path.abspath(__file__)); root=os.path.dirname(here)
dark = '--dark' in sys.argv
w = 1440
for a in sys.argv:
    if a.startswith('--w='): w=int(a[4:])
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
    ctx=b.new_context(viewport={'width':w,'height':1000}, color_scheme='dark' if dark else 'light')
    ctx.route('**/fonts.g*/**', lambda r: r.abort())
    ctx.add_init_script('window.__CP_DEBUG=true;')
    pg=ctx.new_page(); pg.goto('file://'+os.path.join(root,'dist/contrapunctus.html'), wait_until='domcontentloaded'); pg.wait_for_timeout(1200)
    pg.add_style_tag(content='#rail{max-height:none!important;position:static!important;overflow:visible!important}')
    pg.wait_for_timeout(300)
    el=pg.query_selector('#rail'); el.screenshot(path=os.path.join(here,'out','rail'+('_dark' if dark else '')+'.png'))
    b.close()
