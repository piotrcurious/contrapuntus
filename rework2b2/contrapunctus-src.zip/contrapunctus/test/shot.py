#!/usr/bin/env python3
"""Load the built page in headless Chromium, report console / page errors, and take screenshots.
usage: shot.py [--nogl] [--w 1440] [--h 1000] [--dark] [--out name] [--full]"""
import sys, json, argparse, os
from playwright.sync_api import sync_playwright
ap=argparse.ArgumentParser()
ap.add_argument('--w',type=int,default=1440); ap.add_argument('--h',type=int,default=1000)
ap.add_argument('--dark',action='store_true'); ap.add_argument('--nogl',action='store_true')
ap.add_argument('--out',default='shot'); ap.add_argument('--full',action='store_true')
ap.add_argument('--src',default='dist/contrapunctus.html')
a=ap.parse_args()
here=os.path.dirname(os.path.abspath(__file__)); root=os.path.dirname(here)
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist','--autoplay-policy=no-user-gesture-required'])
    ctx=b.new_context(viewport={'width':a.w,'height':a.h}, color_scheme='dark' if a.dark else 'light', device_scale_factor=1)
    ctx.route('**/fonts.googleapis.com/**', lambda r: r.abort()); ctx.route('**/fonts.gstatic.com/**', lambda r: r.abort())
    ctx.add_init_script('window.__CP_DEBUG=true;'+('window.__CP_NOGL=true;' if a.nogl else ''))
    pg=ctx.new_page()
    pg.on('console', lambda m: errs.append(('console.'+m.type, m.text)) if m.type in ('error','warning') else None)
    pg.on('pageerror', lambda e: errs.append(('pageerror', str(e))))
    pg.goto('file://'+os.path.join(root,a.src), wait_until='domcontentloaded')
    pg.wait_for_timeout(1500)
    kind=pg.evaluate("window.__cp ? [window.__cp.GL_LAT && window.__cp.GL_LAT.kind, window.__cp.GL_ROLL && window.__cp.GL_ROLL.kind] : null")
    print('painters', kind)
    out=os.path.join(here,'out',a.out+'.png')
    pg.screenshot(path=out, full_page=a.full)
    print('shot', out)
    b.close()
for k,m in errs: print(k, m[:400])
print('errors:', len(errs))
