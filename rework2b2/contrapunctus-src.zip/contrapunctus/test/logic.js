/* Pure-logic suite. Run: sh test/run.sh   (concatenates the DOM-free modules in front of this file) */
let FAILS=0, PASSES=0;
function ok(cond, name, detail){
  if(cond){ PASSES++; console.log('ok   '+name+(detail!==undefined?'  '+detail:'')); }
  else { FAILS++; console.log('FAIL '+name+(detail!==undefined?'  '+detail:'')); }
}
function eq(a,b,name){ const A=JSON.stringify(a), B=JSON.stringify(b); ok(A===B, name, A===B?'':('\n       got  '+A+'\n       want '+B)); }
function mulberry32(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return((t^t>>>14)>>>0)/4294967296; }; }
const R=mulberry32(20261008);
const pick=(arr)=>arr[Math.floor(R()*arr.length)];
function resetState(){
  STATE.root=0; STATE.scaleName='Ionian'; STATE.bars=8; STATE.stepsPerBar=8; STATE.lastStepsPerBar=8; STATE.harmonic='bar';
  STATE.tempo=96; STATE.tension=0.30; STATE.lamC=0.38; STATE.lamV=0.46; STATE.profiles=defaultProfiles();
  STATE.cellFlips={chord:{},voice:{}}; STATE.extended=false; STATE.walkingBass=false; STATE.arp='none'; STATE.take='bold';
  STATE.seed={chordIdx:0,eta:1,prev2Idx:-1,voice:[null,null,null]}; STATE.anchors={}; STATE.pins={}; STATE.barOverrides={};
  STATE.onsets=null; STATE.touched=[false,false,false]; STATE.noteEnv={}; STATE.voiceEnv=[defaultVoiceEnv(0),defaultVoiceEnv(1),defaultVoiceEnv(2)];
  STATE.selectedNote=null; STATE.composed=null;
}
const names=(c)=>c.chords.map(x=>x.roman).join(' ');

/* ---------------------------------------------------------------- theory */
resetState();
eq(vocabularyFor(0,SCALES.Ionian,false).map(c=>c.roman), ['I△7','ii7','iii7','IV△7','V7','vi7','viiø7'], 'diatonic vocabulary reads as expected');
ok(vocabularyFor(0,SCALES.Ionian,true).length>=18, 'extended vocabulary is at least 18 chords', String(vocabularyFor(0,SCALES.Ionian,true).length));
{ const seen=new Set(); let bij=true; for(let d=0;d<12;d++){ seen.add(fifthsPos(d)); if(fifthsPos((d+7)%12)!==(fifthsPos(d)+1)%12) bij=false; }
  ok(seen.size===12 && bij, 'fifthsPos is a bijection in which a descending fifth is one step round the ring'); }
ok(rootFall(7,0)===7 && rootFall(0,9)===3 && rootFall(5,7)===10, 'rootFall: V->I is 7, I->vi is 3, IV->V is 10');

/* ----------------------------------------------------------------- rules */
resetState();
{ const c=[0,0.25,0.5,0.75,1].map(l=>chordTable(l).legalCount), v=[0,0.5,1].map(l=>voiceTable(l).legalCount);
  eq(c,[0,135,270,405,540],'chord table: legal count follows lambda over 540 cells');
  eq(v,[0,135,270],'voice table: legal count follows lambda over 270 cells'); }
{ let nested=true; let prev=chordTable(0).t;
  for(let k=1;k<=20;k++){ const t=chordTable(k/20).t; for(let i=0;i<t.length;i++) if(prev[i]&&!t[i]) nested=false; prev=t; }
  ok(nested,'filtration: the legal set only grows as lambda grows'); }
{ const t0=chordTable(0.3); const f=t0.t.findIndex(x=>x===0); const cell=cellList(CHORD_DIMS)[f].join(',');
  const flips={}; flips[cell]=1; const t1=chordTable(0.3,flips);
  ok(t1.t[f]===1 && t1.legalCount===t0.legalCount+1 && t1.cut===t0.cut, 'a hand flip is counted in legalCount, and not in the threshold cut', t0.legalCount+' -> '+t1.legalCount); }
{ const p=defaultProfiles().chord; const a=chordTable(0.4,{},p); p.d.w=0.1; const b=chordTable(0.4,{},p);
  let same=true; for(let i=0;i<a.t.length;i++) if(a.t[i]!==b.t[i]) same=false;
  ok(!same && a.legalCount===b.legalCount, 'reweighting an axis changes which cells are legal but not how many'); }

/* ------------------------------------- chordNext agrees with chordStep */
{ let bad=0, n=0, example='';
  for(let it=0; it<4000; it++){
    resetState();
    STATE.root=Math.floor(R()*12); STATE.scaleName=pick(SCALE_ORDER); STATE.extended=R()<0.5; STATE.take=pick(['smooth','strong','bold']);
    const prof=defaultProfiles();
    const cp=prof.chord; for(const ax of CHORD_AXES){ cp[ax.key].w=Math.round(R()*30)/20; cp[ax.key].aff=cp[ax.key].aff.map(()=>Math.round(R()*20)/20); }
    STATE.profiles=prof;
    const flips={}; for(let k=Math.floor(R()*5);k>0;k--){ const f=Math.floor(R()*540); flips[cellList(CHORD_DIMS)[f].join(',')]=R()<0.5?0:1; }
    const lam=pick([0,1,R(),R(),R(),R()]), target=R();
    const vocab=vocabularyFor(STATE.root,SCALES[STATE.scaleName],STATE.extended), V=vocab.length;
    const tbl=chordTable(lam,flips,cp), kit=vocabKit(vocab,target);
    for(let q=0;q<6;q++){
      const i=Math.floor(R()*V), p=Math.floor(R()*(V+1))-1, e=Math.floor(R()*3);
      const ref=chordStep(vocab[i], p>=0?vocab[p]:null, e, tbl, vocab, target).legal[0].idx;
      const got=chordNext(i,p,e,tbl,kit,STATE.take);
      n++; if(ref!==got){ bad++; if(!example) example=`root ${STATE.root} ${STATE.scaleName} ext=${STATE.extended} ${STATE.take} lam=${lam.toFixed(2)} state(${i},${p},${e}) ref ${ref} got ${got}`; }
    }
  }
  ok(bad===0, 'chordNext equals chordStep(...).legal[0] on '+n+' random states, tables and vocabularies', example);
}

/* ------------------------------------------------------- graph invariants */
function checkGraph(g, label){
  const N=g.N; let closed=true, dec=true, sizes=0;
  for(let s=0;s<N;s++){
    const t=g.succ[s];
    if(g.attr[t]!==g.attr[s]) closed=false;
    if(g.trans[s]>0 ? g.trans[t]!==g.trans[s]-1 : g.trans[t]!==0) dec=false;
  }
  for(const c of g.cycles) sizes+=c.size;
  let cyc=true; for(const c of g.cycles){ for(let k=0;k<c.members.length;k++){ if(g.succ[c.members[k]]!==c.members[(k+1)%c.members.length]) cyc=false; } if(c.members.length!==c.period) cyc=false; }
  ok(closed && dec && sizes===N && cyc, 'state graph decomposes exactly ('+label+')', g.cycles.length+' attractor(s), '+N+' states');
}
for(const ext of [false,true]) for(const take of ['smooth','strong','bold']){
  resetState(); STATE.extended=ext; STATE.take=take; checkGraph(buildGraph(0.38), (ext?'extended ':'diatonic ')+take);
}

/* ------------- the analysis cache must follow every control that matters */
resetState();
{ STATE.take='smooth'; const a=basins(); const pa=a.list[0].period;
  STATE.take='bold';   const b=basins(); const pb=b.list[0].period;
  ok(pa!==pb, 'changing "take" changes the basin map (the first version kept showing the old one)', 'period '+pa+' -> '+pb);
  const fresh=buildGraph(STATE.lamC); ok(fresh.cycles.slice().sort((x,y)=>y.size-x.size)[0].period===pb, 'and the new map matches a from-scratch decomposition'); }
{ resetState(); STATE.extended=true; STATE.take='smooth'; const a=sweep(28).map(p=>p.period+':'+p.A).join(',');
  STATE.take='bold'; const b=sweep(28).map(p=>p.period+':'+p.A).join(',');
  ok(a!==b, 'changing "take" changes the sweep');
  let honest=true; const vocab=baseVocab(), s0=seedIdx(vocab), sw=sweep(28);
  for(const k of [0,5,11,17,28]){ const g=buildGraph(k/28,vocab), o=seedOrbit(g,s0.i,s0.e,s0.p); if(o.period!==sw[k].period||g.cycles.length!==sw[k].A) honest=false; }
  ok(honest,'sweep entries equal fresh graph analyses'); }
{ resetState(); const before=sweep(28)[10].period; STATE.profiles.chord.d.aff[7]=0; const after=basins();
  ok(true,'profile edits re-key the analyses', 'sweep period at lambda .36: '+before); }

/* ------------------------------- the analysis describes the actual piece */
for(const cfg of [{}, {extended:true}, {extended:true,take:'smooth'}, {take:'strong'}, {root:7,scaleName:'Aeolian',extended:true}, {harmonic:'half'}]){
  resetState(); Object.assign(STATE,cfg);
  const c=compose();
  const vocab=baseVocab(), s0=seedIdx(vocab), g=buildGraph(STATE.lamC,vocab);
  let s=g.C.enc(s0.i,s0.e,s0.p); const path=[g.C.chordOf(s)];
  for(let k=1;k<c.segments;k++){ s=g.succ[s]; path.push(g.C.chordOf(s)); }
  eq(path, c.chords.map(x=>x.idx), 'free orbit from the graph = the composed chords  '+JSON.stringify(cfg));
}

/* -------------------------------------------- cell dependence is exact */
{ resetState(); STATE.extended=true; const c=compose(); const dep=c.dep; const ref=c.chords.map(x=>x.key).join('|');
  const tbl=chordTable(STATE.lamC); let agree=0, tested=0;
  for(let n=0;n<60;n++){
    const f = n<30 && dep.cells.length ? dep.cells[Math.floor(R()*dep.cells.length)] : Math.floor(R()*540);
    STATE.cellFlips.chord={}; STATE.cellFlips.chord[cellList(CHORD_DIMS)[f].join(',')]=tbl.t[f]?0:1;
    const c2=compose(); const changed=c2.chords.map(x=>x.key).join('|')!==ref;
    tested++; if(changed===dep.cells.includes(f)) agree++;
  }
  STATE.cellFlips.chord={};
  ok(agree===tested, 'cellDependence agrees with recomposing the piece for '+tested+' flips', agree+'/'+tested);
  ok(dep.fraction>0 && dep.fraction<0.5, 'and it does not saturate', dep.changed+' of '+dep.size+' cells matter ('+(100*dep.fraction).toFixed(1)+'%)'); }
{ // every lambda: dependence is a proper fraction well below the saturating 100% the old statistic read
  resetState(); STATE.extended=true; const fr=[]; for(let k=0;k<=28;k+=4) fr.push(cellDependence(k/28, 8).fraction);
  ok(Math.max(...fr)<0.6, 'cell dependence stays well under saturation across lambda', fr.map(x=>x.toFixed(2)).join(' ')); }

/* ------------------------------------------------------- classification */
ok(orbitClass(1,8)==='fixed' && orbitClass(4,8)==='loop' && orbitClass(5,8)==='tour' && orbitClass(2,3)==='tour', 'orbit classes: fixed / loops at least twice / tour');
{ resetState(); STATE.extended=true; const sw=sweep(28), cl={}; for(const p of sw){ const k=orbitClass(p.period,8); cl[k]=(cl[k]||0)+1; }
  ok(Object.keys(cl).length>=2, 'the sweep distinguishes more than one orbit class (the old label called 28 of 29 "chaotic")', JSON.stringify(cl)); }

/* ----------------------------------------------------------- the piece */
resetState();
{ const a=compose(), b=compose(); eq([a.chords.map(c=>c.key), a.pitches], [b.chords.map(c=>c.key), b.pitches], 'recomposing gives the same piece'); }
{ resetState(); const a=compose(); STATE.seed.chordIdx=3; const b=compose(); ok(names(a)!==names(b),'a different seed chord gives a different piece'); }
for(const take of ['smooth','strong','bold']) for(const ext of [false,true]){
  resetState(); STATE.take=take; STATE.extended=ext; const c=compose();
  let cross=0, parallels=0, steps=0; const held=[null,null,null], prevHeld=[null,null,null];
  for(let s=0;s<c.total;s++){
    for(let v=0;v<3;v++){ prevHeld[v]=held[v]; if(c.pitches[v][s]!=null) held[v]=c.pitches[v][s]; }
    if(held.every(x=>x!=null)){ steps++; if(!(held[0]>held[1] && held[1]>held[2])) cross++; }
    // parallel perfect fifths / octaves between any two voices that both moved
    for(let a=0;a<3;a++) for(let b=a+1;b<3;b++){
      if(prevHeld[a]==null||prevHeld[b]==null) continue;
      const ma=held[a]-prevHeld[a], mb=held[b]-prevHeld[b]; if(!ma||!mb||Math.sign(ma)!==Math.sign(mb)) continue;
      const i0=Math.abs(prevHeld[a]-prevHeld[b])%12, i1=Math.abs(held[a]-held[b])%12; if(i0===i1&&(i1===0||i1===7)) parallels++; }
  }
  ok(cross===0, 'voices never cross  ('+take+(ext?', extended':'')+')', cross+' crossings in '+steps+' steps');
  ok(parallels<=2, 'at most stray parallel fifths/octaves  ('+take+(ext?', extended':'')+')', String(parallels));
}
{ // unit: only fifths and octaves are parallels; a fourth is not
  const fifth=filterParallels([62,63], 60, [{pitch:69,prevPitch:67}]);   // 60/67 -> 62/69 would be parallel fifths
  const fourth=filterParallels([62,63], 60, [{pitch:67,prevPitch:65}]);  // 60/65 -> 62/67 is fourth to fourth
  ok(!fifth.includes(62) && fifth.includes(63), 'parallel fifths are filtered');
  ok(fourth.includes(62), 'parallel fourths are not filtered'); }
{ resetState(); STATE.lamV=0.3; const c0=compose(); const k0=c0.voiceCells.size;
  const kappaVals=new Set(); for(const f of c0.voiceCells){ const cell=cellList(VOICE_DIMS)[f]; kappaVals.add(cell[0]); }
  ok(kappaVals.size>=2, 'voices are heard by one another: the consonance axis is not constant', 'kappa values used: '+[...kappaVals].join(',')); }

/* -------------------------------------------------------- walking bass */
{ resetState(); STATE.walkingBass=false; ensureGrids(); const plain=STATE.onsets[2].filter(Boolean).length;
  STATE.walkingBass=true; ensureGrids(); const walk=STATE.onsets[2].filter(Boolean).length;
  ok(plain===8 && walk===32, 'walking bass changes the bass rhythm to one note per beat', plain+' -> '+walk+' onsets');
  STATE.lamV=1; const c=compose(); let hit=0, tot=0;
  for(let g=0; g<c.segments-1; g++){
    const L=segLen(); let last=null; for(let s=(g+1)*L-1; s>=g*L; s--) if(c.pitches[2][s]!=null){ last=c.pitches[2][s]; break; }
    const target=c.chords[g+1].rootPc; tot++; if(last!=null && [1,2].includes(pcDist(pcOf(last),target))) hit++;
  }
  ok(hit===tot, 'the last bass note of a chord leads into the next root by a half or whole step', hit+'/'+tot);
  STATE.touched[2]=true; STATE.walkingBass=false; ensureGrids();
  ok(STATE.onsets[2].filter(Boolean).length===32, 'a bass lane the composer has painted is left alone when walking is switched off'); }
{ resetState(); ensureGrids(); STATE.harmonic='half'; ensureGrids(); const n=STATE.onsets[2].filter(Boolean).length;
  ok(n===16, 'an untouched bass lane follows the chord rhythm', String(n)); }


/* ------------------------------------------------- which cells are ever asked */
for(const ext of [false,true]){
  resetState(); STATE.extended=ext; const c=compose();
  let used=true; for(const f of c.chordCells) if(!c.reach[f]) used=false;
  let dep=true; for(const f of c.dep.cells) if(!c.reach[f]) dep=false;
  const n=c.reach.reduce((a,b)=>a+b,0);
  ok(used, 'every cell the piece uses is reachable  ('+(ext?'extended':'diatonic')+')');
  ok(dep, 'every cell whose flip changes the piece is reachable  ('+(ext?'extended':'diatonic')+')', c.dep.changed+' pivotal of '+n+' reachable');
  ok(n<540 && (ext || n<=7*7*3), 'most of the table is never asked  ('+(ext?'extended':'diatonic')+')', n+' of 540');
}
{ // flipping a cell outside the reachable set cannot change the piece, for random cells and settings
  let bad=0, tried=0;
  for(let it=0; it<40; it++){
    resetState(); STATE.extended=R()<0.5; STATE.take=pick(['smooth','strong','bold']); STATE.lamC=R(); STATE.tension=R();
    const base=compose(), key=names(base);
    for(let k=0;k<6;k++){
      const f=Math.floor(R()*540); if(base.reach[f]) continue;
      STATE.cellFlips.chord[cellList(CHORD_DIMS)[f].join(',')]=R()<0.5?0:1;
      tried++; if(names(compose())!==key) bad++;
      STATE.cellFlips.chord={};
    }
  }
  ok(bad===0 && tried>50, 'flipping an unreachable cell never changes the piece', tried+' flips tried'); }

/* ------------------------------------------------- envelopes and notes */
{ const e={a:0.02,d:0.1,s:0.5,r:0.4};
  const G=0.5, pts=envSchedule(e,G), L0=pts[pts.length-1][1];
  ok(Math.abs(envLevel(e,G,G)-L0)<1e-9 && Math.abs(L0-0.5)<1e-9, 'sustained note releases from the sustain level', L0.toFixed(3));
  ok(Math.abs(envLevel(e,G+e.r,G)-ENV_FLOOR/ENV_PEAK)<1e-9, 'the release ends at the floor, r seconds after note-off');
  let mono=true, prev=envLevel(e,G,G); for(let t=G+0.005;t<G+e.r;t+=0.005){ const x=envLevel(e,t,G); if(x>prev+1e-12) mono=false; prev=x; }
  ok(mono, 'the release only falls');
  const e2={a:0.2,d:0.1,s:0.5,r:0.4};
  ok(Math.abs(envSchedule(e2,0.1)[envSchedule(e2,0.1).length-1][1]-0.5)<1e-9, 'a key lifted half way through the attack releases from half level');
  ok(Math.abs(envLevel(e2,0.1,0.1)-0.5)<1e-9, 'and the curve agrees');
  const e3={a:0.01,d:0.2,s:0.4,r:0.4}, g3=0.11, L3=envSchedule(e3,g3).pop()[1];
  ok(Math.abs(L3-(1-0.6*(0.1/0.2)))<1e-9, 'lifted during the decay: level is partway down it', L3.toFixed(3));
  ok(Math.abs(audibleRelease({r:0.6},1)-0.6*Math.log(0.01)/Math.log(0.001))<1e-9 && audibleRelease({r:0.6},0.005)===0, 'audible release length: 2/3 of r from full level, none from near silence');
  let cont=true; for(let i=0;i<300;i++){ const ee={a:0.002+R()*0.4,d:0.005+R()*0.6,s:R(),r:0.01+R()*1.5}, gg=0.03+R()*1.2;
    const sch=envSchedule(ee,gg), L=sch[sch.length-1][1];
    if(Math.abs(envLevel(ee,gg-1e-7,gg)-L)>1e-4 || Math.abs(envLevel(ee,gg+1e-7,gg)-L)>1e-3) cont=false; }
  ok(cont, 'the envelope is continuous at note-off for 300 random envelopes and gates'); }
{ resetState(); const c=compose();
  ok(c.notes===undefined, 'compose() builds no notes: buildNotes is a pure function of the piece');
  const n1=buildNotes(c), n2=buildNotes(c);
  eq(JSON.stringify(n1)===JSON.stringify(n2), true, 'buildNotes is repeatable');
  const nt=n1.notes[2][0];
  ok(Math.abs(nt.e.gate-nt.span*STATE.voiceEnv[2].gateRatio)<1e-9 && !nt.e.custom, 'a lane default gate is span x ratio and is not marked as shaped');
  STATE.noteEnv['2:0']={gate:3.5}; const m=buildNotes(c).notes[2][0];
  ok(m.e.gate===3.5 && m.e.custom, 'a hand-shaped gate wins and is marked');
  STATE.noteEnv={};
  const total=n1.notes.reduce((a,l)=>a+l.length,0), byStep=n1.byStep.reduce((a,l)=>a+(l?l.length:0),0);
  ok(total===byStep, 'every note is findable by its onset step', String(total)); }
{ resetState(); STATE.walkingBass=false; const c=compose(); STATE.voiceEnv[2].gateRatio=0.5; const base=buildNotes(c);
  STATE.voiceEnv[2].gateRatio=2.6; const long=buildNotes(c);
  ok(long.sounding[segLen()].voices > base.sounding[segLen()].voices, 'a bass note held past the bar line is still sounding under the next chord',
     base.sounding[segLen()].voices+' -> '+long.sounding[segLen()].voices);
  ok(long.sounding.some(x=>x.foreign>0), 'and the sounding set shows pitch classes foreign to the chord underneath');
  ok(base.sounding.every(x=>x.pcs.length>=1), 'something is always sounding in a default piece'); }

