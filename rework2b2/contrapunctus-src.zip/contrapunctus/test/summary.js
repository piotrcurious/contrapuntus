console.log('\n'+PASSES+' passed, '+FAILS+' failed');
if(FAILS) process.exit(1);
