#!/bin/sh
# The container is rebuilt between turns; only /mnt/user-data survives. Checkpoint the source tree there.
D=/mnt/user-data/outputs/contrapunctus-src
mkdir -p "$D" && rm -rf "$D/src" "$D/test" "$D/tools" \
 && cd /home/claude/cp && tar --exclude=./dist --exclude=./node_modules --exclude=./test/out -cf - . | (cd "$D" && tar -xf -) \
 && echo "checkpointed to $D ($(find "$D" -type f | wc -l) files)"
