// Static checks for the bundle: undefined names, redeclared functions, use before define at module level.
const browser = Object.fromEntries(`window document localStorage sessionStorage navigator performance requestAnimationFrame cancelAnimationFrame
setTimeout clearTimeout setInterval clearInterval console TextEncoder TextDecoder btoa atob FileReader Blob URL MutationObserver ResizeObserver
getComputedStyle AudioContext webkitAudioContext Image Path2D OffscreenCanvas ImageData fetch CompressionStream DecompressionStream Response
matchMedia devicePixelRatio innerWidth innerHeight HTMLElement Event KeyboardEvent CustomEvent CSS queueMicrotask structuredClone crypto
DOMParser XMLSerializer Node SVGElement Element IntersectionObserver AbortController Audio Worker location history screen self
HTMLCanvasElement WebGLRenderingContext WebGL2RenderingContext PointerEvent FormData Uint8Array Float32Array Float64Array Int32Array Uint16Array Uint32Array`.split(/\s+/).map(n=>[n,'readonly']));
export default [{
  files: ['**/*.js'],
  languageOptions: { ecmaVersion: 2022, sourceType: 'script', globals: browser },
  rules: {
    'no-undef': 'error',
    'no-redeclare': 'error',
    'no-dupe-keys': 'error',
    'no-dupe-args': 'error',
    'no-const-assign': 'error',
    'no-func-assign': 'error',
    'no-unreachable': 'warn',
    'no-use-before-define': ['error', { functions: false, classes: false, variables: false }],
    'no-self-assign': 'warn',
    'no-unused-labels': 'warn',
    'no-cond-assign': 'warn',
    'no-fallthrough': 'warn',
    'no-inner-declarations': 'off',
  },
}];
