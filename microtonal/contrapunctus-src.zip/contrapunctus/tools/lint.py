#!/usr/bin/env python3
"""Run eslint over the built bundle and map each message back to its source module and line."""
import json, subprocess, glob, os, sys
here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
mods = sorted(os.path.basename(p) for p in glob.glob(os.path.join(here, 'src', '[0-9][0-9]-*.js')))
# the bundle starts with 2 header lines, then each module, joined by newlines
starts, line = [], 3
for m in mods:
    n = open(os.path.join(here, 'src', m), encoding='utf-8').read().count('\n') + 1   # the file's own lines (a trailing newline adds the join's empty line)
    starts.append((line, m)); line += n
out = subprocess.run(['eslint', '-c', os.path.join(here, 'tools', 'eslint.config.mjs'), '-f', 'json', os.path.join(here, 'dist', 'contrapunctus.js')],
                     capture_output=True, text=True, cwd=here)
try: res = json.loads(out.stdout)
except Exception: print(out.stdout[:3000], out.stderr[:3000]); sys.exit(2)
def where(l):
    cur = starts[0]
    for s in starts:
        if s[0] <= l: cur = s
    return cur[1], l - cur[0] + 1
n = 0
for f in res:
    for m in f['messages']:
        src, ln = where(m['line']); n += 1
        print('%-14s %4d  %-8s %s  [%s]' % (src, ln, 'error' if m['severity']==2 else 'warn', m['message'], m['ruleId']))
print(n, 'messages')
