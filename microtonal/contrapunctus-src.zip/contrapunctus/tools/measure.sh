#!/bin/sh
# usage: sh tools/measure.sh   -- the numbers quoted in the essay, computed by the engine (DOM-free modules, node)
cd "$(dirname "$0")/.." || exit 1
OUT=${TMPDIR:-/tmp}/cp_measure_$$.js
MODS="src/09-psy.js src/10-choice.js src/10-core.js src/11-rules.js src/12-automaton.js src/13-analysis.js src/14-inspect.js src/30-notes.js src/50-io.js"
cat $MODS tools/measure.js > "$OUT" && node "$OUT"; RC=$?; rm -f "$OUT"; exit $RC
