/* Measurements quoted in the essay (src/70-essay.js). Run: sh tools/measure.sh
   Everything here is computed by the engine itself; nothing is typed in. */
function resetState(){
  if(NN!==12) switchSpace(12);
  STATE.colour=false; STATE.notePins={}; STATE.div=12; STATE.timbre='soft';
  STATE.root=0; STATE.scaleName='Ionian'; STATE.bars=8; STATE.stepsPerBar=8; STATE.lastStepsPerBar=8; STATE.harmonic='bar';
  STATE.tempo=96; STATE.tension=0.30; STATE.lamC=0.38; STATE.lamV=0.46; STATE.profiles=defaultProfiles();
  STATE.cellFlips={chord:{},voice:{}}; STATE.extended=false; STATE.walkingBass=false; STATE.arp='none'; STATE.take='bold';
  STATE.seed={chordIdx:0,eta:1,prev2Idx:-1,voice:[null,null,null]}; STATE.anchors={}; STATE.pins={}; STATE.barOverrides={};
  STATE.onsets=null; STATE.touched=[false,false,false]; STATE.noteEnv={}; STATE.voiceEnv=[defaultVoiceEnv(0),defaultVoiceEnv(1),defaultVoiceEnv(2)];
  STATE.selectedNote=null; STATE.composed=null;
  STATE.envBank=defaultEnvBank(); STATE.envBrush=-1; STATE.notePreset={}; STATE.vetoChord={}; STATE.vetoNote={};
  STATE.choice=defaultChoice();
}
const P=(...a)=>console.log(...a);
const fx=(x,n)=>x.toFixed(n==null?2:n);
const piece=()=>{ compose(); return STATE.composed; };
const chordsOf=(c)=>c.chords.map(x=>x.key).join(' ');
const heard=(c)=>{ const o=[]; for(let v=0;v<3;v++) for(let t=0;t<c.total;t++) if(STATE.onsets[v][t]) o.push(v+':'+t+':'+c.pitches[v][t]); return o; };

/* ---- 1. the tables, by division ----------------------------------------------------------- */
P('## tables');
for(const N of [12,19,31,53,72]){
  resetState(); if(N!==12) switchSpace(N);
  for(const col of (SP.colour.length ? [false,true] : [false])){
    STATE.colour=col; STATE.extended=false;
    const v=baseVocab(), ext=(STATE.extended=true, baseVocab());
    STATE.extended=false;
    P('N='+N+' colour='+col+'  chord cells '+CHORD_STR.size+' voice cells '+VOICE_STR.size+'  diatonic vocab '+v.length+' extended '+ext.length+'  chord states '+(v.length*3*(v.length+1))+'/'+(ext.length*3*(ext.length+1)));
  }
}

/* ---- 2. what the piece can ask, and what matters, at the defaults ------------------------- */
P('## reach and dependence at the defaults (12, C major, 8x8, lambda .38)');
for(const ext of [false,true]){
  resetState(); STATE.extended=ext; const c=piece(); const segs=c.chords.length;
  const r=cellReach(segs); let asked=0; for(const x of r.reach||r) asked+=x?1:0;
  const cd=cellDependence(STATE.lamC, segs);
  P('extended='+ext+'  asked '+asked+' of '+CHORD_STR.size+'  flipping one changes the first '+segs+' chords: '+cd.changed+' cells (balanced)');
  for(const take of ['smooth','strong','bold']){ resetState(); STATE.extended=ext; STATE.choice=classicChoice(); STATE.take=take; piece(); const d2=cellDependence(STATE.lamC, segs); P('   classic '+take+': '+d2.changed+' cells'); }
}

/* ---- 3. attractors and cycle lengths over lambda, by choice -------------------------------- */
P('## attractors over lambda (29 values, as the dynamics panel sweeps it), by choice');
function sweepStats(label, setup){
  for(const ext of [false,true]){
    resetState(); STATE.extended=ext; setup();
    const out=sweep(28); const A=out.map(o=>o.A), L=out.map(o=>o.longest), S=out.map(o=>o.S);
    const per=out.map(o=>o.period);
    P(label.padEnd(34)+(ext?'extended ':'diatonic ')+' attractors '+Math.min(...A)+'..'+Math.max(...A)+'  longest cycle '+Math.max(...L)+'  seed orbit period '+Math.min(...per.filter(x=>x>0))+'..'+Math.max(...per)+'  seed memory max '+fx(Math.max(...S)));
  }
}
for(const take of ['smooth','strong','bold']) sweepStats('classic '+take, ()=>{ STATE.choice=classicChoice(); STATE.take=take; });
for(const pr of CHOICE_ORDER) for(const vr of [0,0.3,0.6]) for(const sd of (vr>0?[1,2,3]:[1])) sweepStats('scored '+pr+' var '+vr+' seed '+sd, ()=>{ STATE.choice=defaultChoice(); applyPreset(STATE.choice, pr); STATE.choice.preset=pr; STATE.choice.variety=vr; STATE.choice.seed=sd; });

/* ---- 4. the classic strongest take at the diatonic seven ------------------------------------ */
resetState(); STATE.choice=classicChoice(); STATE.take='strong';
P('## classic strong: '+piece().chords.slice(0,5).map(x=>x.roman).join(' '));
resetState(); P('## default piece chords: '+piece().chords.map(x=>x.roman).join(' '));

/* ---- 5. what the seed changes, at the defaults ----------------------------------------------- */
P('## seeds (defaults: balanced, variety .30, variation 1)');
{
  resetState(); const base=piece(), V=baseVocab().length, bc=chordsOf(base);
  let chordsChanged=0, n=0;
  for(let i=1;i<V;i++){ resetState(); STATE.seed.chordIdx=i; const c=piece(); const a=base.chords.map(x=>x.key), b=c.chords.map(x=>x.key); let d=0; for(let k=0;k<a.length;k++) if(a[k]!==b[k]) d++; chordsChanged+=d/a.length; n++; }
  P('another first chord changes '+fx(chordsChanged/n*100,0)+'% of the chords of the piece (mean over the other '+(V-1)+')');
  for(let v=0; v<3; v++){
    resetState(); const b0=piece(); const reg=REGISTERS[v], scale=scaleSteps(STATE.scaleName).map(o=>(STATE.root+o)%NN);
    const base0=heard(b0);
    let tot=0, cnt=0;
    for(let m=reg.lo; m<=reg.hi; m++){ if(!scale.includes(pcOf(m))) continue; if(m===b0.pitches[v][0]) continue;
      resetState(); STATE.seed.voice[v]=m; const c=piece(); const x=heard(c);
      let diff=0; const set=new Set(base0); for(const e of x) if(!set.has(e)) diff++; tot+=diff/Math.max(1,x.length); cnt++; }
    P(VOICE_NAMES[v]+': another starting pitch changes '+fx(tot/cnt*100,0)+'% of all the notes (mean over '+cnt+' alternatives)');
  }
}

/* ---- 6. variety: how far another variation moves the piece ------------------------------------ */
P('## variety');
for(const vr of [0,0.1,0.3,0.6,1]){
  resetState(); STATE.choice.variety=vr; STATE.choice.seed=1; const base=piece(); const bk=base.chords.map(x=>x.key); const bn=heard(base);
  let dc=0, dn=0, distinct=new Set([chordsOf(base)+'|'+bn.join()]); const K=40;
  for(let s=2;s<=K+1;s++){ resetState(); STATE.choice.variety=vr; STATE.choice.seed=s; const c=piece(); const ck=c.chords.map(x=>x.key); let d=0; for(let k=0;k<bk.length;k++) if(ck[k]!==bk[k]) d++; dc+=d/bk.length;
    const x=heard(c); const set=new Set(bn); let same=0; for(const e of x) if(set.has(e)) same++; dn+=1-same/Math.max(1,x.length); distinct.add(chordsOf(c)+'|'+x.join()); }
  P('variety '+vr+': another variation changes '+fx(dc/K*100,0)+'% of the chords and '+fx(dn/K*100,0)+'% of the notes; '+distinct.size+' distinct pieces in '+(K+1)+' variations');
}
/* how often the best-ranked move is the one played (chords), at variety .3, over all states of the diatonic graph */
{
  resetState(); const vocab=baseVocab(), V=vocab.length, kit=vocabKit(vocab, STATE.tension), eta=etaTable(), tbl=chordTable(STATE.lamC);
  for(const vr of [0.1,0.3,0.6,1]){
    let best=0, tot=0;
    for(let seed=1; seed<=5; seed++){
      const ch=defaultChoice(); ch.variety=vr; ch.seed=seed; const plan=choicePlan(ch), plan0=choicePlan(Object.assign(defaultChoice(),{variety:0}));
      for(let i=0;i<V;i++) for(let p=-1;p<V;p++) for(let e=0;e<3;e++){ tot++; if(chordNext(i,p,e,tbl,kit,plan)===chordNext(i,p,e,tbl,kit,plan0)) best++; }
    }
    P('variety '+vr+': the best-ranked chord is played in '+fx(best/tot*100,0)+'% of the states of the diatonic graph');
  }
}

/* ---- 7. the divisions: how well each reaches the simple ratios -------------------------------- */
P('## divisions');
for(const N of [12,17,19,22,24,31,41,53,72]){
  resetState(); if(N!==12) switchSpace(N);
  const T=(k)=>SP.targets.find(t=>t.key===k);
  const cons=SP.cons ? (SP.consSet? SP.consSet.size : SP.cons.length) : -1;
  P('N='+N+' step '+fx(1200/N,1)+'c  fifth '+T('fifth').steps+' ('+fx(T('fifth').err,1)+')  M3 '+T('M3').steps+' ('+fx(T('M3').err,1)+')  m3 '+T('m3').steps+' ('+fx(T('m3').err,1)+')  h7 '+T('h7').steps+' ('+fx(T('h7').err,1)+')  sub '+T('sub').steps+' ('+fx(T('sub').err,1)+')  neutral '+T('neutral').steps+' ('+fx(T('neutral').err,1)+')  colour '+SP.colour.map(c=>c.q).join(',')+'  consonant classes '+cons+' of '+Math.floor(N/2)+'   chain M3 '+SP.M3c+' used '+SP.M3);
}

/* ---- 8. the colour chords, and the size of melodic moves, over twenty variations -------------------- */
P('## colour chords and melodic moves, mean over variations 1..20 (balanced, variety .30, 8 bars)');
for(const N of [12,19,31,41,53,72]){
  resetState(); if(N!==12) switchSpace(N);
  let colourShare=0, K=20, moves={micro:0, step:0, third:0, leap:0, total:0}, ties=0, recovered=0, leaps=0;
  for(let sd=1; sd<=K; sd++){
    resetState(); if(N!==12) switchSpace(N); STATE.colour=SP.colour.length>0; STATE.choice.seed=sd;
    const c=piece(); const col=c.chords.filter(x=>/^(h7|sub|neu)$/.test(x.key.split(':')[1]||'')).length; colourShare+=col/c.chords.length;
    // melodic moves of the top voice, in cents
    const mel=[]; for(let t=0;t<c.total;t++) if(STATE.onsets[0][t]) mel.push(c.pitches[0][t]);
    for(let k=1;k<mel.length;k++){ const cents=Math.abs(mel[k]-mel[k-1])*1200/NN; moves.total++;
      if(cents===0) ties++; else if(cents<PSY_MICRO_CENTS+0.001) moves.micro++; else if(cents<=250) moves.step++; else if(cents<=420) moves.third++; else moves.leap++; }
  }
  const t=moves.total-ties;
  P('N='+N+' colour '+(SP.colour.length>0)+': colour chords '+fx(colourShare/K*100,0)+'% of the chords; melody moves (not repeats): within '+PSY_MICRO_CENTS+'c '+fx(moves.micro/t*100,0)+'%, up to a whole tone '+fx(moves.step/t*100,0)+'%, up to a major third '+fx(moves.third/t*100,0)+'%, larger '+fx(moves.leap/t*100,0)+'%; repeats '+fx(ties/moves.total*100,0)+'% of all');
}

/* ---- 9. leaps: how many are followed by a step back the other way ------------------------------ */
P('## leaps in the melody (a leap is a motion of 250 cents or more), balanced, variety .30, 20 variations');
for(const N of [12,31,53]){
  let leaps=0, rec=0, big=0, bigRec=0, moves=0;
  for(let sd=1; sd<=20; sd++){
    resetState(); if(N!==12) switchSpace(N); STATE.colour=SP.colour.length>0; STATE.choice.seed=sd;
    const c=piece(); const mel=[]; for(let t=0;t<c.total;t++) if(STATE.onsets[0][t]) mel.push(c.pitches[0][t]);
    for(let k=1;k<mel.length;k++){ const d=mel[k]-mel[k-1], a=Math.abs(d)*1200/NN; if(d!==0) moves++;
      if(a>=PSY_LEAP_CENTS && k+1<mel.length){ const e=mel[k+1]-mel[k], b=Math.abs(e)*1200/NN; const back=(e!==0 && Math.sign(e)!==Math.sign(d) && b<PSY_LEAP_CENTS);
        leaps++; if(back) rec++; if(a>=500){ big++; if(back) bigRec++; } } }
  }
  P('N='+N+': '+leaps+' leaps in '+moves+' moves ('+fx(leaps/moves*100,0)+'%); '+fx(rec/leaps*100,0)+'% are followed by a step the other way; leaps of a fourth or more: '+big+', '+fx(bigRec/Math.max(1,big)*100,0)+'% recovered');
}

/* ---- 10. both ends of lambda are the same rule ------------------------------------------------- */
P('## lambda 0 and lambda 1');
for(const [lbl,setup] of [['balanced',()=>{}],['classic bold',()=>{ STATE.choice=classicChoice(); STATE.take='bold'; }],['balanced, 31 steps',()=>{ switchSpace(31); STATE.colour=true; }]]){
  resetState(); setup(); STATE.lamC=0; STATE.lamV=0; const a=piece(), sa=chordsOf(a)+'|'+heard(a).join();
  resetState(); setup(); STATE.lamC=1; STATE.lamV=1; const b=piece(), sb=chordsOf(b)+'|'+heard(b).join();
  P(lbl+': pieces at lambda 0 and 1 '+(sa===sb?'are identical':'DIFFER'));
}
