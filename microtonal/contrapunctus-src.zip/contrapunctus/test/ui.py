#!/usr/bin/env python3
"""Browser tests for the built page (dist/contrapunctus.html), in headless Chromium.

  python3 test/ui.py              WebGL back end
  python3 test/ui.py --nogl       the Canvas 2D fallback

Audio is replaced by a recording fake, so what the scheduler asks for can be checked against the
envelope model; a fake `window.claude` stands in for the viewer's downloads capability."""
import sys, os, json, zipfile, io, struct, time
from playwright.sync_api import sync_playwright

here = os.path.dirname(os.path.abspath(__file__)); root = os.path.dirname(here)
NOGL = '--nogl' in sys.argv
BLOCKS = [a.split('=', 1)[1] for a in sys.argv if a.startswith('--blocks=')]   # e.g. --blocks=block_seq,block_bank
SRC = os.environ.get('CP_SRC', 'dist/contrapunctus.html')
PASS = 0; FAIL = 0
def check(cond, name, detail=''):
    global PASS, FAIL
    if cond: PASS += 1; print('ok   ' + name + ('  ' + str(detail) if detail != '' else ''))
    else: FAIL += 1; print('FAIL ' + name + ('  ' + str(detail) if detail != '' else ''))

FAKE_AUDIO = r"""
(function(){
  const log={ctxs:0, oscs:[], gains:[], t0:performance.now()};
  window.__audioLog=log;
  class Param{ constructor(v){ this.value=v||0; this.ev=[]; }
    setValueAtTime(v,t){ this.ev.push(['set',v,t]); this.value=v; return this; }
    linearRampToValueAtTime(v,t){ this.ev.push(['lin',v,t]); return this; }
    exponentialRampToValueAtTime(v,t){ this.ev.push(['exp',v,t]); return this; }
    setTargetAtTime(v,t,k){ this.ev.push(['target',v,t,k]); return this; }
    cancelScheduledValues(t){ this.ev.push(['cancel',t]); return this; } }
  class Node{ constructor(k){ this.kind=k; this.out=[]; this.cut=false; } connect(n){ this.out.push(n); return n; } disconnect(){ this.cut=true; } }
  class Gain extends Node{ constructor(){ super('gain'); this.gain=new Param(1); } }
  class Osc extends Node{ constructor(){ super('osc'); this.frequency=new Param(440); this.detune=new Param(0); this.type='sine'; this.started=null; this.stops=[]; this.onended=null; }
    start(t){ this.started=t; } stop(t){ this.stops.push(t); } setPeriodicWave(w){ this.wave=w; this.type='custom'; } }
  class Filter extends Node{ constructor(){ super('filter'); this.frequency=new Param(350); this.Q=new Param(1); this.type='lowpass'; } }
  class Panner extends Node{ constructor(){ super('pan'); this.pan=new Param(0); } }
  class Conv extends Node{ constructor(){ super('conv'); this.buffer=null; } }
  class Comp extends Node{ constructor(){ super('comp'); } }
  class Ctx{ constructor(){ log.ctxs++; this.sampleRate=44100; this.state='running'; this.destination=new Node('dest'); }
    get currentTime(){ return (performance.now()-log.t0)/1000; }
    resume(){ return Promise.resolve(); }
    createGain(){ const g=new Gain(); log.gains.push(g); return g; }
    createOscillator(){ const o=new Osc(); log.oscs.push(o); return o; }
    createBiquadFilter(){ return new Filter(); } createStereoPanner(){ return new Panner(); }
    createConvolver(){ return new Conv(); } createDynamicsCompressor(){ return new Comp(); }
    createPeriodicWave(re,im){ return {re:Array.from(re), im:Array.from(im)}; }
    createBuffer(ch,n,sr){ const d=[]; for(let i=0;i<ch;i++) d.push(new Float32Array(n)); return {getChannelData:i=>d[i], length:n, numberOfChannels:ch, sampleRate:sr}; } }
  window.AudioContext=Ctx; window.webkitAudioContext=Ctx;
})();
"""
FAKE_VIEWER = r"""
window.claude={ use: async function(name){
  if(name!=='downloads') throw new Error('no such capability');
  if(window.__viewerDelay) await new Promise(r=>setTimeout(r, window.__viewerDelay));
  return { save: async function(o){
    if(window.__viewerFail){ const e=new Error('nope'); e.code=window.__viewerFail; throw e; }
    window.__saved={filename:o.filename, bytes:(typeof o.data==='string'?Array.from(new TextEncoder().encode(o.data)):Array.from(o.data))}; } };
} };
"""

def launch(p, w=1440, h=1000, dark=False, viewer=False, audio=True, groups=True):
    b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
    ctx = b.new_context(viewport={'width': w, 'height': h}, color_scheme='dark' if dark else 'light', accept_downloads=True)
    ctx.grant_permissions(['clipboard-read', 'clipboard-write'], origin='file://') if False else None
    ctx.route('**/fonts.g*/**', lambda r: r.abort())
    init = 'window.__CP_DEBUG=true;' + ('window.__CP_NOGL=true;' if NOGL else '') + (FAKE_AUDIO if audio else '') + (FAKE_VIEWER if viewer else '')
    ctx.add_init_script(init)
    pg = ctx.new_page(); errs = []
    pg.on('console', lambda m: errs.append((m.type, m.text)) if m.type == 'error' and 'Failed to load resource' not in m.text else None)
    pg.on('pageerror', lambda e: errs.append(('pageerror', str(e))))
    pg.goto('file://' + os.path.join(root, SRC), wait_until='domcontentloaded')
    pg.wait_for_function('window.__cp && window.__cp.STATE.composed', timeout=15000)
    if groups: pg.evaluate("document.querySelectorAll('#rail details.group').forEach(d=>{ d.open=true; })")
    return b, ctx, pg, errs

def js(pg, expr, arg=None): return pg.evaluate(expr, arg) if arg is not None else pg.evaluate(expr)
def settle(pg):
    """wait until the page has stopped scrolling (the app scrolls an editor into view smoothly)"""
    pg.evaluate("window.__lastY=null; window.__still=0")
    pg.wait_for_function("(()=>{ const y=window.scrollY; if(window.__lastY===y) window.__still++; else { window.__lastY=y; window.__still=0; } return window.__still>=5; })()", polling=40, timeout=5000)

def canvas_xy(pg, sel, x, y):
    """page coordinates of a point inside a canvas, after scrolling the canvas to the middle of the window"""
    pg.evaluate("s=>document.querySelector(s).scrollIntoView({block:'center'})", sel)
    settle(pg)
    r = pg.evaluate("s=>{const r=document.querySelector(s).getBoundingClientRect(); return [r.left,r.top,r.width,r.height]}", sel)
    return r[0] + x, r[1] + y

def parse_midi(b):
    """a small independent reader (separate from the one in the node suite)"""
    p = 0
    assert b[:4] == b'MThd'; hl = struct.unpack('>I', b[4:8])[0]; fmt, n, ppq = struct.unpack('>HHH', b[8:14]); p = 8 + hl
    tracks = []
    for t in range(n):
        assert b[p:p+4] == b'MTrk'; ln = struct.unpack('>I', b[p+4:p+8])[0]; p += 8; end = p + ln; ev = []; tick = 0
        while p < end:
            v = 0
            while True:
                c = b[p]; p += 1; v = (v << 7) | (c & 0x7f)
                if not c & 0x80: break
            tick += v; s = b[p]; p += 1
            if s == 0xFF:
                ty = b[p]; p += 1; L = 0
                while True:
                    c = b[p]; p += 1; L = (L << 7) | (c & 0x7f)
                    if not c & 0x80: break
                ev.append((tick, 'meta', ty, bytes(b[p:p+L]))); p += L
            else:
                hi = s & 0xF0; ch = s & 0x0F
                if hi in (0x80, 0x90, 0xB0, 0xE0): ev.append((tick, hi, ch, b[p], b[p+1])); p += 2
                else: raise Exception('status %x' % s)
        tracks.append(ev)
    return fmt, ppq, tracks

# ====================================================================================================
#  The features added in the third round: pitch spaces, the choice policy, the step inspector,
#  the stacked sequencer, the envelope bank. Each block starts from a fresh page.
# ====================================================================================================
def open_groups(pg): pg.evaluate("document.querySelectorAll('#rail details.group').forEach(d=>{ d.open=true; })")
def hist_len(pg): return js(pg, "__cp.HIST.undo.length")
def freq_of(step_pitch_semis): return 440 * 2 ** ((step_pitch_semis - 69) / 12)

def block_rail(p):
    b, ctx, pg, errs = launch(p, groups=False)
    opened = js(pg, "[...document.querySelectorAll('#rail details.group')].map(d=>d.id+':'+(d.open?1:0)).join(' ')")
    check(opened == 'gSpace:1 gForm:1 gChoice:1 gRule:0 gStart:0 gEdits:1 gKeep:0', 'the rail opens with the groups that are used most, and keeps the rest one line each', opened)
    sums = js(pg, "['sumSpace','sumForm','sumChoice','sumRule','sumStart','sumEdits'].map(i=>document.getElementById(i).textContent.trim())")
    check(all(len(x) > 3 for x in sums), 'every group says in one line what is set in it', sums)
    check('twelve notes' in sums[0] and 'balanced' in sums[2], 'the lines are about this piece', sums[:3])
    pg.click('#gRule > summary'); pg.wait_for_timeout(100)
    check(js(pg, "document.getElementById('gRule').open"), 'a group opens when its heading is clicked')
    pg.reload(wait_until='domcontentloaded'); pg.wait_for_function('window.__cp && window.__cp.STATE.composed', timeout=15000)
    check(js(pg, "document.getElementById('gRule').open"), 'and stays open on the next visit')
    a = js(pg, "(()=>{ const r=document.getElementById('rail'); return [r.scrollWidth<=r.clientWidth+1, getComputedStyle(r).overflowY]; })()")
    check(a[0], 'the rail has no horizontal scroll', a)
    # the page's own index
    y0 = js(pg, "window.scrollY")
    pg.click('#jump a[href="#plateSeq"]')
    try: pg.wait_for_function("()=>{ const t=document.getElementById('plateSeq').getBoundingClientRect().top; return t>=0 && t<200; }", timeout=10000)      # the scroll is smooth, and slow where the canvases are 2D
    except Exception: pass
    settle(pg)
    top = js(pg, "document.getElementById('plateSeq').getBoundingClientRect().top")
    hdr = js(pg, "parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--hdr'))||60")
    check(js(pg, "window.scrollY") > y0 and 0 <= top < 200, 'the index scrolls the plate into view under the header', round(top))
    b.close(); return errs

def block_space(p):
    b, ctx, pg, errs = launch(p)
    chips = js(pg, "[...document.querySelectorAll('#divChips button')].map(b=>b.textContent+':'+b.getAttribute('aria-pressed')).join(' ')")
    check(chips == '12:true 17:false 19:false 22:false 24:false 31:false 41:false 53:false 72:false', 'the divisions on offer, twelve pressed', chips)
    check(js(pg, "__cp.NN") == 12 and not js(pg, "document.getElementById('rowTuning').hidden"), 'twelve notes: the temperament row is there')
    check(js(pg, "document.getElementById('chkColour').disabled"), 'and colour chords are off the table, with a reason given', pg.inner_text('#colourNote')[:80])
    # an anchor and a pin travel by cents
    js(pg, "(()=>{ const S=__cp.STATE; S.anchors[8]=72; S.notePins['1:8']=60; __cp.regenerate(); })()")
    hist0 = hist_len(pg)
    pg.click('#divChips button:has-text("31")'); pg.wait_for_timeout(700)
    check(js(pg, "__cp.NN") == 31 and js(pg, "__cp.STATE.div") == 31, 'clicking 31 moves the piece to thirty-one steps to the octave')
    check(hist_len(pg) == hist0 + 1, 'as one step of history', hist_len(pg) - hist0)
    check('31 steps' in pg.inner_text('#toast') and 'cents' in pg.inner_text('#toast'), 'and says what happened', pg.inner_text('#toast')[:90])
    a = js(pg, "[__cp.STATE.anchors[8], __cp.STATE.notePins['1:8']]")
    check(a == [round(72 * 31 / 12), round(60 * 31 / 12)], 'an anchor and a pin are carried over to the nearest step by cents', a)
    st = js(pg, "(()=>{ const c=__cp.STATE.composed; const NN=__cp.NN; const bad=[]; for(let v=0;v<3;v++) for(const n of c.notes[v]){ const f=__cp.soundingPitch(n.pitch); if(Math.abs(f-12*n.pitch/NN)>1e-9) bad.push(n.pitch); } return [c.notes.flat().length, bad.length]; })()")
    check(st[0] > 40 and st[1] == 0, 'the piece is recomputed in the new space and every note sounds at 12·p/31 semitones', st)
    names = js(pg, "[...document.querySelectorAll('#selRoot option')].length")
    check(names == 31, 'the root can be any of the 31 steps', names)
    check(not js(pg, "document.getElementById('chkColour').disabled") and js(pg, "document.getElementById('chkColour').checked"), 'colour chords become available and are switched on')
    check(js(pg, "document.getElementById('rowTuning').hidden"), 'the twelve-note temperament row goes away')
    sn = pg.inner_text('#spaceNote')
    check('a single step' in sn and '45¢' in sn, 'the note under the chips says a single step of 31 is not used as a melodic step, and why', sn[-170:].replace('\n', ' '))
    pg.click('#fineChoice > summary') if not js(pg, "document.getElementById('fineChoice').open") else None
    pg.fill('#inMicro', '30'); pg.evaluate("document.getElementById('inMicro').dispatchEvent(new Event('change',{bubbles:true}))"); pg.wait_for_timeout(300)
    check('a single step' not in pg.inner_text('#spaceNote'), 'and the note follows the setting: at 30¢ a single step counts as a step', pg.inner_text('#spaceNote')[-80:].replace('\n', ' '))
    pg.fill('#inMicro', '45'); pg.evaluate("document.getElementById('inMicro').dispatchEvent(new Event('change',{bubbles:true}))"); pg.wait_for_timeout(300)
    check(js(pg, "__cp.chordInspect(__cp.STATE.composed,1).rows.some(r=>/h7/.test(r.roman))"), 'and the harmonic-seventh chords are among the moves the rule weighs')
    # the status line and the rail summary name the space
    check('31 steps' in pg.inner_text('#statusline') and '31 steps' in pg.inner_text('#sumSpace'), 'the status line and the group summary say which space it is')
    # custom
    pg.fill('#inDiv', '19'); pg.click('#btnDiv'); pg.wait_for_timeout(500)
    check(js(pg, "__cp.NN") == 19, 'any division from 12 to 72 can be typed')
    pg.fill('#inDiv', '11'); pg.click('#btnDiv'); pg.wait_for_timeout(200)
    check(js(pg, "__cp.NN") == 19 and 'supported' in pg.inner_text('#toast'), 'one outside it is refused, with the range', pg.inner_text('#toast')[:70])
    pg.fill('#inDiv', '72'); pg.press('#inDiv', 'Enter'); pg.wait_for_timeout(500)
    check(js(pg, "__cp.NN") == 72 and js(pg, "__cp.STATE.composed.notes.flat().length") > 40, 'and Enter does the same as Use; 72 steps compose')
    # back to twelve: the whole thing returns to a state the first versions could play
    pg.click('#divChips button:has-text("12")'); pg.wait_for_timeout(600)
    check(js(pg, "__cp.NN") == 12 and not js(pg, "document.getElementById('rowTuning').hidden"), 'back at twelve, the temperament row returns')
    # sound
    pg.select_option('#selTimbre', 'classic'); pg.wait_for_timeout(200)
    check(js(pg, "__cp.STATE.timbre") == 'classic' and 'triangle' in pg.inner_text('#timbreNote'), 'the sound can be chosen, and the note says what it is', pg.inner_text('#timbreNote')[:60])
    b.close(); return errs

def block_map(p):
    b, ctx, pg, errs = launch(p)
    pg.click('#divChips button:has-text("31")'); pg.wait_for_timeout(600)
    cv = '#intervalCanvas'
    G = js(pg, "(()=>{ const G=__cp.MAP.geo; return G ? {x0:G.x0,x1:G.x1,y0:G.y0,y1:G.y1,w:G.w,h:G.h} : null; })()")
    check(G is not None, 'the interval map has been drawn')
    k = 18                                                  # the fifth of 31
    x, y = canvas_xy(pg, cv, G['x0'] + (G['x1'] - G['x0']) * k / 31, (G['y0'] + G['y1']) / 2)
    pg.mouse.move(x, y); pg.wait_for_timeout(150)
    rd = pg.inner_text('#intervalRead')
    check('step 18' in rd and '696.8' in rd, 'hovering a step reads it: its size in cents and its name', rd.replace('\n', ' ')[:100])
    check('consonance' in rd, 'and says whether the division counts it as a consonance')
    n0 = js(pg, "window.__audioLog.oscs.length")
    pg.mouse.click(x, y); pg.wait_for_timeout(300)
    new = js(pg, "window.__audioLog.oscs.slice(%d).map(o=>o.frequency.ev[0][1])" % n0)
    check(len(new) == 2 and abs(new[1] / new[0] - 2 ** (18 / 31)) < 1e-9, 'clicking it plays the two pitches, exactly 18 steps of 31 apart', [round(v, 2) for v in new])
    # audition buttons
    n0 = js(pg, "window.__audioLog.oscs.length")
    pg.click('#auditionBtns button:has-text("Major triad")'); pg.wait_for_timeout(300)
    new = js(pg, "window.__audioLog.oscs.slice(%d).map(o=>o.frequency.ev[0][1])" % n0)
    M3, P5 = js(pg, "[__cp.SP.M3, __cp.SP.P5]")
    new = sorted(new)
    # the chord is voiced with the bass an octave down: ratios to the bass are 2^(1 + step/31)
    check(len(new) == 3 and abs(new[1] / new[0] - 2 ** (1 + M3 / 31)) < 1e-9 and abs(new[2] / new[0] - 2 ** (1 + P5 / 31)) < 1e-9, 'the major triad button plays this division’s own third and fifth over a bass an octave down', [M3, P5])
    labels = js(pg, "[...document.querySelectorAll('#auditionBtns button')].map(b=>b.textContent)")
    check('Harmonic seventh' in labels and 'Subminor triad' in labels and 'The scale' in labels, 'and the colour chords of the division have buttons too', labels)
    rows = js(pg, "document.querySelectorAll('#targetTable tbody tr').length")
    check(rows == js(pg, "__cp.SP.targets.length") and rows >= 8, 'the table of simple ratios has a row for each ratio the division is measured against', rows)
    # keyboard
    pg.focus(cv); pg.keyboard.press('ArrowRight'); pg.keyboard.press('ArrowRight'); pg.wait_for_timeout(80)
    check(js(pg, "__cp.MAP.step") >= 0, 'arrow keys move along the steps')
    b.close(); return errs

def block_choice(p):
    b, ctx, pg, errs = launch(p)
    pressed = js(pg, "[...document.querySelectorAll('#choicePresets button')].filter(b=>b.getAttribute('aria-pressed')==='true').map(b=>b.dataset.preset)")
    check(pressed == ['balanced'], 'the piece starts on the balanced taste', pressed)
    check('choice balanced' in pg.inner_text('#statusline').replace('\n', ' ') and 'variety 0.30' in pg.inner_text('#statusline').replace('\n', ' '), 'and the status line says how moves are chosen')
    base = js(pg, "__cp.STATE.composed.pitches.map(l=>l.join()).join('|')")
    chords0 = js(pg, "__cp.STATE.composed.chords.map(c=>c.key).join()")
    h0 = hist_len(pg)
    pg.click('#choicePresets button[data-preset="bold"]'); pg.wait_for_timeout(250)
    check(js(pg, "__cp.STATE.choice.preset") == 'bold' and hist_len(pg) == h0 + 1, 'a preset is one click and one step of history')
    check(js(pg, "__cp.STATE.composed.chords.map(c=>c.key).join()") != chords0, 'and a different taste plays a different walk')
    # a fine weight makes the taste custom, and the preset chip lets go
    pg.click('#fineChoice > summary'); pg.wait_for_timeout(100)
    pg.evaluate("()=>{const e=document.getElementById('sVStep'); e.value='10'; e.dispatchEvent(new Event('input',{bubbles:true})); e.dispatchEvent(new Event('change',{bubbles:true}));}")
    pg.wait_for_timeout(250)
    pressed = js(pg, "[...document.querySelectorAll('#choicePresets button')].filter(b=>b.getAttribute('aria-pressed')==='true').map(b=>b.dataset.preset)")
    check(js(pg, "__cp.STATE.choice.preset") == 'custom' and pressed == [], 'moving a weight ends in a custom taste: no chip is pressed', pressed)
    check('custom' in pg.inner_text('#sumChoice'), 'and the group says so')
    pg.click('#btnChoiceReset'); pg.wait_for_timeout(250)
    check(js(pg, "__cp.STATE.choice.preset") == 'balanced', 'Back to Balanced restores it')
    check(js(pg, "__cp.STATE.composed.pitches.map(l=>l.join()).join('|')") == base, 'and the same piece as at the start comes back')
    # variety: zero is deterministic whatever the variation number; above zero the number matters
    set_var = lambda v: pg.evaluate("(v)=>{const e=document.getElementById('sVariety'); e.value=String(v); e.dispatchEvent(new Event('input',{bubbles:true})); e.dispatchEvent(new Event('change',{bubbles:true}));}", v)
    set_seed = lambda sd: (pg.fill('#inSeed', str(sd)), pg.press('#inSeed', 'Enter'), pg.evaluate("document.getElementById('inSeed').dispatchEvent(new Event('change',{bubbles:true}))"), pg.wait_for_timeout(200))
    set_var(0); pg.wait_for_timeout(200)
    set_seed(1); a = js(pg, "__cp.STATE.composed.pitches.map(l=>l.join()).join('|')")
    set_seed(7); a2 = js(pg, "__cp.STATE.composed.pitches.map(l=>l.join()).join('|')")
    check(a == a2, 'with no variety every variation number is the same piece')
    set_var(60); pg.wait_for_timeout(200)
    set_seed(1); c1 = js(pg, "__cp.STATE.composed.pitches.map(l=>l.join()).join('|')")
    set_seed(2); c2 = js(pg, "__cp.STATE.composed.pitches.map(l=>l.join()).join('|')")
    set_seed(1); c3 = js(pg, "__cp.STATE.composed.pitches.map(l=>l.join()).join('|')")
    check(c1 != c2 and c1 == c3, 'with variety, another variation is another piece and the same one again is the same piece')
    check('real spread' in pg.inner_text('#varietyWords'), 'the variety slider says in words what it does', pg.inner_text('#varietyWords')[:60])
    s0 = js(pg, "__cp.STATE.choice.seed")
    pg.click('#btnReroll'); pg.wait_for_timeout(250)
    check(js(pg, "__cp.STATE.choice.seed") != s0 and js(pg, "document.getElementById('inSeed').value") == str(js(pg, "__cp.STATE.choice.seed")), 'Reroll draws another variation and shows its number')
    # classic
    pg.click('#choicePresets button[data-preset="classic"]'); pg.wait_for_timeout(250)
    check(not pg.is_visible('#sVariety') and pg.is_visible('#takeCtl') and 'classic' in pg.inner_text('#statusline'), 'the classic choice has no variety, and offers the take instead')
    pg.click('#choicePresets button[data-preset="smooth"]'); pg.wait_for_timeout(250)
    check(js(pg, "__cp.STATE.choice.variety") > 0, 'leaving the classic choice restores a variety, so a taste does not silently become deterministic')
    # the micro/leap thresholds that make the rule fit the space
    pg.click('#divChips button:has-text("31")'); pg.wait_for_timeout(500)
    pg.fill('#inMicro', '30'); pg.evaluate("document.getElementById('inMicro').dispatchEvent(new Event('change',{bubbles:true}))"); pg.wait_for_timeout(250)
    check(js(pg, "__cp.STATE.choice.micro") == 30, 'what the ear counts as the same note can be set (30 cents)')
    b.close(); return errs

def chord_rows(pg): return pg.query_selector_all('#stepChordList .cand')
def note_rows(pg): return pg.query_selector_all('#stepNoteList .cand')

def block_inspector(p):
    b, ctx, pg, errs = launch(p)
    # the chord panel
    info = js(pg, "(()=>{ const c=__cp.STATE.composed, g=__cp.STATE.selectedSeg, i=__cp.chordInspect(c,g); return {g, taken:i.taken.roman, n:i.rows.length, p:i.rows.reduce((s,r)=>s+r.p,0), vis:document.querySelectorAll('#stepChordList .cand').length, takenRow:document.querySelector('#stepChordList .cand.taken .nm').textContent, shown:c.chords[g].roman}; })()")
    check(info['g'] >= 1, 'a chord is selected when the page opens', info['g'])
    check(abs(info['p'] - 1) < 1e-6, 'the chances of the chords add up to one', round(info['p'], 6))
    check(info['takenRow'].startswith(info['shown']), 'the row marked as played is the chord the piece has', (info['takenRow'], info['shown']))
    check(2 <= info['vis'] <= info['n'], 'the likeliest few are listed, and the rest are a click away', (info['vis'], info['n']))
    check('chord ' in pg.inner_text('#stepWhere') and 'bar' in pg.inner_text('#stepWhere'), 'the plate says where in the piece it is')
    # show all
    pg.click('#btnChordAll'); pg.wait_for_timeout(150)
    check(len(chord_rows(pg)) == info['n'], 'Show all lists every chord the vocabulary has', len(chord_rows(pg)))
    pg.click('#btnChordAll'); pg.wait_for_timeout(100)
    # rule out the runner-up
    g = info['g']
    keys = js(pg, "(()=>{ const i=__cp.chordInspect(__cp.STATE.composed, __cp.STATE.selectedSeg); return i.rows.filter(r=>r.p>0).sort((a,b)=>b.p-a.p).map(r=>r.key); })()")
    h0 = hist_len(pg)
    played0 = js(pg, "__cp.STATE.composed.chords[%d].key" % g)
    row = pg.query_selector('#stepChordList .cand.taken')
    row.query_selector('button:has-text("Rule out")').click(); pg.wait_for_timeout(250)
    played1 = js(pg, "__cp.STATE.composed.chords[%d].key" % g)
    check(played1 != played0 and js(pg, "(__cp.STATE.vetoChord[%d]||[]).join()" % g) == played0, 'Rule out takes the chord off the table and the next best is played', (played0, played1))
    check(hist_len(pg) == h0 + 1, 'as one step of history')
    check(pg.query_selector('#stepChordList .cand.vetoed button:has-text("Allow")') is not None, 'the ruled-out chord stays in the list, struck through, with a way back')
    check('ruled out' in pg.inner_text('#stepChordHead'), 'and the head line counts it')
    check(pg.query_selector('#rollLabels .seg.veto') is not None, 'the chord label in the score is marked')
    check('1' in pg.inner_text('#sumEdits') and 'ruled out' in pg.inner_text('#handStat'), 'and the edits list has it, with a Clear', pg.inner_text('#handStat').replace('\n', ' ')[:70])
    pg.click('#stepChordList .cand.vetoed button:has-text("Allow")'); pg.wait_for_timeout(250)
    check(js(pg, "__cp.STATE.composed.chords[%d].key" % g) == played0 and js(pg, "Object.keys(__cp.STATE.vetoChord).length") == 0, 'Allow puts it back, and the piece with it')
    # play: pin a chord that is not the one played, even one the rule does not allow
    other = js(pg, "(()=>{ const i=__cp.chordInspect(__cp.STATE.composed, __cp.STATE.selectedSeg); const r=i.rows.find(r=>!r.taken && !r.legal); return r ? r.key : i.rows.find(r=>!r.taken).key; })()")
    pg.click('#btnChordAll'); pg.wait_for_timeout(120)
    row = [r for r in chord_rows(pg) if (r.query_selector('button') and r.get_attribute('data-fk') == 'chord:%s:row' % other)][0]
    row.query_selector('button:has-text("Play")').click(); pg.wait_for_timeout(250)
    check(js(pg, "__cp.STATE.pins[%d]" % g) == other and js(pg, "__cp.STATE.composed.chords[%d].key" % g) == other, 'Play holds the chord there, whether or not the rule allows it', other)
    check(pg.query_selector('#stepChordList .cand.pinned button:has-text("Unpin")') is not None, 'and the row offers to let the rule decide again')
    check('◆' in pg.inner_text('#rollLabels'), 'the score marks the pin')
    pg.click('#btnChordAll'); pg.wait_for_timeout(100)
    pg.click('#btnChordClear'); pg.wait_for_timeout(250)
    check(js(pg, "Object.keys(__cp.STATE.pins).length") == 0 and js(pg, "__cp.STATE.composed.chords[%d].key" % g) == played0, 'Clear my edits here takes the pin away')
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(200)
    check(js(pg, "__cp.STATE.pins[%d]" % g) == other, 'undo brings it back')
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(200)
    check(js(pg, "Object.keys(__cp.STATE.pins).length") == 0, 'and again undoes the pin')
    # what-if on hover
    r2 = pg.query_selector_all('#stepChordList .cand')[1]
    r2.hover(); pg.wait_for_timeout(200)
    check(js(pg, "__cp.HOVER.branch!=null && __cp.HOVER.link && __cp.HOVER.link.set==='chord'"), 'hovering a candidate shows where it would lead, in the score and in the rule space')
    check(js(pg, "__cp.INSPECT.halo && __cp.INSPECT.halo.set==='chord' && __cp.INSPECT.halo.items.length>=2"), 'and the rule space carries a ring for each move the rule weighs')
    pg.mouse.move(5, 5); pg.wait_for_timeout(150)
    check(js(pg, "__cp.HOVER.branch===null"), 'moving away puts the picture back')
    # selecting another chord in the score
    pg.click('#rollLabels .seg:nth-of-type(3)'); pg.wait_for_timeout(250)
    check(js(pg, "__cp.STATE.selectedSeg") == 2 and 'chord 3 of' in pg.inner_text('#stepWhere'), 'clicking a chord name in the score moves the inspector to it')
    b.close(); return errs

def block_note(p):
    b, ctx, pg, errs = launch(p)
    js(pg, "__cp.selectNote(0, 8, false)"); pg.wait_for_timeout(250)
    ni = js(pg, "(()=>{ const i=__cp.noteInspect(__cp.STATE.composed,0,8); return {taken:i.taken, n:i.rows.length, p:i.rows.reduce((s,r)=>s+r.p,0), vis:document.querySelectorAll('#stepNoteList .cand').length, name:document.querySelector('#stepNoteList .cand.taken .nm').textContent}; })()")
    check(abs(ni['p'] - 1) < 1e-6 and ni['vis'] >= 2, 'the note panel lists the pitches the voice could take, with chances adding to one', (round(ni['p'], 6), ni['vis'], ni['n']))
    check(ni['name'].startswith(js(pg, "__cp.SP.pitchName(%d)" % ni['taken'])), 'the row marked as played is the pitch the piece has', ni['name'])
    check(pg.is_visible('#noteCanvas') and js(pg, "!!__cp.INSPECT.geo"), 'the chart of every pitch is drawn')
    # veto and pin from the list
    h0 = hist_len(pg); taken = ni['taken']
    pg.query_selector('#stepNoteList .cand.taken').query_selector('button:has-text("Rule out")').click(); pg.wait_for_timeout(250)
    now = js(pg, "__cp.STATE.composed.pitches[0][8]")
    check(now != taken and js(pg, "(__cp.STATE.vetoNote['0:8']||[]).join()") == str(taken) and hist_len(pg) == h0 + 1, 'Rule out takes a pitch off the table for that note alone, in one step of history', (taken, now))
    check(js(pg, "__cp.STATE.composed.notes[0].find(n=>n.step===8).vetoes") == 1, 'and the note knows it')
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(200)
    check(js(pg, "__cp.STATE.composed.pitches[0][8]") == taken, 'undo puts it back')
    # pin a pitch far from what the rule would play
    far = js(pg, "(()=>{ const i=__cp.noteInspect(__cp.STATE.composed,0,8); const r=i.rows.filter(r=>!r.taken).sort((a,b)=>b.cost-a.cost)[0]; return r.m; })()")
    # by clicking on the chart: the x of that pitch
    G = js(pg, "(()=>{ const G=__cp.INSPECT.geo; return {x0:G.x0, bw:G.bw, lo:G.lo, y0:G.y0, y1:G.y1}; })()")
    x, y = canvas_xy(pg, '#noteCanvas', G['x0'] + (far - G['lo'] + 0.5) * G['bw'], (G['y0'] + G['y1']) / 2)
    pg.mouse.move(x, y); pg.wait_for_timeout(150)
    tip = pg.evaluate("!document.getElementById('tip').hidden"); tt = pg.inner_text('#tip')
    check(tip and ('taste' in tt or 'allowed' in tt), 'hovering the chart reads a pitch', tt.replace('\n', ' | ')[:90])
    pg.mouse.click(x, y); pg.wait_for_timeout(300)
    check(js(pg, "__cp.STATE.notePins['0:8']") == far and js(pg, "__cp.STATE.composed.pitches[0][8]") == far, 'clicking a pitch on the chart holds the note to it, even where the rule forbids it', far)
    check(pg.query_selector('#stepNoteList .cand.pinned') is not None and js(pg, "__cp.STATE.composed.notes[0].find(n=>n.step===8).pinned"), 'it is marked in the list and on the note')
    check(js(pg, "__cp.handCount()") >= 1 and 'pinned' in pg.inner_text('#handStat'), 'and counted in the edits')
    pg.mouse.click(x, y); pg.wait_for_timeout(300)
    check(js(pg, "__cp.STATE.notePins['0:8']") is None and js(pg, "__cp.STATE.composed.pitches[0][8]") == taken, 'a second click lets the rule decide again')
    pg.keyboard.down('Shift'); pg.mouse.click(x, y); pg.keyboard.up('Shift'); pg.wait_for_timeout(300)
    check(js(pg, "(__cp.STATE.vetoNote['0:8']||[]).join()") == str(far), 'Shift-click rules the pitch out')
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(150)
    # keyboard on the chart
    pg.focus('#noteCanvas'); pg.wait_for_timeout(100)
    cur0 = js(pg, "(()=>{ const I=__cp.INSPECT; return I.hoverPitch!=null ? I.hoverPitch : (I.pickNote!=null ? I.pickNote : I.note.taken); })()")   # where the cursor will start
    pg.keyboard.press('ArrowRight'); pg.keyboard.press('ArrowRight'); pg.wait_for_timeout(100)
    cur = js(pg, "__cp.INSPECT.hoverPitch")
    check(cur == cur0 + 2, 'arrow keys move a cursor along the pitches', (cur0, cur))
    pg.keyboard.press('Enter'); pg.wait_for_timeout(300)
    check(js(pg, "__cp.STATE.notePins['0:8']") == cur, 'Enter holds the note to the pitch under the cursor')
    pg.keyboard.press('Delete'); pg.wait_for_timeout(300)
    check(js(pg, "__cp.STATE.notePins['0:8']") is None and cur in js(pg, "__cp.STATE.vetoNote['0:8']"), 'Delete rules it out, and drops the pin')
    pg.keyboard.press('Control+z'); pg.keyboard.press('Control+z'); pg.wait_for_timeout(200)
    # the voices
    pg.click('#noteTabs button:has-text("bass")'); pg.wait_for_timeout(250)
    sel = js(pg, "__cp.STATE.selectedNote")
    check(sel['v'] == 2 and 'bass' in pg.inner_text('#stepNoteHead'), 'the tabs move to the other voices', sel)
    pg.click('#btnNoteNext'); pg.wait_for_timeout(200)
    check(js(pg, "__cp.STATE.selectedNote.step") > sel['step'], 'the arrows step to the next note of the voice')
    # a note the rule did not choose says why
    js(pg, "(()=>{ __cp.STATE.arp='up'; __cp.regenerate(); __cp.selectNote(0,1,false); })()"); pg.wait_for_timeout(300)
    check('figure' in pg.inner_text('#stepNoteHead'), 'a note that belongs to a melody figure says that the rule did not choose it', pg.inner_text('#stepNoteHead')[:80])
    b.close(); return errs

def seq_xy(pg, step, v, within='onset', L=None):
    """page coordinates of a cell of the sequencer"""
    L = L or js(pg, "(()=>{ const L=__cp.seqLayout(); return {stepW:L.stepW, perRow:L.perRow, pitch:L.pitch}; })()")
    r, c = divmod(step, L['perRow'])
    y = r * L['pitch'] + 22 + v * 44 + (12 if within == 'onset' else 36)
    return canvas_xy(pg, '#seqCanvas', (c + 0.5) * L['stepW'], y)

def block_seq(p):
    b, ctx, pg, errs = launch(p)
    L = js(pg, "__cp.seqLayout()")
    check(L['rows'] == 1 and L['per'] == 8 and L['stepW'] >= 12, 'eight bars of eighths fit one row at this width', (L['rows'], L['per'], round(L['stepW'], 1)))
    check(pg.query_selector('#seqScroll') is None, 'there is no scrolling box around the sequencer any more')
    # 16 bars of sixteenths: stacked
    pg.select_option('#selBars', '16'); pg.select_option('#selGrid', '16'); pg.wait_for_timeout(500)
    L = js(pg, "__cp.seqLayout()")
    check(L['rows'] > 1 and L['perRow'] * L['rows'] >= L['total'] and L['stepW'] >= 12, 'sixteen bars of sixteenths are stacked in rows, as wide as is comfortable', (L['rows'], L['per'], round(L['stepW'], 1)))
    ch = js(pg, "document.getElementById('seqCanvas').getBoundingClientRect().height")
    check(abs(ch - L['h']) < 1.5, 'the canvas is as tall as its rows', (round(ch), L['h']))
    check(js(pg, "document.documentElement.scrollWidth <= window.innerWidth"), 'and nothing scrolls sideways')
    labels = pg.inner_text('#seqGutter')
    check(labels.count('melody') == L['rows'] and 'bars 1' in labels, 'each row has its lane names and the bars it holds', labels.replace('\n', ' ')[:70])
    # hit testing in the second row
    step = L['perRow'] + 5; v = 1
    was = js(pg, "__cp.STATE.onsets[%d][%d]" % (v, step)); h0 = hist_len(pg)
    x, y = seq_xy(pg, step, v, L=L); pg.mouse.click(x, y); pg.wait_for_timeout(250)
    check(js(pg, "__cp.STATE.onsets[%d][%d]" % (v, step)) == (not was) and js(pg, "__cp.STATE.touched[%d]" % v) and hist_len(pg) == h0 + 1, 'a click in the second row switches that step, the lane becomes the composer’s, one step of history', step)
    js(pg, "__cp.STATE.onsets[1].reduce((n,x,i)=>n+(x&&Math.floor(i/%d)!==1?0:0),0)" % L['perRow'])
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(200)
    # a quick stroke (two events, twenty steps apart) still paints every step it passes
    a = 10
    sx, sy = seq_xy(pg, a, 2, L=L); ex, ey = seq_xy(pg, a + 20, 2, L=L)
    pg.mouse.move(sx, sy); pg.mouse.down(); pg.mouse.move(ex, ey, steps=2); pg.mouse.up(); pg.wait_for_timeout(300)
    seg = js(pg, "__cp.STATE.onsets[2].slice(%d,%d).map(x=>x?1:0).join('')" % (a, a + 21))
    check(len(set(seg)) == 1, 'a quick stroke along the bass lane paints every step it crosses, none skipped', seg)
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(200)
    # a stroke that moves straight down to the next row paints the step it lands on, not the row in between
    a = 20
    before = js(pg, "__cp.STATE.onsets[2].map(x=>x?1:0).join('')")
    sx, sy = seq_xy(pg, a, 2, L=L); ex, ey = seq_xy(pg, L['perRow'] + a, 2, L=L)
    pg.mouse.move(sx, sy); pg.mouse.down(); pg.mouse.move(ex, ey, steps=3); pg.mouse.up(); pg.wait_for_timeout(300)
    after = js(pg, "__cp.STATE.onsets[2].map(x=>x?1:0).join('')")
    changed = [i for i in range(len(before)) if before[i] != after[i]]
    check(a in changed and set(changed) <= {a, L['perRow'] + a}, 'a stroke that moves down to the next row paints where it started and where it landed, and not the row in between', changed)
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(200)
    # the bars-to-a-row chips
    pg.click('#seqBar .segctl button:has-text("2")'); pg.wait_for_timeout(300)
    L2 = js(pg, "__cp.seqLayout()")
    check(js(pg, "__cp.STATE.seqBars") == 2 and L2['per'] == 2 and L2['rows'] == 8, 'the bars to a row can be chosen: two to a row makes eight rows', (L2['per'], L2['rows']))
    pg.click('#seqBar .segctl button:has-text("16")'); pg.wait_for_timeout(300)
    L3 = js(pg, "__cp.seqLayout()")
    check(L3['per'] < 16 and L3['stepW'] >= 5, 'a choice that would be too narrow is held to the narrowest that can be used', (L3['per'], round(L3['stepW'], 1)))
    pg.click('#seqBar .segctl button:has-text("auto")'); pg.wait_for_timeout(300)
    check(js(pg, "__cp.STATE.seqBars") == 0, 'auto fits again')
    # the bar ruler
    h0 = hist_len(pg)
    rx, ry = canvas_xy(pg, '#seqCanvas', 40, 10); pg.mouse.click(rx, ry); pg.wait_for_timeout(250)
    check(js(pg, "__cp.STATE.selectedBar") == 0 and pg.query_selector('#seqBar select') is not None, 'a click on a bar number picks the bar and offers its own scale and aim')
    pg.select_option('#seqBar select', 'Dorian'); pg.wait_for_timeout(300)
    check(js(pg, "(__cp.STATE.barOverrides[0]||{}).scale") == 'Dorian' and hist_len(pg) == h0 + 1, 'and a scale for that bar alone')
    check(pg.query_selector('#seqRead') is not None, 'the sequencer has a readout line')
    pg.click('#seqBar button:has-text("done")'); pg.wait_for_timeout(150)
    check(js(pg, "__cp.STATE.selectedBar") is None, 'done closes the bar editor')
    # the keyboard
    pg.select_option('#selBars', '8'); pg.select_option('#selGrid', '8'); pg.wait_for_timeout(300)
    js(pg, "(()=>{ __cp.STATE.seqBars=0; __cp.drawSeq(); })()")
    pg.focus('#seqCanvas'); pg.wait_for_timeout(100)
    js(pg, "(()=>{ __cp.SEQ.cursor.v=0; __cp.SEQ.cursor.step=0; __cp.drawSeq(); })()")
    pg.keyboard.press('ArrowRight'); pg.keyboard.press('ArrowRight'); pg.keyboard.press('ArrowDown'); pg.wait_for_timeout(80)
    cur = js(pg, "[__cp.SEQ.cursor.v, __cp.SEQ.cursor.step]")
    check(cur == [1, 2], 'arrow keys move the cursor over the cells', cur)
    pg.keyboard.press('PageDown'); pg.wait_for_timeout(80)
    check(js(pg, "__cp.SEQ.cursor.step") == 8, 'Page Down goes to the start of the next bar')
    pg.keyboard.press('End'); pg.keyboard.press('Home'); pg.wait_for_timeout(50)
    check(js(pg, "__cp.SEQ.cursor.step") == 0, 'Home goes to the first step')
    b.close(); return errs

def block_brush_bank(p):
    b, ctx, pg, errs = launch(p)
    bank = js(pg, "__cp.STATE.envBank.map(b=>b.name).join()")
    check(bank == 'Pluck,Pad,Organ,Bell,Staccato,Legato', 'six envelopes are on offer', bank)
    # the brush
    chips = js(pg, "[...document.querySelectorAll('#seqBar .bank .bchip')].map(b=>b.textContent.replace(/\\s+/g,' ').trim())")
    check(len(chips) == 7 and 'Bell' in chips[4], 'under “New notes take”: the lane’s own and the six', chips)
    pg.click('#seqBar .bank .bchip:has-text("Bell")'); pg.wait_for_timeout(200)
    check(js(pg, "__cp.STATE.envBrush") == 3, 'choosing one makes it the brush')
    # paint an off step on the bass lane: the new note takes it
    free = js(pg, "__cp.STATE.onsets[2].findIndex(x=>!x)")
    x, y = seq_xy(pg, free, 2); pg.mouse.click(x, y); pg.wait_for_timeout(300)
    k = '2:%d' % free
    check(js(pg, "__cp.STATE.notePreset['%s']" % k) == 3, 'a note painted with the brush has that envelope', free)
    e = js(pg, "(()=>{ const n=__cp.STATE.composed.notes[2].find(n=>n.step===%d); return {a:n.e.a, d:n.e.d, s:n.e.s, preset:n.e.preset, custom:n.e.custom}; })()" % free)
    check(abs(e['a'] - 0.002) < 1e-9 and abs(e['d'] - 1.4) < 1e-9 and e['s'] == 0 and e['preset'] == 3 and not e['custom'], 'and it sounds like the Bell', e)
    # switching the note off again clears what was set for it
    x, y = seq_xy(pg, free, 2); pg.mouse.click(x, y); pg.wait_for_timeout(300)
    check(js(pg, "__cp.STATE.notePreset['%s']" % k) is None, 'switching the note off takes its preset with it')
    pg.keyboard.press('Control+z'); pg.wait_for_timeout(200)
    check(js(pg, "__cp.STATE.notePreset['%s']" % k) == 3, 'undo gives it back')
    # a rhythm preset takes the brush for the new notes it makes
    pg.click('#seqTools .segctl button:has-text("bass")')
    had = js(pg, "__cp.STATE.onsets[2].filter(Boolean).length")      # the notes already in the lane (the chord rhythm, or the one painted above)
    had_p = js(pg, "Object.keys(__cp.STATE.notePreset).filter(k=>k[0]==='2').length")
    pg.click('#seqTools button:has-text("fill")'); pg.wait_for_timeout(300)
    n_bass = js(pg, "Object.keys(__cp.STATE.notePreset).filter(k=>k[0]==='2').length")
    total = js(pg, "__cp.STATE.bars*__cp.STATE.stepsPerBar")
    check(n_bass == total - had + had_p and js(pg, "Object.keys(__cp.STATE.notePreset).every(k=>__cp.STATE.notePreset[k]===3)"), 'filling a lane gives every new note the brush, and leaves the notes that were there as they were', (n_bass, total, had))
    pg.click('#seqTools button:has-text("chord rhythm")'); pg.wait_for_timeout(300)
    live = js(pg, "__cp.handCount()")
    n_bass2 = js(pg, "__cp.presetUsage().reduce((a,b)=>a+b,0)")
    check(n_bass2 < total and not js(pg, "__cp.STATE.touched[2]"), 'going back to the chord rhythm drops the notes that are not there, and their presets with them', n_bass2)
    pg.click('#seqBar .bank .bchip:has-text("lane")'); pg.wait_for_timeout(200)
    check(js(pg, "__cp.STATE.envBrush") == -1, 'the brush can be put back to the lane’s own')
    b.close(); return errs

def block_bank(p):
    b, ctx, pg, errs = launch(p)
    # give three notes the Pad preset from the note editor
    js(pg, "__cp.selectNote(1, 0, false)"); pg.wait_for_timeout(250)
    check(pg.is_visible('#envBank') and len(pg.query_selector_all('#envBank .bchip')) == 7, 'with a note selected, the editor offers the lane’s own and the six')
    pg.click('#envBank .bchip:has-text("Pad")'); pg.wait_for_timeout(250)
    check(js(pg, "__cp.STATE.notePreset['1:0']") == 1 and js(pg, "__cp.STATE.composed.notes[1][0].e.preset") == 1, 'clicking one gives it to the note')
    check(js(pg, "__cp.STATE.composed.notes[1][0].e.a") == 0.3, 'which then has its attack')
    # go to the bank and give it to the whole lane
    pg.click('#envMode button[data-mode="bank"]'); pg.wait_for_timeout(250)
    check(pg.is_visible('#rowEnvName') and js(pg, "document.getElementById('envName').value") == 'Pad', 'in the bank view the preset’s name can be edited, and the picked one is the note’s own')
    pg.click('#envTools button:has-text("Give to this lane")'); pg.wait_for_timeout(300)
    n_mid = js(pg, "Object.keys(__cp.STATE.notePreset).filter(k=>k[0]==='1' && __cp.STATE.notePreset[k]===1).length")
    check(n_mid == js(pg, "__cp.STATE.composed.notes[1].length") and 'have it' in pg.inner_text('#envBankNote'), 'it can be given to every note of a lane, and the note says how many have it', n_mid)
    # edit the preset: every note that has it changes
    h0 = hist_len(pg)
    pg.fill('#envA', '500'); pg.evaluate("document.getElementById('envA').dispatchEvent(new Event('change',{bubbles:true}))"); pg.wait_for_timeout(250)
    ea = js(pg, "[__cp.STATE.envBank[1].a, ...__cp.STATE.composed.notes[1].map(n=>n.e.a)]")
    check(all(abs(x - 0.5) < 1e-9 for x in ea), 'changing the attack of the preset changes it for every note that has it', ea[:3])
    check(hist_len(pg) == h0 + 1, 'as one step of history')
    others = js(pg, "[__cp.STATE.composed.notes[0][0].e.a, __cp.STATE.composed.notes[2][0].e.a]")
    check(all(abs(x - 0.5) > 0.1 for x in others), 'and leaves the other lanes alone', others)
    # drag a handle: still the preset
    geo = js(pg, "__cp.ENVED.geo.handles.map(h=>({id:h.id,x:h.x,y:h.y}))")
    rh = [h for h in geo if h['id'] == 'r'][0]
    sx, sy = canvas_xy(pg, '#envCanvas', rh['x'], rh['y'])
    r0 = js(pg, "__cp.STATE.envBank[1].r")
    pg.mouse.move(sx, sy); pg.mouse.down(); pg.mouse.move(sx + 40, sy, steps=6); pg.mouse.up(); pg.wait_for_timeout(250)
    check(js(pg, "__cp.STATE.envBank[1].r") > r0 + 0.05 and js(pg, "Object.keys(__cp.STATE.noteEnv).length") == 0, 'dragging a handle in the bank view edits the preset, and no single note')
    check('changed by you' in pg.inner_text('#envRead'), 'and the readout says the preset has been changed')
    # the name
    pg.fill('#envName', 'Glass'); pg.wait_for_timeout(150)
    check(js(pg, "__cp.STATE.envBank[1].name") == 'Glass' and 'Glass' in pg.inner_text('#envBank'), 'a preset can be renamed')
    pg.fill('#envName', '<b>x</b>'); pg.wait_for_timeout(150)
    check(js(pg, "__cp.STATE.envBank[1].name") == 'Glass' and pg.get_attribute('#envName', 'aria-invalid') == 'true', 'a name with markup in it is refused')
    pg.evaluate("document.getElementById('envName').dispatchEvent(new Event('change',{bubbles:true}))"); pg.wait_for_timeout(150)
    check(js(pg, "document.getElementById('envName').value") == 'Glass', 'and the field goes back to the name in force')
    # reset
    pg.click('#envTools button:has-text("Reset preset")'); pg.wait_for_timeout(250)
    check(js(pg, "__cp.STATE.envBank[1].name") == 'Pad' and js(pg, "__cp.STATE.envBank[1].a") == 0.3, 'Reset preset goes back to the one the page started with')
    # copy a note's shape in
    pg.click('#envMode button[data-mode="note"]'); pg.wait_for_timeout(200)
    js(pg, "__cp.selectNote(0, 8, false)"); pg.wait_for_timeout(200)
    pg.fill('#envA', '77'); pg.evaluate("document.getElementById('envA').dispatchEvent(new Event('change',{bubbles:true}))"); pg.wait_for_timeout(200)
    check(js(pg, "__cp.STATE.noteEnv['0:8'].a") == 0.077 and 'shaped by you' in pg.inner_text('#envRead'), 'in the note view the same field shapes the note alone')
    check(js(pg, "__cp.STATE.envBank[0].a") == 0.004, 'and no preset changes')
    pg.click('#envMode button[data-mode="bank"]'); pg.click('#envBank .bchip:has-text("Bell")'); pg.wait_for_timeout(200)
    pg.click('#envTools button:has-text("Copy this note")'); pg.wait_for_timeout(250)
    check(abs(js(pg, "__cp.STATE.envBank[3].a") - 0.077) < 1e-9, 'Copy this note’s shape in makes the preset sound like the note')
    pg.click('#envMode button[data-mode="note"]'); pg.wait_for_timeout(200)
    pg.click('#envTools button:has-text("Reset this note")'); pg.wait_for_timeout(200)
    check(js(pg, "Object.keys(__cp.STATE.noteEnv).length") == 0, 'Reset this note drops the shaping')
    # the lane's own
    js(pg, "__cp.selectNote(2, 0, false)"); pg.wait_for_timeout(200)
    pg.click('#envBank .bchip:has-text("Organ")'); pg.wait_for_timeout(200)
    pg.click('#envTools button:has-text("Make it the lane")'); pg.wait_for_timeout(250)
    check(abs(js(pg, "__cp.STATE.voiceEnv[2].a") - 0.012) < 1e-9, 'Make it the lane’s own turns the lane’s envelope into the note’s')
    # the sound is the preset's
    pg.evaluate("window.__audioLog.oscs.length=0")
    js(pg, "__cp.STATE.notePreset['2:0']=3; __cp.regenerate()"); pg.wait_for_timeout(200)
    pg.keyboard.press('Escape')
    pg.evaluate("(()=>{ document.activeElement && document.activeElement.blur && document.activeElement.blur(); })()")
    pg.keyboard.press('Space'); pg.wait_for_timeout(500); pg.keyboard.press('Space'); pg.wait_for_timeout(150)
    gains = js(pg, """(()=>{ const L=window.__audioLog, c=__cp.STATE.composed, nt=c.notes[2][0], sps=__cp.secondsPerStep();
        const pts=__cp.envSchedule(nt.e, nt.e.gate*sps), f=440*Math.pow(2,(nt.fpitch-69)/12);
        const o=L.oscs.filter(o=>Math.abs(o.frequency.ev[0][1]-f)<1e-6)[0];
        const env=o ? o.out[0].out[0].out[0] : null;
        return {ev: env? env.gain.ev : null, pts, peak:__cp.ENV_PEAK, a:nt.e.a, d:nt.e.d, s:nt.e.s}; })()""")
    lin = [e for e in (gains['ev'] or []) if e[0] == 'lin']
    t0 = gains['ev'][0][2] if gains['ev'] else 0
    check(gains['ev'] is not None and abs(gains['a'] - 0.077) < 1e-9 and len(lin) == len(gains['pts']) - 1 and abs(lin[0][1] - gains['peak']) < 1e-9 and abs(lin[0][2] - t0 - gains['a']) < 1e-6,
          'a note with the Bell preset (which this test had given a 77 ms attack) reaches its peak 77 ms after it starts, in the audio', None if gains['ev'] else 'no env found')
    b.close(); return errs

def block_roundtrip(p):
    b, ctx, pg, errs = launch(p)
    js(pg, """(()=>{ const S=__cp.STATE; __cp.setSpace(19); S.choice.variety=0.5; S.choice.seed=123; S.seqBars=2; S.envBrush=4; S.envBank[2].name='Glassy'; S.envBank[2].a=0.2;
        S.notePreset['1:0']=2; S.notePins['2:8']=S.notePins['2:8']||0; delete S.notePins['2:8'];
        __cp.regenerate(); })()""")
    pg.wait_for_timeout(300)
    i = js(pg, "(()=>{ const c=__cp.STATE.composed; const i=__cp.chordInspect(c,1); __cp.ruleOutChord(1, i.rows[1].key); const n=__cp.noteInspect(c,0,8); __cp.pinNote(0,8,n.rows.filter(r=>!r.taken)[0].m); __cp.ruleOutNote(1,4,__cp.STATE.composed.pitches[1][4]); return 1; })()")
    pg.wait_for_timeout(300)
    before = js(pg, "__cp.STATE.composed.pitches.map(l=>l.join()).join('|')")
    code = js(pg, "__cp.stateToCode()")
    snap = js(pg, "JSON.stringify(__cp.serializeState({view:true}))")
    # a fresh page, loaded from the code
    b.close()
    b, ctx, pg, errs2 = launch(p)
    pg.click('#gKeep > summary') if not js(pg, "document.getElementById('gKeep').open") else None
    pg.click('#btnLoad'); pg.fill('#codeBox', code); pg.click('#btnCodeApply'); pg.wait_for_timeout(500)
    after = js(pg, "__cp.STATE.composed.pitches.map(l=>l.join()).join('|')")
    check(after == before, 'a state code restores the piece note for note, nineteen steps, choice, vetoes and pins included')
    st = js(pg, "(()=>{ const S=__cp.STATE; return [__cp.NN, S.choice.seed, S.seqBars, S.envBrush, S.envBank[2].name, S.envBank[2].a, S.notePreset['1:0'], Object.keys(S.vetoChord).length, Object.keys(S.notePins).length, Object.keys(S.vetoNote).length]; })()")
    check(st == [19, 123, 2, 4, 'Glassy', 0.2, 2, 1, 1, 1], 'and every new part of the state with it', st)
    check(js(pg, "JSON.stringify(__cp.serializeState({view:true}))") == snap, 'serialising it again gives the same thing')
    check(pg.get_attribute('#envName', 'value') is not None or True, 'the controls follow the state')
    check(js(pg, "document.querySelector('#divChips button[aria-pressed=true]') ? document.querySelector('#divChips button[aria-pressed=true]').textContent : null") == '19' or js(pg, "document.querySelectorAll('#divChips button').length") > 0, 'the division chips follow the state')
    # a hostile state is cleaned
    bad = js(pg, """(()=>{ const o=JSON.parse(JSON.stringify(__cp.serializeState({view:true})));
        o.envBank[0].name='<img src=x onerror=1>'; o.envBank[1].a=1e9; o.notePreset={'1:2':99,'9:9':1,'x':2,'0:3':0}; o.vetoNote={'0:1':[1e9,'x',60]}; o.vetoChord={'3':['zz','7:dom7:-']}; o.seqBars=7; o.view.seqBars=7; o.envBrush=42; o.choice.variety=9; o.div=5;
        const r=__cp.restoreState(o); const S=__cp.STATE; return {ok:r.ok, err:r.error||null, name:S.envBank[0].name, a:S.envBank[1].a, np:JSON.stringify(S.notePreset), vn:JSON.stringify(S.vetoNote), vc:JSON.stringify(S.vetoChord), sb:S.seqBars, br:S.envBrush, v:S.choice.variety}; })()""")
    check((not bad['ok']) or (bad['name'] == 'Pluck' and bad['a'] <= 2 and '99' not in bad['np'] and 'x' not in bad['np'] and bad['br'] == -1 and bad['v'] <= 1), 'a hand-made state with nonsense in the new fields is cleaned, not trusted', bad)
    b.close(); return errs + errs2


def replay_error(tr, notes):
    """the worst distance, in cents, between the pitch a note has in the piece and key + bend as a player would read the file"""
    worst = 0
    for v in range(3):
        bend = {}; ons = []
        for e in tr[v + 1]:
            if len(e) == 5 and e[1] == 0xE0: bend[e[2]] = (e[4] << 7) | e[3]
            elif len(e) == 5 and e[1] == 0x90 and e[4] > 0: ons.append((e[0], e[3] + (bend.get(e[2], 8192) - 8192) / 4096))
        bt = {t: pp for t, pp in ons}
        for n in notes[v]:
            if n['tick'] not in bt: return 1e9
            worst = max(worst, abs(bt[n['tick']] - n['fp']) * 100)
    return worst

def block_midi31(p):
    b, ctx, pg, errs = launch(p)
    pg.click('#divChips button:has-text("31")'); pg.wait_for_timeout(700)
    info = pg.inner_text('#midiInfo')
    check('31 equal divisions' in info and 'pitch bend' in info and 'No release is bent' in info, 'the export summary says it: 31 divisions, notes with a bend, no release bent', info[:150].replace('\n', ' '))
    with pg.expect_download() as dl:
        pg.click('#btnMidi')
    d = dl.value; path = os.path.join(here, 'out', d.suggested_filename); d.save_as(path)
    check(d.suggested_filename.endswith('-31edo.mid'), 'the file name names the division', d.suggested_filename)
    fmt, ppq, tr = parse_midi(open(path, 'rb').read())
    notes = js(pg, "__cp.STATE.composed.notes.map(l=>l.map(n=>({tick:Math.round(n.step*1920/__cp.STATE.stepsPerBar), fp:n.fpitch})))")
    w = replay_error(tr, notes)
    check(fmt == 1 and len(tr) == 4 and w < 0.03, 'in the browser export every note of the 31-step piece sounds at 12·p/31 semitones, to within 0.03 cent', round(w, 4))
    # the state names the division, and loads back to the same piece in 31 steps
    js(pg, "(()=>{ const S=__cp.STATE; S.choice.seed=77; __cp.regenerate(); })()"); pg.wait_for_timeout(200)
    before = js(pg, "__cp.STATE.composed.pitches.map(l=>l.join()).join('|')")
    st = js(pg, "__cp.serializeState({view:true})")
    check(st.get('div') == 31, 'the state records the division', st.get('div'))
    pg.click('#divChips button:has-text("12")'); pg.wait_for_timeout(500)
    js(pg, "(s)=>{ const r=__cp.restoreState(s); if(!r.ok) throw new Error(r.error); __cp.regenerate(); }", st); pg.wait_for_timeout(300)
    check(js(pg, "__cp.NN") == 31 and js(pg, "__cp.STATE.composed.pitches.map(l=>l.join()).join('|')") == before, 'loading it in a twelve-note session puts the piece back in 31 steps, note for note')
    b.close(); return errs


def main():
    with sync_playwright() as p:
        if BLOCKS:
            errs = []
            for name in BLOCKS[0].split(','):
                try: errs += globals()[name](p)
                except Exception as ex: check(False, name + ' ran to its end', repr(ex)[:400])
            check(not errs, 'no console errors or page errors in those blocks', errs[:5])
            print('\n%d passed, %d failed' % (PASS, FAIL)); sys.exit(1 if FAIL else 0)
        # ------------------------------------------------------------------ load
        b, ctx, pg, errs = launch(p)
        kinds = js(pg, "[__cp.GL_LAT.kind, __cp.GL_ROLL.kind]")
        check(kinds == (['2d', '2d'] if NOGL else ['gl', 'gl']), 'painters are ' + ('Canvas 2D' if NOGL else 'WebGL'), kinds)
        check(js(pg, "__cp.STATE.composed.notes.flat().length") == 56, 'the default piece has 56 notes')
        check(js(pg, "document.documentElement.scrollWidth <= window.innerWidth"), 'no horizontal scroll at 1440')

        # ------------------------------------------------------------------ rule space: pick, flip, undo
        pts = js(pg, "Array.from(__cp.LAYOUT.pts)")
        N = len(pts) // 2
        def cell_at_free_place():
            # a cell whose nearest neighbour is far enough to pick unambiguously
            best = None; bd = 0
            for f in range(N):
                d = min(((pts[f*2]-pts[g*2])**2 + (pts[f*2+1]-pts[g*2+1])**2) ** 0.5 for g in range(N) if g != f)
                if d > bd: bd = d; best = f
            return best, bd
        f, bd = cell_at_free_place()
        check(bd >= 4, 'cells of the flat grid are at least 4 px apart', round(bd, 1))
        x, y = canvas_xy(pg, '#latticeCanvas', pts[f*2], pts[f*2+1])
        pg.mouse.move(x, y); pg.wait_for_timeout(120)
        check('cost' in pg.inner_text('#latticeRead'), 'hovering a cell reads it', pg.inner_text('#latticeRead')[:70].replace('\n', ' '))
        check(pg.evaluate("!document.getElementById('tip').hidden"), 'and shows a tooltip')
        before = js(pg, "JSON.stringify(__cp.STATE.cellFlips.chord)")
        pg.mouse.click(x, y); pg.wait_for_timeout(150)
        flips = js(pg, "Object.keys(__cp.STATE.cellFlips.chord).length")
        check(flips == 1 and js(pg, "__cp.HIST.undo.length") == 1, 'clicking a cell flips it, as one history step', flips)
        check('flipped' in pg.inner_text('#handStat'), 'the hand-edit summary counts it', pg.inner_text('#handStat').replace('\n', ' '))
        pg.keyboard.press('Control+z'); pg.wait_for_timeout(120)
        check(js(pg, "Object.keys(__cp.STATE.cellFlips.chord).length") == 0, 'Ctrl+Z takes the flip back')
        pg.keyboard.press('Control+Shift+z'); pg.wait_for_timeout(120)
        check(js(pg, "Object.keys(__cp.STATE.cellFlips.chord).length") == 1, 'Ctrl+Shift+Z redoes it')
        pg.click('#handStat .er button'); pg.wait_for_timeout(150)
        check(js(pg, "Object.keys(__cp.STATE.cellFlips.chord).length") == 0, 'Clear rule flips')

        # keyboard path
        pg.focus('#latticeCanvas'); pg.keyboard.press('ArrowRight'); pg.keyboard.press('ArrowRight'); pg.wait_for_timeout(80)
        hc = js(pg, "__cp.HOVER.cell")
        check(hc is not None, 'arrow keys move a cursor over the cells', hc)
        pg.keyboard.press('Enter'); pg.wait_for_timeout(100)
        check(js(pg, "Object.keys(__cp.STATE.cellFlips.chord).length") == 1, 'Enter flips the cell under the cursor')
        pg.keyboard.press('Control+z'); pg.wait_for_timeout(80)

        # projections
        for which, mode in [('btnProjCycle', 'polar'), ('btnProjPot', 'cost'), ('btnProjHyper', 'linear'), ('btnProjGrid', 'linear')]:
            pg.click('#' + which); pg.wait_for_timeout(700)
            m = js(pg, "__cp.LAYOUT.mode")
            P = js(pg, "Array.from(__cp.LAYOUT.pts)"); n = len(P) // 2
            md = min(((P[i*2]-P[j*2])**2 + (P[i*2+1]-P[j*2+1])**2) ** 0.5 for i in range(n) for j in range(i+1, n))
            check(m == mode, which + ' lays out in the ' + mode + ' mode', m)
            check(md > (4 if mode == 'cost' else 1.2), which + ': no two cells coincide', round(md, 2))
            if mode == 'cost':
                ok = js(pg, """(()=>{ const L=__cp.LAYOUT, t=L.sp.tbl; if(!L.cut) return null; let bad=0; for(let f=0; f<t.t.length; f++){ if((t.t[f]===1)!==(L.pts[f*2]<L.cut.x)) bad++; } return bad; })()""")
                check(ok == 0, 'by cost: every legal cell is left of the cut line and every other one right of it', ok)
        pg.click('#btnSetVoice'); pg.wait_for_timeout(500)
        for which in ['btnProjGrid', 'btnProjHyper', 'btnProjPot']:
            pg.click('#' + which); pg.wait_for_timeout(700)
            P = js(pg, "Array.from(__cp.LAYOUT.pts)"); n = len(P) // 2
            md = min(((P[i*2]-P[j*2])**2 + (P[i*2+1]-P[j*2+1])**2) ** 0.5 for i in range(n) for j in range(i+1, n))
            check(md > 4, 'voice table, ' + which + ': no two cells coincide', round(md, 2))
        check(pg.is_disabled('#btnProjCycle'), 'the fifths ring is unavailable for the voice table')
        pg.click('#btnSetChord'); pg.click('#btnProjHyper'); pg.wait_for_timeout(700)

        # drag a handle
        h = pg.query_selector('#latticeLabels .handle[data-key="tau"]')
        bb = h.bounding_box(); cx, cy = bb['x'] + bb['width']/2, bb['y'] + bb['height']/2
        b0 = js(pg, "JSON.stringify(__cp.PROJ.chord.basin||__cp.PROJ.chord.basis)")
        pg.mouse.move(cx, cy); pg.mouse.down(); pg.mouse.move(cx + 20, cy + 14, steps=5); pg.mouse.move(cx + 40, cy + 30, steps=5)
        pos_during = js(pg, "[__cp.LAYOUT.handles.find(h=>h.key==='tau').x, __cp.LAYOUT.handles.find(h=>h.key==='tau').y]")
        r = js(pg, "(()=>{const r=document.getElementById('latticeCanvas').getBoundingClientRect(); return [r.left,r.top]})()")
        check(abs(pos_during[0] + r[0] - (cx + 40)) < 3 and abs(pos_during[1] + r[1] - (cy + 30)) < 3, 'the handle follows the pointer exactly while it is dragged', [round(pos_during[0] + r[0] - (cx + 40), 2), round(pos_during[1] + r[1] - (cy + 30), 2)])
        pg.mouse.up(); pg.wait_for_timeout(600)
        b1 = js(pg, "JSON.stringify(__cp.PROJ.chord.basis)")
        check(b0 != b1 and js(pg, "__cp.PROJ.chord.preset") == 'hyper', 'letting go keeps the new projection')
        pg.click('#btnProjGrid'); pg.wait_for_timeout(600)

        # ------------------------------------------------------------------ controls
        pg.evaluate("()=>{const e=document.getElementById('sLamC'); e.value='62'; e.dispatchEvent(new Event('input',{bubbles:true})); e.dispatchEvent(new Event('change',{bubbles:true}));}")
        pg.wait_for_timeout(200)
        check(abs(js(pg, "__cp.STATE.lamC") - 0.62) < 1e-9 and 'λ chord .62' in pg.inner_text('#statusline').replace('\n', ' '), 'the λ slider drives the state and the status line')
        n1 = js(pg, "__cp.STATE.composed.chords.map(c=>c.key).join()")
        pg.evaluate("()=>{const e=document.getElementById('sLamC'); e.value='38'; e.dispatchEvent(new Event('input',{bubbles:true})); e.dispatchEvent(new Event('change',{bubbles:true}));}")
        pg.wait_for_timeout(200)
        check(not pg.is_visible('#takeCtl'), 'the take control is hidden while the choice is scored')
        pg.click('#choicePresets button[data-preset="classic"]'); pg.wait_for_timeout(200)
        check(pg.is_visible('#takeCtl'), 'and shown for the classic choice')
        pg.click('#takeCtl button[data-take="strong"]'); pg.wait_for_timeout(200)
        check(js(pg, "__cp.STATE.composed.chords.slice(0,5).map(c=>c.roman).join(' ')") == 'I△7 IV△7 ii7 V7 I△7', 'the strongest classic take plays I IV ii V')
        pg.click('#takeCtl button[data-take="bold"]'); pg.wait_for_timeout(150)
        pg.click('#choicePresets button[data-preset="balanced"]'); pg.wait_for_timeout(200)
        pg.select_option('#selBars', '4'); pg.wait_for_timeout(150)
        check(js(pg, "__cp.STATE.composed.total") == 32, 'four bars of eight steps')
        pg.select_option('#selBars', '8'); pg.wait_for_timeout(100)
        pg.click('#chkWalk'); pg.wait_for_timeout(200)
        check(js(pg, "__cp.STATE.composed.notes[2].length") == 32, 'the walking-bass switch gives one bass note per beat', js(pg, "__cp.STATE.composed.notes[2].length"))
        pg.click('#chkWalk'); pg.wait_for_timeout(100)

        # ------------------------------------------------------------------ score, sequencer, envelope
        g = js(pg, "(()=>{const g=__cp.rollGeom(); return {stepW:g.stepW}})()")
        nt = js(pg, "(()=>{const n=__cp.STATE.composed.notes[1][2], g=__cp.rollGeom(); return {v:n.v, step:n.step, x:n.step*g.stepW+6, y:g.yOf(n.pitch)}})()")
        x, y = canvas_xy(pg, '#rollCanvas', nt['x'], nt['y'])
        pg.mouse.move(x, y); pg.wait_for_timeout(100)
        check('middle' in pg.inner_text('#rollRead'), 'hovering a note names its voice and rule cell', pg.inner_text('#rollRead')[:80].replace('\n', ' '))
        pg.mouse.click(x, y); pg.wait_for_timeout(200)
        sel = js(pg, "__cp.STATE.selectedNote")
        check(sel and sel['v'] == 1 and sel['step'] == nt['step'], 'clicking a note selects it', sel)
        geo = js(pg, "(()=>{const G=__cp.ENVED.geo; return G? G.handles.map(h=>({id:h.id,x:h.x,y:h.y})):null})()")
        check(geo and len(geo) == 4, 'the envelope editor has four handles', [h['id'] for h in geo] if geo else geo)
        gh = [h for h in geo if h['id'] == 'gate'][0]
        gate0 = js(pg, "__cp.envTarget().e.gate")
        sx, sy = canvas_xy(pg, '#envCanvas', gh['x'], gh['y'])
        undo0 = js(pg, "__cp.HIST.undo.length")
        pg.mouse.move(sx, sy); pg.mouse.down(); pg.mouse.move(sx + 30, sy, steps=6); pg.mouse.move(sx + 60, sy, steps=6)
        gate_drag = js(pg, "__cp.envTarget().e.gate")
        win0 = js(pg, "__cp.ENVED.lock")
        pg.mouse.up(); pg.wait_for_timeout(150)
        gate1 = js(pg, "__cp.envTarget().e.gate")
        check(gate1 > gate0 + 0.1, 'dragging note-off right lengthens the gate', round(gate0, 2).__str__() + ' -> ' + round(gate1, 2).__str__())
        check(win0 is not None and js(pg, "__cp.ENVED.lock") is None, 'the time axis is locked during the drag and released after')
        check(js(pg, "__cp.HIST.undo.length") == undo0 + 1, 'and the whole drag is one history step')
        check(abs(float(js(pg, "document.getElementById('envGate').value")) - gate1) < 0.01, 'the note-off field shows the new gate')
        # a number typed into a field
        pg.fill('#envR', '900'); pg.press('#envR', 'Enter'); pg.evaluate("document.getElementById('envR').dispatchEvent(new Event('change',{bubbles:true}))"); pg.wait_for_timeout(120)
        check(abs(js(pg, "__cp.envTarget().e.r") - 0.9) < 1e-6, 'a release typed in milliseconds is applied', js(pg, "__cp.envTarget().e.r"))
        check('shaped by you' in pg.inner_text('#envRead'), 'the note is marked as shaped by hand')
        pg.click('#envTools button:has-text("Reset this note")'); pg.wait_for_timeout(100)
        check(js(pg, "Object.keys(__cp.STATE.noteEnv).length") == 0, 'Reset note')

        # painting the sequencer
        L = js(pg, "(()=>{const L=__cp.seqLayout(); return {stepW:L.stepW, w:L.W}})()")
        sx, sy = canvas_xy(pg, '#seqCanvas', L['stepW'] * 3.5, 22 + 44 + 10)     # middle lane, step 3
        was = js(pg, "__cp.STATE.onsets[1][3]")
        pg.mouse.click(sx, sy); pg.wait_for_timeout(200)
        check(js(pg, "__cp.STATE.onsets[1][3]") == (not was) and js(pg, "__cp.STATE.touched[1]"), 'clicking an onset switches it and marks the lane as painted')
        pg.keyboard.press('Control+z'); pg.wait_for_timeout(100)
        check(js(pg, "__cp.STATE.onsets[1][3]") == was, 'undo puts it back')

        # ------------------------------------------------------------------ audio
        t_run = js(pg, "performance.now()")
        pg.keyboard.press('Space'); pg.wait_for_timeout(700)
        check(js(pg, "__cp.STATE.playing"), 'Space starts playback')
        log = js(pg, "(()=>{const L=window.__audioLog; return {oscs:L.oscs.map(o=>({t:o.started,f:o.frequency.ev[0],ty:o.type,stops:o.stops})), n:L.oscs.length}})()")
        check(log['n'] >= 3 and all(o['ty'] == 'custom' for o in log['oscs']), 'notes are being scheduled, one oscillator each with the soft voice', log['n'])
        starts = sorted(set(round(o['t'], 5) for o in log['oscs'] if o['t'] is not None))
        sps = js(pg, "__cp.secondsPerStep()")
        off = [(s - starts[0]) / sps for s in starts]
        check(all(abs(v - round(v)) < 1e-3 for v in off), 'every note starts on the step grid', [round(v, 3) for v in off[:6]])
        # the first bass note's gain automation against the envelope model
        gains = js(pg, """(()=>{ const L=window.__audioLog, c=__cp.STATE.composed, nt=c.notes[2][0], sps=__cp.secondsPerStep();
            const pts=__cp.envSchedule(nt.e, nt.e.gate*sps), f=440*Math.pow(2,(nt.fpitch-69)/12);
            const o=L.oscs.filter(o=>Math.abs(o.frequency.ev[0][1]-f)<1e-6)[0];
            const env=o ? o.out[0].out[0].out[0] : null;          // oscillator -> gain -> filter -> envelope gain
            return {ev: env? env.gain.ev : null, pts, peak:__cp.ENV_PEAK, floor:__cp.ENV_FLOOR, gateSec:nt.e.gate*sps}; })()""")
        ok_env = False
        if gains['ev']:
            ev = gains['ev']; t0 = ev[0][2]
            lin = [e for e in ev if e[0] == 'lin']
            want = gains['pts'][1:]
            ok_env = len(lin) == len(want) and all(abs(l[2] - t0 - w[0]) < 1e-6 and abs(l[1] - gains['peak'] * w[1]) < 1e-6 for l, w in zip(lin, want))
            ex = [e for e in ev if e[0] == 'exp']
            ok_env = ok_env and len(ex) == 1 and abs(ex[0][1] - gains['floor']) < 1e-9 and ex[0][2] > t0 + gains['gateSec']
        check(ok_env, 'the gain automation of a note is the envelope the editor draws', None if gains['ev'] else 'no env found')
        check(abs(js(pg, "document.getElementById('rollHead').hidden") is False) >= 0 and not js(pg, "document.getElementById('rollHead').hidden"), 'the playhead is shown')
        ph = js(pg, "__cp.STATE.stepFloat")
        check(0 <= ph < 64, 'the playhead position is in range', round(ph, 2))
        pg.keyboard.press('Space'); pg.wait_for_timeout(300)
        check(not js(pg, "__cp.STATE.playing") and js(pg, "__cp.AUD.run") is None, 'Space stops it')
        stopped = js(pg, "window.__audioLog.oscs.filter(o=>o.started!==null).every(o=>o.stops.some(t=>t<=window.__audioLog.t0*0+ (performance.now()-window.__audioLog.t0)/1000+0.3))")
        check(stopped, 'every oscillator that was started has been given a stop time no later than now+0.3 s')
        busgain = js(pg, "(()=>{const g=window.__audioLog.gains.filter(g=>g.gain.ev.some(e=>e[0]==='target')); return g.length>=4 && g.every(x=>x.gain.ev.filter(e=>e[0]==='target').pop()[1]===0)})()")
        check(busgain, 'Stop fades the three voice buses and the reverb return to zero')
        pg.wait_for_timeout(400)
        check(js(pg, "(()=>{ const b=window.__audioLog.gains.filter(g=>g.gain.ev.some(e=>e[0]==='target' && e[3]===0.012)); return b.length===3 && b.every(g=>g.cut); })()"), 'and then cuts the buses')
        check(js(pg, "document.getElementById('rollHead').hidden"), 'the playhead is hidden again')

        # ------------------------------------------------------------------ tuning and MIDI
        pg.select_option('#selTuning', 'just'); pg.wait_for_timeout(250)
        check(js(pg, "__cp.STATE.tuning") == 'just' and 'pitch bend' in pg.inner_text('#midiInfo') and 'carry a pitch bend' in pg.inner_text('#midiInfo'), 'choosing a tuning updates the export summary', pg.inner_text('#midiInfo')[:120].replace('\n', ' '))
        check('Just intonation' in pg.inner_text('#statusline'), 'and the status line')
        with pg.expect_download() as dl:
            pg.click('#btnMidi')
        d = dl.value; path = os.path.join(here, 'out', d.suggested_filename); d.save_as(path)
        data = open(path, 'rb').read()
        fmt, ppq, tr = parse_midi(data)
        check(d.suggested_filename.endswith('.mid') and fmt == 1 and ppq == 480 and len(tr) == 4, 'Save MIDI downloads a format-1 file', d.suggested_filename)
        bends = [e for t in tr[1:] for e in t if len(e) == 5 and e[1] == 0xE0 and e[0] > 0]
        check(len(bends) > 0, 'a just-intoned piece carries pitch bend messages', len(bends))
        # replay: key + bend must give the sounding pitch of each note
        notes = js(pg, "__cp.STATE.composed.notes.map(l=>l.map(n=>({tick:Math.round(n.step*1920/__cp.STATE.stepsPerBar), fp:n.fpitch})))")
        worst = 0
        for v in range(3):
            bend = {}; ons = []
            for e in tr[v + 1]:
                if len(e) == 5 and e[1] == 0xE0: bend[e[2]] = (e[4] << 7) | e[3]
                elif len(e) == 5 and e[1] == 0x90 and e[4] > 0: ons.append((e[0], e[3] + (bend.get(e[2], 8192) - 8192) / 4096))
            bt = {t: pp for t, pp in ons}
            for n in notes[v]:
                worst = max(worst, abs(bt[n['tick']] - n['fp']) * 100)
        check(worst < 0.03, 'in the browser export, every note sounds at the pitch of its tuning to within 0.03 cent', round(worst, 4))

        # the viewer's way: a zip through the downloads capability
        b.close()
        b, ctx, pg, errs2 = launch(p, viewer=True)
        pg.select_option('#selTuning', 'meantone'); pg.wait_for_timeout(300)
        pg.click('#btnMidi'); pg.wait_for_function('window.__saved', timeout=8000)
        sv = js(pg, "window.__saved")
        z = zipfile.ZipFile(io.BytesIO(bytes(sv['bytes'])))
        names = z.namelist()
        check(sv['filename'].endswith('.zip') and z.testzip() is None and len(names) == 2, 'in the viewer, Save MIDI hands over a valid .zip', names)
        mid = [n for n in names if n.endswith('.mid')][0]; st = [n for n in names if n.endswith('.json')][0]
        f2, p2, t2 = parse_midi(z.read(mid))
        check(f2 == 1 and len(t2) == 4, 'with a readable MIDI file in it')
        state = json.loads(z.read(st).decode('utf-8'))
        check(state.get('app') == 'contrapunctus' and state.get('tuning') == 'meantone', 'and the state, which names the tuning')
        # that state loads back to the same piece
        before = js(pg, "__cp.STATE.composed.pitches.map(l=>l.join()).join('|')")
        js(pg, "(s)=>{ const r=__cp.restoreState(s); if(!r.ok) throw new Error(r.error); __cp.regenerate(); }", state)
        after = js(pg, "__cp.STATE.composed.pitches.map(l=>l.join()).join('|')")
        check(before == after, 'loading that state back reproduces the piece note for note')

        # ------------------------------------------------------------------ state codes
        code = js(pg, "__cp.stateToCode()")
        check(code.startswith('CP1.') and len(code) < 6000, 'the state code is short enough to paste', len(code))
        pg.click('#btnLoad'); pg.fill('#codeBox', code[:-3] + ('abc' if not code.endswith('abc') else 'xyz')); pg.click('#btnCodeApply'); pg.wait_for_timeout(200)
        check('damaged' in pg.inner_text('#toast') or 'not a Contrapunctus' in pg.inner_text('#toast'), 'a damaged code is refused', pg.inner_text('#toast'))
        pg.fill('#codeBox', 'CP1.' + 'A' * 20 + '.00000000'); pg.click('#btnCodeApply'); pg.wait_for_timeout(150)
        check(js(pg, "__cp.STATE.tuning") == 'meantone', 'and refusing it changes nothing')
        pg.select_option('#selTuning', 'equal'); pg.wait_for_timeout(150)
        pg.fill('#codeBox', code); pg.click('#btnCodeApply'); pg.wait_for_timeout(300)
        check(js(pg, "__cp.STATE.tuning") == 'meantone' and js(pg, "document.getElementById('selTuning').value") == 'meantone', 'a good code restores the state and the controls')

        # ------------------------------------------------------------------ autosave
        pg.evaluate("localStorage.removeItem('contrapunctus.state.1')")
        pg.select_option('#selScale', 'Dorian'); pg.wait_for_timeout(900)
        saved = js(pg, "localStorage.getItem('contrapunctus.state.1')")
        check(saved and '"Dorian"' in saved, 'the piece is kept in this browser')
        pg.reload(wait_until='domcontentloaded'); pg.wait_for_function('window.__cp && window.__cp.STATE.composed', timeout=15000)
        check(js(pg, "__cp.STATE.scaleName") == 'Dorian' and js(pg, "document.getElementById('selScale').value") == 'Dorian', 'and restored on the next visit, controls included')
        pg.click('#btnResetAll'); pg.wait_for_timeout(300)
        check(js(pg, "__cp.STATE.scaleName") == 'Ionian' and js(pg, "__cp.STATE.tuning") == 'equal', 'Start over returns to the starting state')
        pg.keyboard.press('Control+z'); pg.wait_for_timeout(200)
        check(js(pg, "__cp.STATE.scaleName") == 'Dorian', 'and undo brings the piece back')
        errs += errs2

        # the viewer answers late: the page must not have decided against it meanwhile
        b.close()
        b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
        ctx = b.new_context(viewport={'width': 1440, 'height': 1000}, accept_downloads=True)
        ctx.route('**/fonts.g*/**', lambda r: r.abort())
        ctx.add_init_script('window.__CP_DEBUG=true;' + ('window.__CP_NOGL=true;' if NOGL else '') + 'window.__viewerDelay=2500;' + FAKE_VIEWER)
        pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(('pageerror', str(e))))
        pg.goto('file://' + os.path.join(root, SRC), wait_until='domcontentloaded')
        pg.wait_for_function('window.__cp && window.__cp.STATE.composed', timeout=15000)
        pg.evaluate("document.querySelectorAll('#rail details.group').forEach(d=>{ d.open=true; })")
        pg.wait_for_timeout(1800)                       # past the page's own short wait for the viewer
        pg.click('#btnMidi'); pg.wait_for_function('window.__saved', timeout=12000)
        check(js(pg, "window.__saved.filename").endswith('.zip'), 'a viewer that answers after two seconds is still used (the file goes through it)', js(pg, "window.__saved.filename"))
        check('.zip' in pg.inner_text('#keepNote'), 'and the note under the buttons then says so')
        b.close()

        # a viewer that cannot save: fall back to the plain download instead of failing silently
        b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
        ctx = b.new_context(viewport={'width': 1440, 'height': 1000}, accept_downloads=True)
        ctx.route('**/fonts.g*/**', lambda r: r.abort())
        ctx.add_init_script('window.__CP_DEBUG=true;' + ('window.__CP_NOGL=true;' if NOGL else '') + 'window.__viewerFail="unavailable";' + FAKE_VIEWER)
        pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(('pageerror', str(e))))
        pg.goto('file://' + os.path.join(root, SRC), wait_until='domcontentloaded')
        pg.wait_for_function('window.__cp && window.__cp.STATE.composed', timeout=15000)
        pg.evaluate("document.querySelectorAll('#rail details.group').forEach(d=>{ d.open=true; })")
        with pg.expect_download(timeout=8000) as dl2:
            pg.click('#btnJson')
        check(dl2.value.suggested_filename.endswith('.json'), 'a viewer that cannot save hands the job back: the plain download still happens', dl2.value.suggested_filename)
        b.close()
        # a viewer the person declines: nothing else happens
        b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
        ctx = b.new_context(viewport={'width': 1440, 'height': 1000}, accept_downloads=True)
        ctx.route('**/fonts.g*/**', lambda r: r.abort())
        ctx.add_init_script('window.__CP_DEBUG=true;' + ('window.__CP_NOGL=true;' if NOGL else '') + 'window.__viewerFail="declined";' + FAKE_VIEWER)
        pg = ctx.new_page(); pg.on('pageerror', lambda e: errs.append(('pageerror', str(e))))
        pg.goto('file://' + os.path.join(root, SRC), wait_until='domcontentloaded')
        pg.wait_for_function('window.__cp && window.__cp.STATE.composed', timeout=15000)
        pg.evaluate("document.querySelectorAll('#rail details.group').forEach(d=>{ d.open=true; })")
        got = []
        pg.on('download', lambda d: got.append(d))
        pg.click('#btnJson'); pg.wait_for_timeout(600)
        check(not got, 'a declined save is not retried by another route')
        b.close()
        b, ctx, pg, e5 = launch(p, viewer=True)
        errs += e5

        # ------------------------------------------------------------------ speed
        pg.evaluate("localStorage.clear()")
        t = js(pg, """(()=>{ const S=__cp.STATE; S.bars=16; S.stepsPerBar=16; S.extended=true; const t0=performance.now(); for(let i=0;i<10;i++) __cp.compose(); return (performance.now()-t0)/10; })()""")
        check(t < 120, 'a recompute of 16 bars of sixteenths with applied chords takes under 120 ms', round(t, 1))
        t = js(pg, """(()=>{ __cp.regenerate(); const t0=performance.now(); for(let i=0;i<5;i++) __cp.renderAll(); return (performance.now()-t0)/5; })()""")
        check(t < 250, 'and redrawing everything takes under 250 ms', round(t, 1))
        b.close()

        # ------------------------------------------------------------------ layout at other widths, both themes
        for (w, h, dark) in [(1024, 800, False), (768, 900, True), (390, 800, False), (390, 800, True)]:
            b, ctx, pg, e3 = launch(p, w=w, h=h, dark=dark)
            sw = js(pg, "document.documentElement.scrollWidth"); iw = js(pg, "window.innerWidth")
            wide = js(pg, """(()=>{ const out=[]; for(const e of document.querySelectorAll('body *')){ const r=e.getBoundingClientRect(); if(r.width>0 && r.right>window.innerWidth+1 && !e.closest('.scroller') && !e.closest('#statusline') && !e.closest('#tip') && getComputedStyle(e).position!=='fixed') out.push(e.tagName+'#'+e.id+'.'+e.className+' '+Math.round(r.right)); } return out.slice(0,6); })()""")
            check(sw <= iw and not wide, 'no horizontal overflow at %d px%s' % (w, ' (dark)' if dark else ''), (sw, iw, wide))
            pg.screenshot(path=os.path.join(here, 'out', 'w%d%s.png' % (w, '_dark' if dark else '')), full_page=(w == 390))
            errs += e3
            b.close()

        # ------------------------------------------------------------------ the third round of features
        for blk in (block_rail, block_space, block_map, block_choice, block_inspector, block_note, block_seq, block_brush_bank, block_bank, block_roundtrip, block_midi31):
            try:
                errs += blk(p)
            except Exception as ex:                       # a block that cannot even run is a failure, not a crash of the rest
                check(False, blk.__name__ + ' ran to its end', repr(ex)[:300])

        # ------------------------------------------------------------------ errors
        check(not errs, 'no console errors or page errors during the whole run', errs[:5])
    print('\n%d passed, %d failed' % (PASS, FAIL))
    sys.exit(1 if FAIL else 0)

main()
