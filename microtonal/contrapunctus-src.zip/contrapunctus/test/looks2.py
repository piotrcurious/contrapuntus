#!/usr/bin/env python3
"""Scenario screenshots of the new plates: python3 test/looks2.py <scenario> [--dark] [--w N]
scenarios: seq16 (16 bars of sixteenths, wrapped), e19/e53/e72 (other divisions: rule space, step plate, interval map), e31 (31 steps to the octave, step inspector), bank (envelope presets), edits (pins and vetoes)"""
import sys, os, argparse
from playwright.sync_api import sync_playwright
ap=argparse.ArgumentParser(); ap.add_argument('scn'); ap.add_argument('--dark',action='store_true'); ap.add_argument('--w',type=int,default=1440); ap.add_argument('--h',type=int,default=1000)
a=ap.parse_args()
here=os.path.dirname(os.path.abspath(__file__)); root=os.path.dirname(here)
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
    ctx=b.new_context(viewport={'width':a.w,'height':a.h}, color_scheme='dark' if a.dark else 'light')
    ctx.route('**/fonts.g*/**', lambda r: r.abort())
    ctx.add_init_script('window.__CP_DEBUG=true;')
    pg=ctx.new_page()
    pg.on('console', lambda m: errs.append((m.type,m.text)) if m.type=='error' and 'Failed to load resource' not in m.text else None)
    pg.on('pageerror', lambda e: errs.append(('pageerror',str(e))))
    pg.goto('file://'+root+'/dist/contrapunctus.html', wait_until='domcontentloaded')
    pg.wait_for_function('window.__cp && window.__cp.STATE.composed', timeout=15000)
    pg.evaluate("localStorage.clear()")
    def shot(sel, name, pad=10):
        pg.evaluate("s=>document.querySelector(s).scrollIntoView({block:'start'})", sel); pg.wait_for_timeout(250)
        out=os.path.join(here,'out',name+('_dark' if a.dark else '')+('_w%d'%a.w if a.w!=1440 else '')+'.png')
        pg.query_selector(sel).screenshot(path=out)
        print('shot',out)
    s=a.scn
    if s=='seq16':
        pg.evaluate("(()=>{ const S=__cp.STATE; S.bars=16; S.stepsPerBar=16; __cp.regenerate(); })()")
        pg.wait_for_timeout(300); shot('#plateSeq','seq16')
        print(pg.evaluate("JSON.stringify(__cp.seqLayout())"))
    elif s=='e31':
        pg.evaluate("__cp.setSpace(31)"); pg.wait_for_timeout(600)
        pg.evaluate("__cp.selectNote(0,8,false)"); pg.wait_for_timeout(300)
        shot('#plateStep','e31_step'); shot('#plateSpace','e31_space'); shot('#gSpace','e31_rail')
    elif s in ('e53','e72','e19'):
        n=int(s[1:]); pg.evaluate("n=>__cp.setSpace(n)", n); pg.wait_for_timeout(700)
        pg.evaluate("__cp.selectNote(0,8,false)"); pg.wait_for_timeout(300)
        shot('#plateRule', s+'_rule'); shot('#plateStep', s+'_step'); shot('#plateSpace', s+'_space')
    elif s=='bank':
        pg.evaluate("(()=>{ __cp.selectNote(1,0,false); document.querySelector('#envMode button[data-mode=bank]').click(); })()"); pg.wait_for_timeout(300)
        shot('#plateEnv','bank')
    elif s=='edits':
        pg.evaluate("(()=>{ const c=__cp.STATE.composed, i=__cp.chordInspect(c,1); __cp.ruleOutChord(1, i.rows[1].key); __cp.pinChord(2, __cp.chordInspect(c,2).rows[3].key); __cp.selectNote(0,8,false); })()")
        pg.wait_for_timeout(400); shot('#plateStep','edits_step'); shot('#gEdits','edits_rail'); shot('#plateScore','edits_score')
    b.close()
for e in errs: print(e)
print('errors',len(errs))
