/* The choice policy (10-choice.js): classic reproduces the earlier engine exactly; the scored choice is a
   deterministic, analysable, tuning-independent function of the situation. */

/* ---------------------------------------------- classic = the engine of the first two versions */
{
  const fs=require('fs'), path=require('path');
  const golden=JSON.parse(fs.readFileSync(path.join(process.env.CP_ROOT||'.','test','golden-classic.json'),'utf8'));
  const fnv=(s)=>{ let h=0x811c9dc5; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,0x01000193); } return h>>>0; };
  let bad=0, firstBad='';
  for(const g of golden){
    resetState(); const c=g.cfg;
    if(c.N!==12) switchSpace(c.N);
    STATE.root=c.root; STATE.scaleName=c.scale; STATE.take=c.take; STATE.extended=c.ext; STATE.colour=c.colour; STATE.walkingBass=c.walk; STATE.arp=c.arp;
    STATE.harmonic=c.half?'half':'bar'; STATE.lamC=c.lamC; STATE.lamV=c.lamV; STATE.tension=c.tension; STATE.bars=c.bars; STATE.stepsPerBar=c.spb; STATE.lastStepsPerBar=c.spb;
    STATE.seed.chordIdx=c.seedChord; STATE.seed.eta=c.seedEta; STATE.onsets=null;
    const out=compose(); attachNotes(out);
    const chords=out.chords.map(x=>x.key), pit=out.pitches.map(v=>fnv(v.map(p=>p==null?-1:p).join(','))), vc=out.vcell.map(v=>fnv(v.join(',')));
    const same = JSON.stringify(chords)===JSON.stringify(g.chords) && JSON.stringify(pit)===JSON.stringify(g.pitches) && JSON.stringify(vc)===JSON.stringify(g.vcells)
      && out.dyn.orbit.period===g.period && out.dyn.attractors===g.attractors;
    if(!same){ bad++; if(!firstBad) firstBad=JSON.stringify(c); }
  }
  resetState();
  ok(bad===0, 'the classic choice plays exactly the pieces the first two versions played ('+golden.length+' pieces, 12 to 72 divisions)', firstBad);
}

/* ---------------------------------------------- the hash: uniform, independent, and a Gumbel source */
{
  const B=64, n=200000, cnt=new Array(B).fill(0);
  for(let i=0;i<n;i++) cnt[Math.floor(unitOf(hash4(i%97, i>>3, (i*7)&1023, i&15))*B)]++;
  let chi=0; const e=n/B; for(const c of cnt) chi+=(c-e)*(c-e)/e;
  ok(chi<63+4*Math.sqrt(2*63), 'hash4 is uniform over 200000 inputs (chi-square, 63 degrees of freedom)', chi.toFixed(1));
  let bits=0, trials=3000;                                      // avalanche: one flipped input bit moves about half of the output bits
  const pc=(x)=>{ let c=0; while(x){ c+=x&1; x>>>=1; } return c; };
  for(let t=0;t<trials;t++){
    const a=[Math.floor(R()*2**31),Math.floor(R()*2**31),Math.floor(R()*2**31),Math.floor(R()*2**31)], k=Math.floor(R()*4), b=a.slice(); b[k]^=1<<Math.floor(R()*31);
    bits+=pc((hash4(a[0],a[1],a[2],a[3])^hash4(b[0],b[1],b[2],b[3]))>>>0);
  }
  ok(Math.abs(bits/trials-16)<0.6, 'one flipped input bit flips half of the 32 output bits', (bits/trials).toFixed(2));
  let s=0, s2=0, m=100000; for(let i=0;i<m;i++){ const g=gumbelOf(hash4(1,2,3,i)); s+=g; s2+=g*g; }
  const mean=s/m, vr=s2/m-mean*mean;
  ok(Math.abs(mean-0.5772)<0.02 && Math.abs(vr-Math.PI*Math.PI/6)<0.06, 'the noise is Gumbel: mean 0.577, variance pi^2/6', mean.toFixed(3)+' / '+vr.toFixed(3));
  ok(unitOf(0)>0 && unitOf(0xffffffff)<1 && isFinite(gumbelOf(0)) && isFinite(gumbelOf(0xffffffff)), 'the extreme hashes still give finite noise');
}

/* ---------------------------------------------- variety is a temperature: the draw is the softmax of the utilities */
{
  const u=[1.0,0.7,0.3,0.0,-0.5];
  for(const T of [0.15,0.4,1.0]){
    const w=u.map(x=>Math.exp(x/T)), S=w.reduce((a,b)=>a+b,0), p=w.map(x=>x/S), n=40000, cnt=u.map(()=>0);
    for(let seed=0;seed<n;seed++){
      let best=-1, bk=-Infinity;
      for(let j=0;j<u.length;j++){ const k=u[j]+T*gumbelOf(hash4(seed, 11, j, 3)); if(k>bk){ bk=k; best=j; } }
      cnt[best]++;
    }
    const worst=Math.max.apply(null, p.map((q,j)=>Math.abs(cnt[j]/n-q)/Math.sqrt(q*(1-q)/n)));
    ok(worst<4.2, 'over 40000 seeds the move chosen at T='+T+' has the Luce probabilities softmax(u/T)', 'worst deviation '+worst.toFixed(2)+' sigma');
  }
  // and the temperature the engine uses grows with variety, relative to the weights
  const a=choicePlan(Object.assign(defaultChoice(),{variety:0.2})), b=choicePlan(Object.assign(defaultChoice(),{variety:0.6}));
  ok(a.Tc<b.Tc && a.Tv<b.Tv && choicePlan(Object.assign(defaultChoice(),{variety:0})).Tc===0, 'the temperature rises with variety and is zero at variety zero');
  const heavy=defaultChoice(); heavy.chord.favour*=3; heavy.chord.smooth*=3; heavy.variety=0.3;
  const light=defaultChoice(); light.variety=0.3;
  ok(Math.abs(choicePlan(heavy).Tc/choicePlan(light).Tc-3)<1e-9, 'the temperature scales with the size of the weights, so a variety means the same thing at any weight');
}

/* ---------------------------------------------- the policy on real pieces */
function scoredState(cfg, div, colour){
  resetState();
  if(div && div!==12) switchSpace(div);
  STATE.colour=!!colour && NN!==12 && SP.colour.length>0;
  STATE.choice=defaultChoice();
  for(const k of Object.keys(cfg||{})){ if(typeof cfg[k]==='object') Object.assign(STATE.choice[k], cfg[k]); else STATE.choice[k]=cfg[k]; }
}
const chordsOf=(c)=>c.chords.map(x=>x.key);
function pieceHash(c){ return JSON.stringify([chordsOf(c), c.pitches]); }
{
  scoredState({seed:5}); const a=compose(), a2=compose();
  eq(pieceHash(a), pieceHash(a2), 'a scored piece comes back identically');
  scoredState({seed:6}); const b=compose();
  ok(pieceHash(a)!==pieceHash(b), 'a different seed is a different piece');
  const diff=(x,y)=>{ let d=0; for(let i=0;i<x.length;i++) if(x[i]!==y[i]) d++; return d/x.length; };
  scoredState({seed:5, variety:0}); const z1=compose(); scoredState({seed:6, variety:0}); const z2=compose();
  eq(chordsOf(z1), chordsOf(z2), 'at variety zero the chords do not depend on the seed: it is the rule and the weights alone');
  // variety makes pieces differ: the mean fraction of bars in which two seeds disagree grows with it
  const ds=[];
  for(const v of [0.05,0.3,0.8]){
    const P=[]; for(let sd=1;sd<=6;sd++){ scoredState({seed:sd, variety:v, }); STATE.bars=16; P.push(chordsOf(compose())); }
    let s=0,n=0; for(let i=0;i<P.length;i++) for(let j=i+1;j<P.length;j++){ s+=diff(P[i],P[j]); n++; } ds.push(s/n);
  }
  ok(ds[0]<ds[1] && ds[1]<=ds[2]+0.05 && ds[1]>0.5, 'two seeds disagree more as variety grows, and at the default most bars differ', ds.map(x=>x.toFixed(2)).join(' < '));
}

/* ---------------------------------------------- the analysis stays exact under the scored choice */
for(const preset of CHOICE_ORDER) for(const variety of [0,0.3,1]){
  scoredState({variety, seed:3}); applyPreset(STATE.choice, preset); STATE.extended=true;
  checkGraph(buildGraph(STATE.lamC), preset+', variety '+variety);
}
for(const [label, div, col, cfg] of [['12 balanced',12,false,{}],['12 smooth, half bars',12,false,{chord:{favour:0.15,smooth:1}}],['19',19,false,{seed:9}],['31 with colour',31,true,{seed:4}],['53 with colour',53,true,{seed:11, variety:0.5}],['72 with colour, still off',72,true,{chord:{still:false}}]]){
  scoredState(cfg, div, col); if(label.indexOf('half')>=0) STATE.harmonic='half'; STATE.extended=true;
  const c=compose(); const vocab=baseVocab(), s0=seedIdx(vocab), g=buildGraph(STATE.lamC,vocab);
  let s=g.C.enc(s0.i,s0.e,s0.p); const path=[g.C.chordOf(s)];
  for(let k=1;k<c.segments;k++){ s=g.succ[s]; path.push(g.C.chordOf(s)); }
  eq(path, c.chords.map(x=>x.idx), 'free orbit from the graph = the composed chords  ('+label+', '+choiceLabel()+')');
  checkGraph(g, label);
}
{ // the map from state to next chord is a function: whenever the same state comes round again, so does the same move
  let bad=0, repeats=0;
  for(const [div,col] of [[12,false],[31,true],[53,true]]) for(let seed=1;seed<=4;seed++){
    scoredState({seed, variety:0.6}, div, col); STATE.bars=16; STATE.harmonic='half'; STATE.extended=true;
    const c=compose(), seen=new Map();
    for(const w of c.walk){ if(!w.from) continue; const key=w.from.key+'|'+(w.prev2?w.prev2.key:'-')+'|'+w.etaIn+'|'+w.target.toFixed(3); const nxt=w.chord.key;
      if(seen.has(key)){ repeats++; if(seen.get(key)!==nxt) bad++; } else seen.set(key,nxt); }
  }
  ok(bad===0, 'the same chord state always leads to the same next chord, within a piece ('+repeats+' repeats seen)'); }
{ // what the inspector will show agrees with what the piece did
  let bad=0, n=0;
  for(const [div,col] of [[12,false],[31,true],[53,true]]){
    scoredState({seed:7}, div, col); const c=compose(), tbl=chordTable(), plan=choicePlan();
    for(let g=1; g<c.walk.length; g++){ const w=c.walk[g]; if(!w.from||w.pinned) continue;
      const all=chordCandidates(w.from, w.prev2, w.etaIn, tbl, baseVocab(), w.target, plan), legal=all.filter(x=>x.legal);
      const pool=(legal.length?legal:all).slice().sort(scoredOrder(plan)); n++;
      if(pool[0].c.key!==w.chord.key) bad++; }
    for(let v=0;v<3;v++) for(let s=0;s<c.total;s++){ const L=c.look[v][s]; if(!L) continue;
      const all=noteCandidates(L.cands, L.ctx, plan, false); if(!all.length||c.walk.length<1) continue;
      n++; const want=all.filter(x=>true).map(x=>x.m);
      if(!want.includes(c.pitches[v][s]) && !(L.ctx.force!=null) && !STATE.anchors[s] && L.cands.length) bad++; }
  }
  ok(bad===0, 'the candidates the inspector lists contain the move that was played ('+n+' decisions)'); }

/* ---------------------------------------------- the pieces are musical in every division */
{
  const f=(x)=>x.toFixed(2);
  const rows=[];
  let worst={cross:0, rough:0, aba:0, out:0, stp:1, ct:1, fus:1, stay:0};
  for(const N of DIV_CHOICES) for(const col of (N===12?[false]:[false,true])) for(let seed=1;seed<=3;seed++){
    scoredState({seed}, N, col); if(col && !STATE.colour) continue; STATE.bars=16; STATE.extended=true;
    const c=compose(), f1=1200/NN;
    let aba=0, motions=0, stp=0, ct=0, nct=0, out=0, cross=0, pairs=0, fus=0, rough=0, steps=0;
    for(let v=0;v<3;v++){
      const seq=[]; for(let s=0;s<c.total;s++){ const p=c.pitches[v][s]; if(p!=null){ seq.push(p); if(p<REGISTERS[v].lo||p>REGISTERS[v].hi) out++; if(!c.deco[v][s]) ct++; nct++; } }
      for(let i=1;i<seq.length;i++){ motions++; const a=Math.abs(seq[i]-seq[i-1])*f1; if(a>=PSY_MICRO_CENTS && a<=PSY_LEAP_CENTS) stp++; if(i>=2 && seq[i]===seq[i-2] && seq[i-1]!==seq[i]) aba++; }
    }
    const held=[null,null,null];
    for(let s=0;s<c.total;s++){
      for(let v=0;v<3;v++) if(c.pitches[v][s]!=null) held[v]=c.pitches[v][s];
      if(held.every(x=>x!=null)){ steps++; if(!(held[0]>held[1] && held[1]>held[2])) cross++;
        for(const [a,b] of [[0,1],[1,2],[0,2]]){ const d=held[a]-held[b]; pairs++; fus+=CONSONANCE_BY_IC[ic(d)]; if(d && SP.rough(held[b],d)>PSY_ROUGH_GATE) rough++; } }
    }
    let stay=0; for(let i=1;i<c.chords.length;i++) if(c.chords[i].key===c.chords[i-1].key) stay++;
    const r={N, col, seed, aba:aba/Math.max(1,motions), stp:stp/Math.max(1,motions), ct:ct/Math.max(1,nct), out, cross, rough:rough/Math.max(1,pairs), fus:fus/Math.max(1,pairs), stay:stay/(c.chords.length-1)};
    rows.push(r);
    worst.cross=Math.max(worst.cross,r.cross); worst.rough=Math.max(worst.rough,r.rough); worst.aba=Math.max(worst.aba,r.aba); worst.out=Math.max(worst.out,r.out);
    worst.stp=Math.min(worst.stp,r.stp); worst.ct=Math.min(worst.ct,r.ct); worst.fus=Math.min(worst.fus,r.fus); worst.stay=Math.max(worst.stay,r.stay);
  }
  const where=(k,cmp)=>{ let b=rows[0]; for(const r of rows) if(cmp(r[k],b[k])) b=r; return 'N='+b.N+(b.col?'+colour':'')+' seed '+b.seed; };
  ok(rows.length>=26, 'pieces composed in all nine divisions, with and without colour chords', String(rows.length));
  ok(worst.out===0, 'every note is inside the register of its voice', String(worst.out));
  ok(worst.cross===0, 'voices never cross', String(worst.cross));
  ok(worst.aba<0.08, 'the melody does not trill (a note, its neighbour, the note again): worst '+f(worst.aba), where('aba',(a,b)=>a>b));
  ok(worst.stp>0.28, 'a good share of the motions are steps, in every division: worst '+f(worst.stp), where('stp',(a,b)=>a<b));
  ok(worst.ct>0.65, 'most notes are chord tones, in every division: worst '+f(worst.ct), where('ct',(a,b)=>a<b));
  ok(worst.fus>0.62, 'the sounding pairs fuse, in every division: worst mean '+f(worst.fus), where('fus',(a,b)=>a<b));
  ok(worst.rough<0.08, 'and are almost never rougher than the gate allows: worst '+f(worst.rough), where('rough',(a,b)=>a>b));
  ok(worst.stay<0.35, 'the chords do not stand still: worst '+f(worst.stay), where('stay',(a,b)=>a>b));
}

/* ---------------------------------------------- the policy reads cents, not step numbers */
{
  // the same musical distance scores the same in every division that has it (700 cents: 7, 14, 21, 28 steps in 12, 24, 36, 48)
  const pr=[]; for(const [N,steps] of [[12,7],[24,14],[72,42]]){ scoredState({}, N); pr.push(proxOf(Math.abs(steps)*1200/NN, STATE.choice.micro)); }
  ok(pr.every(x=>Math.abs(x-pr[0])<1e-12), 'melodic proximity of a fifth is the same in 12, 24 and 72 divisions');
  const sm=[]; for(const [N,steps] of [[12,2],[24,4],[72,12]]){ scoredState({}, N); sm.push(smoothOf(steps)); }
  ok(sm.every(x=>Math.abs(x-sm[0])<1e-12), 'and so is how little a voice-leading of a whole tone costs');
  // a quarter tone is a step in 24 and in 31 (the "micro" limit is not a constant of one division) and a repeat-like drift when the limit is raised
  scoredState({}, 24); const step24=Math.abs(1)*1200/NN;
  ok(proxOf(step24, 45)>0.7 && proxOf(step24, 120)<=0.2, 'a quarter tone is a step or an out-of-tune repeat, as the composer sets the limit', proxOf(step24,45).toFixed(2)+' / '+proxOf(step24,120).toFixed(2));
  scoredState({}, 31); ok(proxOf(1200/31, 45)===0.2 && proxOf(1200/31, 30)>0.7, 'a step of 31 (38.7 cents) is a drift under the default limit and a step when the composer lowers the limit', proxOf(1200/31,45).toFixed(2)+' / '+proxOf(1200/31,30).toFixed(2));
  // no hidden dependence on pitch-class numbering: in every division the hash order, not "lowest root number", settles a level choice
  let level=0, lowest=0, n=0;
  for(const [N,col] of [[12,false],[19,false],[31,true],[53,true]]) for(let seed=1;seed<=3;seed++){
    scoredState({seed, variety:0}, N, col); STATE.bars=16; const c=compose(), tbl=chordTable(), plan=choicePlan();
    for(let g=1; g<c.walk.length; g++){ const w=c.walk[g]; if(!w.from) continue;
      const all=chordCandidates(w.from, w.prev2, w.etaIn, tbl, baseVocab(), w.target, plan).filter(x=>x.legal).sort(scoredOrder(plan)); n++;
      if(all.length>1 && all[0].tier===all[1].tier && all[0].score===all[1].score){ level++; if(all[0].j<all[1].j) lowest++; } }
  }
  ok(level===0 || lowest/level<0.8, 'level choices are settled by the hash, not by the lowest index', level+' level of '+n+' chord choices, lowest index '+lowest);
}

/* ---------------------------------------------- note-level policy is what the code says it is */
{
  let bad=0, n=0, forced=0;
  for(const [N,col,seed,variety] of [[12,false,2,0],[12,false,3,0.3],[31,true,4,0],[31,true,5,0.8],[53,true,6,0.3]]){
    scoredState({seed, variety}, N, col); const c=compose(), plan=choicePlan();
    for(let v=0;v<3;v++) for(let s=0;s<c.total;s++){
      const L=c.look[v][s]; if(!L) continue; if(L.ctx.force!=null){ forced++; continue; }
      const all=noteCandidates(L.cands, L.ctx, plan, false); if(!all.length) continue;
      // the hard keys (the bass root, the walking-bass approach) come first, then the score
      const rootKey=(x)=>(L.ctx.preferRoot!=null && plan.root) ? (pcOf(x.m)===L.ctx.preferRoot?0:1) : 0;
      const best=all.slice().sort((a,b)=>rootKey(a)-rootKey(b) || (b.score-a.score) || (b.h-a.h))[0];
      if(L.ctx.approachPc!=null) continue;
      n++; if(best.m!==c.pitches[v][s]) bad++;
    }
  }
  ok(bad===0, 'each note played is the best-scoring legal candidate (bass root first)', n+' notes, '+bad+' differ, '+forced+' pinned');
}
