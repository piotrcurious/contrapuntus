/* The step inspector (14-inspect.js), the composer's pins and vetoes, the envelope bank, and what the state code keeps of them.
   The numbers the inspector shows are checked against the engine itself: every probability is compared with how often
   the engine really plays that move over thousands of seeds. */

function scored(div, patch){
  resetState(); if(div!==12) switchSpace(div);
  STATE.choice=defaultChoice(); STATE.bars=8;
  if(patch) patch(STATE.choice);
}
const key2=(v,s)=>v+':'+s;
const zOf=(freq,p,n)=>Math.abs(freq-p)/Math.sqrt(Math.max(p*(1-p),1e-9)/n);

/* ---------------------------------------------- luce */
{
  const p=luce([1,0.5,0],0.5), S=p.reduce((a,b)=>a+b,0);
  ok(Math.abs(S-1)<1e-12 && p[0]>p[1] && p[1]>p[2], 'luce: the chances sum to one and follow the utilities', p.map(x=>x.toFixed(3)).join(' '));
  eq(luce([0.2,0.9,0.9,0.1],0), [0,1,0,0], 'luce at temperature zero gives everything to the first of the greatest');
  ok(luce([1,1,1,1],0.7).every(x=>Math.abs(x-0.25)<1e-12), 'equal utilities are equally likely');
  const big=luce([1,0,-1],1e6); ok(Math.max.apply(null,big)-Math.min.apply(null,big)<1e-5, 'a very high temperature is uniform');
  const lo=luce([-1e9,0],0.1); ok(lo[1]>0.999999 && lo[0]>=0 && isFinite(lo[0]), 'a utility a billion below the rest has no chance and is not a number problem');
  ok(luce([],1).length===0, 'luce of nothing is nothing');
}

/* ---------------------------------------------- the words */
{
  scored(12);
  ok(intervalWords(7).indexOf('fifth')>=0 && intervalWords(7).indexOf('700¢')>=0, 'seven steps of 12 are a fifth, said in cents too', intervalWords(7));
  ok(intervalWords(0).indexOf('no motion')===0, 'zero steps is no motion');
  ok(intervalWords(5)==='about a fourth (500¢, +2 off)' || intervalWords(5).indexOf('fourth')>=0, 'five steps of 12 are a fourth', intervalWords(5));
  scored(31);
  ok(intervalWords(18).indexOf('fifth')>=0 && /−\d+ off/.test(intervalWords(18)), 'eighteen steps of 31 are a fifth, a little flat', intervalWords(18));
  ok(intervalWords(1)==='39¢', 'a step of 31 is not near any simple interval, so only its size is said', intervalWords(1));
  let nUndef=0, nV=VOICE_AXES.length;
  for(let f=0;f<270;f++){ const w=voiceCellWords(f); if(w.indexOf('undefined')>=0 || w.split(' · ').length!==nV) nUndef++; }
  ok(nUndef===0, 'every one of the 270 voice cells has five phrases and no hole');
  for(const N of [12,19,31,53]){
    if(NN!==N) switchSpace(N);
    let bad=0;
    for(const d of [0,1,N>>1,N-1]) for(let t=0;t<5;t++) for(let r=0;r<CHORD_DIMS[2];r++) for(let e=0;e<3;e++){
      const w=chordCellWords({d,tau:t,rho:r,eta:e}); if(w.indexOf('undefined')>=0 || w.split(' · ').length!==4) bad++; }
    ok(bad===0, 'every chord cell can be put in words at '+N+' divisions');
  }
}

/* ---------------------------------------------- the chord inspector describes what the engine did */
{
  let checked=0; const bad=[]; let freeCells=0;
  for(const div of [12,19,31]) for(const preset of ['balanced','strong','bold']) for(const variety of [0,0.3,1]){
    scored(div, ch=>{ applyPreset(ch,preset); ch.variety=variety; ch.seed=7; });
    STATE.bars=12; STATE.colour=SP.colour.length>0;
    const c=compose();
    for(let g=1; g<c.walk.length; g++){
      const ins=chordInspect(c,g), tag=div+'/'+preset+'/'+variety+'@'+g; checked++;
      if(!ins){ bad.push(tag+' no inspection'); continue; }
      const rs=ins.rows, S=rs.reduce((a,r)=>a+r.p,0), tk=rs.filter(r=>r.taken), w=c.walk[g];
      if(rs.length!==vocabFor(scaleForSeg(g)).length) bad.push(tag+' rows != vocabulary');
      if(Math.abs(S-1)>1e-9) bad.push(tag+' chances sum to '+S);
      if(tk.length!==1 || tk[0].key!==w.chord.key) bad.push(tag+' taken row is wrong');
      else {
        if(!(tk[0].p>0)) bad.push(tag+' the chord that was played had no chance');
        if(variety===0 && Math.abs(tk[0].p-1)>1e-12) bad.push(tag+' greedy but not certain');
        if(JSON.stringify(tk[0].cell)!==JSON.stringify({d:w.cell.d,tau:w.cell.tau,rho:w.cell.rho,eta:w.cell.eta})) bad.push(tag+' cell differs from the walk\'s '+JSON.stringify(tk[0].cell)+' '+JSON.stringify(w.cell));
        if(tk[0].legal!==!w.fellBack && !w.fellBack) bad.push(tag+' played an illegal chord without falling back');
      }
      if(rs.some(r=>r.p>0 && (!r.eligible || r.vetoed))) bad.push(tag+' a chord that is out of the draw has a chance');
      if(rs.some(r=>!isFinite(r.p) || r.p<0 || r.p>1)) bad.push(tag+' a chance outside 0..1');
      for(let i=1;i<rs.length;i++){ if(rs[i].group<rs[i-1].group) bad.push(tag+' groups out of order'); else if(rs[i].group===0 && rs[i-1].group===0 && rs[i].p>rs[i-1].p+1e-12) bad.push(tag+' chances out of order'); }
      if(ins.nLegal!==rs.filter(r=>r.legal).length || ins.nLegal!==w.nLegal) bad.push(tag+' count of legal moves '+ins.nLegal+' vs '+w.nLegal);
      if(rs.some(r=>r.util!=null && Math.abs(r.util-(r.parts.favour+r.parts.smooth))>1e-12)) bad.push(tag+' parts do not add up to the utility');
      if(rs.some(r=>r.cost<-1e-12 || r.cost>1+1e-12)) bad.push(tag+' cost outside 0..1');
      freeCells+=rs.filter(r=>r.legal).length;
    }
  }
  ok(bad.length===0, 'the chord inspector agrees with the engine at '+checked+' chord steps ('+freeCells+' legal moves)', bad.slice(0,3).join(' | '));
}

/* ---------------------------------------------- ... and its chances are the real chances */
{
  const worstAll=[]; let nCand=0, nState=0;
  for(const [div,variety,preset] of [[12,0.6,'balanced'],[12,1,'strong'],[31,0.6,'balanced'],[19,0.45,'bold']]){
    scored(div, ch=>{ applyPreset(ch,preset); ch.variety=variety; ch.chord.still=false; });
    STATE.bars=16; STATE.colour=SP.colour.length>0;
    const c=compose(), tbl=chordTable();
    for(const g of [2,5,9,13]){
      const ins=chordInspect(c,g), w=c.walk[g], vocab=vocabFor(scaleForSeg(g)), N=1500, cnt=new Map();
      for(let seed=0; seed<N; seed++){
        STATE.choice.seed=seed*7919+3;
        const k=chordStep(w.from, w.prev2, w.etaIn, tbl, vocab, w.target).legal[0].key;
        cnt.set(k,(cnt.get(k)||0)+1);
      }
      let worst=0;
      for(const r of ins.rows){ const f=(cnt.get(r.key)||0)/N; if(r.p===0 && f>0) worst=99; else if(r.p>0.01) worst=Math.max(worst, zOf(f,r.p,N)); }
      worstAll.push(worst); nState++; nCand+=ins.rows.filter(r=>r.p>0.01).length;
    }
    STATE.choice.seed=1;
  }
  ok(Math.max.apply(null,worstAll)<4.5, 'over 1500 seeds each, the chord that is played has the chances the inspector shows ('+nState+' states, '+nCand+' moves)', 'worst '+Math.max.apply(null,worstAll).toFixed(2)+' sigma');
}

/* ---------------------------------------------- the note inspector describes what the engine did */
{
  let checked=0, rootHeld=0, approachHeld=0; const bad=[];
  for(const div of [12,31]) for(const preset of ['balanced','bold']) for(const variety of [0,0.3,1]) for(const walkBass of [false,true]){
    scored(div, ch=>{ applyPreset(ch,preset); ch.variety=variety; ch.seed=11; });
    STATE.walkingBass=walkBass; STATE.bars=8;
    const c=compose();
    for(let v=0;v<3;v++) for(let s=0;s<c.total;s++){
      const L=c.look[v][s]; if(!L){ if(noteInspect(c,v,s)!==null) bad.push('a note nobody chose was inspected'); continue; }
      const ins=noteInspect(c,v,s), tag=div+'/'+preset+'/'+variety+'/'+v+':'+s; checked++;
      const rs=ins.rows, S=rs.reduce((a,r)=>a+r.p,0), tk=rs.filter(r=>r.taken);
      if(rs.length!==L.cands.length) bad.push(tag+' rows '+rs.length+' != candidates '+L.cands.length);
      if(Math.abs(S-1)>1e-9) bad.push(tag+' chances sum to '+S);
      if(tk.length!==1 || tk[0].m!==c.pitches[v][s]) bad.push(tag+' taken row is wrong');
      else { if(!(tk[0].p>0)) bad.push(tag+' the note that was played had no chance'); if(variety===0 && Math.abs(tk[0].p-1)>1e-12) bad.push(tag+' greedy but not certain'); }
      if(rs.some(r=>r.p>0 && (!r.legal && !ins.fellBack))) bad.push(tag+' an illegal note has a chance');
      if(rs.some(r=>r.util!=null && Math.abs(r.util-(r.parts.favour+r.parts.step+r.parts.shape+r.parts.harmony+r.parts.contrary))>1e-9)) bad.push(tag+' parts do not add up');
      if(rs.some(r=>!isFinite(r.p) || r.p<0 || r.p>1+1e-12)) bad.push(tag+' chance out of range');
      for(let i=1;i<rs.length;i++) if(rs[i].m<=rs[i-1].m) bad.push(tag+' rows not in pitch order');
      if(ins.preferRoot!=null && STATE.choice.voice.root!==false){            // the bass takes the root when the rule lets it
        const roots=rs.filter(r=>r.legal && pcOf(r.m)===ins.preferRoot);
        if(roots.length){ rootHeld++; if(rs.some(r=>r.p>0 && pcOf(r.m)!==ins.preferRoot)) bad.push(tag+' the bass could take a note other than the root'); }
      }
      if(ins.approachPc!=null){
        const best=Math.min.apply(null, rs.filter(r=>r.legal).map(r=>approachScoreOf(r.m, ins.approachPc, ins.plan)));
        if(rs.some(r=>r.p>0 && approachScoreOf(r.m, ins.approachPc, ins.plan)!==best)) bad.push(tag+' a worse approach has a chance'); else approachHeld++;
      }
    }
  }
  ok(bad.length===0, 'the note inspector agrees with the engine at '+checked+' notes ('+rootHeld+' bass roots, '+approachHeld+' walking approaches)', bad.slice(0,3).join(' | '));
  ok(rootHeld>20 && approachHeld>20, 'the check on the bass root and on the walking bass had enough cases to mean something', rootHeld+' / '+approachHeld);
}

/* ---------------------------------------------- ... and its chances are the real chances */
{
  const worstAll=[]; let nCand=0, nSit=0;
  for(const [div,variety,preset] of [[12,0.6,'balanced'],[31,0.6,'balanced'],[19,1,'bold'],[12,0.45,'smooth']]){
    scored(div, ch=>{ applyPreset(ch,preset); ch.variety=variety; });
    STATE.bars=8; const c=compose(); let used=0;
    for(let v=0; v<3; v++) for(let s=1; s<c.total && used<4; s+=3){
      const L=c.look[v][s]; if(!L) continue;
      const ins=noteInspect(c,v,s); if(ins.nCompete<4) continue;
      const N=1500, cnt=new Map();
      for(let seed=0; seed<N; seed++){
        const ctx=Object.assign({}, L.ctx, {plan:Object.assign({}, L.ctx.plan, {seed:seed*104729+5})});
        const m=pickNote(L.cands, ctx).pitch; cnt.set(m,(cnt.get(m)||0)+1);
      }
      let worst=0;
      for(const r of ins.rows){ const f=(cnt.get(r.m)||0)/N; if(r.p===0 && f>0) worst=99; else if(r.p>0.01) worst=Math.max(worst, zOf(f,r.p,N)); }
      worstAll.push(worst); used++; nSit++; nCand+=ins.rows.filter(r=>r.p>0.01).length;
    }
  }
  ok(nSit>=8 && Math.max.apply(null,worstAll)<4.5, 'over 1500 seeds each, the note that is played has the chances the inspector shows ('+nSit+' situations, '+nCand+' pitches)', 'worst '+Math.max.apply(null,worstAll).toFixed(2)+' sigma');
}

/* ---------------------------------------------- the classic choice has no chances, only an order */
{
  resetState(); STATE.bars=8;
  const c=compose();
  const ci=chordInspect(c,3), ni=noteInspect(c,1,1)||noteInspect(c,0,0)||noteInspect(c,2,0);
  ok(ci.classic && ci.rows.filter(r=>r.p>0).length===1 && ci.rows.find(r=>r.taken).p===1 && ci.rows.every(r=>r.util===null), 'classic chords: the one that was played has the whole draw and there are no utilities');
  ok(ni.classic && ni.rows.filter(r=>r.p>0).length===1 && ni.rows.find(r=>r.taken).p===1, 'classic notes: the one that was played has the whole draw');
}

/* ---------------------------------------------- notes the rule did not choose */
{
  scored(12); STATE.anchors={0:67}; STATE.arp='none';
  let c=compose();
  ok(noteInspect(c,0,0)===null, 'an anchored melody note has no inspection: nothing chose it');
  ok(chordInspect(c,0)===null, 'the first chord is the seed: there was no choice to inspect');
  STATE.anchors={}; STATE.arp='up'; c=compose();
  ok(noteInspect(c,0,0)===null && noteInspect(c,0,4)===null, 'an arpeggiated melody has no inspection');
  ok(noteInspect(c,2,0)!==null, 'but the bass, which is not arpeggiated, does');
  ok(chordInspect(c,999)===null && noteInspect(c,0,9999)===null && noteInspect(c,3,0)===null, 'positions that do not exist inspect to nothing');
}

/* ---------------------------------------------- the composer overrides a chord */
{
  scored(12); STATE.bars=12; STATE.extended=true;
  const c0=compose(), tbl=chordTable();
  let g=-1;                                                   // a place where the rule allows several chords and forbids some
  for(let t=2;t<c0.walk.length && g<0;t++){ const r=chordInspect(c0,t).rows; if(r.filter(x=>x.legal).length>=3 && r.some(x=>!x.legal)) g=t; }
  const w0=c0.walk[g], vocab=vocabFor(scaleForSeg(g)), ins0=chordInspect(c0,g);
  const legalRows=ins0.rows.filter(r=>r.legal), runner=legalRows.find(r=>!r.taken), illegalRows=ins0.rows.filter(r=>!r.legal);
  ok(g>0 && runner && illegalRows.length>0, 'there is a chord the rule allows, one it forbids and one it played at this place', 'step '+g+': '+legalRows.length+' legal of '+ins0.rows.length);

  // a pin on a chord the rule allows
  STATE.pins[g]=runner.key; let c=compose(), w=c.walk[g];
  ok(w.chord.key===runner.key && w.pinned && !w.outside && !w.pinMissed, 'a pin on an allowed chord plays it', w.chord.key);
  ok(c.walk.slice(0,g).every((x,i)=>x.chord.key===c0.walk[i].chord.key), 'everything before the pin is as it was');
  ok(chordInspect(c,g).rows.find(r=>r.pinned).taken===true, 'the inspector shows the pinned chord as the one taken');
  ok(c.walk[g+1].from.key===runner.key, 'the walk goes on from the pinned chord');

  // a pin on a chord the rule forbids is still played, and says so
  const forb=illegalRows[0];
  STATE.pins[g]=forb.key; c=compose(); w=c.walk[g];
  ok(w.chord.key===forb.key && w.pinned && w.outside, 'a pin on a forbidden chord is played, marked as outside the rule', w.chord.key);
  const insF=chordInspect(c,g);
  ok(insF.outside && insF.rows.find(r=>r.taken).legal===false && insF.rows.find(r=>r.taken).p===0, 'the inspector shows it: taken, not allowed, no chance of being drawn');
  ok(c.dyn && c.walk.length===c0.walk.length && c.chords.length===c0.chords.length, 'and the piece still composes and is analysed');

  // a pin on something this vocabulary does not hold does nothing
  STATE.pins[g]='5:zzz:-'; c=compose(); w=c.walk[g];
  ok(w.chord.key===w0.chord.key && !w.pinned && w.pinMissed, 'a pin on a chord that is not in the vocabulary is ignored, and says so');
  delete STATE.pins[g];

  // a veto
  STATE.vetoChord[g]=[w0.chord.key]; c=compose(); w=c.walk[g];
  const step=chordStep(w0.from, w0.prev2, w0.etaIn, tbl, vocab, w0.target), want=step.legal.find(x=>x.key!==w0.chord.key);
  ok(w.chord.key===want.key && w.vetoed===1, 'ruling out the chord that was played plays the runner-up', w0.chord.key+' -> '+w.chord.key);
  const insV=chordInspect(c,g), vr=insV.rows.find(r=>r.key===w0.chord.key);
  ok(vr.vetoed && vr.p===0 && Math.abs(insV.rows.reduce((a,r)=>a+r.p,0)-1)<1e-9, 'the inspector shows the ruled-out chord with no chance and the others sum to one');
  STATE.vetoChord[g]=step.legal.map(x=>x.key); c=compose(); w=c.walk[g];
  ok(w.chord.key===w0.chord.key && w.vetoed===0, 'ruling out every allowed chord is ignored: the rule must have a move');
  ok(chordInspect(c,g).vetoIgnored===true, 'and the inspector says so');
  STATE.vetoChord[g]=['5:zzz:-', forb.key]; c=compose();
  ok(c.walk[g].chord.key===w0.chord.key, 'a veto on chords that were not going to be played changes nothing');
  // a pin beats a veto of the same chord
  STATE.pins[g]=runner.key; STATE.vetoChord[g]=[runner.key]; c=compose();
  ok(c.walk[g].chord.key===runner.key && c.walk[g].pinned, 'a pin is stronger than a veto on the same chord');
  STATE.pins={}; STATE.vetoChord={};
  eq(compose().chords.map(x=>x.key), c0.chords.map(x=>x.key), 'with the overrides removed the original piece returns exactly');
}

/* ---------------------------------------------- the composer overrides a note */
{
  scored(12); STATE.bars=8;
  const c0=compose(); attachNotes(c0);
  // a melody note with several moves to choose from
  let v=0, s=-1;
  for(let t=1;t<c0.total && s<0;t++){ const L=c0.look[0][t]; if(L && noteInspect(c0,0,t).nLegal>=3) s=t; }
  ok(s>0, 'there is a melody note with at least three allowed pitches');
  const key=key2(v,s), ins0=noteInspect(c0,v,s), taken=c0.pitches[v][s], L0=c0.look[v][s];
  const alt=ins0.rows.filter(r=>r.legal && !r.taken).sort((a,b)=>b.p-a.p);

  // veto the pitch that was played
  STATE.vetoNote[key]=[taken]; let c=compose();
  const want=pickNote(L0.cands.filter(m=>m!==taken), L0.ctx).pitch;
  ok(c.pitches[v][s]!==taken && c.pitches[v][s]===want, 'ruling out the pitch that was played plays the next best', taken+' -> '+c.pitches[v][s]);
  const insV=noteInspect(c,v,s);
  ok(insV.rows.find(r=>r.m===taken).vetoed && insV.rows.find(r=>r.m===taken).p===0 && Math.abs(insV.rows.reduce((a,r)=>a+r.p,0)-1)<1e-9, 'the inspector shows it ruled out and the others add to one');
  // everything ruled out is ignored
  STATE.vetoNote[key]=L0.cands.slice(); c=compose();
  ok(c.pitches[v][s]===taken && noteInspect(c,v,s).vetoIgnored, 'ruling out every candidate is ignored');
  // a pin on a candidate the rule did not prefer
  STATE.vetoNote={}; const pinM=alt[alt.length-1].m;
  STATE.notePins[key]=pinM; c=compose();
  ok(c.pitches[v][s]===pinM && noteInspect(c,v,s).forced, 'a pinned pitch is the pitch', String(pinM));
  ok(noteInspect(c,v,s).rows.find(r=>r.pinned).taken, 'the inspector marks it');
  // a pin on a pitch the voice could not have reached by itself (outside its range for the step)
  const far=L0.ctx.reg.hi+3; STATE.notePins[key]=far; c=compose(); const insF=noteInspect(c,v,s);
  ok(c.pitches[v][s]===far && insF.rows.some(r=>r.m===far && r.outside && r.taken), 'a pin outside what the voice could reach is played and shown as outside');
  STATE.notePins={}; STATE.vetoNote={};
  eq(compose().pitches, c0.pitches, 'with the overrides removed the original notes return exactly');

  // the same in a microtonal space
  scored(31); const d0=compose(); let sv=-1;
  for(let t=1;t<d0.total && sv<0;t++){ const L=d0.look[1][t]; if(L && noteInspect(d0,1,t).nLegal>=3) sv=t; }
  const k2=key2(1,sv), t2=d0.pitches[1][sv]; STATE.vetoNote[k2]=[t2]; const d1=compose();
  ok(sv>0 && d1.pitches[1][sv]!==t2, 'a veto works in 31 divisions as well', t2+' -> '+d1.pitches[1][sv]);
  STATE.vetoNote={}; resetState();
}

/* ---------------------------------------------- the envelope bank */
{
  resetState(); STATE.bars=8;
  const bank0=defaultEnvBank();
  ok(bank0.length===ENV_BANK_SIZE && ENV_BANK_SIZE===6, 'there are six envelopes in the bank');
  ok(new Set(bank0.map(b=>b.name)).size===6 && bank0.every(b=>/^[A-Za-z0-9][A-Za-z0-9 .+'-]{0,13}$/.test(b.name)), 'each has its own name that the state code accepts');
  ok(bank0.every(b=>b.a>=ENV_LIMITS.a[0] && b.a<=ENV_LIMITS.a[1] && b.d>=ENV_LIMITS.d[0] && b.d<=ENV_LIMITS.d[1] && b.s>=0 && b.s<=1 && b.r>=ENV_LIMITS.r[0] && b.r<=ENV_LIMITS.r[1] && b.gateRatio>=ENV_LIMITS.gateRatio[0] && b.gateRatio<=ENV_LIMITS.gateRatio[1]), 'and the defaults sit inside the limits the state code enforces');
  ok(new Set(bank0.map(b=>[b.a,b.d,b.s,b.r,b.gateRatio].join())).size===6, 'and the six are different from one another');
  let c=compose(); attachNotes(c);
  ok(c.notes.every(l=>l.every(n=>n.e.preset===-1)), 'with nothing assigned, every note takes its lane\'s envelope');
  const n0=c.notes[0][2], key=key2(0,n0.step), lane=STATE.voiceEnv[0];
  ok(Math.abs(n0.e.a-lane.a)<1e-12 && Math.abs(n0.e.gate-n0.span*lane.gateRatio)<1e-9 || n0.e.gate===0.03, 'a lane note has the lane\'s attack and gate');

  STATE.notePreset[key]=3; c=compose(); attachNotes(c);
  let n=c.notes[0].find(x=>x.step===n0.step), b=STATE.envBank[3];
  ok(n.e.preset===3 && n.e.a===b.a && n.e.d===b.d && n.e.s===b.s && n.e.r===b.r, 'a note given bank envelope 3 takes its attack, decay, sustain and release', JSON.stringify([n.e.a,n.e.d,n.e.s,n.e.r]));
  ok(Math.abs(n.e.gate-Math.max(0.03,n.span*b.gateRatio))<1e-9, 'its gate is its span times the preset\'s gate ratio');
  ok(!n.e.custom, 'it is not marked as hand-edited');
  ok(c.notes[0].filter(x=>x.step!==n0.step).every(x=>x.e.preset===-1), 'and no other note changes');
  STATE.envBank[3].a=0.4; STATE.envBank[3].gateRatio=0.5; c=compose(); attachNotes(c); n=c.notes[0].find(x=>x.step===n0.step);
  ok(n.e.a===0.4 && Math.abs(n.e.gate-Math.max(0.03,n.span*0.5))<1e-9, 'editing the preset changes every note that has it');
  STATE.noteEnv[key]={a:0.9}; c=compose(); attachNotes(c); n=c.notes[0].find(x=>x.step===n0.step);
  ok(n.e.a===0.9 && n.e.d===STATE.envBank[3].d && n.e.custom && n.e.preset===3, 'a hand edit of one number sits on top of the preset and the rest still comes from it');
  const w=c.notes[0].find(x=>x.step===n0.step);
  ok(w.tailSteps>=0 && isFinite(w.e.tail) && isFinite(w.e.L0), 'the derived numbers (release tail, level at note-off) follow');
  STATE.notePreset={}; STATE.noteEnv={}; STATE.envBank=defaultEnvBank();
}

/* ---------------------------------------------- the state code keeps all of it */
{
  scored(31); STATE.bars=8; STATE.timbre='soft';
  const c0=compose(); let s=-1; for(let t=1;t<c0.total&&s<0;t++) if(c0.look[0][t]) s=t;
  STATE.envBank[2]={name:'My bell',a:0.01,d:1.2,s:0.1,r:3,gateRatio:0.3}; STATE.envBrush=2;
  STATE.notePreset['0:'+s]=2; STATE.notePreset['1:0']=5;
  STATE.vetoChord[3]=[c0.walk[3].chord.key]; STATE.vetoNote['0:'+s]=[c0.pitches[0][s]];
  STATE.pins[5]=c0.walk[5].chord.key; STATE.notePins['2:0']=c0.pitches[2][0]+NN;
  const before=compose(), snap=snapshot();
  const code=stateToCode();
  ok(/^CP1\./.test(code), 'a state with all of that makes a code');
  resetState();
  const parsed=parseStateText(code); ok(!!parsed.obj, 'and the code reads back', parsed.error);
  const r=restoreState(parsed.obj);
  ok(r.ok, 'it restores', r.error||'');
  ok(snapshot()===snap, 'and the restored state is the same state, byte for byte');
  eq(STATE.envBank[2], {name:'My bell',a:0.01,d:1.2,s:0.1,r:3,gateRatio:0.3}, 'the edited bank entry survived');
  ok(STATE.envBrush===2 && STATE.notePreset['0:'+s]===2 && STATE.notePreset['1:0']===5, 'the brush and the notes that have a bank envelope survived');
  ok(STATE.vetoChord[3].length===1 && STATE.vetoNote['0:'+s][0]===c0.pitches[0][s], 'the vetoes survived');
  const after=compose();
  eq([after.chords.map(x=>x.key), after.pitches], [before.chords.map(x=>x.key), before.pitches], 'and the restored state composes the same piece');
  resetState();
}
{
  // a state from before any of this: no bank, no brush, no vetoes
  resetState(); STATE.choice=defaultChoice();
  const o=JSON.parse(JSON.stringify(serializeState()));
  for(const k of ['envBank','envBrush','notePreset','vetoChord','vetoNote']) delete o[k];
  STATE.envBank[0].a=1.5; STATE.envBrush=4; STATE.vetoChord={2:['0:maj7:-']};
  const r=restoreState(o);
  ok(r.ok, 'a state without any of the new fields loads');
  eq(STATE.envBank, defaultEnvBank(), 'with the six default envelopes');
  ok(STATE.envBrush===-1 && !Object.keys(STATE.notePreset).length && !Object.keys(STATE.vetoChord).length && !Object.keys(STATE.vetoNote).length, 'and nothing assigned, nothing ruled out');
}
{
  // hostile input: every one of them is cleaned and none of them stops the load
  resetState(); STATE.choice=defaultChoice();
  const o=JSON.parse(JSON.stringify(serializeState()));
  o.envBank=[{name:'<script>alert(1)</script>',a:-5,d:1e9,s:7,r:'x',gateRatio:NaN},null,42,'str',{name:'ok name',a:0.2,d:0.2,s:0.2,r:0.2,gateRatio:0.2}, {name:'x'.repeat(500)}, {a:1}, {a:1}];
  o.envBrush=99; o.notePreset={'0:0':9,'0:1':-1,'0:2':1.5,'0:3':'2','9:0':1,'0:99999':1,'0:4':3,'bad':1};
  o.vetoChord={'1':['0:maj7:-','zzz',42,null,'0:maj7:-'],'-1':['0:maj7:-'],'999':['0:maj7:-'],'2':'nope','3':[]};
  o.vetoNote={'0:3':[60,60,'x',1.5,-4,1e9,64],'7:1':[60],'0:99999':[60],'0:4':'nope','0:5':[]};
  const r=restoreState(o);
  ok(r.ok, 'a state with hostile bank, brush, presets and vetoes still loads');
  ok(STATE.envBank.length===6 && STATE.envBank.every(b=>/^[A-Za-z0-9][A-Za-z0-9 .+'-]{0,13}$/.test(b.name)), 'the bank is still six entries with safe names');
  ok(STATE.envBank.every(b=>b.a>=ENV_LIMITS.a[0] && b.a<=ENV_LIMITS.a[1] && b.d<=ENV_LIMITS.d[1] && b.s>=0 && b.s<=1 && typeof b.r==='number' && isFinite(b.r) && isFinite(b.gateRatio)), 'every number is clamped or defaulted');
  eq(STATE.envBank[4], {name:'ok name',a:0.2,d:0.2,s:0.2,r:0.2,gateRatio:0.2}, 'a good entry is kept as it is');
  ok(STATE.envBrush===-1, 'a brush that is not one of the six means the lane\'s own');
  eq(STATE.notePreset, {'0:4':3}, 'only well-formed note presets survive');
  eq(STATE.vetoChord, {'1':['0:maj7:-']}, 'only well-formed chord vetoes survive, once each');
  eq(STATE.vetoNote, {'0:3':[60,64]}, 'only well-formed note vetoes survive, once each');
  const c=compose(); attachNotes(c);
  ok(c.notes.every(l=>l.every(n=>isFinite(n.e.a)&&isFinite(n.e.gate))) && c.chords.length>0, 'and the cleaned state composes and sounds');
  resetState();
}
