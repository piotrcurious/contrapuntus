# Contrapunctus

A deterministic three-voice counterpoint automaton, the rule space it lives in, and the tools to look at both and to steer it.
One HTML file; no server, no network (fonts load from Google Fonts when online and fall back to system fonts when not).

    python3 build.py         -> dist/contrapunctus.html           standalone page (open it in a browser)
                                dist/contrapunctus.artifact.html  the same page as a fragment for a page host
                                dist/contrapunctus.js             the script alone
    sh test/run.sh           node suites on the DOM-free modules: theory, pitch spaces, rule tables, choice policy,
                             automaton, analysis, inspector, envelopes, MIDI written and read back by an independent
                             reader, zip, state codes (484 checks)
    python3 test/ui.py       browser suite in headless Chromium via Playwright (236 checks, fake AudioContext)
                             --nogl                     Canvas 2D fallback instead of WebGL
                             --blocks=block_seq,...     only the named blocks (block_rail, block_space, block_map,
                                                        block_choice, block_inspector, block_note, block_seq,
                                                        block_brush_bank, block_bank, block_roundtrip, block_midi31)
                             CP_SRC=path                run it against another build
    python3 tools/lint.py    ESLint over the bundle, each message mapped back to its module and line
    sh tools/measure.sh      the numbers quoted in the essay, computed by the engine (re-run after changing a rule)
    python3 test/looks.py    element screenshots of the plates (--dark for the dark theme)
    python3 test/looks2.py   scenario screenshots: seq16 e19 e31 e53 e72 bank edits (--dark, --w N)
    python3 test/shot.py     page screenshots (--w --h --dark --full --nogl)
    ./sync.sh                copy the source tree to /mnt/user-data/outputs (the only place that survives a rebuild)

Set `window.__CP_DEBUG = true` before the page loads to expose `window.__cp` (state, compose, inspectors, buildMidi, ...) to tests.

## src/ (concatenated in file-name order into one function scope)

    00-head.html    tokens and CSS             01-body.html   markup
    09-psy.js       psychoacoustics: fusion, roughness, what the ear counts as a step
    10-choice.js    the choice policy: taste, variety, tie             10-core.js    theory, pitch spaces, state
    11-rules.js     cost surface, level-set tables                     12-automaton.js  chord and voice walks
    13-analysis.js  functional graph, orbit classes, basins, sweep     14-inspect.js    rule space at one step, forks
    20-gl.js        painter (WebGL / Canvas 2D), theme, tooltips
    30-notes.js     envelope model, presets and the note list that the score, sequencer, editor and audio all read
    31-lattice.js   rule space: projections, handles, by-cost layout
    32-roll.js      score        33-seq.js  stacked sequencer        34-env.js  envelope editor
    35-readouts.js  dynamics, basins, branches, status line
    36-space.js     pitch-space controls and the interval map          37-choice.js   choice controls
    38-step.js      the step plate: candidates, Play, Rule out         39-bank.js     the six envelope presets
    40-audio.js     Web Audio scheduler
    50-io.js        state codes, autosave, MIDI with pitch-bend microtones, zip, downloads
    60-ui.js        controls, history, pointer and keyboard handling
    70-essay.js     the prose in the page (its numbers come from tools/measure.sh)       99-boot.js  start-up

Function declarations hoist across modules; top-level `const` and `let` do not, so a module may call a later one only from inside a function.
`tools/validate_palette.mjs` and `tools/pal*.mjs` are the contrast checks that chose the colour tokens; they are not needed to build.

## What is in it

**Pitch spaces.** A pitch is a whole number of steps of an N-division octave (middle C is 5N). Twelve is the default; 17, 19, 22,
24, 31, 41, 53 and 72 have buttons and any N from 12 to 72 can be typed. Each division gets its own consonance table, its own third
and fifth, names (circle-of-fifths letters up to 31, nearest twelve-note name plus steps beyond), and, where the division
approximates them well, colour chords (harmonic seventh, subminor, neutral). The rule tables grow with the division (45N chord cells,
270 voice cells), so everything the analysis says is still exact. Changing division carries anchors and pins over by cents.

**Psychoacoustics (09-psy.js).** Consonance is not read off the arithmetic. Fusion is a Gaussian around each simple ratio (sigma 14 cents,
7 at the unison and octave) and says which intervals are consonances in the tuning in force; roughness is Sethares' measure over six
partials, taken at the register where the voices are, and an interval that fusion calls consonant stops counting as one when it is
rougher than `PSY_ROUGH_GATE` (a third that is clean at C4 is mud at C2). A motion shorter than `PSY_MICRO_CENTS` (45) is the same
note out of tune and counts as a repeat; a leap is `PSY_LEAP_CENTS` (250) or more. The fusion scale is anchored to the consonance
table of the first two versions, so in twelve-tone equal temperament it returns exactly those numbers. These are calibrated
approximations, not measurements taken by ear; the page lets you change the last two numbers.

**Choice policy (10-choice.js, 12-automaton.js).** The rule says what is allowed; the policy chooses among the allowed. It was a
hard-coded tie-break tuned to twelve notes. Now: a taste score (chords: favour the rule, smooth voices, keep the chords moving; notes:
favour the rule, stepwise, line shape, harmony, contrary motion, bass takes the root) -> variety (a Gumbel-softmax whose noise is a hash
of the state, the variation number and the candidate) -> a hash for what is still tied. Presets Balanced, Smooth, Strong, Bold, any
custom weights, and Classic, which plays exactly the pieces of the first two versions (`test/golden-classic.json` pins it). The noise
is a function of the state, so the walk remains a deterministic function on a finite set and the analysis stays exact; a variation is
another automaton, not a roll of dice.

**Rule space at each step, with a hand on it (14-inspect.js, 38-step.js).** Click a chord or a note and the step plate lists every
candidate with the cost it has under the rule (a meter marks where the rule's cut falls), its taste score and the reasons. *Play* pins a
candidate (the walk is forced there; everything after it is recomputed), *Rule out* vetoes one (ignored if it would leave none).
Hovering a chord candidate shows the four chords that would follow it, in the list, on the score and in the rule space. Pins and vetoes
are listed under *Your edits* with a way back and are in the state code.

**Sequencer (33-seq.js).** Bars are fitted to the width and stacked in rows, so nothing scrolls sideways; *Bars to a row* is auto or one
of 1, 2, 4, 8, 16 (up to the number of bars the piece has). Drag to paint a rhythm; fast strokes fill the cells between pointer events.
Every pointer path has a keyboard path.

**Envelopes (34-env.js, 39-bank.js).** One envelope per lane, one per note, and six shared presets (Pluck, Pad, Organ, Bell,
Staccato, Legato) that can be edited and renamed; editing a preset changes every note that carries it. A note takes the first of: its
own envelope, its preset, its lane's. The sequencer has a brush (*New notes take*) so notes switched on carry a preset; digits 1-6
give the note under the cursor a preset and 0 returns it to its lane. The note-off (gate length against release) is editable per note.

**Keeping the piece (50-io.js).** *Copy code* / *Save state* produce a code that holds every setting, seed, hand edit and view; loading
reproduces the piece note for note, and the same view always gives the same code. Everything read back is validated and clamped. The piece
is also autosaved in the browser. Undo and redo (Ctrl/Cmd+Z, Ctrl+Shift+Z or Ctrl+Y) cover edits and setting changes; Space plays
and pauses.

**Microtonal MIDI.** The engine thinks in whole-number steps; the audio plays 12·p/N semitones, and the .mid file writes the nearest key
plus a 14-bit pitch bend (+/-2 semitones, set with RPN 0). Bend belongs to a channel, so each voice has a small channel pool (channel
10 is skipped) and the writer places notes so that a bend change does not move a note that is still sounding; the cases where it cannot
are counted and reported under the Save button. Twelve-note equal temperament writes no bend. The receiving instrument must honour pitch
bend in its default range of +/-2 semitones. File names carry the division (`-31edo`) when it is not twelve.

## Known limits

- Nothing here has been listened to by a person on a real instrument; the tests run a fake AudioContext and read the MIDI back with an independent parser.
- With the default `PSY_MICRO_CENTS` of 45, a single step of 31, 41, 53 or 72 is shorter than the limit and is treated as the same note out of tune, so the melody does not use it; lower the setting to allow it.
- About half of the leaps of a fourth or more are not recovered by a step back; colour chords take 18-31 % of the chords in the divisions that offer them.
- The bass cannot take the root when the rule makes its cell illegal; in 53 and 72 steps the polar rule-space ring is dense and the cost view reads best.
- The rule and the choice are time-invariant. A step-dependent drift (the rule changing along the piece) is not built.
