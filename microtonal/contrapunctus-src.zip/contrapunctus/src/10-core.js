/* =====================================================================
   1 · THEORY CORE: PITCH SPACES
   ---------------------------------------------------------------------
   A pitch is a whole number of steps of an equal division of the octave,
   counted from the bottom of the MIDI range: NN steps to the octave (12 by
   default), C4 at 5*NN. Everything the rules see is a count of steps, so the
   same automaton runs in any division; what changes with the division is
   what a step *is*, and therefore which intervals are consonances, which
   notes make a scale, which chords exist and how the circle of fifths closes.
   Those are not transposed from the twelve-tone case but derived from the
   ear: see 09-psy.js. A space therefore carries
     g        the step nearest a pure fifth (the generator of the circle of fifths)
     K(j)     the note j fifths above the tonic, folded into one octave
     cons[]   how well each interval class fuses (the old twelve-tone table, in 12)
     M3, m3   the thirds chords are built from: the ones the circle of fifths gives
              (a Pythagorean third in 53 divisions, a poor one) unless a step within
              45 cents fuses clearly better (the pure third, 17 steps in 53)
     colour   chord types the division can play well and twelve cannot: the harmonic
              seventh 4:5:6:7, the subminor 6:7:9 and the neutral 18:22:27 triads
   The sounding pitch of a step is 12*p/NN semitones, so the synthesiser and the
   MIDI writer, which think in fractional semitones, are unchanged.
   ===================================================================== */
const NOTE_NAMES = ['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
const MIN_DIV = 12, MAX_DIV = 72;
const TIMBRES = ['classic','soft','pure'];
const DIV_CHOICES = [12,17,19,22,24,31,41,53,72];

// The twelve-tone definitions: the reference every other space is built to agree with at 12.
const SCALES = {
  Ionian:[0,2,4,5,7,9,11], Dorian:[0,2,3,5,7,9,10], Phrygian:[0,1,3,5,7,8,10],
  Lydian:[0,2,4,6,7,9,11], Mixolydian:[0,2,4,5,7,9,10], Aeolian:[0,2,3,5,7,8,10],
  Locrian:[0,1,3,5,6,8,10], HarmonicMinor:[0,2,3,5,7,8,11], MelodicMinor:[0,2,3,5,7,9,11],
  WholeTone:[0,2,4,6,8,10], OctatonicHW:[0,1,3,4,6,7,9,10], OctatonicWH:[0,2,3,5,6,8,9,11],
  MajorPentatonic:[0,2,4,7,9], MinorPentatonic:[0,3,5,7,10], Blues:[0,3,5,6,7,10],
};
// ...and how each one is built from the circle of fifths, so that it exists in every division:
// a mode is a run of seven fifths (the tonic's position in the run is what makes it Dorian or Lydian),
// the minors swap one note of the run for the raised seventh, and the symmetric scales are divided
// equally, or placed by cents where nothing else fixes them.
const SCALE_DEF = {
  Lydian:{chain:[0,6]}, Ionian:{chain:[-1,5]}, Mixolydian:{chain:[-2,4]}, Dorian:{chain:[-3,3]}, Aeolian:{chain:[-4,2]},
  Phrygian:{chain:[-5,1]}, Locrian:{chain:[-6,0]},
  HarmonicMinor:{chain:[-4,2], swap:[[-2,5]]}, MelodicMinor:{chain:[-3,3], swap:[[-2,5]]},
  MajorPentatonic:{chain:[0,4]}, MinorPentatonic:{chain:[-3,1]}, Blues:{chain:[-3,1], add:[6]},
  WholeTone:{equal:6}, OctatonicHW:{map:true}, OctatonicWH:{map:true},
};
// Scales that only some divisions have: given as ratios, and offered where every degree lands within
// 20 cents of a step. Neutral thirds and sevenths (Rast), and the three-quarter tone (Bayati).
const SCALE_JUST = {
  Rast:  [[1,1],[9,8],[11,9],[4,3],[3,2],[27,16],[11,6]],
  Bayati:[[1,1],[12,11],[6,5],[4,3],[3,2],[8,5],[9,5]],
};
const SCALE_LABELS = {
  Ionian:'Ionian (major)', Dorian:'Dorian', Phrygian:'Phrygian', Lydian:'Lydian',
  Mixolydian:'Mixolydian', Aeolian:'Aeolian (minor)', Locrian:'Locrian',
  HarmonicMinor:'Harmonic minor', MelodicMinor:'Melodic minor', WholeTone:'Whole tone',
  OctatonicHW:'Octatonic (H–W)', OctatonicWH:'Octatonic (W–H)',
  MajorPentatonic:'Major pentatonic', MinorPentatonic:'Minor pentatonic', Blues:'Blues',
  Rast:'Rast (neutral third)', Bayati:'Bayati (three-quarter tone)',
};
const SCALE_ORDER = Object.keys(SCALES);            // the fifteen every division has
const MICRO_SCALES = Object.keys(SCALE_JUST);

const CHORD_TEMPLATES = {
  '0':'1','0,7':'5','0,4,7':'maj','0,3,7':'min','0,3,6':'dim','0,4,8':'aug',
  '0,2,7':'sus2','0,5,7':'sus4','0,4,7,11':'maj7','0,4,7,10':'dom7','0,3,7,10':'min7',
  '0,3,6,10':'m7b5','0,3,6,9':'dim7','0,3,7,11':'minMaj7','0,4,8,10':'aug7','0,4,8,11':'augMaj7',
  '0,2,4,7':'add9',
};
const ROMAN = ['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'];

function midiToFreq(m){ return 440*Math.pow(2,(m-69)/12); }
function clamp01(x){ return x<0?0:x>1?1:x; }

/* ---- the space in force -------------------------------------------------------------- */
let NN = 12;                       // steps to the octave
let SP = null;                     // the space of NN steps: see buildSpace
let CONSONANCE_BY_IC = [1.0,0.05,0.25,0.65,0.75,0.9,0.15];
let CONSONANT_ICS = new Set([0,3,4,5]);

function pcOf(x){ return ((Math.round(x)%NN)+NN)%NN; }
function ic(x){ const s=((Math.round(x)%NN)+NN)%NN; return Math.min(s,NN-s); }
// the name of a pitch, with its octave (the function keeps the name it had when a step was always a semitone)
function midiName(p){ return SP.pitchName(Math.round(p)); }

/* ---- building a space ---------------------------------------------------------------- */
function nearestStep(N, cents){ return Math.round(cents*N/1200); }
const PURE = { fifth:[3,2], fourth:[4,3], M3:[5,4], m3:[6,5], h7:[7,4], sub:[7,6], neutral:[11,9], M2:[9,8], p11:[11,8], s9:[9,7], tt:[7,5] };

// a chain third (the third four fifths up, or three fifths down) stays, unless a step within 45 cents of it
// fuses clearly better
function pickThird(N, chain){
  const base=psyFusion(chain*1200/N); let best=chain, bf=base;
  const reach=Math.ceil(45*N/1200)+1;
  for(let s=chain-reach; s<=chain+reach; s++){
    if(Math.abs(s-chain)*1200/N>45) continue;
    const f=psyFusion(s*1200/N); if(f>bf+1e-9){ bf=f; best=s; }
  }
  best=((best%N)+N)%N;
  return (bf>=base+0.15 && bf>=0.5) ? best : chain;
}
// position of each root fall round the circle of fifths. Where the fifth does not generate every step
// (24 divisions: it stays on the even ones) the cosets are interleaved, so every step still has a place.
function ringPositions(N, g){
  let h=g, b=N; while(b){ const t=h%b; h=b; b=t; }       // gcd(g, N)
  const pos=new Array(N).fill(-1);
  for(let r=0;r<h;r++) for(let j=0;j<N/h;j++) pos[(r+g*j)%N]=j*h+r;
  return pos;
}
// Names. Up to 31 divisions the circle of fifths gives the letters (F C G D A E B) and sharps and flats run
// outward from them, as in meantone notation; a step the circle does not reach is the nearest name below with an
// arrow up. Beyond that the circle runs out of room, and a step is its nearest twelve-tone name and a count of steps
// (E-1, C#+2), which is also what you would play it as.
function buildNames(S){
  const N=S.N; if(N===12) return {pc:NOTE_NAMES.slice(), pitch:(p)=>NOTE_NAMES[((p%12)+12)%12]+(Math.floor(p/12)-1)};
  const pc=new Array(N).fill(null);
  if(N<=31){
    const letter={'-1':'F','0':'C','1':'G','2':'D','3':'A','4':'E','5':'B'};
    const order=[-1,0,1,2,3,4,5];
    for(let k=1;k<=8;k++){ order.push(5+k); order.push(-1-k); }
    for(const j of order){
      const x=S.K(j); if(pc[x]!==null) continue;
      let nm;
      if(j>=-1&&j<=5) nm=letter[j];
      else if(j>5){ const m=Math.ceil((j-5)/7); nm=letter[j-7*m]+'#'.repeat(m); }
      else { const m=Math.ceil((-1-j)/7); nm=letter[j+7*m]+'b'.repeat(m); }
      pc[x]=nm;
    }
    for(let x=0;x<N;x++) if(pc[x]===null){
      let k=x, n=0; do{ k=(k-1+N)%N; n++; }while(pc[k]===null && n<N);
      pc[x]=(pc[k]||'?')+'\u2191'.repeat(n);
    }
    return {pc, pitch:(p)=>pc[((p%N)+N)%N]+(Math.floor(p/N)-1)};
  }
  const sg=(n)=>n>0?'+'+n:n<0?'-'+(-n):'';
  const parts=(x)=>{ let k=Math.round(12*x/N), oct=0; if(k===12){ k=0; oct=1; } return {k, oct, off:x-(k===0&&oct?N:Math.round(k*N/12))}; };
  for(let x=0;x<N;x++){ const q=parts(x); pc[x]=NOTE_NAMES[q.k]+sg(q.off); }
  return {pc, pitch:(p)=>{ const x=((p%N)+N)%N, q=parts(x), o=Math.floor(p/N)-1+q.oct; return NOTE_NAMES[q.k]+o+sg(q.off); }};
}
// The twelve-tone interval class a step stands for: the one the circle of fifths gives it (the note j fifths
// up, within six, is class 7j mod 12), or failing that the one it is within 40 cents of. A step that is neither
// (a neutral third, which is 50 cents from both) belongs to none.
function shadow12(S, step){
  for(let t=0;t<=6;t++) for(const j of (t?[t,-t]:[0])) if(S.K(j)===step) return (((7*j)%12)+12)%12;
  const c=step*1200/S.N, k=Math.round(c/100), e=Math.abs(c-100*k);
  return e<=40 ? ((k%12)+12)%12 : null;
}

function buildSpace(N){
  const S={N, step:1200/N, scales:new Map(), roughMemo:new Map()};
  const g=Math.round(N*Math.log2(1.5)); S.g=g;
  S.K=(j)=>(((j*g)%N)+N)%N;
  S.cents=(k)=>k*1200/N;
  const half=N>>1;
  S.cons=[]; S.consSet=new Set();
  for(let i=0;i<=half;i++){ S.cons.push(psyCons(i*1200/N)); if(S.cons[i]>=PSY_YES) S.consSet.add(i); }
  S.rough=(low,delta)=>{ const k=low*1024+delta; let v=S.roughMemo.get(k); if(v===undefined){ v=psyRough(midiToFreq(12*low/N), delta*1200/N); S.roughMemo.set(k,v); } return v; };
  S.ringPos=ringPositions(N,g);
  S.M3c=S.K(4); S.m3c=S.K(-3);
  S.M3=pickThird(N,S.M3c); S.m3=pickThird(N,S.m3c);
  S.P5=g; S.P4=N-g; S.d5=S.K(-6); S.m7=(g+S.m3)%N; S.M7=(g+S.M3)%N;
  { const nm=buildNames(S); S.names=nm.pc; S.name=(pc)=>nm.pc[pc]; S.pitchName=nm.pitch; }
  // the best step for each simple ratio, and how far off it is: this is the quality of the division
  S.targets=Object.keys(PURE).map(k=>{
    const [n,d]=PURE[k], c=1200*Math.log2(n/d), s=nearestStep(N,c);
    return {key:k, label:n+'/'+d, cents:c, step:s%N, steps:s, err:s*1200/N-c, fusion:psyFusion(s*1200/N)};
  });
  // colour chords: each is on offer when every interval in it fuses (>= .5) and lies within 15 cents of its ratio
  S.colour=[];
  const T=(k)=>S.targets.find(t=>t.key===k);
  const ok=(...ks)=>ks.every(k=>T(k).fusion>=0.5 && Math.abs(T(k).err)<=15);   // fuses, and is the ratio it is named for
  if(ok('M3','fifth','h7') && T('h7').steps%N!==S.m7 ) S.colour.push({q:'h7', offs:[0,T('M3').steps%N,g,T('h7').steps%N]});
  if(ok('sub','fifth') && T('sub').steps%N!==S.m3) S.colour.push({q:'sub', offs:[0,T('sub').steps%N,g]});
  if(ok('neutral','fifth') && T('neutral').steps%N!==S.M3 && T('neutral').steps%N!==S.m3) S.colour.push({q:'neu', offs:[0,T('neutral').steps%N,g]});
  // the default root-fall profile: the twelve-tone ranking, carried to wherever each of its intervals lands here,
  // and fading with distance from it (35 cents) so a step beside a strong root motion is not itself one
  const named=[[0,0],[1,S.K(-5)],[2,S.K(2)],[3,S.m3],[4,S.M3],[5,S.K(-1)],[6,S.K(6)],[6,S.K(-6)],[7,S.K(1)],[8,S.K(-4)],[9,S.K(3)],[10,S.K(-2)],[11,S.K(5)]];
  S.affD=new Array(N).fill(0).map((_,d)=>{
    let best=0;
    for(const [cls,st] of named){
      let dc=Math.abs(d-st)*1200/N; dc=Math.min(dc,1200-dc);
      const a=DEF_AFF_D[cls]*(dc<1e-9 ? 1 : Math.exp(-(dc/35)*(dc/35)));
      if(a>best) best=a;
    }
    return best;
  });
  return S;
}
const SPACES=new Map();
function spaceFor(N){ N=Math.round(N); let S=SPACES.get(N); if(!S){ S=buildSpace(N); SPACES.set(N,S); } return S; }

/* ---- scales in a space ---------------------------------------------------------------- */
function buildScale(S, name){
  const N=S.N, uniq=(a)=>[...new Set(a.map(x=>((x%N)+N)%N))].sort((x,y)=>x-y);
  if(SCALE_JUST[name]){
    const steps=[]; for(const [n,d] of SCALE_JUST[name]){ const c=1200*Math.log2(n/d), s=nearestStep(N,c); if(Math.abs(s*1200/N-c)>20) return null; steps.push(s); }
    const u=uniq(steps); return u.length===SCALE_JUST[name].length ? u : null;
  }
  const def=SCALE_DEF[name]; if(!def) return null;
  let steps, want;
  if(def.chain){
    let js=[]; for(let j=def.chain[0]; j<=def.chain[1]; j++) js.push(j);
    for(const [a,b] of (def.swap||[])) js=js.map(j=>j===a?b:j);
    for(const j of (def.add||[])) js.push(j);
    steps=js.map(j=>S.K(j)); want=js.length;
  } else if(def.equal){ steps=[]; for(let k=0;k<def.equal;k++) steps.push(Math.round(k*N/def.equal)); want=def.equal; }
  else { steps=SCALES[name].map(s=>Math.round(s*N/12)); want=SCALES[name].length; }
  const u=uniq(steps);
  return (u.length===want && u[0]===0) ? u : null;
}
function scaleStepsIn(S, name){
  let v=S.scales.get(name); if(v===undefined){ v=buildScale(S,name); S.scales.set(name,v); }
  return v;
}
function scaleSteps(name){ return scaleStepsIn(SP, name) || scaleStepsIn(SP,'Ionian'); }
function scaleNamesIn(S){ return SCALE_ORDER.concat(MICRO_SCALES).filter(n=>scaleStepsIn(S,n)); }
function scaleNames(){ return scaleNamesIn(SP); }
function scaleAvailable(name){ return !!scaleStepsIn(SP,name); }

/* ---- chords ---------------------------------------------------------------------------- */
function chordTension(tones){
  const pcs=[...new Set(tones.map(pcOf))];
  if(pcs.length<2) return 0;
  let sum=0,n=0;
  for(let i=0;i<pcs.length;i++) for(let j=i+1;j<pcs.length;j++){ sum += 1-CONSONANCE_BY_IC[ic(pcs[j]-pcs[i])]; n++; }
  return sum/n;
}
// What a chord is called is read from the twelve-tone interval each of its notes stands for (see shadow12);
// a chord with a note that stands for none (a neutral third) is 'other' unless its builder named it.
function chordQuality(tones){
  const root=tones[0], iv=[];
  for(const t of tones){
    const s=shadow12(SP, (((t-root)%NN)+NN)%NN);
    if(s===null) return 'other';
    iv.push(s);
  }
  const u=[...new Set(iv)].sort((a,b)=>a-b);
  return CHORD_TEMPLATES[u.join(',')] || 'other';
}
function romanNumeral(degree, quality){
  if(degree<0) return '?';
  const b = ROMAN[degree] || ('d'+degree);
  switch(quality){
    case 'dim': return b.toLowerCase()+'°';
    case 'dim7': return b.toLowerCase()+'°7';
    case 'm7b5': return b.toLowerCase()+'ø7';
    case 'min': return b.toLowerCase();
    case 'min7': return b.toLowerCase()+'7';
    case 'minMaj7': return b.toLowerCase()+'△7';
    case 'maj7': return b+'△7';
    case 'dom7': return b+'7';
    case 'aug': case 'aug7': case 'augMaj7': return b+'+';
    case 'sus2': return b+'sus2';
    case 'sus4': return b+'sus4';
    case '5': return b+'5';
    case '1': return b;
    case 'h7': return b+'h7';                 // harmonic seventh, 4:5:6:7
    case 'sub': return b.toLowerCase()+'↓'; // subminor, 6:7:9
    case 'neu': return b+'~';                 // neutral third, 18:22:27
    default: return b+'*';
  }
}
function annotate(c, quality){
  c.quality = quality || chordQuality(c.tones);
  if(c.applied==='dom') c.roman = 'V7/'+c.of;
  else if(c.applied==='lt') c.roman = 'vii°7/'+c.of;
  else c.roman = romanNumeral(c.degree, c.quality);
  c.tensionVal = chordTension(c.tones);
  c.key = c.rootPc+':'+c.quality+':'+(c.applied||'-');
  return c;
}
// the third, and the seventh above the fifth, that a chord is built from: the circle of fifths gives a
// Pythagorean third that some divisions replace with a better one (see pickThird); a chord uses the
// replacement wherever the scale would have used the circle's own
function adaptOffsets(offs){
  const S=SP, N=NN, out=offs.slice();
  const third=(x)=> x===S.M3c ? S.M3 : x===S.m3c ? S.m3 : x;
  if(out.length>1) out[1]=third(out[1]);
  if(out.length>3 && offs[3]!==0){ const t=((offs[3]-offs[2])%N+N)%N, r=third(t); if(r!==t) out[3]=(out[2]+r)%N; }
  return out;
}
function buildDiatonic(rootPc, steps, size){
  size = size||4;
  const n=steps.length, N=NN, out=[];
  for(let deg=0;deg<n;deg++){
    const r=(rootPc+steps[deg])%N;
    const offs=[]; for(let k=0;k<size;k++) offs.push((((steps[(deg+2*k)%n]-steps[deg])%N)+N)%N);
    const chain=offs.map(o=>(r+o)%N), q=chordQuality(chain);
    const tones=adaptOffsets(offs).map(o=>(r+o)%N);
    const uniq=[...new Set(tones)];
    out.push(annotate({degree:deg, rootPc:uniq[0], tones:uniq, ring:0}, q));
  }
  return out;
}
function buildExtended(rootPc, steps){
  const S=SP, N=NN, dia = buildDiatonic(rootPc, steps);
  const out = dia.slice(), seen = new Set(dia.map(c=>c.key));
  const add = (c)=>{ if(!seen.has(c.key)){ seen.add(c.key); out.push(c); } };
  const dom=(r)=>[r,(r+S.M3)%N,(r+S.P5)%N,(r+S.P5+S.m3)%N];
  const lt =(l)=>[l,(l+S.m3)%N,(l+S.d5)%N,(l+S.d5+S.m3)%N];
  for(const t of dia){
    if(t.degree!==0){
      const r=(t.rootPc+S.P5)%N;
      add(annotate({degree:-1, rootPc:r, tones:dom(r), applied:'dom', of:t.roman, ring:1}, 'dom7'));
    }
    const l=(t.rootPc+S.K(5))%N;
    add(annotate({degree:-1, rootPc:l, tones:lt(l), applied:'lt', of:t.roman, ring:2}, 'dim7'));
  }
  out.forEach((c,i)=>{ c.idx=i; if(c.ring==null) c.ring=0; });
  return out;
}
// The colour chords of the space (ring 3). The harmonic seventh stands where the scale has a major triad on a
// degree (it is the dominant seventh as the ear would tune it), the subminor triad where it has a minor one;
// the neutral triad can go on any degree.
function addColour(vocab, rootPc, steps){
  const S=SP, N=NN, seen=new Set(vocab.map(c=>c.key));
  const dia=vocab.filter(c=>c.degree>=0&&!c.applied&&c.ring===0);
  const third=(t)=>(((t.tones[1]-t.tones[0])%N)+N)%N;
  for(const col of S.colour) for(const t of dia){
    if(col.q==='h7' && third(t)!==S.M3) continue;
    if(col.q==='sub' && third(t)!==S.m3) continue;
    const tones=col.offs.map(o=>(t.rootPc+o)%N);
    const c=annotate({degree:t.degree, rootPc:t.rootPc, tones, ring:3}, col.q);
    if(seen.has(c.key)) continue; seen.add(c.key); vocab.push(c);
  }
  vocab.forEach((c,i)=>{ c.idx=i; });
  return vocab;
}
const VOCAB_CACHE = new Map();
function vocabularyFor(rootPc, steps, extended, colour){
  const k = NN+'/'+rootPc+':'+steps.join(',')+':'+(extended?1:0)+':'+(colour&&SP.colour.length?1:0);
  let v = VOCAB_CACHE.get(k);
  if(!v){
    v = extended ? buildExtended(rootPc, steps) : buildDiatonic(rootPc, steps);
    v.forEach((c,i)=>{ c.idx=i; });
    if(colour && SP.colour.length) addColour(v, rootPc, steps);
    VOCAB_CACHE.set(k,v);
  }
  return v;
}
// the vocabulary of a scale under the controls as they stand
function vocabFor(scaleName){ return vocabularyFor(STATE.root, scaleSteps(scaleName), STATE.extended, STATE.colour); }

// distance between two chords: the steps each note of one must move to reach the nearest note of the other
function voiceLeadingDistance(a, b){
  const A=[...new Set(a.map(pcOf))], B=[...new Set(b.map(pcOf))];
  let t=0;
  for(const x of A){ let best=NN; for(const y of B){ const d=ic(x-y); if(d<best) best=d; } t+=best; }
  return t;
}
// How far the root falls going from chord A to chord B, in steps of the space.
// The fifth is the classic descending fifth (V-I, ii-V), the minor third is I-vi, the step above a fourth is a step up (IV-V).
// (The first version called this "directed fifths" and labelled it "in fifths"; it never was.)
function rootFall(rootA, rootB){ return ((rootA-rootB)+NN)%NN; }
// Position of a root-fall value around the circle of fifths: consecutive positions differ
// by a fifth, so a ring laid out in this order really is the circle of fifths.
function fifthsPos(d){ return SP.ringPos[d]; }

/* ---- tunings ---------------------------------------------------------------
   Twelve divisions only. A tuning says how far each of the twelve pitch classes sits from its
   equal-tempered pitch, in cents, so a note is a whole number (what the rules see) plus a small offset
   (what you hear). Offsets that are measured from the root follow the root around; a well temperament
   is fixed to C, because the unevenness between keys is the point of one. In any other division the
   step *is* the tuning, and there is no layer on top of it. The sounding pitch of a note is therefore
   fractional, which is what the audio engine plays and what the MIDI export has to encode (as pitch bend). */
function ratioCents(n,d){ return 1200*Math.log2(n/d); }
function fifthChain(fifth){            // twelve notes from a chain of equal fifths, wolf above the sixth step
  const o=[];
  for(let k=0;k<12;k++){
    let j=(7*k)%12; if(j>8) j-=12;     // position on the chain, -3 .. 8 fifths from the root
    const c=((j*fifth)%1200+1200)%1200;
    o.push(c-100*k);
  }
  return o.map(x=>Math.abs(x)>600 ? x-1200*Math.sign(x) : x);
}
const TUNINGS = {
  equal:       {label:'Equal temperament',            fixed:false, cents:new Array(12).fill(0)},
  just:        {label:'Just intonation, 5-limit',     fixed:false,
                cents:[[1,1],[16,15],[9,8],[6,5],[5,4],[4,3],[45,32],[3,2],[8,5],[5,3],[9,5],[15,8]].map((r,k)=>ratioCents(r[0],r[1])-100*k)},
  pythagorean: {label:'Pythagorean',                  fixed:false, cents:fifthChain(ratioCents(3,2))},
  meantone:    {label:'Quarter-comma meantone',       fixed:false, cents:fifthChain(1200*Math.log2(5)/4)},
  werckmeister:{label:'Werckmeister III (from C)',    fixed:true,
                cents:[0,90.225,192.18,294.135,390.225,498.045,588.27,696.09,792.18,888.27,996.09,1092.18].map((c,k)=>c-100*k)},
};
const TUNING_ORDER = ['equal','just','pythagorean','meantone','werckmeister'];
// the offset, in cents, of a pitch class under the tuning in force (the root matters for the relative ones)
function tuningCents(pc, tuning, root){
  const T=TUNINGS[tuning==null?STATE.tuning:tuning]||TUNINGS.equal, r=root==null?STATE.root:root;
  return T.fixed ? T.cents[((pc%12)+12)%12] : T.cents[(((pc-r)%12)+12)%12];
}
// the pitch a whole-number note actually sounds at, as a fractional MIDI note number
function soundingPitch(p){ return NN===12 ? p + tuningCents(pcOf(p))/100 : 12*p/NN; }
// where a pitch is on a keyboard of semitones (no tuning layer): what the piano roll draws
function semis(p){ return 12*p/NN; }

/* =====================================================================
   2 · STATE
   ===================================================================== */
const REGISTERS = [{lo:60,hi:84},{lo:48,hi:72},{lo:36,hi:60}];
const VOICE_NAMES = ['melody','middle','bass'];

// Cost surfaces are separable: cost(cell) = sum over axes of w * (1 - affinity[value]).
// Defaults reproduce the classical ranking the first version hard-coded, but every
// number here is now a handle rather than a constant.
const FUNCTIONAL_RANK = [3,7,6,1,1,4,7,0,5,5,2,7]; // by root fall d (semitones), 0 = strongest
const DEF_AFF_D = FUNCTIONAL_RANK.map(r=>1-r/7);

const CHORD_AXES = [
  {key:'d',    n:12, label:'d',   what:'root fall, in steps of the octave', tick:i=>String(i), ringOrder:d=>SP.ringPos[d]},
  {key:'tau',  n:5,  label:'τ', what:'tension against the aim', tick:i=>['--','-','0','+','++'][i]},
  {key:'rho',  n:3,  label:'ρ', what:'kind of chord', tick:i=>['dia','V7','vii°'][i]},
  {key:'eta',  n:3,  label:'η', what:'momentum coming in', tick:i=>['weak','mid','str'][i]},
];
const VOICE_AXES = [
  {key:'kappa',n:3, label:'κ', what:'voices it agrees with', tick:i=>String(i)},
  {key:'mu',   n:5, label:'μ', what:'its own leap or step',  tick:i=>['↓↓','↓','=','↑','↑↑'][i]},
  {key:'phi',  n:3, label:'φ', what:'chromatic / scale / chord tone', tick:i=>['chr','scl','chd'][i]},
  {key:'sigma',n:2, label:'σ', what:'structural or passing', tick:i=>['struct','pass'][i]},
  {key:'gamma',n:3, label:'γ', what:'against the other voices', tick:i=>['sim','obl','con'][i]},
];
function axisDims(axes){ return axes.map(a=>a.n); }
// the dimensions of the chord table in a given space: the root-fall axis has one value per step, and the kind-of-chord axis a fourth when the space has colour chords
function chordDimsFor(S){ return [S.N, 5, S.colour.length?4:3, 3]; }
function axisStrides(dims){
  const s=new Array(dims.length); let acc=1;
  for(let i=dims.length-1;i>=0;i--){ s[i]=acc; acc*=dims[i]; }
  return {strides:s, size:acc};
}
const CHORD_DIMS = axisDims(CHORD_AXES), CHORD_STR = axisStrides(CHORD_DIMS);
const VOICE_DIMS = axisDims(VOICE_AXES), VOICE_STR = axisStrides(VOICE_DIMS);

// How the rule table is laid out on screen. 'grid' and 'hyper' are linear: every axis owns a
// direction (a basis vector) that you can drag, and a cell sits at the sum of its coordinates'
// vectors; an axis can also be wrapped into a ring. 'cycle' and 'cost' are not linear: the first
// puts the root fall d on a circle of fifths with tension as the radius, the second puts every
// cell at its cost, so the legal set is everything left of a vertical line.
// The grid presets nest the axes like digits of a number, so no two cells ever coincide; the
// oblique ones were found by search for the arrangement that keeps all cells apart while giving
// every axis a long enough reach to read. They were found for twelve divisions; in another the
// root-fall columns and the chord-kind offsets inside them are scaled by 12/NN together.
const PROJ = {
  chord:{ preset:'grid', basis:{d:[46,0], tau:[0,-64], rho:[14,0], eta:[0,13]}, cyclic:{}, rows:'d' },
  voice:{ preset:'grid', basis:{kappa:[200,0], mu:[0,-80], phi:[60,0], sigma:[0,-30], gamma:[20,0]}, cyclic:{}, rows:'mu' },
};
const PROJ_BASES = {
  chord:{ grid:{d:[46,0], tau:[0,-64], rho:[14,0], eta:[0,13]},
          hyper:{d:[-9,-5], tau:[19,0], rho:[-98,3], eta:[-11,72]} },
  voice:{ grid:{kappa:[200,0], mu:[0,-80], phi:[60,0], sigma:[0,-30], gamma:[20,0]},
          hyper:{kappa:[-42,-47], mu:[-24,-50], phi:[-16,-34], sigma:[-240,-44], gamma:[56,-8]} },
};
const PROJ_12 = JSON.parse(JSON.stringify(PROJ_BASES));

// Put the whole engine in an NN-step space. Arrays that other modules hold on to (the dimensions, the
// strides, the registers) are changed in place. The state is not touched: use switchSpace for that.
function setDivisions(N){
  N=Math.round(N); if(!(N>=MIN_DIV && N<=MAX_DIV)) N=12;
  const S=spaceFor(N);
  NN=N; SP=S;
  CONSONANCE_BY_IC=S.cons; CONSONANT_ICS=S.consSet;
  const col=S.colour.length>0;
  CHORD_AXES[0].n=N;
  CHORD_AXES[2].n=col?4:3;
  CHORD_AXES[2].tick=col ? (i=>['dia','V7','vii°','col'][i]) : (i=>['dia','V7','vii°'][i]);
  const dims=axisDims(CHORD_AXES), st=axisStrides(dims);
  CHORD_DIMS.length=0; for(const x of dims) CHORD_DIMS.push(x);
  CHORD_STR.strides.length=0; for(const x of st.strides) CHORD_STR.strides.push(x);
  CHORD_STR.size=st.size;
  REGISTERS[0].lo=5*N; REGISTERS[0].hi=7*N;
  REGISTERS[1].lo=4*N; REGISTERS[1].hi=6*N;
  REGISTERS[2].lo=3*N; REGISTERS[2].hi=5*N;
  const k=12/N;
  { const g12=PROJ_12.chord.grid, g=PROJ_BASES.chord.grid, h12=PROJ_12.chord.hyper, h=PROJ_BASES.chord.hyper;
    g.d=[g12.d[0]*k, g12.d[1]*k]; g.rho=[g12.rho[0]*k, g12.rho[1]]; g.tau=g12.tau.slice(); g.eta=g12.eta.slice();
    h.d=[h12.d[0]*k, h12.d[1]*k]; h.rho=h12.rho.slice(); h.tau=h12.tau.slice(); h.eta=h12.eta.slice(); }
  PROJ.chord={ preset: N>24?'cycle':'grid', basis:JSON.parse(JSON.stringify(PROJ_BASES.chord.grid)), cyclic:{}, rows:'d' };
  PROJ.voice={ preset:'grid', basis:JSON.parse(JSON.stringify(PROJ_BASES.voice.grid)), cyclic:{}, rows:'mu' };
}
setDivisions(12);

function defaultProfiles(S){
  S=S||SP;
  const rho=S.colour.length ? [1,0.5,0,0.5] : [1,0.5,0];
  return {
    chord:{
      d:    {w:1.00, aff:S.affD.slice()},
      tau:  {w:0.45, aff:[0,0.5,1,0.5,0]},
      rho:  {w:0.45, aff:rho},
      eta:  {w:0.25, aff:[0.5,1,0.5]},
    },
    voice:{
      kappa:{w:0.45, aff:[0,0.5,1]},
      mu:   {w:0.35, aff:[0,0.5,1,0.5,0]},
      phi:  {w:1.00, aff:[0,0.5,1]},
      sigma:{w:0.20, aff:[1,0.55]},
      gamma:{w:0.30, aff:[0,0.5,1]},
    },
  };
}
// Six envelopes a note can be given when it is painted into the sequencer (and that any note can be given later). They are shared:
// change one and every note that uses it changes. gateRatio is note-off as a fraction of the distance to the next onset.
const ENV_BANK_SIZE = 6;
function defaultEnvBank(){
  return [
    {name:'Pluck',    a:0.004, d:0.12, s:0.10, r:0.25, gateRatio:0.50},
    {name:'Pad',      a:0.30,  d:0.50, s:0.85, r:1.10, gateRatio:1.00},
    {name:'Organ',    a:0.012, d:0.04, s:1.00, r:0.06, gateRatio:0.98},
    {name:'Bell',     a:0.002, d:1.40, s:0.00, r:1.60, gateRatio:1.00},
    {name:'Staccato', a:0.005, d:0.05, s:0.45, r:0.10, gateRatio:0.28},
    {name:'Legato',   a:0.06,  d:0.10, s:0.80, r:0.45, gateRatio:1.12},
  ];
}
function defaultVoiceEnv(v){
  return [
    {a:0.010, d:0.085, s:0.55, r:0.30, gateRatio:0.92},
    {a:0.022, d:0.120, s:0.66, r:0.42, gateRatio:0.98},
    {a:0.016, d:0.160, s:0.72, r:0.55, gateRatio:0.90},
  ][v];
}

const STATE = {
  div:12,        // steps to the octave: the pitch space (see buildSpace)
  colour:false,  // whether the colour chords of the space are in the vocabulary
  timbre:'soft', // the voice the synthesiser uses: classic | soft | pure
  root:0, scaleName:'Ionian',
  bars:8, stepsPerBar:8, lastStepsPerBar:8, harmonic:'bar',
  tempo:96, tension:0.30,
  lamC:0.38, lamV:0.46,
  profiles: defaultProfiles(),
  cellFlips:{ chord:{}, voice:{} },   // "i0,i1,.." -> 0|1
  extended:false, walkingBass:false, arp:'none',
  choice:defaultChoice(),   // how a legal move is chosen (10-choice.js)
  take:'bold',   // the classic choice only: which legal move to take: smooth | strong | bold
  tuning:'equal',// how the twelve pitch classes are tuned: see TUNINGS
  seed:{ chordIdx:0, eta:1, prev2Idx:-1, voice:[null,null,null] },
  anchors:{},                          // step -> pitch (melody)
  notePins:{},                         // "v:step" -> pitch: a note the composer has fixed, in any voice
  pins:{},                             // segIdx -> chord.key
  barOverrides:{},                     // bar -> {scale?, tension?}
  touched:[false,false,false],         // a lane the composer has painted stops following the defaults
  onsets:null,
  voiceEnv:[defaultVoiceEnv(0), defaultVoiceEnv(1), defaultVoiceEnv(2)],
  noteEnv:{},                          // "v:step" -> partial env
  envBank:defaultEnvBank(),            // the six shared envelopes
  envBrush:-1,                         // the one a note painted into the sequencer takes: an index, or -1 for its lane's own
  notePreset:{},                       // "v:step" -> index in envBank: the envelope this note was given
  vetoChord:{},                        // segIdx -> [chord.key]: moves the composer has ruled out at that chord
  vetoNote:{},                         // "v:step" -> [pitch]: pitches the composer has ruled out for that note
  selectedNote:null,                   // {v, step}
  selectedSeg:1, selectedBar:null, lane:'all',
  seqBars:0,                           // bars to a row in the sequencer: 0 fits as many as are comfortable
  show:{ tails:true, ghosts:true, sounding:false },
  lattice:{ set:'chord' },
  life:{w:18,h:10,grid:null},
  composed:null,
  audio:null, playing:false, step:0, stepFloat:0, nextTime:0, startTime:0, timer:null, raf:null,
};

/* ---- moving a piece from one space to another ------------------------------------------
   Everything that is a pitch moves to the step nearest it in cents; everything that is an index into
   the space's own vocabulary (pinned chords) or its own steps (hand-set root-fall cells) is remapped or
   dropped. The root-fall profile is carried over by cents too: each new step takes the strongest of the old
   affinities near it, fading with distance, which is the rule that made the defaults. */
function resampleAff(aff, fromN, toN){
  if(fromN===toN) return aff.slice();
  const out=new Array(toN).fill(0);
  for(let d=0; d<toN; d++){
    let best=0;
    for(let e=0; e<fromN; e++){
      let dc=Math.abs(d*1200/toN - e*1200/fromN); dc=Math.min(dc,1200-dc);
      const a=aff[e]*Math.exp(-(dc/35)*(dc/35)); if(a>best) best=a;
    }
    out[d]=Math.round(best*1000)/1000;
  }
  return out;
}
function switchSpace(N){
  N=Math.round(N); if(!(N>=MIN_DIV && N<=MAX_DIV)) return false;
  const from=NN; if(N===from && STATE.div===N) return true;
  const S=spaceFor(N), old=SP, cv=(p)=>Math.round(p*N/from);
  const wasDefault = STATE.profiles.chord.d.aff.length===old.affD.length && STATE.profiles.chord.d.aff.every((x,i)=>Math.abs(x-old.affD[i])<1e-9);
  const oldD=STATE.profiles.chord.d.aff, oldRho=STATE.profiles.chord.rho.aff.slice();
  const oldCol=old.colour.length>0, newCol=S.colour.length>0;
  STATE.root=Math.round(STATE.root*N/from)%N;
  for(const k of Object.keys(STATE.anchors)) STATE.anchors[k]=cv(STATE.anchors[k]);
  for(const k of Object.keys(STATE.notePins)) STATE.notePins[k]=cv(STATE.notePins[k]);
  for(const k of Object.keys(STATE.vetoNote)) STATE.vetoNote[k]=[...new Set(STATE.vetoNote[k].map(cv))];
  STATE.vetoChord={};
  STATE.seed.voice=STATE.seed.voice.map(p=>p==null?null:cv(p));
  STATE.pins={};
  if(!scaleStepsIn(S,STATE.scaleName)) STATE.scaleName='Ionian';
  for(const k of Object.keys(STATE.barOverrides)){ const o=STATE.barOverrides[k]; if(o.scale && !scaleStepsIn(S,o.scale)) delete o.scale; if(o.scale===undefined && o.tension===undefined) delete STATE.barOverrides[k]; }
  // hand-set root-fall cells follow their step
  const flips={};
  for(const k of Object.keys(STATE.cellFlips.chord)){
    const c=k.split(',').map(Number); c[0]=Math.round(c[0]*N/from)%N; if(c[2]>=(newCol?4:3)) continue;
    flips[c.join(',')]=STATE.cellFlips.chord[k];
  }
  STATE.cellFlips.chord=flips;
  if(N!==12) STATE.tuning='equal';
  setDivisions(N); STATE.div=N;
  const prof=defaultProfiles();
  STATE.profiles.chord.d.aff = wasDefault ? prof.chord.d.aff : resampleAff(oldD, from, N);
  STATE.profiles.chord.rho.aff = newCol ? oldRho.slice(0,3).concat([oldRho.length>3?oldRho[3]:0.5]) : oldRho.slice(0,3);
  if(!oldCol && newCol) STATE.colour=true;
  if(!newCol) STATE.colour=false;
  STATE.selectedNote=null; STATE.composed=null;
  return true;
}
