/* =====================================================================
   13 · READOUTS
   ---------------------------------------------------------------------
   Everything here reads the composed piece and its analysis (13-analysis.js)
   and says what they say. The wording keeps to what was measured: the chord
   automaton is a deterministic map on a few hundred states, so what can be
   reported is where a seed goes, how long it takes, what cycle it ends in,
   and how much the answer depends on the seed and on the rule's cells.
   ===================================================================== */
const ONE_PLATE_H = 78;

function popcount(a){ let n=0; for(let i=0;i<a.length;i++) if(a[i]) n++; return n; }
function esc(s){ return String(s).replace(/[&<>"']/g, ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch])); }
function pct(x){ return Math.round(x*100)+'%'; }
function listCount(o){ let n=0; for(const k of Object.keys(o)) n+=Array.isArray(o[k])?o[k].length:1; return n; }
const BANK_FIELDS=['name','a','d','s','r','gateRatio'];
function bankEdited(){ const d=defaultEnvBank(); let n=0; STATE.envBank.forEach((b,i)=>{ if(BANK_FIELDS.some(f=>b[f]!==d[i][f])) n++; }); return n; }
// An edit belongs to a note, and a note that is not there (its onset was switched off, or the rhythm that follows the chords moved)
// is not an edit anyone can see; those are not counted, and they are dropped the next time the lane is painted.
function liveCount(o){ return liveNoteKeys(o).length; }
function liveListCount(o){ let n=0; for(const k of liveNoteKeys(o)) n+=Array.isArray(o[k])?o[k].length:1; return n; }
function liveAnchors(){ let n=0; for(const k of Object.keys(STATE.anchors)) if(STATE.onsets && STATE.onsets[0] && STATE.onsets[0][+k]) n++; return n; }
function handCount(){
  return Object.keys(STATE.cellFlips.chord).length+Object.keys(STATE.cellFlips.voice).length
    +Object.keys(STATE.pins).length+listCount(STATE.vetoChord)+liveCount(STATE.notePins)+liveListCount(STATE.vetoNote)
    +liveAnchors()+liveCount(STATE.noteEnv)+liveCount(STATE.notePreset)+bankEdited()
    +Object.keys(STATE.barOverrides).length+STATE.touched.filter(Boolean).length;
}

/* ---- selection ------------------------------------------------------------------ */
// The note and the chord that the inspector shows go together: selecting one moves the other into place.
function ensureSelectedNote(){
  const c=STATE.composed, n=STATE.selectedNote; if(!c||!c.notes) return;
  if(n && c.notes[n.v] && c.notes[n.v].some(x=>x.step===n.step)) return;
  const g=Math.max(0,Math.min(c.segments-1,STATE.selectedSeg)), lo=g*segLen(), hi=Math.min(c.total,lo+segLen());
  const inSeg=(u)=>c.notes[u].find(x=>x.step>=lo&&x.step<hi);
  const first=inSeg(0)||inSeg(1)||inSeg(2)||c.notes[0][0]||c.notes[1][0]||c.notes[2][0];
  STATE.selectedNote = first ? {v:first.v, step:first.step} : null;
}
function selectNote(v, step, reveal){
  const c=STATE.composed;
  STATE.selectedNote={v,step}; INSPECT.pickNote=null; HOVER.branch=null;
  if(c){ const g=Math.min(c.segments-1, segOfStep(step)); if(g!==STATE.selectedSeg){ STATE.selectedSeg=g; INSPECT.pickChord=null; } }
  renderInspector(); drawRoll(); drawSeq(); drawEnv(); renderBank(); drawLattice();
  if(reveal){
    const el=$('envCanvas');
    if(el && el.scrollIntoView) try{ el.scrollIntoView({block:'nearest', behavior:REDUCED_MOTION()?'auto':'smooth'}); }catch(e){}
  }
}
function selectSeg(s){
  const c=STATE.composed; if(!c) return;
  const g=Math.max(0,Math.min(c.segments-1,s));
  STATE.selectedSeg=g; HOVER.branch=null; HOVER.link=null; INSPECT.pickChord=null; INSPECT.pickNote=null;
  const L=segLen(), lo=g*L, hi=Math.min(c.total,lo+L), cur=STATE.selectedNote;
  const inSeg=(u)=>c.notes[u].find(x=>x.step>=lo&&x.step<hi);
  const nt=(cur&&inSeg(cur.v))||inSeg(0)||inSeg(1)||inSeg(2);
  if(nt) STATE.selectedNote={v:nt.v, step:nt.step};
  renderInspector(); drawRoll(); drawSeq(); drawEnv(); renderBank(); drawLattice();
}

/* ---- status line -------------------------------------------------------------------- */
function renderStatus(){
  const c=STATE.composed, el=$('statusline'); if(!c||!el) return;
  const d=c.dyn, o=d.orbit, hand=handCount();
  const items=[
    ['space', NN+' steps'], ['λ chord', fmt2(STATE.lamC)], ['λ voice', fmt2(STATE.lamV)],
    ['seed', c.chords[0].roman+' · η '+ETA_NAMES[Math.min(2,Math.max(0,STATE.seed.eta))]],
    ['orbit', o.cls+', period '+o.period], ['attractors', String(d.attractors)],
    ['cells asked', popcount(c.reach)+'/'+CHORD_STR.size], ['choice', choiceLabel()],
  ];
  if(NN===12 && STATE.tuning!=='equal') items.push(['tuning', TUNINGS[STATE.tuning].label]);
  el.textContent='';
  for(const [k,v] of items){ const s=mk('span'); s.appendChild(document.createTextNode(k+' ')); s.appendChild(mk('b',null,v)); el.appendChild(s); }
  if(hand){ const s=mk('span','hand'); s.appendChild(document.createTextNode('by hand ')); s.appendChild(mk('b',null,String(hand))); el.appendChild(s); }
  fitHeader();
}
function fitHeader(){
  const h=$('masthead'), s=$('statusline'), r=document.documentElement.style;
  if(h) r.setProperty('--hdr', h.offsetHeight+'px');
  if(s) r.setProperty('--stat', s.offsetHeight+'px');
}

/* ---- the sweep ------------------------------------------------------------------------- */
const CLASS_WORDS = {
  fixed:'stands still: period 1',
  loop:'loops: goes round at least twice within the piece',
  tour:'tours: the piece ends before the orbit has closed twice',
};
function sweepTip(p, n){
  const cls=orbitClass(p.period,n);
  return ['λ '+fmt2(p.lam)+' · '+cls,
    'period '+p.period+' of '+p.V+' chords · wanders '+p.transient,
    p.A+' attractor'+(p.A===1?'':'s')+' in the whole graph',
    'seed memory '+pct(p.S)+' · '+p.H.toFixed(2)+' bits'];
}
function renderSweep(){
  const c=STATE.composed, el=$('sweep'); if(!c||!el) return;
  const sw=c.sweep, n=c.segments, maxP=Math.max(n, Math.max.apply(null, sw.map(p=>p.period))), H=ONE_PLATE_H-6;
  el.textContent='';
  const here=sw.reduce((b,p,i)=>Math.abs(p.lam-STATE.lamC)<Math.abs(sw[b].lam-STATE.lamC)?i:b, 0);
  sw.forEach((p,i)=>{
    const cls=orbitClass(p.period,n), b=mk('button','c'+(i===here?' here':''));
    b.type='button'; b.style.height=Math.max(5,Math.round(H*p.period/maxP))+'px'; b.style.background='var(--cls-'+cls+')';
    b.tabIndex = i===here?0:-1; b.dataset.i=i;
    b.setAttribute('aria-label','lambda '+p.lam.toFixed(2)+', '+cls+', period '+p.period+'. Set the chord rule to this value.');
    const tip=(e)=>{ const r=b.getBoundingClientRect(); showTip(e&&e.clientX!=null?e.clientX:r.left+r.width/2, e&&e.clientY!=null?e.clientY:r.top, sweepTip(p,n)); };
    b.addEventListener('mouseenter', tip); b.addEventListener('mousemove', tip);
    b.addEventListener('mouseleave', hideTip); b.addEventListener('focus', ()=>tip(null)); b.addEventListener('blur', hideTip);
    b.addEventListener('click', ()=>setLambdaC(p.lam));
    el.appendChild(b);
  });
  // the line at half the piece: a cycle longer than this cannot go round twice
  const box=el.parentNode; let line=$('sweepLine');
  if(!line){ line=mk('div'); line.id='sweepLine'; line.appendChild(mk('span')); box.insertBefore(line, el.nextSibling); }
  line.style.top=(ONE_PLATE_H-Math.round(H*(n/2)/maxP)-1)+'px';
  line.firstChild.textContent='half the piece ('+(n/2)+')';
  line.hidden = (n/2)/maxP>0.97;
  const mem=$('memrow'); mem.textContent='';
  for(const p of sw){ const i=mk('i'); i.style.height=Math.max(1,Math.round(22*p.S))+'px'; mem.appendChild(i); }
  // the table that carries the same numbers
  const tb=$('sweepTable'); tb.textContent='';
  const t=mk('table','tbl'), hd=mk('tr');
  for(const h of ['λ','class','period','wanders','attractors','seed memory','bits','longest']) hd.appendChild(mk('th',null,h));
  t.appendChild(mk('thead')).appendChild(hd);
  const body=mk('tbody');
  sw.forEach((p,i)=>{ const r=mk('tr', i===here?'here':null);
    for(const x of [fmt2(p.lam), orbitClass(p.period,n), p.period, p.transient, p.A, pct(p.S), p.H.toFixed(2), p.longest]) r.appendChild(mk('td',null,String(x)));
    body.appendChild(r); });
  t.appendChild(body); tb.appendChild(t);
  renderSweepKey();
}
function renderSweepKey(){
  const el=$('sweepKey'); if(!el) return; el.textContent='';
  for(const k of ['fixed','loop','tour']){ const s=mk('span'); const i=mk('i','sw'); i.style.background='var(--cls-'+k+')'; s.appendChild(i); s.appendChild(document.createTextNode(CLASS_WORDS[k])); el.appendChild(s); }
}
function sweepKeys(e){
  const items=[...$('sweep').querySelectorAll('button.c')]; const i=items.indexOf(document.activeElement); if(i<0) return;
  let j=i; if(e.key==='ArrowRight') j=Math.min(items.length-1,i+1); else if(e.key==='ArrowLeft') j=Math.max(0,i-1); else if(e.key==='Home') j=0; else if(e.key==='End') j=items.length-1; else return;
  e.preventDefault(); items.forEach((b,k)=>b.tabIndex=k===j?0:-1); items[j].focus();
}

function renderDyn(){
  const c=STATE.composed, el=$('dynRead'); if(!c||!el) return;
  const d=c.dyn, o=d.orbit, n=c.segments, names=o.chords.map(x=>x.roman);
  const cyc = names.length>8 ? names.slice(0,8).join(' ')+' …' : names.join(' ');
  let l1;
  if(o.cls==='fixed') l1='From this seed the chords settle on <b>'+esc(names[0])+'</b> after <b>'+o.transient+'</b> step'+(o.transient===1?'':'s')+' and stay there.';
  else if(o.cls==='loop') l1='From this seed the chords wander <b>'+o.transient+'</b> step'+(o.transient===1?'':'s')+', then repeat <b>'+esc(cyc)+'</b> (period '+o.period+'): about '+(n/o.period).toFixed(1)+' laps in a piece of '+n+' chords.';
  else l1='The cycle this seed ends in, <b>'+esc(cyc)+'</b>, has period <b>'+o.period+'</b>, longer than half of the '+n+' chords, so the piece ends before it has gone round twice.';
  if(o.transient>=n-1 && o.cls!=='fixed') l1+=' The piece ends before the walk has reached that cycle.';
  const l2='The whole graph has <b>'+d.N+'</b> states ('+d.V+' chords × 3 momenta × '+(d.V+1)+' choices of the chord two back) and <b>'+d.attractors+'</b> attractor'+(d.attractors===1?'':'s')
    +'. This seed’s basin holds <b>'+o.basin+'</b>. Changing one seed control lands in a different attractor <b>'+pct(d.memory)+'</b> of the time.';
  const reach=popcount(c.reach), dep=c.dep;
  const l3='This vocabulary can ask <b>'+reach+'</b> of the '+CHORD_STR.size+' rule cells. Flipping any single cell changes the first '+n+' chords in <b>'+dep.changed+'</b> case'+(dep.changed===1?'':'s')
    +(dep.changed? ' (earliest at chord '+(dep.first+1)+')':'')+'.';
  const l4=c.sequence ? 'A run of '+c.sequence.k+' root motions occurs twice in a row from chord '+(c.sequence.i+1)+': a sequence, in the musical sense.' : '';
  el.innerHTML=l1+'<br>'+l2+'<br>'+l3+(l4?'<br>'+l4:'');
}

/* ---- basins ------------------------------------------------------------------------------ */
let BASIN_GEO=null;
function basinColor(rank){ return rank===0?THEME.att[0] : rank===1?THEME.att[1] : THEME.att[2]; }
function drawBasin(){
  const c=STATE.composed, cv=$('basinCanvas'); if(!c||!c.basin||!cv) return;
  const b=c.basin, {g,w,h}=ctx2d(cv), S=THEME.str;
  const L=48, T=18, pw=w-L-4, ph=h-T-4, cols=b.V*3, rows=b.P, cw=pw/cols, ch=ph/rows;
  g.font='9px '+THEME.font.mono; g.textBaseline='middle';
  for(let i=0;i<b.V;i++) for(let e=0;e<3;e++) for(let p=-1;p<b.V;p++){
    const s=b.enc(i,e,p), rank=b.rank.get(b.attr[s]), t=b.trans[s]/Math.max(1,b.maxT);
    const col=mix(basinColor(rank), THEME.bg, t*0.62);
    g.fillStyle=css(col,1);
    const x=L+(i*3+e)*cw, y=T+(p+1)*ch;
    g.fillRect(x, y, Math.max(0.6,cw-(e===2?1.8:0.5)), Math.max(0.6,ch-0.5));
    if(b.trans[s]===0 && cw>5 && ch>5){ g.fillStyle=css(THEME.dark?[1,1,1]:[0,0,0],0.7); g.beginPath(); g.arc(x+cw/2-0.4,y+ch/2,1.2,0,7); g.fill(); }
  }
  // labels: the chord of each column group, the chord two back of each row
  g.fillStyle=S.dim; g.textAlign='center';
  const fitsCol=cw*3>34;
  for(let i=0;i<b.V;i++) if(fitsCol || i%2===0) g.fillText(b.vocab[i].roman, L+(i*3+1.5)*cw, T-8);
  g.textAlign='right';
  const rowEvery=ch>=10?1:2;
  for(let p=-1;p<b.V;p++) if((p+1)%rowEvery===0) g.fillText(p<0?'none':b.vocab[p].roman, L-5, T+(p+1.5)*ch);
  // the seed
  const sd=seedIdx(b.vocab);
  g.strokeStyle=S.ink; g.lineWidth=2; g.strokeRect(L+(sd.i*3+sd.e)*cw-1, T+(sd.p+1)*ch-1, cw+1.4, ch+1.4);
  BASIN_GEO={L,T,cw,ch,V:b.V,P:b.P};

  const leg=$('basinLegend'); leg.textContent='';
  const row=(rank,color,html)=>{ const d=mk('div','attr'); const i=mk('i','sw'); i.style.background=color; d.appendChild(i); const t=mk('span'); t.innerHTML=html; d.appendChild(t); leg.appendChild(d); };
  const list=b.list;
  list.slice(0,2).forEach((a,r)=>{
    const names=a.chords.map(x=>x.roman), shown=names.length>6?names.slice(0,6).join(' ')+' …':names.join(' ');
    row(r, css(THEME.att[r]), '<b>'+(r===0?'largest':'second')+'</b>: period <b>'+a.period+'</b> · '+pct(a.size/b.N)+' of states · '+esc(shown));
  });
  if(list.length>2){ const rest=list.slice(2), sz=rest.reduce((s,a)=>s+a.size,0);
    row(2, css(THEME.att[2]), '<b>'+rest.length+' other</b> attractor'+(rest.length===1?'':'s')+' · '+pct(sz/b.N)+' of states'); }
  if(list.length===1) row(0, css(THEME.att[0]), 'every state ends in this one cycle');
  $('basinStat').innerHTML='<b>'+b.N+'</b> states · <b>'+list.length+'</b> attractor'+(list.length===1?'':'s')+' · longest wander <b>'+b.maxT+'</b>';
}
function basinPick(clientX, clientY){
  const cv=$('basinCanvas'), G=BASIN_GEO; if(!cv||!G) return null;
  const r=cv.getBoundingClientRect(), x=clientX-r.left-G.L, y=clientY-r.top-G.T;
  const col=Math.floor(x/G.cw), row=Math.floor(y/G.ch);
  if(col<0||col>=G.V*3||row<0||row>=G.P) return null;
  return {chordIdx:Math.floor(col/3), eta:col%3, prev2Idx:row-1};
}
function basinTip(clientX, clientY, s){
  const c=STATE.composed; if(!c||!c.basin||!s) return hideTip();
  const b=c.basin, st=b.enc(s.chordIdx,s.eta,s.prev2Idx), rank=b.rank.get(b.attr[st]), a=b.list[rank];
  showTip(clientX, clientY, [b.vocab[s.chordIdx].roman+' · η '+ETA_NAMES[s.eta]+' · after '+(s.prev2Idx<0?'nothing':b.vocab[s.prev2Idx].roman),
    'wanders '+b.trans[st]+', then cycles with period '+a.period, (rank===0?'the largest attractor':rank===1?'the second largest':'one of '+(b.list.length-2)+' smaller ones')+' · click to start here']);
}

/* ---- the rail: statistics, hand edits, bar settings, export summary ------------------------------ */
function renderStats(){
  const c=STATE.composed; if(!c) return;
  const vocab=baseVocab(), tc=chordTable(), tv=voiceTable();
  const br=chordBranching(tc, vocab, STATE.tension);
  const reach=c.reach; let rl=0; for(let i=0;i<tc.t.length;i++) if(reach[i] && tc.t[i]) rl++;
  const flips=Object.keys(STATE.cellFlips.chord).length;
  $('statC').innerHTML=
    '<b>'+tc.legalCount+'</b> of '+tc.size+' cells legal'+(flips?' (λ alone admits '+tc.cut+')':'')
    +'<br>this vocabulary can ask <b>'+popcount(reach)+'</b> of them, <b>'+rl+'</b> legal'
    +'<br>from a state, <b>'+br.mean.toFixed(1)+'</b> of '+vocab.length+' moves are legal · <b>'+pct(br.forced)+'</b> forced · <b>'+pct(br.dead)+'</b> none';
  $('statV').innerHTML='<b>'+tv.legalCount+'</b> of '+tv.size+' cells legal'+(Object.keys(STATE.cellFlips.voice).length?' (λ alone admits '+tv.cut+')':'');
  const mc=chordMarginals(tc), mv=voiceMarginals(tv);
  document.querySelectorAll('.axis').forEach(wrap=>{
    const set=wrap.dataset.set, key=wrap.dataset.key, axes=set==='chord'?CHORD_AXES:VOICE_AXES, marg=set==='chord'?mc:mv;
    const ai=axes.findIndex(a=>a.key===key);
    wrap.querySelectorAll('.marg i u').forEach((u,i)=>{ u.style.height=Math.round(marg[ai][i]*100)+'%'; });
  });
}
/* ---- what you have changed by hand, each with its own way back ------------------------------------ */
const EDIT_KINDS=[
  {n:()=>Object.keys(STATE.cellFlips.chord).length+Object.keys(STATE.cellFlips.voice).length, text:n=>'rule cell'+(n===1?'':'s')+' flipped', clear:()=>{ STATE.cellFlips={chord:{},voice:{}}; }},
  {n:()=>Object.keys(STATE.pins).length, text:n=>'chord'+(n===1?'':'s')+' pinned', clear:()=>{ STATE.pins={}; }},
  {n:()=>listCount(STATE.vetoChord), text:n=>'chord move'+(n===1?'':'s')+' ruled out', clear:()=>{ STATE.vetoChord={}; }},
  {n:()=>liveCount(STATE.notePins), text:n=>'note'+(n===1?'':'s')+' pinned to a pitch', clear:()=>{ STATE.notePins={}; }},
  {n:()=>liveListCount(STATE.vetoNote), text:n=>'pitch'+(n===1?'':'es')+' ruled out', clear:()=>{ STATE.vetoNote={}; }},
  {n:()=>liveAnchors(), text:n=>'melody pitch'+(n===1?'':'es')+' anchored', clear:()=>{ STATE.anchors={}; }},
  {n:()=>liveCount(STATE.noteEnv), text:n=>'note'+(n===1?'':'s')+' with its own envelope shaping', clear:()=>{ STATE.noteEnv={}; }},
  {n:()=>liveCount(STATE.notePreset), text:n=>'note'+(n===1?'':'s')+' given a preset envelope', clear:()=>{ STATE.notePreset={}; }},
  {n:()=>bankEdited(), text:n=>'preset envelope'+(n===1?'':'s')+' changed', clear:()=>{ STATE.envBank=defaultEnvBank(); }},
  {n:()=>Object.keys(STATE.barOverrides).length, text:n=>'bar'+(n===1?'':'s')+' with its own scale or aim', clear:()=>{ STATE.barOverrides={}; STATE.selectedBar=null; }},
  {n:()=>STATE.touched.filter(Boolean).length, text:n=>'lane'+(n===1?'':'s')+' with painted rhythm', clear:()=>{ STATE.touched=[false,false,false]; }},
];
function renderHandStat(){
  const el=$('handStat'); if(!el) return;
  const keep=document.activeElement && el.contains(document.activeElement) ? document.activeElement.dataset.ek : null;
  el.textContent='';
  const rows=EDIT_KINDS.map(k=>({k, n:k.n()})).filter(r=>r.n>0);
  if(!rows.length){ el.appendChild(mk('p','aside','Nothing yet. Anything you change by hand (a flipped cell, a pinned chord or pitch, an anchor, a painted rhythm, a reshaped envelope) is listed here with a way back, and marked in magenta where it shows.')); return; }
  const box=mk('div','edits');
  rows.forEach((r,i)=>{
    const row=mk('div','er'), t=mk('span'); t.appendChild(mk('b',null,String(r.n))); t.appendChild(document.createTextNode(r.k.text(r.n)));
    const b=mk('button','tiny','Clear'); b.type='button'; b.dataset.ek='e'+i; b.setAttribute('aria-label','Clear: '+r.n+' '+r.k.text(r.n));
    b.addEventListener('click', ()=>{ r.k.clear(); regenerate(); histCommit(); });
    row.append(t,b); box.appendChild(row);
  });
  el.appendChild(box);
  if(rows.length>1){
    const all=mk('button','tiny','Clear all of these'); all.type='button'; all.id='btnClearEdits'; all.style.marginTop='8px';
    all.title='Takes back every edit listed above and leaves every setting as it is';
    all.addEventListener('click', ()=>{ for(const r of rows) r.k.clear(); regenerate(); histCommit(); });
    el.appendChild(all);
  }
  if(keep){ const nb=el.querySelector('[data-ek="'+keep+'"]'); if(nb) try{ nb.focus({preventScroll:true}); }catch(e){} }
}
// the one line each group of the rail keeps showing while it is shut
function syncSummaries(){
  const set=(id,html)=>{ const e=$(id); if(e) e.innerHTML=html; };
  const c=STATE.composed;
  set('sumSpace', esc(spaceSummary()));
  set('sumForm', esc(STATE.bars+' bars · '+({4:'quarters',8:'eighths',16:'sixteenths'}[STATE.stepsPerBar]||STATE.stepsPerBar+' steps')+' · chords '+(STATE.harmonic==='bar'?'every bar':'twice a bar')+' · aim '+fmt2(STATE.tension)
    +(STATE.extended?' · applied chords':'')+(STATE.walkingBass?' · walking bass':'')+(STATE.arp!=='none'?' · figure '+STATE.arp:'')));
  set('sumRule', esc('chords λ '+fmt2(STATE.lamC)+' · notes λ '+fmt2(STATE.lamV)));
  if(c) set('sumStart', esc(c.chords[0].roman+' · momentum '+ETA_NAMES[Math.min(2,Math.max(0,STATE.seed.eta))]+(STATE.seed.voice.some(v=>v!=null)?' · voices chosen':'')));
  const n=handCount();
  set('sumEdits', n ? '<span class="hand">'+n+' by hand</span>' : 'none yet');
}
function renderKeep(){ const el=$('midiInfo'); if(el) el.textContent=midiSummary(); }

/* ---- everything ------------------------------------------------------------------------------------- */
let SPACE_KEY='';
function renderAll(){
  const c=STATE.composed; if(!c) return;
  ensureSelectedNote();
  renderRollGutter();
  renderStatus(); renderStats(); renderHandStat(); syncSummaries(); renderSeqTools(); renderKeep(); syncChoiceControls();
  renderInspector();
  drawLattice(); latticeReadout(HOVER.cell);
  drawRoll(); drawSeq(); drawEnv(); renderBank(); noteReadout(HOVER_NOTE.nt && c.notes[HOVER_NOTE.nt.v].find(x=>x.step===HOVER_NOTE.nt.step) || null);
  renderSweep(); renderDyn(); drawBasin();
  const key=[NN, STATE.scaleName, STATE.colour?1:0, THEME.dark?1:0].join('|');
  if(key!==SPACE_KEY){ SPACE_KEY=key; renderSpacePlate(); } else drawIntervalMap();
}
