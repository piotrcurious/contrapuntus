/* =====================================================================
   9 · RULE SPACE
   ---------------------------------------------------------------------
   Every cell of a rule table is a point in a space of four (chord) or five
   (voice) discrete axes, and the screen has two. So the picture is a
   projection, and which projection is a choice about what to look at:

     flat grid   the axes nested like the digits of a number, no two cells ever meet
     fifths ring root fall on a circle of fifths (so that a strong root motion is
                 next to "no motion"), tension as the radius
     oblique     the second-order axes spread apart, first-order ones folded together
     by cost     every cell at its cost: the legal set is a cut by a vertical line
     your own    drag any handle of a flat or oblique view; wrap any axis into a ring

   Marks: how a cell is drawn says whether it is legal, whether this piece can
   ever ask about it, whether the piece used it, whether flipping it would change
   the piece, and whether you flipped it by hand.
   ===================================================================== */
let GL_LAT=null, LAYOUT=null, TWEEN=null, FRAME=null;
const HOVER = {cell:null, link:null, branch:null};
const DRAG = {axis:null};

function latticeSpec(){
  const set=STATE.lattice.set, c=STATE.composed;
  const chord = set==='chord';
  const seq = c ? (chord ? c.chordCellSeq : c.voiceCellSeq) : [];
  const counts=new Map(); for(const f of seq) counts.set(f,(counts.get(f)||0)+1);
  return {
    set, axes: chord?CHORD_AXES:VOICE_AXES, dims: chord?CHORD_DIMS:VOICE_DIMS, strides: chord?CHORD_STR.strides:VOICE_STR.strides,
    tbl: chord?chordTable():voiceTable(), seq, counts,
    used: c ? (chord?c.chordCells:c.voiceCells) : null,
    flips: chord?STATE.cellFlips.chord:STATE.cellFlips.voice, proj: PROJ[set],
    reach: chord && c ? c.reach : null,
    dep: chord && c && c.dep ? new Set(c.dep.cells) : null,
  };
}
function cellKey(set, f){ return cellList(set==='chord'?CHORD_DIMS:VOICE_DIMS)[f].join(','); }

/* ---- layout ------------------------------------------------------------ */
const POLAR = {R0:70, DR:24, get WEDGE(){ return 2*Math.PI/NN; }, SPREAD:0.27, ETA:8};
function polarOf(cell){
  const [d,tau,rho,eta]=cell;
  const th=-Math.PI/2 + fifthsPos(d)*POLAR.WEDGE + (rho-1)*POLAR.WEDGE*POLAR.SPREAD;
  const r=POLAR.R0 + tau*POLAR.DR + (eta-1)*POLAR.ETA;
  return [Math.cos(th)*r, Math.sin(th)*r];
}
function axisVec(P, a, val){
  const b=P.basis[a.key];
  if(P.cyclic[a.key]){
    const R=Math.hypot(b[0],b[1]), pos=a.ringOrder?a.ringOrder(val):val, th=Math.atan2(b[1],b[0]) + 2*Math.PI*pos/a.n;
    return [Math.cos(th)*R, Math.sin(th)*R];
  }
  return [b[0]*val, b[1]*val];
}
function rowAxisOf(sp){
  const k=sp.proj.rows; let i=sp.axes.findIndex(a=>a.key===k);
  if(i<0){ i=0; for(let j=1;j<sp.axes.length;j++) if(sp.axes[j].n>sp.axes[i].n) i=j; }
  return i;
}
/* By cost: x is the cell's cost, y is its row. Cells that share a cost (the cost surface is a sum of
   a few discrete profiles, so there are far fewer costs than cells) would sit on one another, so within a
   row they are fanned out vertically, and only when a row is full sideways by a couple of pixels. Legal
   cells keep to the left of the cut line and the others to the right of it, ties included.            */
function costLayout(sp, cells, ri, ra, G){
  const tbl=sp.tbl;
  const key=ri+'|'+G.W+'|'+G.H;
  if(tbl._costLay && tbl._costLay.key===key) return tbl._costLay;
  const N=cells.length, costs=tbl.costs, ord=tbl.order, cut=tbl.cut, W=G.W, padL=G.padL, padR=G.padR, padT=G.padT, band=G.band;
  let lo=1e9, hi=-1e9;
  for(let f=0;f<N;f++){ if(costs[f]<lo) lo=costs[f]; if(costs[f]>hi) hi=costs[f]; }
  const span=Math.max(1e-9,hi-lo), X=c=>padL+(c-lo)/span*(W-padL-padR);
  const cutX=(cut>0&&cut<N) ? X((costs[ord[cut-1]]+costs[ord[cut]])/2) : null;
  const D=5, half=Math.max(0,band/2-3.5), slots=[0];
  for(let k=1;k*D<=half+1e-6;k++) slots.push(k*D,-k*D);
  const rows=[]; for(let r=0;r<ra.n;r++) rows.push({x:[],y:[],h:new Map()});
  const hk=(ix,iy)=>ix*4096+iy;
  const pts=new Float64Array(N*2);
  for(let r=0;r<N;r++){
    const f=ord[r], row=cells[f][ri], legal=r<cut, P=rows[row];
    let x0=X(costs[f]);
    if(cutX!=null) x0 = legal ? Math.min(x0,cutX-0.5) : Math.max(x0,cutX+0.5);
    const cy=padT+(ra.n-1-row)*band+band/2;
    let bx=x0, by=cy, done=false;
    for(let j=0;j<=70 && !done;j++){
      for(let sg=1;sg>=-1 && !done;sg-=2){
        if(j===0 && sg<0) break;
        const x=x0+sg*j*D*0.5;
        if(x<padL-6 || x>W-padR+6) continue;
        if(cutX!=null && (legal ? x>cutX-0.5 : x<cutX+0.5)) continue;
        for(const dy of slots){
          const y=cy+dy; let free=true;
          const ix=Math.floor(x/D), iy=Math.floor(y/D);
          for(let u=-1;u<=1&&free;u++) for(let w=-1;w<=1&&free;w++){
            const bucket=P.h.get(hk(ix+u+2,iy+w+2)); if(!bucket) continue;
            for(const q of bucket){ const a=P.x[q]-x, b=P.y[q]-y; if(a*a+b*b<D*D){ free=false; break; } }
          }
          if(free){ bx=x; by=y; done=true; break; }
        }
      }
    }
    { const k=hk(Math.floor(bx/D)+2, Math.floor(by/D)+2); let b=P.h.get(k); if(!b){ b=[]; P.h.set(k,b); } b.push(P.x.length); }
    P.x.push(bx); P.y.push(by); pts[f*2]=bx; pts[f*2+1]=by;
  }
  return tbl._costLay={key, pts, cutX};
}
function layoutLattice(){
  const sp=latticeSpec(), P=sp.proj, cells=cellList(sp.dims), N=cells.length;
  const cv=$('latticeCanvas'), W=cv.clientWidth||600, H=cv.clientHeight||420;
  const pad=26, pts=new Float64Array(N*2);
  const L={sp, set:sp.set, cells, pts, W, H, handles:[], tags:[], lines:[], cut:null, mode:'linear', sc:1, ox:0, oy:0, org:null};

  if(P.preset==='cost'){
    L.mode='cost';
    const ri=rowAxisOf(sp), ra=sp.axes[ri], padL=44, padR=18, padT=22, padB=24;
    const band=(H-padT-padB)/ra.n, lay=costLayout(sp, cells, ri, ra, {W,H,padL,padR,padT,band});
    pts.set(lay.pts);
    for(let v=0; v<ra.n; v++){
      const y=padT+(ra.n-1-v)*band;
      L.lines.push([padL-6,y+band,W-padR,y+band,0.07]);
      L.tags.push({x:padL-10, y:y+band/2, text:ra.label+' '+ra.tick(v), right:true});
    }
    if(lay.cutX!=null){
      L.cut={x: lay.cutX, y0:padT-8, y1:H-padB+4,
             label:'λ '+fmt2(sp.set==='chord'?STATE.lamC:STATE.lamV)};
    }
    L.tags.push({x:padL, y:H-9, text:'cheapest', left:true}, {x:W-padR, y:H-9, text:'dearest', right:true});
    return LAYOUT=L;
  }

  const raw=new Float64Array(N*2);
  let zero=[0,0], zeros=[];
  if(P.preset==='cycle' && sp.set==='chord'){
    L.mode='polar';
    for(let f=0;f<N;f++){ const p=polarOf(cells[f]); raw[f*2]=p[0]; raw[f*2+1]=p[1]; }
    for(let t=0;t<5;t++){
      const r=POLAR.R0+t*POLAR.DR; let prev=null;
      for(let k=0;k<=72;k++){ const th=k/72*Math.PI*2, q=[Math.cos(th)*r, Math.sin(th)*r]; if(prev) L.lines.push([prev[0],prev[1],q[0],q[1],0.06,true]); prev=q; }
    }
    // a spoke between wedges and a number at the outer edge: every one in twelve divisions, every few in a finer one
    const every=Math.max(1,Math.ceil(NN/16));
    for(let k=0;k<NN;k+=every){
      const th=-Math.PI/2+k*POLAR.WEDGE-POLAR.WEDGE/2, r0=POLAR.R0-14, r1=POLAR.R0+4*POLAR.DR+14;
      L.lines.push([Math.cos(th)*r0,Math.sin(th)*r0,Math.cos(th)*r1,Math.sin(th)*r1,0.05,true]);
    }
    for(let d=0; d<NN; d++){
      const pos=fifthsPos(d); if(pos%every!==0 && d!==SP.g && d!==0) continue;
      const th=-Math.PI/2+pos*POLAR.WEDGE, r=POLAR.R0+4*POLAR.DR+24;
      L.tags.push({x:Math.cos(th)*r, y:Math.sin(th)*r, text:String(d), raw:true});
    }
  } else {
    for(let i=0;i<sp.axes.length;i++){ const v=axisVec(P,sp.axes[i],0); zeros.push(v); zero[0]+=v[0]; zero[1]+=v[1]; }
    for(let f=0;f<N;f++){
      let x=0,y=0;
      for(let i=0;i<sp.axes.length;i++){ const v=axisVec(P,sp.axes[i],cells[f][i]); x+=v[0]; y+=v[1]; }
      raw[f*2]=x; raw[f*2+1]=y;
    }
  }
  // fit the raw layout into the canvas, or hold the frame still while a handle is being dragged
  let ox, oy, sc;
  if(FRAME && L.mode==='linear'){ ox=FRAME.ox; oy=FRAME.oy; sc=FRAME.sc; }
  else {
    let minX=1e9,maxX=-1e9,minY=1e9,maxY=-1e9;
    for(let f=0;f<N;f++){ const x=raw[f*2], y=raw[f*2+1]; if(x<minX)minX=x; if(x>maxX)maxX=x; if(y<minY)minY=y; if(y>maxY)maxY=y; }
    sc=Math.min((W-2*pad)/Math.max(1e-6,maxX-minX), (H-2*pad)/Math.max(1e-6,maxY-minY));
    ox=pad+(W-2*pad-(maxX-minX)*sc)/2-minX*sc;
    oy=pad+(H-2*pad-(maxY-minY)*sc)/2-minY*sc;
  }
  for(let f=0;f<N;f++){ pts[f*2]=ox+raw[f*2]*sc; pts[f*2+1]=oy+raw[f*2+1]*sc; }
  L.sc=sc; L.ox=ox; L.oy=oy;
  for(const l of L.lines){ const a=l[0],b=l[1],c=l[2],d=l[3]; l[0]=ox+a*sc; l[1]=oy+b*sc; l[2]=ox+c*sc; l[3]=oy+d*sc; }
  for(const t of L.tags) if(t.raw){ t.x=ox+t.x*sc; t.y=oy+t.y*sc; }
  if(L.mode==='linear'){
    L.org=[ox+zero[0]*sc, oy+zero[1]*sc];
    L.handles=sp.axes.map((a,i)=>{
      const b=P.basis[a.key], cyc=!!P.cyclic[a.key], n=cyc?0:Math.max(1,a.n-1);
      return {key:a.key, label:a.label+(cyc?'↻':''), what:a.what, cyclic:cyc, n, i,
        x:ox+(zero[0]+b[0]*n)*sc, y:oy+(zero[1]+b[1]*n)*sc,
        zeroX:zero[0]-(cyc?zeros[i][0]:0), zeroY:zero[1]-(cyc?zeros[i][1]:0)};
    });
  }
  return LAYOUT=L;
}

/* ---- drawing ----------------------------------------------------------- */
function latCellClass(sp, f){
  const legal=sp.tbl.t[f]===1, reach=sp.reach ? sp.reach[f]===1 : true;
  return {legal, reach};
}
function drawLattice(){
  if(!GL_LAT) return;
  const L=layoutLattice(), sp=L.sp, cells=L.cells;
  if(TWEEN && TWEEN.set===L.set && TWEEN.from.length===L.pts.length){
    const t=Math.min(1,(performance.now()-TWEEN.t0)/TWEEN.dur), e=1-Math.pow(1-t,3);
    for(let k=0;k<L.pts.length;k++) L.pts[k]=TWEEN.from[k]+(L.pts[k]-TWEEN.from[k])*e;
    if(t>=1) TWEEN=null; else requestAnimationFrame(drawLattice);
  } else TWEEN=null;
  const tweening=!!TWEEN, pts=L.pts;
  if(!GL_LAT.begin()) return;
  const P=GL_LAT, ink=THEME.ink, dark=THEME.dark;

  // guides and mesh
  const gridCol=rgba(THEME.grid, dark?0.30:0.30);
  if(!tweening){
    for(const l of L.lines) P.line(l[0],l[1],l[2],l[3],1, rgba(THEME.grid,l[4]*(dark?2.6:2.6)));
    if(L.mode==='linear'){
      const mag=sp.axes.map(ax=>{ const b=sp.proj.basis[ax.key]; return Math.hypot(b[0],b[1])*(sp.proj.cyclic[ax.key]?1:ax.n); });
      const rank=sp.axes.map((a,i)=>i).sort((x,y)=>mag[y]-mag[x]).slice(0,2);
      for(const ai of rank){
        const st=sp.strides[ai], n=sp.axes[ai].n;
        for(let f=0; f<cells.length; f++){
          if(cells[f][ai]>=n-1) continue;
          const g=f+st;
          P.line(pts[f*2],pts[f*2+1],pts[g*2],pts[g*2+1],1,gridCol);
        }
      }
    }
  }
  if(L.cut){
    P.dash(L.cut.x,L.cut.y0,L.cut.x,L.cut.y1,1.5,rgba(ink,0.7),6);
  }

  // cells
  const legalCol=rgba(THEME.permit, 0.92), notCol=rgba(THEME.forbid, dark?0.62:0.58);
  const faintLegal=rgba(THEME.permit, 0.30), faintNot=rgba(THEME.dim, 0.30);
  for(let f=0; f<cells.length; f++){
    const k=latCellClass(sp,f), x=pts[f*2], y=pts[f*2+1];
    if(k.reach){ if(k.legal) P.disc(x,y,3.7,legalCol); else P.disc(x,y,1.9,notCol); }
    else { if(k.legal) P.disc(x,y,2.1,faintLegal); else P.disc(x,y,1.3,faintNot); }
  }
  // a flip would change the piece
  if(sp.dep) for(const f of sp.dep) P.disc(pts[f*2],pts[f*2+1],6.2, rgba(THEME.dim,0.75), 0.66);
  // cells the piece used, and the order it used them in
  if(sp.used) for(const f of sp.used) P.disc(pts[f*2],pts[f*2+1],8, rgba(ink,0.9), 0.74);
  if(sp.seq.length>1){
    for(let i=1;i<sp.seq.length;i++){
      const p=sp.seq[i-1], q=sp.seq[i]; if(p===q) continue;
      P.line(pts[p*2],pts[p*2+1],pts[q*2],pts[q*2+1],1.4,rgba(ink,0.38));
    }
    const s0=sp.seq[0]; P.disc(pts[s0*2],pts[s0*2+1],2.4,rgba(ink,0.95));
  }
  // cells you flipped
  for(const k in sp.flips){
    if(sp.flips[k]==null) continue;
    const c=k.split(',').map(Number); let f=0; for(let i=0;i<c.length;i++) f+=c[i]*sp.strides[i];
    P.disc(pts[f*2],pts[f*2+1],10.5, rgba(THEME.hand,0.96), 0.78);
  }
  // a road not taken, through the same space
  const gh=ghostCells();
  if(gh && gh.length>0){
    for(let i=1;i<gh.length;i++){
      const p=gh[i-1], q=gh[i]; if(p===q) continue;
      P.dash(pts[p*2],pts[p*2+1],pts[q*2],pts[q*2+1],1.6,rgba(ink,0.8),7);
    }
    for(const f of gh) P.disc(pts[f*2],pts[f*2+1],5.4, rgba(THEME.dim,0.9), 0.62);
  }
  // what the rule is weighing at the step picked under "At this step": a thin ring for each move, wider where it is likelier, the one played heavier
  if(INSPECT.halo && INSPECT.halo.set===L.set && !tweening){
    for(const it of INSPECT.halo.items){
      if(it.f==null || it.f<0 || it.f>=cells.length) continue;
      const r=4.5+11*Math.sqrt(Math.min(1,Math.max(0,it.p))), w=it.taken?2.2:1.2;
      P.disc(pts[it.f*2],pts[it.f*2+1], r, rgba(it.taken?ink:THEME.dim, it.taken?0.95:0.8), Math.max(0,1-w/r));
    }
  }
  // pointer and cross-plate highlights
  if(HOVER.cell!=null) P.disc(pts[HOVER.cell*2],pts[HOVER.cell*2+1],12, rgba(ink,0.95), 0.84);
  if(HOVER.link && HOVER.link.set===L.set) P.disc(pts[HOVER.link.f*2],pts[HOVER.link.f*2+1],12, rgba(ink,0.95), 0.84);
  // the projection frame
  if(L.mode==='linear' && !tweening){
    for(const h of L.handles) P.line(L.org[0],L.org[1],h.x,h.y,1.1,rgba(ink, DRAG.axis===h.key?0.85:0.32));
    if(!L.handles.some(h=>h.cyclic)) P.disc(L.org[0],L.org[1],2.6,rgba(ink,0.7));
  }
  P.end();
  syncLatticeLabels(L, tweening);
}
function ghostCells(){
  const c=STATE.composed; if(!c||!STATE.show.ghosts) return null;
  const b=HOVER.branch; if(!b || STATE.lattice.set!=='chord') return null;
  return b.cells.map(x=>cIdx(x.d,x.tau,x.rho,x.eta));
}

/* ---- DOM labels and handles over the canvas ------------------------------ */
let LABEL_KEY='';
function syncLatticeLabels(L, tweening){
  const host=$('latticeLabels'); if(!host) return;
  const hs=L.handles, show=!tweening;
  // handles persist between frames (so a drag is not interrupted by a rebuild)
  const wantH = show ? hs : [];
  const have=[...host.querySelectorAll('.handle')];
  if(have.length!==wantH.length || have.some((e,i)=>e.dataset.key!==wantH[i].key || e.dataset.set!==L.set)){
    have.forEach(e=>e.remove());
    for(const h of wantH){
      const b=mk('button','handle'); b.type='button'; b.dataset.key=h.key; b.dataset.set=L.set;
      b.setAttribute('aria-label','Projection handle for axis '+h.key+'. Drag, or use the arrow keys.');
      b.appendChild(mk('span',null,h.label));
      host.appendChild(b);
    }
  }
  host.querySelectorAll('.handle').forEach((e,i)=>{
    const h=wantH[i]; if(!h) return;
    e.style.left=h.x+'px'; e.style.top=h.y+'px';
    e.classList.toggle('drag', DRAG.axis===h.key);
    e.firstChild.textContent=h.label;
  });
  const key=[L.set, L.mode, L.W, L.H, sp_key(L), show].join('|');
  if(key!==LABEL_KEY){
    LABEL_KEY=key;
    host.querySelectorAll('.tag').forEach(e=>e.remove());
    if(show) for(const t of L.tags){
      const d=mk('div','tag',t.text);
      d.style.left=t.x+'px'; d.style.top=t.y+'px';
      if(t.right) d.style.transform='translate(-100%,-50%)';
      else if(t.left) d.style.transform='translate(0,-50%)';
      d.style.color=THEME.str.dim;
      host.appendChild(d);
    }
    if(show && L.cut){
      const d=mk('div','tag',L.cut.label); d.style.left=L.cut.x+'px'; d.style.top=(L.cut.y0-6)+'px'; d.style.fontWeight='500';
      host.appendChild(d);
    }
  }
}
function sp_key(L){ return L.sp.proj.preset+':'+(L.sp.proj.rows||'')+':'+(L.cut?Math.round(L.cut.x):''); }

/* ---- picking, readout --------------------------------------------------- */
function latticePick(mx,my){
  if(!LAYOUT) return null;
  let best=-1, bd=14;
  const pts=LAYOUT.pts;
  for(let f=0; f<pts.length/2; f++){
    const d=Math.hypot(mx-pts[f*2], my-pts[f*2+1]);
    if(d<bd){ bd=d; best=f; }
  }
  return best>=0 ? best : null;
}
function chordCellExamples(f, limit){
  const [d,tau,rho]=cellList(CHORD_DIMS)[f], V=baseVocab(), out=[];
  for(const a of V) for(const b of V){
    if(rootFall(a.rootPc,b.rootPc)===d && tensionBucket(b.tensionVal-STATE.tension)===tau && b.ring===rho){
      out.push(a.roman+'→'+b.roman); if(out.length>=limit) return out;
    }
  }
  return out;
}
function latticeReadout(f){
  const el=$('latticeRead'), sp=latticeSpec();
  if(f==null){
    const c=STATE.composed, size=sp.tbl.size;
    if(sp.set==='chord' && c && c.reach){
      let r=0, rl=0; for(let i=0;i<size;i++) if(c.reach[i]){ r++; if(sp.tbl.t[i]) rl++; }
      el.innerHTML='This vocabulary can ask <b>'+r+'</b> of the '+size+' cells. <b>'+rl+'</b> of those are legal at λ '+fmt2(STATE.lamC)
        +(c.dep ? '; flipping any one of <b>'+c.dep.changed+'</b> changes the opening chords.' : '.')
        +'<br>Hover a cell to read it. The other '+(size-r)+' are drawn faint: flipping them does nothing.';
    } else el.innerHTML='Hover a cell to read it. Click to flip it by hand.<br>&nbsp;';
    return;
  }
  const c=cellList(sp.dims)[f], maxCost=Math.max.apply(null, Array.from(sp.tbl.costs));
  const parts=sp.axes.map((a,i)=>a.label+' <b>'+a.tick(c[i])+'</b>');
  const legal=sp.tbl.t[f], flipped=sp.flips[c.join(',')]!=null, n=sp.counts.get(f)||0;
  const k=latCellClass(sp,f);
  let l2;
  if(sp.set==='chord'){
    if(!k.reach) l2='no move in this vocabulary lands here, so the rule never asks about this cell';
    else { const ex=chordCellExamples(f,3); l2='asked by moves like '+(ex.length?ex.join(', '):'(depends on momentum)'); }
  } else l2='';
  el.innerHTML = parts.join('  ')+'   ·   cost <b>'+(sp.tbl.costs[f]/Math.max(1e-9,maxCost)).toFixed(2)+'</b>   ·   <b>'+(legal?'legal':'not legal')+'</b>'
    + (flipped?'   ·   <span class="hand">flipped by you</span>':'')
    + '<br>'+(l2?l2+'   ·   ':'')
    + (n?'used <b>'+n+'×</b> by this piece':'not used by this piece')
    + (sp.dep && sp.dep.has(f)?'   ·   <b>flipping it changes the piece</b>':'');
}

/* ---- legend and axis modes ------------------------------------------------ */
function renderLatKey(){
  const el=$('latKey'); if(!el) return;
  const chord=STATE.lattice.set==='chord';
  el.textContent='';
  const add=(cls,text,color,extra)=>{
    const s=mk('span'); const i=mk('i','sw '+cls); if(color) i.style.background=color; s.appendChild(i); s.appendChild(document.createTextNode(text)); el.appendChild(s);
  };
  add('dot','legal',THEME.str.permit);
  add('dot small','not legal',THEME.str.forbid);
  if(chord){          // a cell the piece cannot ask about is drawn faint, whether or not it is legal
    const sp=mk('span'), i1=mk('i','sw dot small'), i2=mk('i','sw dot small');
    i1.style.background=THEME.str.permit; i1.style.opacity='0.4'; i2.style.background=THEME.str.faint;
    sp.append(i1,i2,document.createTextNode('never asked')); el.appendChild(sp);
  }
  add('ring','used by the piece');
  if(chord) add('ring dimmer','a flip would change the piece');
  add('ring hand','flipped by you');
  add('ring thin','the moves the rule weighs at the step picked above');
  add('dash','a road not taken');
}
function renderAxisModes(){
  const el=$('axisModes'); if(!el) return;
  const set=STATE.lattice.set, P=PROJ[set], axes=set==='chord'?CHORD_AXES:VOICE_AXES;
  el.textContent='';
  const lab=mk('span','aside'); lab.style.marginRight='6px';
  if(P.preset==='cost'){
    lab.textContent='one row per value of:'; el.appendChild(lab);
    const ri=rowAxisOf({proj:P, axes});
    axes.forEach((a,i)=>{
      const b=mk('button','tiny',a.label); b.type='button'; b.setAttribute('aria-pressed', i===ri?'true':'false'); b.title=a.what;
      b.style.marginRight='4px';
      b.addEventListener('click', ()=>{ P.rows=a.key; renderAxisModes(); drawLattice(); });
      el.appendChild(b);
    });
    return;
  }
  if(P.preset==='cycle'){
    lab.textContent='angle: root fall d around the circle of fifths · radius: tension · the fine offsets inside a wedge are the kind of chord and the momentum'; el.appendChild(lab); return;
  }
  lab.textContent='wrap an axis into a ring:'; el.appendChild(lab);
  for(const a of axes){
    const b=mk('button','tiny',a.label); b.type='button'; b.style.marginRight='4px';
    b.setAttribute('aria-pressed', P.cyclic[a.key]?'true':'false');
    b.title=a.what+(P.cyclic[a.key]?' — wrapped into a ring':' — laid out straight');
    b.addEventListener('click', ()=> toggleWrap(a));
    el.appendChild(b);
  }
}
function toggleWrap(a){
  const set=STATE.lattice.set, P=PROJ[set], b=P.basis[a.key], len=Math.hypot(b[0],b[1])||1;
  const from=LAYOUT && !REDUCED_MOTION() ? LAYOUT.pts.slice() : null;
  // keep the total length of the axis: a straight run of n steps becomes a ring of that circumference
  const k = P.cyclic[a.key] ? (2*Math.PI/a.n) : (a.n/(2*Math.PI));
  P.cyclic[a.key]=!P.cyclic[a.key];
  P.basis[a.key]=[b[0]*k, b[1]*k];
  if(len*k<2) P.basis[a.key]=[40,0];
  P.preset = P.preset==='grid'||P.preset==='hyper' ? P.preset : 'hyper';
  if(from) TWEEN={from, t0:performance.now(), dur:420, set};
  renderAxisModes(); drawLattice();
}

/* ---- projections --------------------------------------------------------- */
function updateProjButtons(){
  const set=STATE.lattice.set, P=PROJ[set];
  for(const [id,key] of [['btnProjGrid','grid'],['btnProjCycle','cycle'],['btnProjHyper','hyper'],['btnProjPot','cost']]){
    const b=$(id); if(!b) continue;
    b.setAttribute('aria-pressed', P.preset===key?'true':'false');
  }
  const cyc=$('btnProjCycle'); if(cyc){ cyc.disabled = set!=='chord'; cyc.title = set==='chord' ? '' : 'Only the chord table has a root-fall axis to wrap'; }
  $('btnSetChord').setAttribute('aria-pressed', set==='chord'?'true':'false');
  $('btnSetVoice').setAttribute('aria-pressed', set==='voice'?'true':'false');
}
function setPreset(which, animate){
  const set=STATE.lattice.set, P=PROJ[set];
  if(which==='cycle' && set!=='chord') return;
  const from=(animate!==false && LAYOUT && LAYOUT.set===set && !REDUCED_MOTION()) ? LAYOUT.pts.slice() : null;
  P.preset=which; P.cyclic={};
  if(which==='grid'||which==='hyper') P.basis=JSON.parse(JSON.stringify(PROJ_BASES[set][which]));
  FRAME=null;
  if(from) TWEEN={from, t0:performance.now(), dur:460, set};
  updateProjButtons(); renderAxisModes(); renderLatKey(); drawLattice();
}
function setLatticeSet(set){
  if(STATE.lattice.set===set) return;
  STATE.lattice.set=set; TWEEN=null; FRAME=null; HOVER.cell=null; LABEL_KEY='';
  updateProjButtons(); renderAxisModes(); renderLatKey(); latticeReadout(null); computeHalo(); drawLattice();
}

// dragging a handle: the frame is held still so the handle follows the pointer exactly;
// letting go refits the picture, with a short glide
function handleDragStart(h){
  if(!LAYOUT) return;
  FRAME={ox:LAYOUT.ox, oy:LAYOUT.oy, sc:LAYOUT.sc};
  DRAG.axis=h.key;
}
function handleDragMove(h, mx, my){
  const P=PROJ[STATE.lattice.set];
  const rx=(mx-FRAME.ox)/FRAME.sc, ry=(my-FRAME.oy)/FRAME.sc;
  const n=h.cyclic?1:h.n;
  P.basis[h.key]=[(rx-h.zeroX)/n, (ry-h.zeroY)/n];
  drawLattice();
}
function handleDragEnd(){
  if(!DRAG.axis) return;
  const from = LAYOUT && !REDUCED_MOTION() ? LAYOUT.pts.slice() : null;
  DRAG.axis=null; FRAME=null;
  const P=PROJ[STATE.lattice.set]; if(P.preset==='cycle'||P.preset==='cost') P.preset='hyper';
  if(from) TWEEN={from, t0:performance.now(), dur:320, set:STATE.lattice.set};
  updateProjButtons(); renderAxisModes(); drawLattice();
}
function handleNudge(h, dx, dy){
  const P=PROJ[STATE.lattice.set], L=LAYOUT; if(!L) return;
  const n=h.cyclic?1:h.n, b=P.basis[h.key];
  P.basis[h.key]=[b[0]+dx/(L.sc*n), b[1]+dy/(L.sc*n)];
  if(P.preset==='cycle'||P.preset==='cost') P.preset='hyper';
  updateProjButtons(); drawLattice();
}
