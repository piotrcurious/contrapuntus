/* =====================================================================
   0 · HOW A LEGAL MOVE IS CHOSEN
   ---------------------------------------------------------------------
   The rule says which moves are allowed. Something still has to pick one of
   them, and in the first two versions that was a fixed sort: anything but
   standing still first; then the cost ranking read from one end (the "take");
   then the smallest voice-leading distance, counted in steps of the division;
   then the lowest root number or pitch. Measured, that sort had four faults:

     - it was one answer. Whatever the rule, the seed was the only source of
       variety, so every piece was a loop of three to seven chords, and the same
       loop in every division (I IV ii V in the strongest take, in 12 and in 53);
     - the melody took the nearest legal note, which is a trill (E F E F E F...),
       or, in the bold take, the dearest, which is a leap of more than a fourth
       in two moves out of three;
     - its last two keys, "lowest root number" and "lowest pitch", are artefacts
       of numbering. They mean something in no division, and in 53 they decide
       the move whenever the cost ties, which is often;
     - a motion under 45 cents was a repeat and one over a step: a constant that
       happens to fall between the quarter tone of 24 and the diesis of 31.

   Here a choice is made in three layers, each of them a handle:

     UTILITY  every candidate gets a number from a few features that mean the same
              in every division, because they are measured in cents, in fusion and in
              roughness (09-psy.js) and never in steps or pitch classes: how much the
              rule favours the cell it falls in, how far the voices have to move
              (chords) or the melodic shape it makes (notes), how well it fuses with
              the others. The weights are the composer's.
     VARIETY  with variety v the candidate chosen is the one with the highest
              utility + T(v) * G, where G is Gumbel noise. That is exactly a draw
              from the softmax of the utilities at temperature T (the Luce choice
              rule), so "variety" is a temperature with a plain reading: every
              candidate has a probability, and the inspector can show it. The
              noise is not random: it is a hash of (seed, situation, candidate).
              For the chords the situation is the automaton's state, so the map
              from state to next state is still a function, still has cycles and
              basins, and the analysis plates stay exact; the seed picks which
              function. For the notes it is the voice and the step, so the
              same piece comes back from the same code and a repeat of the chords
              is not a repeat of the melody.
     TIE      candidates that are still level are ordered by the hash, never by
              a number they happen to carry.

   "Classic" is the fixed sort of the first two versions, kept so that a state
   code written then plays the same piece now.
   ===================================================================== */

/* ---- the hash: every pseudo-random number in the engine comes from here ------------------ */
function mix32(h, x){
  h = (h ^ x) >>> 0;
  h = Math.imul(h ^ (h >>> 16), 0x85ebca6b);
  h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
  return (h ^ (h >>> 16)) >>> 0;
}
function hash4(a, b, c, d){ return mix32(mix32(mix32(mix32(0x9e3779b9, a|0), b|0), c|0), d|0); }
function strHash(s){ let h=0x811c9dc5; for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,0x01000193); } return h>>>0; }
function unitOf(h){ return (h+0.5)/4294967296; }                  // strictly inside (0,1)
function gumbelOf(h){ return -Math.log(-Math.log(unitOf(h))); }

/* ---- the policy -------------------------------------------------------------------------------- */
const CHOICE_LIMITS = { w:[-1,1.5], variety:[0,1], seed:[0,999999], micro:[10,120], leap:[150,500] };
// Weights, by what they mean. Chords: favour = how much the rule's own cost ranking counts (negative reads it from the
// dear end), smooth = how little the voices have to move. Notes: favour as for chords; step = a melodic step is better than a
// repeat or a leap; shape = no trills, a leap answered by a step the other way, no hugging the edge of the register;
// harm = chord tone on a structural note, and fusing with the voices that sound with it; contrary = moving against them.
const CHOICE_PRESETS = {
  balanced:{ label:'Balanced', chord:{favour:0.55, smooth:0.55}, voice:{favour:0.50, step:1.00, shape:0.80, harm:0.80, contrary:0.30} },
  smooth:  { label:'Smooth',   chord:{favour:0.15, smooth:1.00}, voice:{favour:0.20, step:1.40, shape:0.60, harm:0.70, contrary:0.10} },
  strong:  { label:'Strong',   chord:{favour:1.00, smooth:0.15}, voice:{favour:1.00, step:0.70, shape:0.60, harm:0.80, contrary:0.30} },
  bold:    { label:'Bold',     chord:{favour:-0.80, smooth:0.15}, voice:{favour:-0.50, step:0.30, shape:0.40, harm:0.50, contrary:0.60} },
};
const CHOICE_ORDER = ['balanced','smooth','strong','bold'];
const CHORD_WEIGHTS = ['favour','smooth'], VOICE_WEIGHTS = ['favour','step','shape','harm','contrary'];
function defaultChoice(){
  const p=CHOICE_PRESETS.balanced;
  return { mode:'scored', preset:'balanced',
    chord:Object.assign({still:true}, p.chord), voice:Object.assign({root:true}, p.voice),
    variety:0.30, seed:1, micro:PSY_MICRO_CENTS, leap:PSY_LEAP_CENTS };
}
// the older fixed sort, for a state written before there was a choice
function classicChoice(){
  const c=defaultChoice(); c.mode='classic'; c.preset='classic'; c.variety=0; return c;
}

// Variety is a temperature, and it is measured against the weights: the same variety means the same thing whether the composer
// has set the weights to a half or to one and a quarter. Calibrated on real pieces (the median chord state has ten legal
// moves, the median note nine): at variety 0.3 the best move is played about three times in five, at 1 nearly every legal
// move is as likely as any other, and below 0.1 the best move is played nearly always.
const TEMP_CHORD = 0.70, TEMP_NOTE = 0.78;
function tempOf(variety, scale, wsum){ return variety<=0 ? 0 : scale*variety*variety*Math.max(wsum, 0.25); }
function absSum(o, keys){ let s=0; for(const k of keys) s+=Math.abs(o[k]); return s; }

// A compiled, numeric view of STATE.choice: the engine never reads the state object in a loop.
function choicePlan(ch){
  ch = ch || STATE.choice;
  const classic = ch.mode==='classic';
  return {
    mode:ch.mode, take:STATE.take,
    wF:ch.chord.favour, wS:ch.chord.smooth, still:ch.chord.still!==false,
    Tc: classic?0:tempOf(ch.variety, TEMP_CHORD, absSum(ch.chord, CHORD_WEIGHTS)), Tv: classic?0:tempOf(ch.variety, TEMP_NOTE, absSum(ch.voice, VOICE_WEIGHTS)),
    seed:ch.seed|0, micro:ch.micro, leap:ch.leap,
    vw:ch.voice, root:ch.voice.root!==false,
  };
}
// everything that decides the chord automaton, as text, for the cache keys of the analyses
function chordChoiceSig(ch){
  ch = ch || STATE.choice;
  if(ch.mode==='classic') return 'classic:'+STATE.take;
  return ['scored', ch.chord.favour.toFixed(3), ch.chord.smooth.toFixed(3), ch.chord.still!==false?1:0, ch.variety.toFixed(3), ch.seed|0].join(':');
}
function choiceSig(ch){
  ch = ch || STATE.choice;
  return chordChoiceSig(ch)+'|'+[ch.mode==='classic'?'':VOICE_WEIGHTS.map(k=>ch.voice[k].toFixed(3)).join(','), ch.voice.root!==false?1:0, ch.micro, ch.leap].join('|');
}
// a short name for the status line and the file name
function choiceLabel(ch){
  ch = ch || STATE.choice;
  if(ch.mode==='classic') return 'classic '+STATE.take;
  const name = ch.preset==='custom' ? 'custom' : (CHOICE_PRESETS[ch.preset]||CHOICE_PRESETS.balanced).label.toLowerCase();
  return name+(ch.variety>0 ? ' · variety '+ch.variety.toFixed(2)+' · seed '+(ch.seed|0) : '');
}
// the weights of a preset, copied into a choice (the flags and the thresholds are left as they are)
function applyPreset(ch, name){
  const p=CHOICE_PRESETS[name]; if(!p) return false;
  ch.mode='scored'; ch.preset=name;
  for(const k of CHORD_WEIGHTS) ch.chord[k]=p.chord[k];
  for(const k of VOICE_WEIGHTS) ch.voice[k]=p.voice[k];
  return true;
}
// does the choice still match the preset it says it came from? (the weights were edited if not)
function presetMatches(ch, name){
  const p=CHOICE_PRESETS[name]; if(!p) return false;
  return CHORD_WEIGHTS.every(k=>Math.abs(ch.chord[k]-p.chord[k])<1e-9) && VOICE_WEIGHTS.every(k=>Math.abs(ch.voice[k]-p.voice[k])<1e-9);
}

/* ---- features of a note, in cents -------------------------------------------------------------- */
// How good a melodic motion of `a` cents is as a motion. A repeat is allowed but not the best; a motion shorter than `micro` is the
// same note a little out of tune; a step is best; and the preference falls away smoothly as the leap grows.
const PROX_KNOTS = [[0,0.80],[100,1],[220,1],[320,0.78],[420,0.56],[520,0.38],[720,0.20],[920,0.10],[1250,0.05],[2400,0]];
function proxOf(a, micro){
  if(a===0) return 0.5;
  if(a<micro) return 0.2;
  const K=PROX_KNOTS;
  for(let i=1;i<K.length;i++) if(a<=K[i][0]){ const [x0,y0]=K[i-1], [x1,y1]=K[i]; return y0+(y1-y0)*(a-x0)/(x1-x0); }
  return 0;
}
// the melodic shape a candidate makes with the notes before it
function shapeOf(m, ctx, plan){
  const f=1200/NN; let s=0;
  const prev=ctx.prevPitch, reg=ctx.reg;
  let e=0;                                                                                                       // how far out in its register, 0 at the middle, 1 at the edge
  if(reg){ const c=(reg.lo+reg.hi)/2, h=Math.max(1,(reg.hi-reg.lo)/2); e=Math.abs(m-c)/h; }
  if(prev!=null){
    const d=m-prev, a=Math.abs(d)*f, sg=d>0?1:d<0?-1:0;
    if(ctx.prev2Pitch!=null && ctx.prev2Pitch!==prev && Math.abs(m-ctx.prev2Pitch)*f<plan.micro) s-=1;       // back to where it just was: a trill
    if(ctx.lastLeap){
      if(sg!==0 && sg===-ctx.lastDir && a<=plan.leap) s+=0.8;                                                 // a leap is answered by a step the other way
      else if(sg===ctx.lastDir && a>plan.leap) s-=0.8;                                                        // and not by another leap the same way
    }
    if(ctx.run>=4 && sg===ctx.lastDir) s-=0.4;                                                                // a long run turns
  } else if(reg) s+=0.8*(1-Math.min(1,e));                                                                    // a line begins near the middle of its register
  if(reg) s-=Math.max(0,(e-0.55)/0.45);                                                                       // and does not hug the edge of it
  return s<-1.5?-1.5:s>1?1:s;
}
// how well a note suits its place in the harmony: chord tone on a structural note, and how well it fuses with the voices it sounds with
function harmOf(m, cell, ctx){
  const tone = ctx.structural ? [0,0.35,1][cell.phi] : [0.1,0.8,0.7][cell.phi];
  let fuse=0.5, n=0, s=0;
  for(const o of ctx.others){
    if(o.pitch==null) continue;
    const d=m>o.pitch?m-o.pitch:o.pitch-m;
    let q=CONSONANCE_BY_IC[ic(d)];
    if(d){ const r=SP.rough(m<o.pitch?m:o.pitch, d); q-=0.5*Math.min(1,Math.max(0,(r-0.25)/0.5)); }
    s+=q>0?q:0; n++;
  }
  if(n) fuse=s/n;
  return 0.55*tone+0.45*fuse;
}
const CONTRARY_OF = [0,0.5,1];                    // gamma: moves with the others, they hold, moves against them
