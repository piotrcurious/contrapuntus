/* =====================================================================
   5 · WHAT THE RULE THOUGHT AT ONE STEP
   ---------------------------------------------------------------------
   The rule table says which moves are allowed and the choice policy
   (10-choice.js) says which of them is played. Both are decided in a place no
   one can see into: the engine only keeps the winner. Here the same numbers
   are laid out for one step, for the inspector to draw:

     every candidate the voice or the chord could have taken, whether the rule
     allows it, the cell of the rule table it falls in, what each feature of
     the policy says about it, and the chance it has of being drawn.

   That chance is exact. A draw is the candidate with the highest
   utility + T * Gumbel noise, which is a draw from softmax(utility / T), so a
   probability here is the share of seeds that would play that move from this
   very situation (the test suite checks it by drawing from thousands of seeds).
   Two things take a candidate out of the draw before it starts: the hard
   preferences the engine keeps ahead of the score (the chord that keeps moving;
   the bass that takes the root), and the moves the composer has ruled out.
   ===================================================================== */

/* ---- probabilities --------------------------------------------------------------------------- */
// The chance each utility has of being the one drawn at temperature T (0: the greatest takes everything; the first of equals).
function luce(us, T){
  const n=us.length, p=new Array(n);
  if(!n) return p;
  let mx=-Infinity, at=0; for(let i=0;i<n;i++) if(us[i]>mx){ mx=us[i]; at=i; }
  if(!(T>0)){ for(let i=0;i<n;i++) p[i]=i===at?1:0; return p; }
  let S=0; for(let i=0;i<n;i++){ p[i]=Math.exp((us[i]-mx)/T); S+=p[i]; }
  for(let i=0;i<n;i++) p[i]/=S;
  return p;
}

/* ---- words ------------------------------------------------------------------------------------ */
const VOICE_WORDS = {
  kappa:['agrees with neither of the others','agrees with one','agrees with both'],
  mu:['a leap down','a step down','repeats','a step up','a leap up'],
  phi:['chromatic','in the scale','a chord tone'],
  sigma:['structural','passing'],
  gamma:['moves with the others','others hold','moves against the others'],
};
function voiceCellWords(f){
  const c=cellList(VOICE_DIMS)[f];
  return VOICE_AXES.map((a,i)=>VOICE_WORDS[a.key][c[i]]).join(' · ');
}
const RATIO_NAMES = {
  '3/2':'fifth','4/3':'fourth','5/4':'major third','8/5':'minor sixth','6/5':'minor third','5/3':'major sixth',
  '7/4':'harmonic seventh','8/7':'septimal tone','7/6':'subminor third','12/7':'subminor sixth','9/7':'septimal major third','14/9':'septimal minor sixth',
  '11/9':'neutral third','18/11':'neutral sixth','11/8':'undecimal fourth','16/11':'undecimal fifth','7/5':'septimal tritone','10/7':'septimal tritone',
  '9/8':'whole tone','16/9':'minor seventh','10/9':'minor tone','9/5':'minor seventh','45/32':'tritone','64/45':'tritone','16/15':'semitone','15/8':'major seventh',
};
// an interval of `steps` steps of the division, in words: the simple interval it stands for if it is near one, always its size in cents
function intervalWords(steps){
  const c=((steps%NN)+NN)%NN*1200/NN;
  if(c===0) return 'no motion (0¢)';
  const n=psyNearest(c), name=RATIO_NAMES[n.ratio];
  const cents=Math.round(c)+'¢';
  if(name && Math.abs(n.err)<=25) return 'about a '+name+' ('+cents+(Math.abs(n.err)>=1?', '+(n.err>0?'+':'−')+Math.abs(n.err).toFixed(0)+' off':'')+')';
  return cents;
}
const CHORD_WORDS = {
  tau:['much calmer than the aim','calmer than the aim','at the aim','tenser than the aim','much tenser than the aim'],
  rho:['a diatonic chord','an applied dominant','an applied leading-tone chord','a colour chord'],
  eta:['arrives with weak momentum','arrives with neutral momentum','arrives with strong momentum'],
};
function chordCellWords(cell){
  return ['root falls '+intervalWords(cell.d), CHORD_WORDS.tau[cell.tau], CHORD_WORDS.rho[cell.rho]||'a chord', CHORD_WORDS.eta[cell.eta]].join(' · ');
}

/* ---- the chord at one place -------------------------------------------------------------------- */
// c: the composed piece; g: the chord position (not the first: that one is the seed). Returns null where there was no choice.
function chordInspect(c, g){
  const w=c && c.walk && c.walk[g]; if(!w || !w.from) return null;
  const plan=choicePlan(), tbl=chordTable(), vocab=vocabFor(scaleForSeg(g)), maxC=tableMax(tbl), classic=plan.mode==='classic';
  const all=chordCandidates(w.from, w.prev2, w.etaIn, tbl, vocab, w.target, plan);
  const step=chordStep(w.from, w.prev2, w.etaIn, tbl, vocab, w.target);
  const order=new Map(step.legal.map((ch,i)=>[ch.key,i]));        // the engine's own order, best first, noise and ties included
  const veto=new Set(STATE.vetoChord[g]||[]), pin=STATE.pins[g]||null;
  const rows=all.map(x=>({
    chord:x.c, key:x.c.key, roman:x.c.roman, j:x.j, f:x.f,
    cell:{d:rootFall(w.from.rootPc,x.c.rootPc), tau:tensionBucket(x.c.tensionVal-w.target), rho:x.c.ring, eta:w.etaIn},
    legal:!!x.legal, eligible:!!x.legal || step.fellBack, tier:x.tier, order:order.has(x.c.key)?order.get(x.c.key):1e9,
    cost:x.cost/maxC, vl:x.vl, vlCents:x.vl*1200/NN, smo:x.smo, fav:x.fav,
    util:classic?null:x.util, parts:classic?null:{favour:plan.wF*x.fav, smooth:plan.wS*x.smo},
    vetoed:veto.has(x.c.key), pinned:pin===x.c.key, taken:x.c.key===w.chord.key, p:0, held:null,
  }));
  // who is in the draw: eligible, not ruled out (unless that would leave nobody), and of the best tier when the chords are to keep moving
  const eligible=rows.filter(r=>r.eligible);
  let pool=eligible.filter(r=>!r.vetoed), vetoIgnored=false;
  if(!pool.length){ pool=eligible.slice(); vetoIgnored=eligible.some(r=>r.vetoed); }
  let compete=pool;
  if(!classic && plan.still){
    const mt=Math.min.apply(null, pool.map(r=>r.tier));
    compete=pool.filter(r=>r.tier===mt);
    for(const r of pool) if(r.tier!==mt) r.held = r.tier===2 ? 'stay' : 'back';
  } else if(classic){
    const mt=Math.min.apply(null, pool.map(r=>r.tier));
    compete=pool.filter(r=>r.tier===mt);
    for(const r of pool) if(r.tier!==mt) r.held = r.tier===2 ? 'stay' : 'back';
  }
  compete=compete.slice().sort((a,b)=>a.order-b.order);
  const ps = classic ? compete.map((r,i)=>i===0?1:0) : luce(compete.map(r=>r.util), plan.Tc);
  compete.forEach((r,i)=>{ r.p=ps[i]; });
  for(const r of rows) r.group = r.p>0||compete.includes(r) ? 0 : (r.eligible && !r.vetoed) ? 1 : r.vetoed ? 2 : 3;
  rows.sort((a,b)=> a.group-b.group || (b.p-a.p) || (a.group===0||a.group===1 ? a.order-b.order : a.cost-b.cost) || a.j-b.j);
  rows.forEach((r,i)=>{ r.rank=i; });
  return { g, from:w.from, prev2:w.prev2, eta:w.etaIn, target:w.target, plan, classic, rows,
    taken:w.chord, pinned:w.pinned, outside:w.outside, pinMissed:w.pinMissed, vetoed:w.vetoed, vetoIgnored,
    nLegal:rows.filter(r=>r.legal).length, nCompete:compete.length, fellBack:step.fellBack, T:plan.Tc, maxCost:maxC };
}

/* ---- the note at one place ----------------------------------------------------------------------- */
// v, step: which voice and when. Returns null for a note the rule did not choose (an anchor, a figure) or no note at all.
function noteInspect(c, v, step){
  const L=c && c.look && c.look[v] && c.look[v][step]; if(!L) return null;
  const plan=choicePlan(), ctx=L.ctx, classic=plan.mode==='classic', key=v+':'+step;
  const raw=noteCandidates(L.cands, ctx, plan, true);
  const veto=new Set(STATE.vetoNote[key]||[]), pin=typeof STATE.notePins[key]==='number' ? STATE.notePins[key] : null;
  const taken=c.pitches[v][step], f=1200/NN;
  const rows=raw.map(x=>({
    m:x.m, name:SP.pitchName(x.m), cell:x.cell, fi:x.fi, legal:x.legal, cost:x.cost/Math.max(1e-9,tableMax(ctx.tbl)), fav:x.fav, prox:x.prox, shape:x.shape, harm:x.harm, contr:x.contr,
    cents:ctx.prevPitch==null?null:(x.m-ctx.prevPitch)*f, chordTone:x.cell.phi===2,
    util:classic?null:x.util, h:x.h, score:x.score,
    parts:classic?null:{favour:plan.vw.favour*x.fav, step:plan.vw.step*x.prox, shape:plan.vw.shape*x.shape, harmony:plan.vw.harm*x.harm, contrary:plan.vw.contrary*x.contr},
    vetoed:veto.has(x.m), pinned:pin===x.m, taken:x.m===taken, p:0, held:null, outside:false,
  }));
  if(taken!=null && !rows.some(r=>r.m===taken)){        // a pitch the composer fixed that the voice could not have reached by itself
    rows.push({m:taken, name:SP.pitchName(taken), cell:noteCell(taken,ctx), legal:false, cost:0, fav:0, prox:0, shape:0, harm:0, contr:0, cents:ctx.prevPitch==null?null:(taken-ctx.prevPitch)*f,
      chordTone:false, util:null, h:0, score:-Infinity, parts:null, vetoed:false, pinned:true, taken:true, p:0, held:null, outside:true});
  }
  for(const r of rows) if(r.cell) r.fi=vIdx(r.cell.kappa,r.cell.mu,r.cell.phi,r.cell.sigma,r.cell.gamma);
  // in the draw: legal (or everything, if nothing is), not ruled out, and best on the hard preferences the engine keeps ahead of the score
  const real=rows.filter(r=>!r.outside);
  let eligible=real.filter(r=>r.legal), fellBack=false;
  if(!eligible.length){ eligible=real.slice(); fellBack=true; }
  let pool=eligible.filter(r=>!r.vetoed), vetoIgnored=false;
  if(!pool.length){ pool=eligible.slice(); vetoIgnored=eligible.some(r=>r.vetoed); }
  const hard=(r)=>[ (ctx.preferRoot!=null && plan.root) ? (pcOf(r.m)===ctx.preferRoot?0:1) : 0, ctx.approachPc!=null ? approachScoreOf(r.m, ctx.approachPc, plan) : 0 ];
  for(const r of pool) r.hard=hard(r);
  let best=null; for(const r of pool){ if(!best || r.hard[0]<best[0] || (r.hard[0]===best[0] && r.hard[1]<best[1])) best=r.hard; }
  const compete=pool.filter(r=>r.hard[0]===best[0] && r.hard[1]===best[1]);
  for(const r of pool) if(!compete.includes(r)) r.held = r.hard[0]!==best[0] ? 'root' : 'approach';
  compete.sort((a,b)=> (b.score-a.score) || (b.h-a.h) || (a.m-b.m));
  // the older fixed sort has its own order, so the note it played is the one that takes the whole draw
  const ps = classic ? compete.map(r=>r.taken?1:0) : luce(compete.map(r=>r.util), plan.Tv);
  compete.forEach((r,i)=>{ r.p=ps[i]; });
  rows.sort((a,b)=>a.m-b.m);
  return { v, step, ctx, plan, classic, rows, taken, pin, forced:!!(ctx.force!=null), vetoIgnored, fellBack,
    nLegal:rows.filter(r=>r.legal).length, nCompete:compete.length, T:plan.Tv, prev:ctx.prevPitch,
    others:ctx.others.filter(o=>o.pitch!=null).map(o=>o.pitch), chordTones:ctx.chordTones, preferRoot:ctx.preferRoot, approachPc:ctx.approachPc, structural:!!ctx.structural };
}
