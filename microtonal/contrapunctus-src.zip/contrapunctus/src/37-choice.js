/* =====================================================================
   13 · HOW MOVES ARE CHOSEN: THE CONTROLS
   ---------------------------------------------------------------------
   The policy itself is in 10-choice.js. Here it is made adjustable in
   three tiers: a taste (a preset), a variety (how far from the favourite the
   dice may go), and, under Fine control, every weight. A change to a preset's
   weights makes the taste "custom"; the preset chips say so by letting go.
   ===================================================================== */
const PRESET_WORDS = {
  balanced:'Weighs what the rule prefers against how little the voices have to move, and asks a melody to sing. A sensible place to start.',
  smooth:'Chords that keep the notes of the last one close, melodies that go by step. Gentle, and it tends to settle on a few chords.',
  strong:'Follows the rule’s strongest preferences, even where the voices have to leap to do it.',
  bold:'Reads the rule’s ranking from the dear end: the unexpected move first, then the next. Leaps are welcome.',
  custom:'Your own weights (under Fine control). Moving any weight of a preset ends up here.',
  classic:'The fixed order of the first two versions: no variety, and ties go to whichever number is lowest, which means little outside twelve notes. It is here so that an older state plays the same piece.',
};
function varietyWords(v){
  if(v<=0) return 'No dice. The move the taste ranks first is always played; the variation number only separates moves that tie exactly.';
  if(v<0.12) return 'Nearly always the move the taste ranks first.';
  if(v<0.45) return 'The favourite most of the time, the next few now and then.';
  if(v<0.75) return 'A real spread: the favourite is only a little ahead of the next few.';
  return 'Close to chance: nearly every allowed move is as likely as any other.';
}
function presetNameOf(ch){
  if(ch.mode==='classic') return 'classic';
  for(const k of CHOICE_ORDER) if(presetMatches(ch,k)) return k;
  return 'custom';
}
function choiceSummary(){
  const ch=STATE.choice;
  if(ch.mode==='classic') return 'classic · '+({smooth:'smoothest',strong:'strongest',bold:'boldest'}[STATE.take]||STATE.take);
  const name=ch.preset==='custom' ? 'custom' : (CHOICE_PRESETS[ch.preset]||CHOICE_PRESETS.balanced).label.toLowerCase();
  return name+' · '+(ch.variety>0 ? 'variety '+fmt2(ch.variety)+', variation '+(ch.seed|0) : 'no variety');
}

const WEIGHT_SLIDERS=[
  ['sCFavour','nCFavour','chord','favour'], ['sCSmooth','nCSmooth','chord','smooth'],
  ['sVFavour','nVFavour','voice','favour'], ['sVStep','nVStep','voice','step'], ['sVShape','nVShape','voice','shape'],
  ['sVHarm','nVHarm','voice','harm'], ['sVContr','nVContr','voice','contrary'],
];
function syncChoiceControls(){
  const ch=STATE.choice, classic=ch.mode==='classic';
  if(!$('choicePresets')) return;
  document.querySelectorAll('#choicePresets button').forEach(b=>b.setAttribute('aria-pressed', String(classic ? b.dataset.preset==='classic' : b.dataset.preset===ch.preset)));
  $('choiceNote').textContent=PRESET_WORDS[classic?'classic':ch.preset]||'';
  $('choiceScored').hidden=classic; $('classicTake').hidden=!classic;
  const put=(id,v)=>{ const e=$(id); if(e && document.activeElement!==e) e.value=String(v); };
  put('sVariety', Math.round(ch.variety*100)); $('nVariety').textContent=fmt2(ch.variety);
  $('varietyWords').textContent=varietyWords(ch.variety);
  put('inSeed', ch.seed|0);
  for(const [sid,nid,set,key] of WEIGHT_SLIDERS){ const w=ch[set][key]; put(sid, Math.round(w*100)); $(nid).textContent=fmt2(w); }
  $('chkStill').checked=ch.chord.still!==false; $('chkRoot').checked=ch.voice.root!==false;
  put('inMicro', ch.micro); put('inLeap', ch.leap);
  document.querySelectorAll('#takeCtl button').forEach(b=>b.setAttribute('aria-pressed', String(b.dataset.take===STATE.take)));
  const sum=$('sumChoice'); if(sum) sum.textContent=choiceSummary();
  renderSpaceNote();                                   // it says which steps the "same note under" setting rules out
}
function choosePreset(name){
  const ch=STATE.choice;
  if(name==='classic'){ ch.mode='classic'; ch.preset='classic'; }
  else{
    const was=ch.mode;
    applyPreset(ch,name);
    if(was==='classic' && ch.variety<=0) ch.variety=0.30;       // the fixed sort had none; a taste without any is a different choice, and a deliberate one
  }
  syncChoiceControls();
}
function setWeight(set, key, w){
  const ch=STATE.choice, L=CHOICE_LIMITS.w;
  ch[set][key]=Math.min(L[1], Math.max(L[0], w));
  ch.mode='scored'; ch.preset=presetNameOf(ch);
}
function bindChoice(){
  document.querySelectorAll('#choicePresets button').forEach(b=>b.addEventListener('click', act(()=>choosePreset(b.dataset.preset))));
  const live=(id, fn)=>{
    const el=$(id);
    el.addEventListener('input', ()=>{ fn((+el.value)/100); syncChoiceControls(); scheduleRegenerate(); });
    el.addEventListener('change', ()=>{ regenerate(); histCommit(); });
  };
  live('sVariety', v=>{ STATE.choice.variety=Math.min(1,Math.max(0,v)); });
  for(const [sid,,set,key] of WEIGHT_SLIDERS) live(sid, v=>setWeight(set,key,v));
  on('chkStill','change', act(e=>{ STATE.choice.chord.still=e.target.checked; syncChoiceControls(); }));
  on('chkRoot','change', act(e=>{ STATE.choice.voice.root=e.target.checked; syncChoiceControls(); }));
  const num=(id, lim, set)=>on(id,'change', act(e=>{
    const x=Math.round(parseFloat(e.target.value));
    if(isFinite(x)) set(Math.min(lim[1], Math.max(lim[0], x)));
    syncChoiceControls(); e.target.value=String(id==='inMicro'?STATE.choice.micro:STATE.choice.leap);
  }));
  num('inMicro', CHOICE_LIMITS.micro, x=>{ STATE.choice.micro=x; });
  num('inLeap',  CHOICE_LIMITS.leap,  x=>{ STATE.choice.leap=x; });
  on('inSeed','change', act(e=>{
    const x=Math.round(parseFloat(e.target.value)), L=CHOICE_LIMITS.seed;
    if(isFinite(x)) STATE.choice.seed=Math.min(L[1], Math.max(L[0], x));
    e.target.value=String(STATE.choice.seed|0); syncChoiceControls();
  }));
  on('btnReroll','click', act(()=>{
    const L=CHOICE_LIMITS.seed; let s=STATE.choice.seed|0, n=s;
    while(n===s) n=Math.floor(Math.random()*(L[1]+1));
    STATE.choice.seed=n; syncChoiceControls();
    if(STATE.choice.variety<=0) toast('Variety is zero, so the variation number only separates exact ties. Raise Variety to hear another variation.', 4200);
  }));
  on('btnChoiceReset','click', act(()=>{
    const ch=STATE.choice; applyPreset(ch,'balanced'); ch.chord.still=true; ch.voice.root=true; ch.micro=PSY_MICRO_CENTS; ch.leap=PSY_LEAP_CENTS;
    syncChoiceControls();
  }));
  document.querySelectorAll('#takeCtl button').forEach(b=>b.addEventListener('click', act(()=>{ STATE.take=b.dataset.take; syncChoiceControls(); })));
}
