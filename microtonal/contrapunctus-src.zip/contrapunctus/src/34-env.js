/* =====================================================================
   11 · ENVELOPE EDITOR
   ---------------------------------------------------------------------
   The curve drawn here is envLevel() of the note in 30-notes.js, sampled,
   so it is the curve the audio plays. The upright line is note-off: the
   attack and decay run until then (and are cut short if it comes first),
   sustain holds until it, and the release is free from there on, so it can
   die away well before the next note or ring into it. Handles:

     A     attack time, at the peak
     D S   decay time (across) and sustain level (up)
     off   note-off, in steps of the grid; it snaps to whole steps and to the
           next onset (hold Alt to move freely)
     R     release time, at the end of the fall

   A dashed handle marks where a stage would have ended had the key stayed
   down. The time axis keeps its scale while a handle is being dragged.

   The editor has two targets. One is a note: the changes are that note's own,
   on top of whatever envelope it started from. The other is one of the six
   presets of the bank (39-bank.js): the changes are shared by every note that
   was given that preset, and the note-off is then a fraction of each note's
   length, shown here for a note one beat long.
   ===================================================================== */
const ENVED = { pad:{l:34, r:16, t:30, b:26}, geo:null, lock:null, drag:null, hover:null };

function envTarget(){
  if(BANK.mode==='bank') return presetTarget(BANK.k);
  const n=STATE.selectedNote, c=STATE.composed;
  if(!n || !c || !c.notes) return null;
  return c.notes[n.v].find(x=>x.step===n.step) || null;
}
function envWindow(nt){
  const e=nt.e, sps=secondsPerStep();
  const own=Math.max(e.a+e.d, e.gateSec)+e.r*1.1+0.08;
  return Math.max(0.35, own, nt.span*sps*1.12);
}
function envGeometry(w, h, T){
  const P=ENVED.pad, x0=P.l, x1=w-P.r, y0=h-P.b, y1=P.t;
  return { w, h, x0, x1, y0, y1, T, X:t=>x0+(t/T)*(x1-x0), Y:l=>y0-l*(y0-y1), tOf:x=>(x-x0)/(x1-x0)*T, lOf:y=>(y0-y)/(y0-y1) };
}

function drawEnv(){
  const cv=$('envCanvas'); if(!cv) return;
  const {g,w,h}=ctx2d(cv), nt=envTarget(), S=THEME.str;
  syncEnvInputs(nt);
  g.textBaseline='alphabetic';
  if(!nt){
    g.fillStyle=S.dim; g.font='13px '+THEME.font.sans; g.textAlign='center';
    g.fillText('Click a note in the score, or the thin strip under a note in a lane,', w/2, h/2-6);
    g.fillText('to shape its envelope, or switch to the six presets.', w/2, h/2+14);
    ENVED.geo=null; envReadout(null); return;
  }
  const e=nt.e, sps=secondsPerStep(), T=ENVED.lock!=null?ENVED.lock:envWindow(nt);
  const G=envGeometry(w,h,T), col=S.voice[nt.v], cV=THEME.voice[nt.v];
  g.font='10px '+THEME.font.mono;

  // musical time: a line at every step
  const dense=(G.x1-G.x0)/(T/sps) < 26;
  g.strokeStyle=css(THEME.grid,0.3); g.lineWidth=1; g.fillStyle=S.faint; g.textAlign='center';
  for(let k=0; k*sps<=T+1e-9; k++){
    const x=Math.round(G.X(k*sps))+0.5;
    g.beginPath(); g.moveTo(x,G.y1-6); g.lineTo(x,G.y0); g.stroke();
    if(!dense || k%2===0) g.fillText(String(k), x, G.y0+14);
  }
  g.textAlign='right'; g.fillStyle=S.faint; g.fillText('steps', G.x1+10, G.y0+16);
  // level
  g.strokeStyle=css(THEME.grid,0.28);
  for(const l of [0.5,1]){ g.beginPath(); g.moveTo(G.x0,Math.round(G.Y(l))+0.5); g.lineTo(G.x1,Math.round(G.Y(l))+0.5); g.stroke(); }
  g.textAlign='right'; g.fillStyle=S.faint; g.fillText('1',G.x0-6,G.Y(1)+3); g.fillText('0',G.x0-6,G.Y(0)+3);

  // the free part, after note-off
  const xOff=G.X(e.gateSec);
  g.fillStyle=css(THEME.ink,0.045); g.fillRect(xOff, G.y1-6, G.x1-xOff, G.y0-G.y1+6);

  // the next note in this voice
  const nextT=nt.span*sps;
  if(nextT<=T){
    const xn=G.X(nextT);
    g.strokeStyle=col; g.lineWidth=1.4; g.setLineDash([4,3]);
    g.beginPath(); g.moveTo(xn,G.y1-10); g.lineTo(xn,G.y0); g.stroke(); g.setLineDash([]);
    g.fillStyle=S.dim;
    // when the two lines are close, the left-hand label goes to the left of its line and the right-hand one to the right of its
    const gate_x=G.X(e.gateSec), near=Math.abs(gate_x-xn)<92, rightSide=near ? xn>gate_x : xn<=G.x1-70;
    g.textAlign=rightSide?'left':'right'; g.fillText(nt.isPreset?'one beat on':'next note', xn+(rightSide?4:-4), G.y1-12);
  }

  // what it would have been had the key stayed down
  const nom=[[0,0],[e.a,1],[e.a+e.d,e.s],[Math.max(e.a+e.d,e.gateSec),e.s]];
  if(e.gateSec < e.a+e.d){
    g.strokeStyle=css(THEME.ink,0.45); g.lineWidth=1; g.setLineDash([3,3]); g.beginPath();
    nom.forEach((p,i)=>{ const x=G.X(Math.min(p[0],T)), y=G.Y(p[1]); if(i) g.lineTo(x,y); else g.moveTo(x,y); });
    g.stroke(); g.setLineDash([]);
  }
  // the curve itself, sampled from the same function the audio uses
  const N=Math.max(80, Math.round(G.x1-G.x0)), xs=[], ys=[];
  for(let i=0;i<=N;i++){ const t=T*i/N; xs.push(G.X(t)); ys.push(G.Y(envLevel(e,t,e.gateSec))); }
  g.beginPath(); g.moveTo(xs[0],G.y0); for(let i=0;i<=N;i++) g.lineTo(xs[i],ys[i]); g.lineTo(xs[N],G.y0); g.closePath();
  g.fillStyle=css(cV,0.18); g.fill();
  g.beginPath(); g.moveTo(xs[0],ys[0]); for(let i=1;i<=N;i++) g.lineTo(xs[i],ys[i]);
  g.strokeStyle=col; g.lineWidth=1.9; g.lineJoin='round'; g.stroke();

  // note-off
  g.strokeStyle=S.ink; g.lineWidth=2; g.beginPath(); g.moveTo(xOff,G.y1-10); g.lineTo(xOff,G.y0); g.stroke();
  { const xn2=nextT<=T?G.X(nextT):null, near=xn2!=null && Math.abs(xOff-xn2)<92, right = near ? xOff>=xn2 : xOff<=G.x1-60;
    g.fillStyle=S.ink; g.textAlign=right?'left':'right'; g.fillText('note-off', xOff+(right?6:-6), G.y1-12); }
  // where the release stops being audible
  const tAud=e.gateSec+e.tail;
  if(tAud<=T){ const xa=G.X(tAud); g.strokeStyle=S.dim; g.lineWidth=1; g.beginPath(); g.moveTo(xa,G.y0-4); g.lineTo(xa,G.y0+4); g.stroke();
    g.fillStyle=S.faint; g.textAlign='center'; g.fillText('−40 dB', xa, G.y0+22>h-2?G.y0-8:G.y0+22); }
  g.strokeStyle=css(THEME.grid,0.7); g.lineWidth=1; g.beginPath(); g.moveTo(G.x0,G.y0+0.5); g.lineTo(G.x1,G.y0+0.5); g.stroke();

  // handles
  const hs=[
    {id:'a',    x:G.X(Math.min(e.a,T)),            y:G.Y(1),            nominal:e.gateSec<e.a,          tag:'A'},
    {id:'ds',   x:G.X(Math.min(e.a+e.d,T)),        y:G.Y(e.s),          nominal:e.gateSec<e.a+e.d,      tag:'D·S'},
    {id:'gate', x:xOff,                            y:G.y1-4,            nominal:false,                  tag:''},
    {id:'r',    x:G.X(Math.min(e.gateSec+e.r,T)), y:G.Y(0),            nominal:false,                  tag:'R'},
  ];
  for(const hd of hs){
    const on=(ENVED.drag===hd.id), hv=(ENVED.hover===hd.id);
    g.beginPath(); if(hd.id==='gate') g.rect(hd.x-5,hd.y-5,10,10); else g.arc(hd.x,hd.y,on||hv?6.4:5,0,7);
    g.fillStyle=on?S.ink:S.plate; g.fill();
    g.strokeStyle=S.ink; g.lineWidth=1.6; if(hd.nominal) g.setLineDash([2.5,2]); g.stroke(); g.setLineDash([]);
    if(hd.tag){                    // the decay/sustain label sits to the right of its handle, clear of the slope that arrives from the left
      g.fillStyle=S.dim;
      if(hd.id==='ds'){ g.textAlign='left'; g.fillText(hd.tag, hd.x+9, hd.y-8); }
      else{ g.textAlign='center'; g.fillText(hd.tag, hd.x, hd.y-9); }
    }
  }
  ENVED.geo={G, handles:hs};
  envReadout(nt);
}

function signed(x, d){ return (x>=0?'+':'−')+Math.abs(x).toFixed(d==null?1:d); }
function envReadout(nt){
  const el=$('envRead'); if(!el) return;
  if(!nt){ el.innerHTML='&nbsp;<br>&nbsp;<br>&nbsp;'; return; }
  const e=nt.e, sps=secondsPerStep(), over=e.gate-nt.span, reach=e.gate+nt.tailSteps-nt.span, ms=x=>Math.round(x*1000);
  const adsr='A <b>'+ms(e.a)+'</b> ms  D <b>'+ms(e.d)+'</b> ms  S <b>'+fmt2(e.s)+'</b>  R <b>'+ms(e.r)+'</b> ms';
  if(nt.isPreset){
    const b=STATE.envBank[nt.k], used=presetUsage()[nt.k]||0;
    el.innerHTML='<b>'+esc(b.name)+'</b> (preset '+(nt.k+1)+')   ·   '+adsr+'<br>'
      +'note-off at <b>'+fmt2(b.gateRatio)+'</b> of each note\u2019s length: for a note one beat long ('+nt.span+' steps) that is '+e.gate.toFixed(2)+' steps, '+ms(e.gateSec)+' ms<br>'
      +'the release is audible for <b>'+ms(e.tail)+'</b> ms after note-off · '+(used?'<b>'+used+'</b> note'+(used===1?'':'s')+' in the piece '+(used===1?'has':'have')+' it':'no note in the piece has it yet')
      +(b.name!==defaultEnvBank()[nt.k].name||BANK_FIELDS.some(f=>b[f]!==defaultEnvBank()[nt.k][f])?'   ·   <span class="hand">changed by you</span>':'');
    return;
  }
  const bar=Math.floor(nt.step/STATE.stepsPerBar)+1, st=nt.step%STATE.stepsPerBar+1;
  const origin = e.preset>=0 ? 'preset <b>'+esc(STATE.envBank[e.preset].name)+'</b>' : 'the lane default';
  const l1='<b>'+VOICE_NAMES[nt.v]+'</b> · bar '+bar+', step '+st+' · <b>'+midiName(nt.pitch)+'</b>'+(Math.abs(nt.cents)>0.05?' '+signed(nt.cents)+'¢':'')
    +'   ·   '+adsr
    +(e.custom?'   ·   <span class="hand">shaped by you</span> from '+origin:'   ·   '+origin);
  const l2='note-off at <b>'+e.gate.toFixed(2)+'</b> steps ('+ms(e.gateSec)+' ms); the next note in this voice starts at <b>'+nt.span+'</b>: '
    +(over>0.03?'<span class="hand">held '+over.toFixed(2)+' steps into it</span>':over<-0.03?'silent for '+(-over).toFixed(2)+' steps first':'note-off lands on that onset');
  const l3='the release is audible for <b>'+ms(e.tail)+'</b> ms after note-off ('+(nt.tailSteps).toFixed(2)+' steps): '
    +(reach>0.03?'it is still sounding <b>'+reach.toFixed(2)+'</b> steps into the next note':'it has died away '+(-reach).toFixed(2)+' steps before the next note');
  el.innerHTML=l1+'<br>'+l2+'<br>'+l3;
}

/* ---- the number fields under the plot: exact values, and a way in without a pointer ------ */
const ENV_FIELDS=[['envA','a',1000],['envD','d',1000],['envS','s',1],['envGate','gate',1],['envR','r',1000]];
function syncEnvInputs(nt){
  const gate=$('envGate'), unit=$('envGateUnit'), lab=$('lblEnvGate');
  if(gate){
    const pre=!!(nt&&nt.isPreset);
    gate.min=pre?'0.02':'0.03'; gate.max=pre?'3':'64'; gate.step=pre?'0.02':'0.05';
    if(unit) unit.textContent=pre?'of the note':'steps';
    if(lab) lab.title=pre?'Note-off as a fraction of the distance to the next note: 1 is as long as the note, less is shorter, more runs into the next':'Where the key comes up, in steps from the onset';
  }
  for(const [id,f,k] of ENV_FIELDS){
    const el=$(id); if(!el) continue;
    el.disabled=!nt;
    if(!nt){ el.value=''; continue; }
    if(document.activeElement===el) continue;
    const v=f==='gate' ? (nt.isPreset ? nt.e.gate/nt.span : nt.e.gate) : nt.e[f];
    el.value = f==='s' ? (v).toFixed(2) : f==='gate' ? v.toFixed(2) : String(Math.round(v*k));
  }
}
function envSetField(f, value){
  const nt=envTarget(); if(!nt) return;
  if(!ENV_LIMITS[f] || !isFinite(value)) return;
  envPatch(nt, {[f]: (f==='gate' && nt.isPreset) ? value*nt.span : value});
}
// the one place an envelope is changed from the editor: a note takes the change as its own, a preset as a change for everyone who has it
function envPatch(nt, patch){
  const lim=(f,x)=>Math.min(ENV_LIMITS[f][1], Math.max(ENV_LIMITS[f][0], x));
  if(nt.isPreset){
    const b=STATE.envBank[nt.k];
    for(const f of ['a','d','s','r']) if(patch[f]!=null) b[f]=lim(f,patch[f]);
    if(patch.gate!=null) b.gateRatio=lim('gateRatio', patch.gate/nt.span);
  } else {
    const key=nt.v+':'+nt.step, cur=Object.assign({}, STATE.noteEnv[key]||{});
    for(const f of ['a','d','s','r','gate']) if(patch[f]!=null) cur[f]=lim(f,patch[f]);
    STATE.noteEnv[key]=cur;
  }
  envChanged();
}
function envChanged(){ refreshNotes(); drawSeq(); drawRoll(); drawEnv(); renderBank(); renderSeqBar(); }
function envCommit(){ renderHandStat(); syncSummaries(); renderStatus(); histCommit(); autosaveSoon(); }
function refreshNotes(){ if(STATE.composed) attachNotes(STATE.composed); }

/* ---- dragging ------------------------------------------------------------------------ */
function envPick(mx,my){
  const G=ENVED.geo; if(!G) return null;
  let best=null, bd=15;
  for(const hd of G.handles){ const d=Math.hypot(mx-hd.x,my-hd.y); if(d<bd){ bd=d; best=hd.id; } }
  return best;
}
function envDragStart(id){ if(!ENVED.geo) return; ENVED.drag=id; ENVED.lock=ENVED.geo.G.T; }
function envDragMove(id, mx, my, free){
  const nt=envTarget(), G=ENVED.geo&&ENVED.geo.G; if(!nt||!G) return;
  const sps=secondsPerStep(), e=nt.e, t=Math.max(0,G.tOf(mx)), lvl=clamp01(G.lOf(my)), patch={};
  if(id==='a') patch.a=t;
  else if(id==='ds'){ patch.d=t-e.a; patch.s=lvl; }
  else if(id==='gate'){
    let gs=t/sps;
    if(!free){ for(const snap of [Math.round(gs), nt.span]) if(Math.abs(gs-snap)<0.12){ gs=snap; break; } }
    patch.gate=gs;
  }
  else if(id==='r') patch.r=t-e.gateSec;
  envPatch(nt, patch);
}
function envDragEnd(){ ENVED.drag=null; ENVED.lock=null; drawEnv(); }
