/* =====================================================================
   14 · AT THIS STEP
   ---------------------------------------------------------------------
   The rule table says what is allowed, the choice policy says which allowed
   move is played, and 14-inspect.js lays out both for one place in the piece.
   Here that is drawn and made to answer: every chord the rule could have played
   at the selected chord, and every pitch the selected note could have taken, with
   the chance each had. Two edits are offered on any of them:

     Play      hold the piece to this move, even where the rule forbids it
     Rule out  take it off the table; the next best of the rest is played

   Both are kept with the piece (state code, undo) and marked in magenta wherever
   they show up. Nothing else about the rule changes: a rule is still a table, and
   a pin or a veto is an exception made at one place.
   ===================================================================== */
const INSPECT = { chordAll:false, pickChord:null, pickNote:null, hoverPitch:null, halo:null, chord:null, note:null, geo:null };
const NOTE_PAD = { l:12, r:12, t:24, b:30 };

/* ---- the edits ------------------------------------------------------------------------------- */
function without(list, x){ return (list||[]).filter(y=>y!==x); }
function setList(obj, key, list){ if(list.length) obj[key]=list; else delete obj[key]; }
function pinChord(g, key){
  if(STATE.pins[g]===key) delete STATE.pins[g];
  else{ STATE.pins[g]=key; setList(STATE.vetoChord, g, without(STATE.vetoChord[g], key)); }
  regenerate(); histCommit();
}
function ruleOutChord(g, key){
  const cur=STATE.vetoChord[g]||[];
  if(cur.indexOf(key)>=0) setList(STATE.vetoChord, g, without(cur, key));
  else{ STATE.vetoChord[g]=cur.concat([key]); if(STATE.pins[g]===key) delete STATE.pins[g]; }
  regenerate(); histCommit();
}
function pinNote(v, step, m){
  const k=v+':'+step;
  if(STATE.notePins[k]===m) delete STATE.notePins[k];
  else{ STATE.notePins[k]=m; setList(STATE.vetoNote, k, without(STATE.vetoNote[k], m)); }
  regenerate(); histCommit();
}
function ruleOutNote(v, step, m){
  const k=v+':'+step, cur=STATE.vetoNote[k]||[];
  if(cur.indexOf(m)>=0) setList(STATE.vetoNote, k, without(cur, m));
  else{ STATE.vetoNote[k]=cur.concat([m]); if(STATE.notePins[k]===m) delete STATE.notePins[k]; }
  regenerate(); histCommit();
}
function editsHere(){
  const g=STATE.selectedSeg, n=STATE.selectedNote;
  if(STATE.pins[g] || (STATE.vetoChord[g]||[]).length) return true;
  if(n){ const k=n.v+':'+n.step; if(STATE.notePins[k]!=null || (STATE.vetoNote[k]||[]).length || (n.v===0 && STATE.anchors[n.step]!=null)) return true; }
  return false;
}
function clearEditsHere(){
  if(!editsHere()){ toast('Nothing of yours is set here.', 2200); return; }
  const g=STATE.selectedSeg, n=STATE.selectedNote;
  delete STATE.pins[g]; delete STATE.vetoChord[g];
  if(n){ const k=n.v+':'+n.step; delete STATE.notePins[k]; delete STATE.vetoNote[k]; if(n.v===0) delete STATE.anchors[n.step]; }
  regenerate(); histCommit();
}

/* ---- words ----------------------------------------------------------------------------------- */
function cutPos(tbl){ const m=tableMax(tbl); return tbl.cut>0 ? tbl.costs[tbl.order[Math.min(tbl.order.length,tbl.cut)-1]]/m : 0; }
function costWords(cost, cut){
  const s=mk('span');
  s.appendChild(document.createTextNode('cost '));
  const mt=mk('span','meter'), f=mk('i','fillc'), t=mk('i','cut');
  f.style.width=Math.round(Math.min(1,cost)*100)+'%'; t.style.left=Math.round(Math.min(1,cut)*100)+'%'; t.title='the rule allows cells up to here';
  mt.append(f,t); s.appendChild(mt); s.appendChild(mk('b',null,fmt2(cost)));
  return s;
}
function motionWords(m, prev){
  if(prev==null) return 'the first note of the voice';
  const d=m-prev; if(d===0) return 'repeats the note';
  const a=Math.abs(d);
  return (d>0?'up ':'down ')+(a>=NN ? Math.round(a*1200/NN)+'¢' : intervalWords(a));
}
function signedW(x){ return (x<0?'−':'')+fmt2(Math.abs(x)); }
function pcText(p){ return p>0 ? (p<0.01?'<1%':Math.round(p*100)+'%') : '–'; }
function barStep(step){ return {bar:Math.floor(step/STATE.stepsPerBar)+1, st:step%STATE.stepsPerBar+1}; }

/* ---- focus survives a rebuild: the buttons are replaced whenever the piece is recomputed --------- */
function inspectorFocusKey(){
  const a=document.activeElement, host=$('plateStep');
  return (a && a.dataset && a.dataset.fk && host && host.contains(a)) ? a.dataset.fk : null;
}
function restoreInspectorFocus(k){
  if(!k) return;
  const el=[...$('plateStep').querySelectorAll('[data-fk]')].find(e=>e.dataset.fk===k);
  if(el) try{ el.focus({preventScroll:true}); }catch(e){}
}

/* ---- one candidate, as a row ------------------------------------------------------------------------ */
// o: {fk, name, small, taste, p, taken, pinned, vetoed, out, sel, meta:[Node|string], onPick, onEnter, onLeave, onPlay, onRule, label}
function candRow(o){
  const row=mk('div','cand'+(o.taken?' taken':'')+(o.pinned?' pinned':'')+(o.vetoed?' vetoed':'')+(o.out?' out':'')+(o.sel?' sel':''));
  row.setAttribute('role','listitem'); row.tabIndex=0; row.dataset.fk=o.fk+':row';
  const nm=mk('span','nm'); nm.appendChild(document.createTextNode(o.name)); if(o.small) nm.appendChild(mk('small',null,o.small));
  row.appendChild(nm);
  const bar=mk('span','pbar');
  if(o.taste!=null){ const u=mk('i','u'); u.style.width=Math.round(Math.max(0,Math.min(1,o.taste))*100)+'%'; bar.appendChild(u); }
  if(o.p>0){ const p=mk('i','p'); p.style.width=Math.max(1,Math.round(o.p*100))+'%'; bar.appendChild(p); }
  row.appendChild(bar);
  const pc=mk('span','pc'+(o.p>0?'':' zero'), pcText(o.p)); pc.title='the chance it has of being played here'; row.appendChild(pc);
  const acts=mk('span','acts');
  const play=mk('button','tiny'+(o.pinned?' hand':''), o.pinned?'Unpin':'Play'); play.type='button'; play.dataset.fk=o.fk+':play';
  play.title=o.pinned?'Let the rule decide here again':'Hold the piece to this'+(o.out?' (the rule does not allow it here)':'');
  play.setAttribute('aria-label', (o.pinned?'Unpin ':'Play ')+o.label);
  play.addEventListener('click', e=>{ e.stopPropagation(); o.onPlay(); });
  const rule=mk('button','tiny'+(o.vetoed?' hand':''), o.vetoed?'Allow':'Rule out'); rule.type='button'; rule.dataset.fk=o.fk+':rule';
  rule.title=o.vetoed?'Put it back on the table':'Take it off the table: the next best is played';
  rule.setAttribute('aria-label', (o.vetoed?'Allow ':'Rule out ')+o.label);
  rule.addEventListener('click', e=>{ e.stopPropagation(); o.onRule(); });
  acts.append(play, rule); row.appendChild(acts);
  const meta=mk('span','meta');
  for(const x of o.meta){ if(x==null) continue; meta.appendChild(typeof x==='string' ? (()=>{ const s=mk('span'); s.innerHTML=x; return s; })() : x); }
  row.appendChild(meta);
  if(o.onPick){
    row.addEventListener('click', o.onPick);
    row.addEventListener('keydown', e=>{ if((e.key==='Enter'||e.key===' ') && e.target===row){ e.preventDefault(); o.onPick(); } });
  }
  if(o.onEnter){ row.addEventListener('mouseenter', o.onEnter); row.addEventListener('focusin', o.onEnter); }
  if(o.onLeave){ row.addEventListener('mouseleave', o.onLeave); row.addEventListener('focusout', e=>{ if(!row.contains(e.relatedTarget)) o.onLeave(); }); }
  return row;
}
function breakdown(items, total){
  const el=mk('div','bd'), scale=Math.max(0.25, ...items.map(x=>Math.abs(x.v)), Math.abs(total.v));
  const track=(v)=>{
    const t=mk('span','track'); t.appendChild(mk('span','zero'));
    const i=mk('i', v<0?'neg':''); const w=Math.min(50, Math.abs(v)/scale*50);
    if(v<0){ i.style.left=(50-w)+'%'; i.style.width=w+'%'; } else { i.style.left='50%'; i.style.width=w+'%'; }
    t.appendChild(i); return t;
  };
  for(const x of items){ const l=mk('span',null,x.label); if(x.title) l.title=x.title; el.append(l, track(x.v), mk('span','v',signedW(x.v))); }
  const tl=mk('span','tot',total.label), tt=mk('span','tot'); tt.appendChild(track(total.v));
  el.append(tl, tt, mk('span','v totv',signedW(total.v)));
  return el;
}

/* ---- the chord ----------------------------------------------------------------------------------------- */
function visibleChordRows(info){
  if(INSPECT.chordAll) return info.rows;
  const keep=new Set(info.rows.slice(0,6).map(r=>r.key));
  for(const r of info.rows) if(r.taken || r.pinned || r.vetoed) keep.add(r.key);
  return info.rows.filter(r=>keep.has(r.key));
}
function chordHeadHtml(c, g, info){
  const taken=info.taken, bs=barOfSeg(g)+1;
  const l1='chord <b>'+(g+1)+'</b> of '+c.segments+' · bar '+bs+' · after <b>'+esc(info.from.roman)+'</b>'+(info.prev2?' (and <b>'+esc(info.prev2.roman)+'</b> before)':'')
    +' · <b>'+info.nLegal+'</b> of '+info.rows.length+' chords allowed'+(info.fellBack?' <span class="hand">(none was, so every chord is in play)</span>':'');
  let l2;
  const tr=info.rows.find(r=>r.taken), pcs=tr&&tr.p>0 ? ' (chance '+pcText(tr.p)+')' : '';
  if(info.pinned) l2='<span class="hand">you hold it to <b>'+esc(taken.roman)+'</b></span>'+(info.outside?' <span class="hand">(the rule does not allow it here)</span>':'');
  else l2='played: <b>'+esc(taken.roman)+'</b>'+pcs+(info.vetoed?' · <span class="hand">'+info.vetoed+' of the allowed moves ruled out by you</span>':'');
  if(info.vetoIgnored) l2+=' · <span class="hand">every allowed chord is ruled out, so the rule goes on as if none were</span>';
  if(info.pinMissed) l2+=' · <span class="hand">your pin is not in this scale’s chords, so it does nothing</span>';
  const l3=info.classic ? 'the classic order: no variety, one move is always played'
    : 'tension aim <b>'+fmt2(info.target)+'</b> · momentum in <b>'+ETA_NAMES[Math.min(2,Math.max(0,info.eta))]+'</b> · '+(info.T>0?'variety <b>'+fmt2(STATE.choice.variety)+'</b>, variation <b>'+(STATE.choice.seed|0)+'</b>':'no variety: the favourite is always played');
  return l1+'<br>'+l2+'<br>'+l3;
}
function renderChordPanel(c, g){
  const info=INSPECT.chord, head=$('stepChordHead'), list=$('stepChordList'), hint=$('stepChordHint'), detail=$('stepChordDetail');
  list.textContent=''; detail.textContent='';
  const all=$('btnChordAll'), clr=$('btnChordClear');
  clr.disabled=!editsHere();
  if(!info){
    head.innerHTML = g<=0 ? 'The first chord is the seed: nothing was chosen. Set it under <b>Start</b>, or select a later chord in the score.' : 'There was no choice at this chord.';
    hint.textContent=''; all.disabled=true; all.textContent='Show every chord'; return;
  }
  head.innerHTML=chordHeadHtml(c,g,info);
  const tbl=chordTable(), cut=cutPos(tbl), vis=visibleChordRows(info), hidden=info.rows.length-vis.length;
  all.disabled=info.rows.length<=vis.length && !INSPECT.chordAll; all.setAttribute('aria-pressed', String(INSPECT.chordAll));
  all.textContent=INSPECT.chordAll ? 'Show fewer' : 'Show all '+info.rows.length;
  const pick=INSPECT.pickChord && info.rows.some(r=>r.key===INSPECT.pickChord) ? INSPECT.pickChord : info.taken.key;
  const us=info.rows.filter(r=>r.util!=null).map(r=>r.util), umin=Math.min.apply(null,us), umax=Math.max.apply(null,us);
  let futures=0;
  for(const r of vis){
    const meta=[];
    meta.push(r.cell.d===0 ? '<b>the root stays</b>' : 'root falls <b>'+esc(intervalWords(r.cell.d))+'</b>');
    meta.push(costWords(r.cost, cut));
    meta.push('voices move <b>'+Math.round(r.vlCents)+'¢</b>');
    if(r.taken) meta.push('<b>the rule plays this</b>');
    if(r.pinned) meta.push('<span class="hand">pinned by you</span>'+(!r.eligible||!r.legal?' <span class="hand">(outside the rule)</span>':''));
    if(r.vetoed) meta.push('<span class="hand">ruled out by you</span>');
    if(!r.legal && !r.pinned) meta.push('not allowed: cost above the cut');
    if(r.held==='stay') meta.push('held back: it would repeat the chord');
    else if(r.held==='back') meta.push('held back: it would go back to the chord before');
    let fork=null;
    if(futures<8){
      futures++;
      fork=forkFrom(c.walk, g, r.chord, 4);
      const span=mk('span','fut'); span.appendChild(document.createTextNode('then '));
      fork.chords.slice(1).forEach((x,i)=>{ const base=c.chords[g+1+i], same=base&&base.key===x.key; const t=x.roman+' '; span.appendChild(same?document.createTextNode(t):mk('em',null,t)); });
      if(fork.chords.length>1) meta.push(span);
    }
    const on=()=>{ if(fork){ HOVER.branch={chords:fork.chords, cells:fork.cells, alt:r.chord}; } HOVER.link={set:'chord', f:r.f}; drawLattice(); drawRoll(); };
    const off=()=>{ HOVER.branch=null; HOVER.link=null; drawLattice(); drawRoll(); };
    list.appendChild(candRow({
      fk:'chord:'+r.key, name:r.roman, small:SP.names[r.chord.rootPc], taste:(r.util!=null && isFinite(umin) && umax>umin) ? (r.util-umin)/(umax-umin) : (r.util!=null?1:null),
      p:r.p, taken:r.taken, pinned:r.pinned, vetoed:r.vetoed, out:!r.legal, sel:r.key===pick, meta, label:r.roman+' at chord '+(g+1),
      onPick:()=>{ INSPECT.pickChord=r.key; const k=inspectorFocusKey(); renderChordPanel(c,g); restoreInspectorFocus(k); },
      onEnter:on, onLeave:off, onPlay:()=>pinChord(g,r.key), onRule:()=>ruleOutChord(g,r.key),
    }));
  }
  hint.textContent = hidden>0 ? hidden+' more chord'+(hidden===1?'':'s')+' below these, none of them likely. Hover a move to see where it would lead, in the score and in the rule space.'
                              : 'Hover a move to see where it would lead, in the score and in the rule space.';
  // the picked chord, taken apart
  const r=info.rows.find(x=>x.key===pick);
  if(r){
    const h=mk('div','readout'); h.innerHTML='<b>'+esc(r.roman)+'</b> · '+esc(chordCellWords(r.cell));
    detail.appendChild(h);
    if(!info.classic && r.parts){
      detail.appendChild(breakdown(
        [{label:'rule favours it', v:r.parts.favour, title:'weight × how cheap its cell is'},{label:'voices stay close', v:r.parts.smooth, title:'weight × how little the chord tones move'}],
        {label:'taste', v:r.util}));
      const t=mk('div','aside'); t.textContent='Chance is each move’s share of the dice: '+(info.T>0?'a move with taste u has weight e^(u/'+info.T.toFixed(2)+')':'with no variety the best taste always wins')+'. It counts only the moves in the draw.';
      detail.appendChild(t);
    } else if(info.classic){
      const t=mk('div','aside'); t.textContent='The classic order has no taste or chance: of the allowed moves it takes, in turn, the one that moves least by the "take", then by voice-leading distance, then by number.';
      detail.appendChild(t);
    }
  }
}

/* ---- the note ---------------------------------------------------------------------------------------------- */
function whyNoNote(v, step){
  if(v===0 && STATE.anchors[step]!=null) return 'This note is an anchor: you placed it, so the rule did not choose it. Remove the anchor in the score to let the rule decide.';
  if(v===0 && STATE.arp!=='none') return 'The melody follows the figure set under Form, so the rule did not choose this note. Turn the melody figure off to see what it weighs.';
  return 'The rule did not choose this note.';
}
function noteHeadHtml(c, ni){
  const nt=ni.taken, {bar,st}=barStep(ni.step), tr=ni.rows.find(r=>r.taken);
  let l1='<b>'+VOICE_NAMES[ni.v]+'</b> · bar '+bar+', step '+st+' · plays <b>'+esc(SP.pitchName(nt))+'</b>'+(ni.prev!=null?' ('+esc(motionWords(nt,ni.prev))+')':'')+' · <b>'+ni.nLegal+'</b> of '+ni.rows.filter(r=>!r.outside).length+' pitches allowed';
  if(ni.fellBack) l1+=' <span class="hand">(none was, so every pitch is in play)</span>';
  let l2;
  if(ni.forced) l2='<span class="hand">you hold this note to <b>'+esc(SP.pitchName(nt))+'</b></span>'+(tr&&tr.outside?' <span class="hand">(out of the rule’s reach)</span>':(tr&&!tr.legal?' <span class="hand">(the rule does not allow it)</span>':''));
  else l2='played: <b>'+esc(SP.pitchName(nt))+'</b>'+(tr&&tr.p>0&&!ni.classic?' (chance '+pcText(tr.p)+')':'')+(ni.structural?' · a structural note, where a chord tone is wanted':' · a passing note');
  if(ni.vetoIgnored) l2+=' · <span class="hand">every allowed pitch is ruled out, so the rule goes on as if none were</span>';
  const bits=[];
  if(ni.preferRoot!=null && ni.plan.root && !ni.classic) bits.push('the bass takes the root when it is allowed');
  else if(ni.preferRoot!=null && ni.classic) bits.push('the bass takes the root when it is allowed');
  if(ni.approachPc!=null) bits.push('leading into the next root: a step away is best');
  const l3=ni.classic ? 'the classic order: no variety, one pitch is always played' : (bits.length?bits.join(' · ')+' · ':'')+(ni.T>0?'variety <b>'+fmt2(STATE.choice.variety)+'</b>':'no variety');
  return l1+'<br>'+l2+'<br>'+l3;
}
function noteGeo(w, h, reg){
  const P=NOTE_PAD, x0=P.l, x1=w-P.r, y0=h-P.b, y1=P.t, n=reg.hi-reg.lo+1, bw=(x1-x0)/n;
  return {w,h,x0,x1,y0,y1,n,bw,lo:reg.lo,hi:reg.hi, X:m=>x0+(m-reg.lo)*bw, mOf:x=>Math.floor((x-x0)/bw)+reg.lo};
}
function noteRowOf(m){ const ni=INSPECT.note; return ni ? ni.rows.find(r=>r.m===m) : null; }
function drawNoteLandscape(){
  const cv=$('noteCanvas'); if(!cv) return;
  const {g,w,h}=ctx2d(cv), ni=INSPECT.note, S=THEME.str;
  g.textBaseline='alphabetic';
  if(!ni){
    INSPECT.geo=null;
    g.fillStyle=S.dim; g.font='13px '+THEME.font.sans; g.textAlign='center';
    const n=STATE.selectedNote, msg=n ? whyNoNote(n.v,n.step) : 'Select a note in the score to see every pitch it could have taken.';
    const words=msg.split(' '), lines=[]; let cur='';
    for(const wd of words){ if(g.measureText(cur+' '+wd).width>w-40){ lines.push(cur); cur=wd; } else cur=cur?cur+' '+wd:wd; }
    lines.push(cur);
    lines.forEach((t,i)=>g.fillText(t, w/2, h/2-(lines.length-1)*9+i*18));
    return;
  }
  const reg=ni.ctx.reg, G=noteGeo(w,h,reg); INSPECT.geo=G;
  g.font='10px '+THEME.font.mono;
  const H=G.y0-G.y1;
  const chordPcs=new Set(ni.chordTones.map(pcOf)), scalePcs=new Set(scalePCsNow());
  // the chord's own pitches, as bands
  for(let m=reg.lo;m<=reg.hi;m++) if(chordPcs.has(pcOf(m))){ g.fillStyle=css(THEME.ink,0.07); g.fillRect(G.X(m),G.y1-4,Math.max(1,G.bw),H+4); }
  g.strokeStyle=css(THEME.grid,0.28); g.lineWidth=1; g.beginPath(); g.moveTo(G.x0,Math.round(G.y1)+0.5); g.lineTo(G.x1,Math.round(G.y1)+0.5); g.stroke();
  // scale of the bars
  const us=ni.rows.filter(r=>r.util!=null).map(r=>r.util), umin=us.length?Math.min.apply(null,us):0, umax=us.length?Math.max.apply(null,us):1;
  let pmax=0; for(const r of ni.rows) if(r.p>pmax) pmax=r.p;
  const bw=Math.max(1, G.bw-(G.bw>5?1:0)), inset=bw>=5?bw*0.22:0;
  for(const r of ni.rows){
    if(r.m<reg.lo||r.m>reg.hi) continue;
    const x=G.X(r.m);
    if(r.util!=null){ const t=umax>umin?(r.util-umin)/(umax-umin):1; g.fillStyle=css(THEME.dim, r.legal?0.30:0.16); g.fillRect(x, G.y0-t*H, bw, t*H); }
    if(r.p>0 && pmax>0){ const hh=Math.max(2, r.p/pmax*H); g.fillStyle=css(THEME.permit,0.92); g.fillRect(x+inset, G.y0-hh, Math.max(1,bw-2*inset), hh); }
    if(!r.legal){ g.fillStyle=css(THEME.forbid,0.85); g.fillRect(x, G.y0-4, bw, 4); }
  }
  // the axis, with the scale and the chord marked on it
  g.strokeStyle=css(THEME.grid,0.7); g.beginPath(); g.moveTo(G.x0,G.y0+0.5); g.lineTo(G.x1,G.y0+0.5); g.stroke();
  let lastRight=-1e9; g.textAlign='center';
  for(let m=reg.lo;m<=reg.hi;m++){
    const pc=pcOf(m), x=G.X(m)+G.bw/2, isChord=chordPcs.has(pc), isScale=scalePcs.has(pc), isRoot=pc===STATE.root;
    if(isScale || isChord){ g.strokeStyle=isChord?S.ink:css(THEME.grid,0.9); g.lineWidth=isChord?1.6:1; g.beginPath(); g.moveTo(Math.round(x)+0.5,G.y0); g.lineTo(Math.round(x)+0.5,G.y0+(isChord?7:4)); g.stroke(); }
    if(isRoot || isChord){
      const t=SP.pitchName(m), tw=g.measureText(t).width;
      if(x-tw/2>lastRight+4 && x+tw/2<G.w){ g.fillStyle=isChord?S.ink:S.dim; g.fillText(t,x,G.y0+20); lastRight=x+tw/2; }
    }
  }
  // where the voice was, and where the others are
  if(ni.prev!=null && ni.prev>=reg.lo && ni.prev<=reg.hi){
    const x=Math.round(G.X(ni.prev)+G.bw/2)+0.5;
    g.strokeStyle=S.ink; g.lineWidth=1.2; g.setLineDash([4,3]); g.beginPath(); g.moveTo(x,G.y1-6); g.lineTo(x,G.y0); g.stroke(); g.setLineDash([]);
    g.fillStyle=S.dim; g.textAlign=x>G.w-60?'right':'left'; g.fillText('before', x+(x>G.w-60?-4:4), G.y1-9);
  }
  for(const o of ni.others){
    if(o<reg.lo||o>reg.hi) continue;
    const x=G.X(o)+G.bw/2; g.fillStyle=S.dim; g.beginPath(); g.moveTo(x-4,G.y1-12); g.lineTo(x+4,G.y1-12); g.lineTo(x,G.y1-5); g.closePath(); g.fill();
  }
  // what is the composer's, what the rule played, and what is under the pointer
  for(const r of ni.rows){
    if(r.m<reg.lo||r.m>reg.hi) continue;
    const x=G.X(r.m)+G.bw/2;
    if(r.vetoed){ g.strokeStyle=S.hand; g.lineWidth=1.8; g.beginPath(); g.moveTo(x-3.5,G.y1+3); g.lineTo(x+3.5,G.y1+10); g.moveTo(x+3.5,G.y1+3); g.lineTo(x-3.5,G.y1+10); g.stroke(); }
    if(r.pinned){ g.fillStyle=S.hand; g.beginPath(); g.moveTo(x,G.y1+1); g.lineTo(x+5,G.y1+7); g.lineTo(x,G.y1+13); g.lineTo(x-5,G.y1+7); g.closePath(); g.fill(); }
    if(r.taken){ g.strokeStyle=S.ink; g.lineWidth=1.8; g.strokeRect(Math.round(G.X(r.m))+0.5, G.y1-2, Math.max(2,G.bw-1), H+2); }
  }
  const sel=INSPECT.pickNote, hv=INSPECT.hoverPitch;
  if(sel!=null && sel>=reg.lo && sel<=reg.hi){ g.strokeStyle=S.ink; g.lineWidth=1; g.setLineDash([2,2]); g.strokeRect(Math.round(G.X(sel))-0.5, G.y1-8, Math.max(3,G.bw)+1, H+8); g.setLineDash([]); }
  if(hv!=null && hv>=reg.lo && hv<=reg.hi){ g.fillStyle=css(THEME.ink,0.10); g.fillRect(G.X(hv), G.y1-8, Math.max(2,G.bw), H+8); }
}
function renderNoteKey(){
  const el=$('noteKey'); if(!el) return; el.textContent='';
  const add=(cls,text,bg,extra)=>{ const s=mk('span'); const i=mk('i','sw '+cls); if(bg) i.style.background=bg; if(extra) i.style.cssText+=extra; s.appendChild(i); s.appendChild(document.createTextNode(text)); el.appendChild(s); };
  const ni=INSPECT.note; let pm=0; if(ni) for(const r of ni.rows) if(r.p>pm) pm=r.p;
  add('', pm>0 ? 'chance (the tallest bar is '+(pm>=0.995?'100':Math.round(pm*100))+'%)' : 'chance', THEME.str.permit); add('', 'taste', THEME.str.dim, 'opacity:.45'); add('', 'not allowed', THEME.str.forbid);
  add('', 'chord pitches', THEME.str.grid, 'opacity:.5'); add('ring', 'the rule played this'); add('dash', 'where the voice was');
  add('', 'pinned or ruled out by you', THEME.str.hand);
}
function noteTipLines(ni, r){
  const L=[SP.pitchName(r.m)+' · '+motionWords(r.m, ni.prev)];
  L.push((r.legal?'allowed':'not allowed by the rule')+' · cost '+fmt2(r.cost)+(r.taken?' · the rule plays this':'')+(r.pinned?' · pinned by you':'')+(r.vetoed?' · ruled out by you':''));
  if(r.util!=null) L.push('taste '+signedW(r.util)+' · chance '+pcText(r.p));
  if(r.cell && r.fi!=null) L.push(voiceCellWords(r.fi));
  return L;
}
function renderNotePanel(c){
  const ni=INSPECT.note, head=$('stepNoteHead'), list=$('stepNoteList'), detail=$('stepNoteDetail'), n=STATE.selectedNote;
  list.textContent=''; detail.textContent='';
  document.querySelectorAll('#noteTabs button').forEach(b=>b.setAttribute('aria-pressed', String(n!=null && +b.dataset.v===n.v)));
  const idx=n ? c.notes[n.v].findIndex(x=>x.step===n.step) : -1;
  $('btnNotePrev').disabled=!(n && idx>0); $('btnNoteNext').disabled=!(n && idx>=0 && idx<c.notes[n.v].length-1);
  renderNoteKey();
  if(!ni){ head.innerHTML = n ? whyNoNote(n.v,n.step) : 'Select a note in the score.'; drawNoteLandscape(); return; }
  head.innerHTML=noteHeadHtml(c,ni);
  const tbl=voiceTable(), cut=cutPos(tbl);
  const pick = INSPECT.pickNote!=null && ni.rows.some(r=>r.m===INSPECT.pickNote) ? INSPECT.pickNote : ni.taken;
  const us=ni.rows.filter(r=>r.util!=null).map(r=>r.util), umin=us.length?Math.min.apply(null,us):0, umax=us.length?Math.max.apply(null,us):1;
  const shown=new Map();
  const ranked=ni.rows.filter(r=>r.p>0).sort((a,b)=>b.p-a.p);
  for(const r of ranked.slice(0,6)) shown.set(r.m,r);
  for(const r of ni.rows) if(r.taken||r.pinned||r.vetoed) shown.set(r.m,r);
  if(!shown.size) for(const r of ni.rows.slice().sort((a,b)=>a.cost-b.cost).slice(0,4)) shown.set(r.m,r);
  const vis=[...shown.values()].sort((a,b)=>(b.p-a.p) || (a.m-b.m));
  for(const r of vis){
    const meta=[];
    meta.push('<b>'+esc(motionWords(r.m,ni.prev))+'</b>');
    if(r.cell && r.fi!=null) meta.push(esc(voiceCellWords(r.fi)));
    meta.push(costWords(r.cost, cut));
    if(r.taken && !r.outside) meta.push('<b>the rule plays this</b>');
    if(r.pinned) meta.push('<span class="hand">pinned by you</span>'+(r.outside?' <span class="hand">(out of the rule’s reach)</span>':(!r.legal?' <span class="hand">(outside the rule)</span>':'')));
    if(r.vetoed) meta.push('<span class="hand">ruled out by you</span>');
    if(!r.legal && !r.pinned && !r.outside) meta.push('not allowed: cost above the cut');
    if(r.held==='root') meta.push('held back: the bass takes the root when it can');
    else if(r.held==='approach') meta.push('held back: a better approach to the next root');
    list.appendChild(candRow({
      fk:'note:'+r.m, name:SP.pitchName(r.m), small:r.chordTone?'chord tone':'', taste:r.util!=null?(umax>umin?(r.util-umin)/(umax-umin):1):null,
      p:r.p, taken:r.taken, pinned:r.pinned, vetoed:r.vetoed, out:!r.legal, sel:r.m===pick, meta, label:SP.pitchName(r.m)+' at this step',
      onPick:()=>{ INSPECT.pickNote=r.m; const k=inspectorFocusKey(); renderNotePanel(c); restoreInspectorFocus(k); },
      onEnter:()=>{ INSPECT.hoverPitch=r.m; if(r.fi!=null) HOVER.link={set:'voice', f:r.fi}; drawNoteLandscape(); if(STATE.lattice.set==='voice') drawLattice(); },
      onLeave:()=>{ INSPECT.hoverPitch=null; HOVER.link=null; drawNoteLandscape(); if(STATE.lattice.set==='voice') drawLattice(); },
      onPlay:()=>pinNote(ni.v,ni.step,r.m), onRule:()=>ruleOutNote(ni.v,ni.step,r.m),
    }));
  }
  const r=ni.rows.find(x=>x.m===pick);
  if(r){
    const h=mk('div','readout'); h.innerHTML='<b>'+esc(SP.pitchName(r.m))+'</b>'+(r.cell && r.fi!=null?' · '+esc(voiceCellWords(r.fi)):'');
    detail.appendChild(h);
    if(!ni.classic && r.parts){
      detail.appendChild(breakdown([
        {label:'rule favours it', v:r.parts.favour, title:'weight × how cheap its cell is'},
        {label:'stepwise', v:r.parts.step, title:'weight × how good a motion of this size is (a step beats a repeat or a leap)'},
        {label:'line shape', v:r.parts.shape, title:'weight × no trills, a leap answered by a step back, not hugging the edge of the register'},
        {label:'harmony', v:r.parts.harmony, title:'weight × chord tone on a structural note, and fusing with the voices it sounds with'},
        {label:'against the rest', v:r.parts.contrary, title:'weight × moving against the other voices'},
      ], {label:'taste', v:r.util}));
    } else if(ni.classic){
      const t=mk('div','aside'); t.textContent='The classic order has no taste or chance: of the allowed pitches it takes the one the "take" ranks first, then the nearest to where the voice was, then the lowest.';
      detail.appendChild(t);
    }
  }
  drawNoteLandscape();
}

/* ---- the whole panel ---------------------------------------------------------------------------------------------- */
function computeHalo(){
  const ci=INSPECT.chord, ni=INSPECT.note;
  if(STATE.lattice.set==='chord' && ci){
    INSPECT.halo={set:'chord', items:ci.rows.filter(r=>r.p>0.004||r.taken).map(r=>({f:r.f, p:r.p, taken:r.taken}))};
  } else if(STATE.lattice.set==='voice' && ni){
    const m=new Map();
    for(const r of ni.rows){
      if((r.p<=0.004 && !r.taken) || r.fi==null) continue;
      const e=m.get(r.fi)||{f:r.fi, p:0, taken:false}; e.p+=r.p; e.taken=e.taken||r.taken; m.set(r.fi,e);
    }
    INSPECT.halo={set:'voice', items:[...m.values()]};
  } else INSPECT.halo=null;
}
function renderStepWhere(c, g){
  const el=$('stepWhere'); if(!el) return;
  const n=STATE.selectedNote;
  let s='chord '+(g+1)+' of '+c.segments+' · bar '+(barOfSeg(g)+1);
  if(n){ const {bar,st}=barStep(n.step); s+=' · '+VOICE_NAMES[n.v]+' note at bar '+bar+', step '+st; }
  el.textContent=s;
}
function renderInspector(){
  const c=STATE.composed; if(!c || !$('plateStep')) return;
  const fk=inspectorFocusKey();
  const g=Math.max(0, Math.min(c.segments-1, STATE.selectedSeg));
  const n=STATE.selectedNote;
  INSPECT.chord=chordInspect(c,g);
  INSPECT.note=n ? noteInspect(c,n.v,n.step) : null;
  if(INSPECT.pickChord && !(INSPECT.chord && INSPECT.chord.rows.some(r=>r.key===INSPECT.pickChord))) INSPECT.pickChord=null;
  if(INSPECT.pickNote!=null && !(INSPECT.note && INSPECT.note.rows.some(r=>r.m===INSPECT.pickNote))) INSPECT.pickNote=null;
  renderStepWhere(c,g); renderChordPanel(c,g); renderNotePanel(c); computeHalo();
  restoreInspectorFocus(fk);
}

/* ---- pointer and keyboard on the landscape ------------------------------------------------------------------------- */
function landscapePitchAt(clientX){
  const cv=$('noteCanvas'), G=INSPECT.geo; if(!cv||!G) return null;
  const x=clientX-cv.getBoundingClientRect().left;
  if(x<G.x0||x>G.x1) return null;
  return Math.max(G.lo, Math.min(G.hi, G.mOf(x)));
}
function bindStep(){
  on('btnChordAll','click', ()=>{ INSPECT.chordAll=!INSPECT.chordAll; const c=STATE.composed; if(c) renderChordPanel(c, Math.max(0,Math.min(c.segments-1,STATE.selectedSeg))); });
  on('btnChordClear','click', clearEditsHere);
  document.querySelectorAll('#noteTabs button').forEach(b=>b.addEventListener('click', ()=>stepVoice(+b.dataset.v)));
  on('btnNotePrev','click', ()=>stepNoteBy(-1)); on('btnNoteNext','click', ()=>stepNoteBy(1));
  const cv=$('noteCanvas');
  cv.addEventListener('pointermove', e=>{
    if(e.pointerType==='touch') return;
    const m=landscapePitchAt(e.clientX), ni=INSPECT.note; cv.style.cursor=(m!=null && ni)?'pointer':'default';
    if(m!==INSPECT.hoverPitch){
      INSPECT.hoverPitch=m; const r=m!=null?noteRowOf(m):null;
      HOVER.link = (r && r.fi!=null) ? {set:'voice', f:r.fi} : null;
      drawNoteLandscape(); if(STATE.lattice.set==='voice') drawLattice();
    }
    const r=m!=null?noteRowOf(m):null;
    if(r && ni) showTip(e.clientX, e.clientY, noteTipLines(ni, r)); else hideTip();
  });
  cv.addEventListener('pointerleave', ()=>{ hideTip(); if(INSPECT.hoverPitch!=null && document.activeElement!==cv){ INSPECT.hoverPitch=null; HOVER.link=null; drawNoteLandscape(); if(STATE.lattice.set==='voice') drawLattice(); } });
  cv.addEventListener('pointerdown', e=>{ takeFocus(cv); });
  cv.addEventListener('click', e=>{
    const ni=INSPECT.note; if(!ni) return;
    const m=landscapePitchAt(e.clientX); if(m==null) return;
    if(e.shiftKey) ruleOutNote(ni.v,ni.step,m); else pinNote(ni.v,ni.step,m);
  });
  cv.addEventListener('contextmenu', e=>{ const ni=INSPECT.note, m=landscapePitchAt(e.clientX); if(!ni||m==null) return; e.preventDefault(); ruleOutNote(ni.v,ni.step,m); });
  cv.addEventListener('keydown', e=>{
    const ni=INSPECT.note, G=INSPECT.geo; if(!ni||!G) return;
    let cur=INSPECT.hoverPitch!=null ? INSPECT.hoverPitch : (INSPECT.pickNote!=null ? INSPECT.pickNote : ni.taken);
    const mv=(d)=>{ cur=Math.max(G.lo,Math.min(G.hi,cur+d)); INSPECT.hoverPitch=cur; INSPECT.pickNote=cur; const r=noteRowOf(cur); HOVER.link=(r&&r.fi!=null)?{set:'voice',f:r.fi}:null; drawNoteLandscape(); if(STATE.lattice.set==='voice') drawLattice(); noteLive(r); };
    if(e.key==='ArrowRight'){ mv(e.shiftKey?5:1); e.preventDefault(); }
    else if(e.key==='ArrowLeft'){ mv(e.shiftKey?-5:-1); e.preventDefault(); }
    else if(e.key==='PageUp'){ mv(NN); e.preventDefault(); }
    else if(e.key==='PageDown'){ mv(-NN); e.preventDefault(); }
    else if(e.key==='Home'){ mv(G.lo-cur); e.preventDefault(); }
    else if(e.key==='End'){ mv(G.hi-cur); e.preventDefault(); }
    else if(e.key==='Enter'||e.key===' '){ pinNote(ni.v,ni.step,cur); e.preventDefault(); }
    else if(e.key==='Delete'||e.key==='Backspace'){ ruleOutNote(ni.v,ni.step,cur); e.preventDefault(); }
    else if(e.key==='Escape'){ INSPECT.hoverPitch=null; INSPECT.pickNote=null; HOVER.link=null; drawNoteLandscape(); }
  });
  cv.addEventListener('focus', ()=>{ const ni=INSPECT.note; if(ni && INSPECT.hoverPitch==null){ INSPECT.hoverPitch=INSPECT.pickNote!=null?INSPECT.pickNote:ni.taken; drawNoteLandscape(); noteLive(noteRowOf(INSPECT.hoverPitch)); } });
  cv.addEventListener('blur', ()=>{ INSPECT.hoverPitch=null; HOVER.link=null; drawNoteLandscape(); if(STATE.lattice.set==='voice') drawLattice(); });
}
// what the keyboard is on, said where a screen reader will hear it
function noteLive(r){
  const ni=INSPECT.note, el=$('stepNoteHead'); if(!ni||!el) return;
  if(!r){ return; }
  el.innerHTML='<b>'+esc(SP.pitchName(r.m))+'</b> · '+esc(motionWords(r.m,ni.prev))+' · '+(r.legal?'allowed':'<span class="hand">not allowed</span>')+(r.util!=null?' · chance <b>'+pcText(r.p)+'</b>':'')
    +(r.taken?' · <b>the rule plays this</b>':'')+(r.pinned?' · <span class="hand">pinned</span>':'')+(r.vetoed?' · <span class="hand">ruled out</span>':'')+'<br>Enter plays it, Delete rules it out.';
}
function stepVoice(v){
  const c=STATE.composed, n=STATE.selectedNote; if(!c) return;
  const list=c.notes[v]; if(!list.length) return;
  const here=n?n.step:0; let best=list[0], bd=1e9;
  for(const nt of list){ const d=Math.abs(nt.step-here); if(d<bd){ bd=d; best=nt; } }
  selectNote(v, best.step, false);
}
function stepNoteBy(d){
  const c=STATE.composed, n=STATE.selectedNote; if(!c||!n) return;
  const list=c.notes[n.v], i=list.findIndex(x=>x.step===n.step), j=i+d;
  if(j>=0 && j<list.length) selectNote(n.v, list[j].step, false);
}
