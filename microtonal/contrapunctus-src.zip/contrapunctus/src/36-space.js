/* =====================================================================
   12 · THE PITCH SPACE: CONTROLS, AND A MAP OF ITS INTERVALS
   ---------------------------------------------------------------------
   A division is chosen here, and the piece is carried over to it by cents
   (switchSpace, 10-core.js). The map draws what the ear does with every
   interval the division has (09-psy.js): the shaded area is how well it fuses,
   the line is how much it beats at the register of the middle voice, and a
   tick is a step, tall where the division counts it a consonance. Click an
   interval to hear it.
   ===================================================================== */
const RATIO_ORDER = [[6,5],[5,4],[4,3],[3,2],[8,5],[5,3],[7,4],[7,6],[9,7],[11,9],[11,8],[9,8]];
const COLOUR_WORDS = { h7:'harmonic seventh 4:5:6:7', sub:'subminor triad 6:7:9', neu:'neutral triad 18:22:27' };
const ERR = (x)=> (x>=0?'+':'−')+Math.abs(x).toFixed(1)+'¢';
const MAP = { pad:{l:36, r:12, t:40, b:34}, step:-1, geo:null, rootHz:261.63 };

function targetOf(S, key){ return S.targets.find(t=>t.key===key); }
// one line about a division, from the numbers themselves
function divisionFacts(N){
  const S=spaceFor(N), f=targetOf(S,'fifth'), M=targetOf(S,'M3'), m=targetOf(S,'m3'), h=targetOf(S,'h7');
  return N+' steps of '+(1200/N).toFixed(1)+'¢ · fifth '+ERR(f.err)+' · major third '+ERR(M.err)+' · minor third '+ERR(m.err)+' · harmonic seventh '+ERR(h.err);
}
function spaceSummary(){
  const sc=SCALE_LABELS[STATE.scaleName]||STATE.scaleName;
  let s=(NN===12 ? 'twelve notes' : NN+' steps to the octave')+' · '+SP.names[STATE.root]+' '+sc;
  if(STATE.colour) s+=' · colour chords';
  if(NN===12 && STATE.tuning!=='equal') s+=' · '+TUNINGS[STATE.tuning].label.toLowerCase();
  return s;
}
// the steps the ear counts as the same note out of tune (choice.micro): how many steps of this division are too small to be a melodic step
function microSentence(){
  const m=STATE.choice.micro, k=Math.ceil(m*NN/1200-1e-9)-1;
  if(k<1) return '';
  return ' A move shorter than '+m+'¢ counts as the same note out of tune, not a step, so the melody never moves by '+(k===1?'a single step':'up to '+k+' steps')+'; lower \u201cSame note under\u201d (Choice, fine controls) to allow '+(k===1?'it':'them')+'.';
}
function renderSpaceNote(){
  const el=$('spaceNote'); if(!el) return;
  if(NN===12){
    el.textContent='Twelve equal steps of 100¢: the usual keyboard. Another division cuts the octave differently, and choosing one carries your piece over to the nearest steps.'+microSentence();
    return;
  }
  const S=SP, f=targetOf(S,'fifth'), M=targetOf(S,'M3'), m=targetOf(S,'m3'), h=targetOf(S,'h7');
  const third=(want,have,chain)=>have+' step'+(have===1?'':'s')+' ('+ERR(have*1200/NN-want.cents)+')'+(have!==chain?'*':'');
  let t='A step is '+(1200/NN).toFixed(1)+'¢. The fifth is '+S.g+' steps ('+ERR(f.err)+'), the major third '+third(M,S.M3,S.M3c)+', the minor third '+third(m,S.m3,S.m3c)+', the harmonic seventh '+h.steps%NN+' ('+ERR(h.err)+').';
  if(S.M3!==S.M3c || S.m3!==S.m3c) t+=' * A third marked with a star is not the one the circle of fifths gives: a step nearby fuses clearly better, so chords are built from it.';
  el.textContent=t+microSentence();
}
function renderDivChips(){
  const host=$('divChips'); if(!host) return;
  host.textContent='';
  const list=DIV_CHOICES.slice(); if(list.indexOf(NN)<0){ list.push(NN); list.sort((a,b)=>a-b); }
  for(const N of list){
    const b=mk('button',null,String(N)); b.type='button'; b.setAttribute('aria-pressed', String(N===NN));
    b.title=divisionFacts(N)+(N===NN?'':'. Click to carry the piece over to it.');
    b.addEventListener('click', ()=>setSpace(N));
    host.appendChild(b);
  }
}
function refreshSpaceControls(){
  if(!$('divChips')) return;
  fill($('selRoot'), SP.names.map((n,i)=>[String(i),n]), STATE.root);
  fill($('selScale'), scaleNames().map(k=>[k,SCALE_LABELS[k]||k]), STATE.scaleName);
  fill($('selTimbre'), TIMBRES.map(k=>[k,TIMBRE_INFO[k].label]), STATE.timbre);
  $('timbreNote').textContent=TIMBRE_INFO[STATE.timbre].note+'.';
  $('inDiv').value=String(NN);
  renderDivChips(); renderSpaceNote();
  const has=SP.colour.length>0, chk=$('chkColour');
  chk.disabled=!has; chk.checked=!!STATE.colour && has;
  $('colourNote').textContent = has
    ? 'On offer here: '+SP.colour.map(c=>COLOUR_WORDS[c.q]).join(', ')+'. Each is built from steps within 15 cents of its ratio that fuse.'
    : (NN===12 ? 'The harmonic seventh, subminor and neutral triads need a finer division: no step of twelve is within 15 cents of their ratios.'
                : 'None in this division: no step within 15 cents of 7/4, 7/6 or 11/9 fuses well enough.');
  const eq=NN===12;
  $('rowTuning').hidden=!eq; $('tuningNote').hidden=!eq;
  $('sumSpace').textContent=spaceSummary();
}
function setSpace(N){
  N=Math.round(+N);
  if(!(N>=MIN_DIV && N<=MAX_DIV)){ toast('Divisions from '+MIN_DIV+' to '+MAX_DIV+' steps are supported.', 3200); refreshSpaceControls(); return; }
  if(N===NN){ refreshSpaceControls(); return; }
  const from=NN, lost=Object.keys(STATE.pins).length+Object.keys(STATE.vetoChord).length;
  switchSpace(N);
  afterSpaceChange(); regenerate(); histCommit();
  toast('Now '+N+' steps to the octave ('+(1200/N).toFixed(1)+'¢ a step). The piece was carried over by cents'+(lost?'; chords you pinned or ruled out belong to the old vocabulary and were cleared':'')+'.', 4600);
}
// everything that depends on which space is in force and is not recomputed by regenerate()
function afterSpaceChange(){
  buildProfiles(); refreshSpaceControls(); refreshSeedSelects(); syncControls();
  FRAME=null; TWEEN=null; LABEL_KEY=''; HOVER.cell=null; HOVER.link=null; HOVER.branch=null; HOVER_NOTE.nt=null;
  MAP.step=-1; INSPECT.pickChord=null; INSPECT.pickNote=null; INSPECT.hoverPitch=null; INSPECT.halo=null; INSPECT.chord=null; INSPECT.note=null;
  updateProjButtons(); renderAxisModes(); renderLatKey();
}

/* ---- the map ---------------------------------------------------------------------------------- */
function mapGeo(w,h){
  const P=MAP.pad, x0=P.l, x1=w-P.r, y0=h-P.b, y1=P.t;
  return {w,h,x0,x1,y0,y1, X:c=>x0+c/1200*(x1-x0), Y:v=>y0-v*(y0-y1), cOf:x=>(x-x0)/(x1-x0)*1200};
}
const ROUGH_TOP = 0.65;                // the roughness scale: the roughest interval at the middle voice is about 0.6
function intervalFacts(k){
  const c=k*1200/NN, n=psyNearest(c), fus=psyFusion(c);
  const cls=ic(k), cons=CONSONANT_ICS.has(cls), rough=k===0?0:psyRough(MAP.rootHz,c);
  return {k, c, near:n, fus, rough, cls, cons, words:intervalWords(k), gated: cons && k>0 && rough>PSY_ROUGH_GATE};
}
function drawIntervalMap(){
  const cv=$('intervalCanvas'); if(!cv) return;
  const {g,w,h}=ctx2d(cv), S=THEME.str, G=mapGeo(w,h);
  MAP.geo=G;
  g.font='10px '+THEME.font.mono; g.textBaseline='alphabetic';
  // axes
  g.strokeStyle=css(THEME.grid,0.22); g.lineWidth=1;
  for(const v of [0.5,1]){ const y=Math.round(G.Y(v))+0.5; g.beginPath(); g.moveTo(G.x0,y); g.lineTo(G.x1,y); g.stroke(); }
  g.fillStyle=S.faint; g.textAlign='right'; g.fillText('1',G.x0-5,G.Y(1)+3); g.fillText('0',G.x0-5,G.Y(0)+3);
  g.textAlign='center';
  for(let c=0;c<=1200;c+=100){
    const x=Math.round(G.X(c))+0.5;
    g.strokeStyle=css(THEME.grid, c%600===0?0.35:0.14); g.beginPath(); g.moveTo(x,G.y1); g.lineTo(x,G.y0); g.stroke();
    if(c%200===0){ g.fillStyle=S.faint; g.fillText(String(c),x,G.y0+14); }
  }
  g.textAlign='right'; g.fillStyle=S.faint; g.fillText('cents',G.x1+8,G.y0+27);
  // how well an interval fuses
  const pts=[]; for(let c=0;c<=1200;c+=2) pts.push([G.X(c), G.Y(psyFusion(c))]);
  g.beginPath(); g.moveTo(G.X(0),G.y0); for(const p of pts) g.lineTo(p[0],p[1]); g.lineTo(G.X(1200),G.y0); g.closePath();
  g.fillStyle=css(THEME.dim,0.16); g.fill();
  g.beginPath(); pts.forEach((p,i)=>{ if(i) g.lineTo(p[0],p[1]); else g.moveTo(p[0],p[1]); });
  g.strokeStyle=css(THEME.dim,0.85); g.lineWidth=1.3; g.stroke();
  // how rough it is, and the line past which a consonance stops counting
  g.beginPath(); for(let c=0;c<=1200;c+=4){ const x=G.X(c), y=G.Y(Math.min(1,psyRough(MAP.rootHz,c)/ROUGH_TOP)); if(c) g.lineTo(x,y); else g.moveTo(x,y); }
  g.strokeStyle=S.hand; g.lineWidth=1.3; g.stroke();
  const gy=Math.round(G.Y(PSY_ROUGH_GATE/ROUGH_TOP))+0.5;
  g.setLineDash([3,3]); g.strokeStyle=css(THEME.hand,0.6); g.beginPath(); g.moveTo(G.x0,gy); g.lineTo(G.x1,gy); g.stroke(); g.setLineDash([]);
  // the simple ratios, named on three levels so that neighbours do not run into each other
  g.textAlign='center'; const right=[-1e9,-1e9,-1e9];
  for(const r of RATIO_ORDER.map(([n,d])=>({txt:n+'/'+d, c:1200*Math.log2(n/d)})).sort((a,b)=>a.c-b.c)){
    const x=Math.round(G.X(r.c))+0.5, tw=g.measureText(r.txt).width; let lv=0;
    while(lv<3 && x-tw/2<right[lv]+5) lv++;
    g.strokeStyle=css(THEME.ink,0.3); g.lineWidth=1; g.setLineDash([2,3]); g.beginPath(); g.moveTo(x,G.y1+(lv<3?lv*11+5:0)); g.lineTo(x,G.y0); g.stroke(); g.setLineDash([]);
    if(lv<3){ g.fillStyle=S.dim; g.fillText(r.txt, x, G.y1+lv*11+2); right[lv]=x+tw/2; }
  }
  // the steps of the division
  for(let k=0;k<=NN;k++){
    const x=Math.round(G.X(k*1200/NN))+0.5, cls=ic(k), cons=k===0||k===NN||CONSONANT_ICS.has(cls), sel=(k===MAP.step);
    g.strokeStyle=sel?S.ink:(cons?css(THEME.ink,0.9):css(THEME.grid,0.7)); g.lineWidth=sel?2.4:(cons?1.7:1);
    const hgt=sel?30:(cons?22:(NN>41?6:9));
    g.beginPath(); g.moveTo(x,G.y0); g.lineTo(x,G.y0-hgt); g.stroke();
    if(NN<=31 && (cons || NN<=24)){ g.fillStyle=cons?S.ink:S.faint; g.textAlign='center'; g.fillText(String(k),x,G.y0-hgt-3); }
  }
  g.strokeStyle=css(THEME.grid,0.7); g.lineWidth=1; g.beginPath(); g.moveTo(G.x0,G.y0+0.5); g.lineTo(G.x1,G.y0+0.5); g.stroke();
  const hd=$('spaceHead'); if(hd){ const cons=[...CONSONANT_ICS].filter(k=>k>0).length; hd.innerHTML='<b>'+NN+'</b> steps · <b>'+cons+'</b> of '+(NN>>1)+' interval classes count as consonances'; }
  intervalReadout(MAP.step);
}
function intervalReadout(k){
  const el=$('intervalRead'); if(!el) return;
  if(k==null || k<0){ el.innerHTML='Hover or click a step to read it and hear it.<br>&nbsp;'; return; }
  const f=intervalFacts(k);
  el.innerHTML='step <b>'+k+'</b> · <b>'+f.c.toFixed(1)+'¢</b> · '+esc(f.words)+'<br>fuses <b>'+f.fus.toFixed(2)+'</b> · beats <b>'+f.rough.toFixed(2)+'</b> at the middle voice · '
    +(k===0||k===NN ? 'the unison and octave'
      : (f.cons ? '<b>counts as a consonance</b>'+(f.gated?' (but is too rough low down to count there)':'') : 'does not count as a consonance'));
}
function mapStepAt(clientX){
  const cv=$('intervalCanvas'), G=MAP.geo; if(!cv||!G) return -1;
  const r=cv.getBoundingClientRect(), c=G.cOf(clientX-r.left);
  if(c<-20||c>1220) return -1;
  return Math.max(0,Math.min(NN,Math.round(c/(1200/NN))));
}
function auditionInterval(k){
  const root=5*NN;
  audition([{p:root,v:1,at:0},{p:root+k,v:0,at:0}], 1.7);
}
function auditionChord(offs, label){
  const root=5*NN;
  audition(offs.map((o,i)=>({p:root+o+(i===0?-NN:0), v:i===0?2:(i%2?1:0), at:0})), 2.2);
  if(label) toast('Playing '+label+'.', 1500);
}
function auditionScale(){
  const root=5*NN, st=scaleSteps(STATE.scaleName), seq=st.map(s=>root+s).concat([root+NN]);
  audition(seq.map((p,i)=>({p, v:0, at:i*0.26})), seq.length*0.26+0.9);
}
function renderAuditionButtons(){
  const host=$('auditionBtns'); if(!host) return; host.textContent='';
  const add=(label, fn, title)=>{ const b=mk('button','tiny',label); b.type='button'; if(title) b.title=title; b.addEventListener('click', fn); host.appendChild(b); };
  add('Major triad', ()=>auditionChord([0,SP.M3,SP.P5],'a major triad'), 'root, third '+SP.M3+' steps, fifth '+SP.P5+' steps');
  add('Minor triad', ()=>auditionChord([0,SP.m3,SP.P5],'a minor triad'), 'root, third '+SP.m3+' steps, fifth '+SP.P5+' steps');
  for(const c of SP.colour) add(COLOUR_WORDS[c.q].replace(/ \d.*$/,'').replace(/^./,x=>x.toUpperCase()), ()=>auditionChord(c.offs, 'the '+COLOUR_WORDS[c.q]), COLOUR_WORDS[c.q]+': steps '+c.offs.join(', '));
  add('The scale', auditionScale, SCALE_LABELS[STATE.scaleName]||STATE.scaleName);
}
function renderTargetTable(){
  const host=$('targetTable'); if(!host) return; host.textContent='';
  const t=mk('table','tbl'), head=mk('tr');
  for(const x of ['ratio','','step','off by']) head.appendChild(mk('th',null,x));
  t.appendChild(mk('thead')).appendChild(head);
  const body=mk('tbody');
  for(const x of SP.targets){
    const r=mk('tr'); const nm=RATIO_NAMES[x.label]||'';
    const off=mk('td'), bar=mk('span','meter'); bar.style.width='40px';
    const fillc=mk('i','fillc'); fillc.style.width=Math.min(100,Math.abs(x.err)/30*100)+'%'; bar.appendChild(fillc);
    const cut=mk('i','cut'); cut.style.left=(PSY_SIGMA/30*100)+'%'; bar.appendChild(cut);
    off.appendChild(document.createTextNode(ERR(x.err)+' ')); off.appendChild(bar);
    r.appendChild(mk('td',null,x.label)); const n=mk('td','nm',nm); r.appendChild(n);
    r.appendChild(mk('td',null,String(x.steps))); r.appendChild(off);
    r.title='the nearest step to '+x.label+' is '+x.steps+' ('+(x.steps*1200/NN).toFixed(1)+'¢ against '+x.cents.toFixed(1)+'¢); it fuses '+x.fusion.toFixed(2);
    body.appendChild(r);
  }
  t.appendChild(body); host.appendChild(t);
  const note=mk('p','aside','The tick on each bar is 14¢, the width of the ear’s tolerance around a ratio: inside it the interval is heard as the ratio, a little out of tune.'); host.appendChild(note);
}
function renderIntervalKey(){
  const el=$('intervalKey'); if(!el) return; el.textContent='';
  const add=(cls,text,color)=>{ const s=mk('span'); const i=mk('i','sw '+cls); if(color) i.style.background=color; s.appendChild(i); s.appendChild(document.createTextNode(text)); el.appendChild(s); };
  add('', 'fuses into one sound', THEME.str.dim); add('', 'beats (roughness)', THEME.str.hand); add('dash','the line past which a consonance is too rough');
  const t=mk('span'); t.appendChild(document.createTextNode('tall tick: a consonant step')); el.appendChild(t);
}
function renderSpacePlate(){
  drawIntervalMap(); renderAuditionButtons(); renderTargetTable(); renderIntervalKey();
}

function bindSpace(){
  on('btnDiv','click', ()=>setSpace($('inDiv').value));
  on('inDiv','keydown', e=>{ if(e.key==='Enter'){ e.preventDefault(); setSpace($('inDiv').value); } });
  on('chkColour','change', act(e=>{ STATE.colour=e.target.checked && SP.colour.length>0; refreshSeedSelects(); refreshSpaceControls(); }));
  on('selTimbre','change', act(e=>{ STATE.timbre=e.target.value; $('timbreNote').textContent=TIMBRE_INFO[STATE.timbre].note+'.'; }));
  on('btnToIntervals','click', ()=>{ const p=$('plateSpace'); if(p&&p.scrollIntoView) p.scrollIntoView({block:'start', behavior:REDUCED_MOTION()?'auto':'smooth'}); });
  const cv=$('intervalCanvas');
  cv.addEventListener('pointermove', e=>{
    const k=mapStepAt(e.clientX); cv.style.cursor=k>=0?'pointer':'default';
    if(k!==MAP.step){ MAP.step=k; drawIntervalMap(); }
  });
  cv.addEventListener('pointerleave', ()=>{ if(document.activeElement!==cv && MAP.step!==-1){ MAP.step=-1; drawIntervalMap(); } });
  cv.addEventListener('click', e=>{ const k=mapStepAt(e.clientX); if(k>=0){ MAP.step=k; drawIntervalMap(); auditionInterval(k); } });
  cv.addEventListener('keydown', e=>{
    if(e.key==='ArrowRight'||e.key==='ArrowLeft'){ MAP.step=Math.max(0,Math.min(NN,(MAP.step<0?0:MAP.step)+(e.key==='ArrowRight'?1:-1))); drawIntervalMap(); e.preventDefault(); }
    else if(e.key==='Home'){ MAP.step=0; drawIntervalMap(); e.preventDefault(); }
    else if(e.key==='End'){ MAP.step=NN; drawIntervalMap(); e.preventDefault(); }
    else if((e.key==='Enter'||e.key===' ') && MAP.step>=0){ auditionInterval(MAP.step); e.preventDefault(); }
  });
  cv.addEventListener('focus', ()=>{ if(MAP.step<0){ MAP.step=SP.g; drawIntervalMap(); } });
  cv.addEventListener('blur', ()=>{ MAP.step=-1; drawIntervalMap(); });
}
