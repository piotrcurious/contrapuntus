/* =====================================================================
   4 · THE AUTOMATON
   ===================================================================== */
function segLen(){ return STATE.harmonic==='bar' ? STATE.stepsPerBar : Math.max(1,Math.floor(STATE.stepsPerBar/2)); }
function segOfStep(s){ return Math.floor(s/segLen()); }
function barOfSeg(g){ return Math.floor(g/(STATE.harmonic==='bar'?1:2)); }
function scaleForSeg(g){ const o=STATE.barOverrides[barOfSeg(g)]; return (o&&o.scale)||STATE.scaleName; }
function targetForSeg(g){
  const o=STATE.barOverrides[barOfSeg(g)];
  return (o && typeof o.tension==='number') ? o.tension : STATE.tension;
}

/* ---- the classic choice -------------------------------------------------------------------
   The fixed sort of the first two versions, kept exactly so that a state written then plays the same
   piece. See 10-choice.js for what was wrong with it. */
function tieBreak(current, prev2){
  // Three tiers first: real motion, backtracking to two chords ago, standing
  // still. Without them the ranking below has two degenerate attractors once
  // lambda stops constraining anything.
  const tier = (c)=>{
    if(c.rootPc===current.rootPc && c.quality===current.quality) return 2;
    if(prev2 && c.rootPc===prev2.rootPc && c.quality===prev2.quality) return 1;
    return 0;
  };
  const mode = STATE.take;
  return (a,b)=>{
    const ta=tier(a.c), tb=tier(b.c);
    if(ta!==tb) return ta-tb;
    const va=voiceLeadingDistance(current.tones,a.c.tones), vb=voiceLeadingDistance(current.tones,b.c.tones);
    if(mode==='strong'){ if(a.cost!==b.cost) return a.cost-b.cost; }
    else if(mode==='bold'){ if(a.cost!==b.cost) return b.cost-a.cost; }
    if(va!==vb) return va-vb;
    if(a.cost!==b.cost) return a.cost-b.cost;
    return a.c.rootPc-b.c.rootPc;
  };
}
function chordStepClassic(current, prev2, eta, tbl, vocab, target){
  const cands=[];
  for(let j=0;j<vocab.length;j++){
    const c=vocab[j];
    const f=cIdx(rootFall(current.rootPc,c.rootPc), tensionBucket(c.tensionVal-target), c.ring, eta);
    if(tbl.t[f]) cands.push({c, cost:tbl.costs[f], f});
  }
  let fellBack=false;
  if(cands.length===0){
    fellBack=true;
    for(let j=0;j<vocab.length;j++){
      const c=vocab[j];
      const f=cIdx(rootFall(current.rootPc,c.rootPc), tensionBucket(c.tensionVal-target), c.ring, eta);
      cands.push({c, cost:tbl.costs[f], f});
    }
  }
  cands.sort(tieBreak(current, prev2));
  return {legal:cands.map(x=>x.c), cands, fellBack};
}

/* ---- the scored choice ---------------------------------------------------------------------- */
const NO_CHORD_HID = 0x51ed;
function chordHid(c){ return c.hid!==undefined ? c.hid : (c.hid=strHash(c.key)); }     // from what the chord is, so adding colour chords does not reshuffle the others
function tierOf(c, current, prev2){
  if(c.rootPc===current.rootPc && c.quality===current.quality) return 2;
  if(prev2 && c.rootPc===prev2.rootPc && c.quality===prev2.quality) return 1;
  return 0;
}
// how little the chord tones have to move, 1 for not at all; the distance is the one the classic sort used, but read in cents
function smoothOf(vlSteps){ return 1/(1+(vlSteps*1200/NN)/400); }
// the dearest cell of a table, for putting a cost on a scale of 0..1 that does not depend on which candidates are present
function tableMax(tbl){
  if(tbl.maxCost===undefined){ let m=0; const c=tbl.costs; for(let i=0;i<c.length;i++) if(c[i]>m) m=c[i]; tbl.maxCost=m>0?m:1; }
  return tbl.maxCost;
}
// Every chord of the vocabulary as a candidate for the move from `current`: whether the rule allows it, the cell it falls in, what each
// feature says about it, and the noise the variety adds. The engine chooses among the legal ones; the inspector shows all.
function chordCandidates(current, prev2, eta, tbl, vocab, target, plan){
  plan = plan || choicePlan();
  const maxC=tableMax(tbl), out=[];
  const sh=hash4(plan.seed, chordHid(current), prev2?chordHid(prev2):NO_CHORD_HID, eta);
  for(let j=0;j<vocab.length;j++){
    const c=vocab[j];
    const f=cIdx(rootFall(current.rootPc,c.rootPc), tensionBucket(c.tensionVal-target), c.ring, eta);
    const cost=tbl.costs[f], vl=voiceLeadingDistance(current.tones,c.tones), smo=smoothOf(vl), h=mix32(sh, chordHid(c));
    const x={c, j, f, cost, legal:!!tbl.t[f], tier:tierOf(c,current,prev2), vl, smo, h, fav:1-cost/maxC};
    x.util=plan.wF*(1-cost/maxC)+plan.wS*smo;
    x.noise=plan.Tc>0 ? plan.Tc*gumbelOf(h) : 0;
    x.score=x.util+x.noise;
    out.push(x);
  }
  return out;
}
function scoredOrder(plan){
  return (a,b)=>{
    if(plan.still && a.tier!==b.tier) return a.tier-b.tier;
    if(a.score!==b.score) return a.score>b.score?-1:1;
    if(a.h!==b.h) return a.h>b.h?-1:1;
    return a.j-b.j;
  };
}
// The reference successor function: used by the piece, the what-if forks and the tests. The rule table
// only says what is allowed; the choice policy (10-choice.js) says which allowed move is played.
function chordStep(current, prev2, eta, tbl, vocab, target){
  const plan=choicePlan();
  if(plan.mode==='classic') return chordStepClassic(current, prev2, eta, tbl, vocab, target);
  const all=chordCandidates(current, prev2, eta, tbl, vocab, target, plan);
  let pool=all.filter(x=>x.legal), fellBack=false;
  if(!pool.length){ pool=all.slice(); fellBack=true; }
  pool.sort(scoredOrder(plan));
  return {legal:pool.map(x=>x.c), cands:pool, fellBack, all, plan};
}

/* ---- the fast path ---------------------------------------------------
   The analysis asks for the successor of every one of up to ~1700 states, at
   each of 29 values of lambda. chordNext() answers the same question as
   chordStep(...).legal[0] without sorting, allocating or recomputing a
   voice-leading distance: those are tabulated once per vocabulary. It is
   *defined* to agree with chordStep; the test suite checks that on thousands
   of random states, tables, policies and vocabularies. */
const KIT_CACHE = new WeakMap();
function vocabKit(vocab, target){
  let k = KIT_CACHE.get(vocab);
  if(!k){
    const V=vocab.length, vl=new Int16Array(V*V), fall=new Uint8Array(V*V), same=new Uint8Array(V*V), smo=new Float64Array(V*V);
    for(let i=0;i<V;i++) for(let j=0;j<V;j++){
      vl[i*V+j]   = voiceLeadingDistance(vocab[i].tones, vocab[j].tones);
      smo[i*V+j]  = smoothOf(vl[i*V+j]);
      fall[i*V+j] = rootFall(vocab[i].rootPc, vocab[j].rootPc);
      same[i*V+j] = (vocab[i].rootPc===vocab[j].rootPc && vocab[i].quality===vocab[j].quality) ? 1 : 0;
    }
    k = {V, vl, fall, same, smo, hid:Int32Array.from(vocab.map(chordHid)), root:Int8Array.from(vocab.map(c=>c.rootPc)), byTarget:new Map()};
    KIT_CACHE.set(vocab, k);
  }
  const tk = target.toFixed(4);
  let t = k.byTarget.get(tk);
  if(!t){
    const V=k.V, tb=new Uint8Array(V), fidx=new Int32Array(V*V);
    for(let j=0;j<V;j++) tb[j]=tensionBucket(vocab[j].tensionVal-target);
    for(let i=0;i<V;i++) for(let j=0;j<V;j++) fidx[i*V+j] = cIdx(k.fall[i*V+j], tb[j], vocab[j].ring, 0);
    t = {fidx};
    if(k.byTarget.size>8) k.byTarget.clear();
    k.byTarget.set(tk, t);
  }
  return {V:k.V, vl:k.vl, same:k.same, fall:k.fall, smo:k.smo, hid:k.hid, root:k.root, fidx:t.fidx};
}
// index of the move the rule plays from (cur, prev2, eta); prev2 = -1 for none. `plan` is choicePlan(); a bare
// string is taken as the classic take.
function chordNext(cur, prev2, eta, tbl, kit, plan){
  if(typeof plan==='string') return chordNextClassic(cur, prev2, eta, tbl, kit, plan);
  if(plan.mode==='classic') return chordNextClassic(cur, prev2, eta, tbl, kit, plan.take);
  return chordNextScored(cur, prev2, eta, tbl, kit, plan);
}
function chordNextScored(cur, prev2, eta, tbl, kit, plan){
  const V=kit.V, smo=kit.smo, same=kit.same, fidx=kit.fidx, hid=kit.hid, tt=tbl.t, cs=tbl.costs, maxC=tableMax(tbl);
  const eo=eta*CS[3], row=cur*V, prow=prev2>=0 ? prev2*V : -1;
  const sh=hash4(plan.seed, hid[cur], prev2>=0?hid[prev2]:NO_CHORD_HID, eta);
  const wF=plan.wF, wS=plan.wS, Tc=plan.Tc, still=plan.still;
  let best=-1, bT=0, bK=0, bH=0;
  for(let pass=0; pass<2 && best<0; pass++){        // pass 1 is the total-rule fallback: everything
    for(let j=0;j<V;j++){
      const f=fidx[row+j]+eo;
      if(pass===0 && !tt[f]) continue;
      const tier = still ? (same[row+j] ? 2 : (prow>=0 && same[prow+j]) ? 1 : 0) : 0;
      const h=mix32(sh, hid[j]);
      const k=wF*(1-cs[f]/maxC)+wS*smo[row+j]+(Tc>0 ? Tc*gumbelOf(h) : 0);
      if(best>=0){
        if(tier!==bT){ if(tier>bT) continue; }
        else if(k!==bK){ if(k<bK) continue; }
        else if(h<=bH) continue;                       // level on everything: the hash decides, and then the earlier index
      }
      best=j; bT=tier; bK=k; bH=h;
    }
  }
  return best;
}
function chordNextClassic(cur, prev2, eta, tbl, kit, mode){
  const V=kit.V, vl=kit.vl, same=kit.same, fidx=kit.fidx, root=kit.root, tt=tbl.t, cs=tbl.costs;
  const eo=eta*CS[3], row=cur*V, prow=prev2>=0 ? prev2*V : -1;
  let best=-1, bT=0, bV=0, bC=0, bR=0;
  for(let pass=0; pass<2 && best<0; pass++){        // pass 1 is the total-rule fallback: everything
    for(let j=0;j<V;j++){
      const f=fidx[row+j]+eo;
      if(pass===0 && !tt[f]) continue;
      const tier = same[row+j] ? 2 : (prow>=0 && same[prow+j]) ? 1 : 0;
      const v=vl[row+j], c=cs[f], r=root[j];
      if(best>=0){
        let cmp;
        if(tier!==bT) cmp = tier<bT ? -1 : 1;
        else {
          cmp = 0;
          if(mode==='strong'){ if(c!==bC) cmp = c<bC ? -1 : 1; }
          else if(mode==='bold'){ if(c!==bC) cmp = c>bC ? -1 : 1; }
          if(cmp===0 && v!==bV) cmp = v<bV ? -1 : 1;
          if(cmp===0 && c!==bC) cmp = c<bC ? -1 : 1;
          if(cmp===0 && r!==bR) cmp = r<bR ? -1 : 1;
        }
        if(cmp>=0) continue;                          // ties keep the earlier index, as a stable sort does
      }
      best=j; bT=tier; bV=v; bC=c; bR=r;
    }
  }
  return best;
}

function cellOfMove(from, to, target, eta){
  return {d:rootFall(from.rootPc,to.rootPc), tau:tensionBucket(to.tensionVal-target), rho:to.ring, eta};
}

function seedState(){
  const v = vocabFor(scaleForSeg(0));
  const i = Math.min(Math.max(0,STATE.seed.chordIdx), v.length-1);
  const p = STATE.seed.prev2Idx;
  return {vocab:v, chord:v[i], prev2:(p>=0&&p<v.length)?v[p]:null, eta:Math.min(2,Math.max(0,STATE.seed.eta))};
}

// What is played at chord g, given the moves the rule ranks (best first). The composer can hold the piece to a chord (a pin: played
// even where the rule forbids it, and then the walk goes on from it) or rule chords out (a veto: the next best of the rest is played;
// if every legal move is ruled out the veto is ignored, as a rule with nothing legal is).
function chooseChord(g, legal, vocab){
  const pin=STATE.pins[g], veto=STATE.vetoChord[g];
  if(pin){
    const f=legal.find(c=>c.key===pin);
    if(f) return {chord:f, pinned:true, outside:false, pinMissed:false, vetoed:0};
    const o=vocab.find(c=>c.key===pin);
    if(o) return {chord:o, pinned:true, outside:true, pinMissed:false, vetoed:0};
  }
  let chord=legal[0], vetoed=0;
  if(veto && veto.length){
    const rest=legal.filter(c=>veto.indexOf(c.key)<0);
    vetoed=legal.length-rest.length;
    if(rest.length) chord=rest[0]; else vetoed=0;
  }
  return {chord, pinned:false, outside:false, pinMissed:!!pin, vetoed};
}

function runChordWalk(totalSegments){
  const tbl = chordTable();
  const cache = {};
  const vocabAt = (g)=>{ const n=scaleForSeg(g); return cache[n] || (cache[n]=vocabFor(n)); };
  const s0 = seedState();
  let current=s0.chord, prev2=s0.prev2, eta=s0.eta;
  const out=[{chord:current, segIdx:0, fellBack:false, legal:[current], nLegal:1, pinned:false, outside:false, pinMissed:false, vetoed:0, cell:null}];
  for(let g=1; g<totalSegments; g++){
    const vocab = vocabAt(g), target = targetForSeg(g);
    const {legal, fellBack} = chordStep(current, prev2, eta, tbl, vocab, target);
    const pick = chooseChord(g, legal, vocab), chosen = pick.chord;
    const cell = cellOfMove(current, chosen, target, eta);
    const from = current, before = prev2;
    eta = etaOf(cell.d);
    prev2 = current; current = chosen;
    out.push({chord:current, segIdx:g, fellBack, legal:legal.slice(0,8), nLegal:legal.length, pinned:pick.pinned, outside:pick.outside, pinMissed:pick.pinMissed, vetoed:pick.vetoed,
              cell, from, prev2:before, target, etaIn:cell.eta});
  }
  return out;
}

// Fork: take an alternative at one segment and let the same rule finish it.
// Returns the chords *and* the rule cells they travel through, so a road not
// taken can be drawn in the score and in the rule space at the same time.
function forkFrom(walk, segIdx, alt, horizon){
  const tbl = chordTable();
  const cache = {};
  const vocabAt = (g)=>{ const n=scaleForSeg(g); return cache[n] || (cache[n]=vocabFor(n)); };
  const w = walk[segIdx];
  if(!w || !w.from) return {chords:[], cells:[]};
  let current = alt, prev2 = w.from;
  const firstCell = cellOfMove(w.from, alt, w.target, w.etaIn);
  let eta = etaOf(firstCell.d);
  const chords=[alt], cells=[firstCell];
  for(let g=segIdx+1; g<Math.min(walk.length, segIdx+1+horizon); g++){
    const vocab = vocabAt(g), target = targetForSeg(g);
    const {legal} = chordStep(current, prev2, eta, tbl, vocab, target);
    const chosen = chooseChord(g, legal, vocab).chord;
    cells.push(cellOfMove(current, chosen, target, eta));
    eta = etaOf(rootFall(current.rootPc, chosen.rootPc));
    prev2 = current; current = chosen;
    chords.push(chosen);
  }
  return {chords, cells};
}

/* ---- voices ----
   What the ear says about a candidate note, measured in cents so that it means the same in every division:
   a motion shorter than 45 cents is the same note a little out of tune, not a step (motionClass, and the
   sort in pickNote, treat it as a repeat); a pair of voices agrees when the interval fuses (the division's own
   consonance table, see 09-psy.js) *and* is not too rough for the register the lower voice is in. */
function motionClass(delta){
  if(delta===0) return 2;
  const c=Math.abs(delta)*1200/NN, ch=STATE.choice;
  if(c<ch.micro) return 2;
  return delta>0 ? (c<ch.leap?3:4) : (c<ch.leap?1:0);
}
function isMicro(delta){ return Math.abs(delta)*1200/NN < STATE.choice.micro; }
function fitClass(pc, chordPCs, scalePCs){ return chordPCs.includes(pc)?2 : scalePCs.includes(pc)?1 : 0; }
// two sounding pitches agree: a consonant interval class that is not too rough where it is sounding
function agrees(m, o){
  const d = m>o ? m-o : o-m;
  if(!CONSONANT_ICS.has(ic(d))) return false;
  return d===0 || SP.rough(m<o?m:o, d) <= PSY_ROUGH_GATE;
}
function consonanceCount(m, others){
  let n=0;
  for(const o of others){ if(o.pitch==null) continue; if(agrees(m,o.pitch)) n++; }
  return n;
}
function relativeMotion(delta, others){
  if(delta===0) return 1;
  let same=0, opp=0;
  for(const o of others){
    if(o.pitch==null||o.prevPitch==null) continue;
    const dv=o.pitch-o.prevPitch;
    if(dv===0) continue;
    if(Math.sign(dv)===Math.sign(delta)) same++; else opp++;
  }
  if(!same && !opp) return 1;
  return opp>same ? 2 : same>opp ? 0 : 1;
}
// Parallel perfect fifths and octaves only. (The first version also forbade
// parallel fourths, which are not a fault, because it tested the interval class
// 5 -- a fourth -- instead of the fifth.)
function filterParallels(cands, prevPitch, others){
  if(!others.length || prevPitch==null) return cands;
  const fifth=SP.g;
  const f = cands.filter(c=>{
    for(const o of others){
      if(o.pitch==null||o.prevPitch==null) continue;
      const before=Math.abs(prevPitch-o.prevPitch)%NN, after=Math.abs(c-o.pitch)%NN;
      const mine=c-prevPitch, theirs=o.pitch-o.prevPitch;
      if(mine!==0 && theirs!==0 && Math.sign(mine)===Math.sign(theirs) && before===after && (after===0||after===fifth)) return false;
    }
    return true;
  });
  return f.length?f:cands;
}
// keep candidates inside [lo,hi]; if that would leave nothing, the constraint yields
function bounded(cands, lo, hi){ const f=cands.filter(m=>m>=lo&&m<=hi); return f.length?f:cands; }
function pcDist(a,b){ const d=(((a-b)%NN)+NN)%NN; return Math.min(d,NN-d); }
function rangeAll(lo,hi){ const o=[]; for(let m=lo;m<=hi;m++) o.push(m); return o; }
function chordTonesIn(tones, lo, hi){
  const pcs=[...new Set(tones.map(pcOf))], o=[];
  for(let m=lo;m<=hi;m++) if(pcs.includes(pcOf(m))) o.push(m);
  return o;
}
function firstOnsetOfSeg(v, step, g){
  const L=segLen(), s0=g*L;
  for(let s=s0;s<step;s++) if(STATE.onsets[v][s]) return false;
  return true;
}
function lastOnsetOfSeg(v, step, g){
  const end=Math.min(STATE.onsets[v].length, (g+1)*segLen());
  for(let s=step+1;s<end;s++) if(STATE.onsets[v][s]) return false;
  return true;
}
// the cell a candidate note falls in, for a note about to be played
function noteCell(m, ctx){
  const {prevPitch, others, chordTones, scalePCs, structural} = ctx;
  const dv = prevPitch==null?0:(m-prevPitch);
  return { kappa:Math.min(2,consonanceCount(m,others)), mu:prevPitch==null?2:motionClass(dv),
           phi:fitClass(pcOf(m),chordTones.map(pcOf),scalePCs), sigma:structural?0:1, gamma:relativeMotion(dv,others) };
}
// a walking bass leads into the next root from a half step or a whole step away: 0 is that, 1 a little further, 2 is on it or far from it
function approachScoreOf(m, approachPc, plan){ const c=pcDist(pcOf(m), approachPc)*1200/NN; return c<plan.micro?2 : c<=150?0 : c<=250?1 : 2; }
// the sort of the first two versions, kept so that a state written then plays the same piece
function pickNoteClassic(cands, ctx, plan){
  const {prevPitch, others, tbl, preferRoot, approachPc} = ctx;
  const memo = new Map();
  const cl = (m)=>{ let v=memo.get(m); if(!v){ v=noteCell(m,ctx); memo.set(m,v); } return v; };
  const costOf = (m)=>{ const c=cl(m); return tbl.costs[vIdx(c.kappa,c.mu,c.phi,c.sigma,c.gamma)]; };
  let legal = cands.filter(m=>{ const c=cl(m); return tbl.t[vIdx(c.kappa,c.mu,c.phi,c.sigma,c.gamma)]===1; });
  let fellBack=false;
  if(!legal.length){ legal=cands.slice(); fellBack=true; }
  // A walking bass leads into the next root from a half step or a whole step away,
  // not by sounding the next root early.
  const approachScore = (m)=>approachScoreOf(m, approachPc, plan);
  const mode = STATE.take;
  legal.sort((a,b)=>{
    if(preferRoot!=null){
      const ra=pcOf(a)===preferRoot?0:1, rb=pcOf(b)===preferRoot?0:1;
      if(ra!==rb) return ra-rb;
    }
    if(approachPc!=null){
      const sa=approachScore(a), sb=approachScore(b);
      if(sa!==sb) return sa-sb;
    }
    const ca=costOf(a), cb=costOf(b);
    if(mode==='strong' && ca!==cb) return ca-cb;
    if(mode==='bold'   && ca!==cb) return cb-ca;
    const da=prevPitch==null?0:Math.abs(a-prevPitch), db=prevPitch==null?0:Math.abs(b-prevPitch);
    const ra=prevPitch!=null&&isMicro(da), rb=prevPitch!=null&&isMicro(db);
    if(ra!==rb) return ra?1:-1;
    if(da!==db) return da-db;
    if(ca!==cb) return ca-cb;
    return a-b;
  });
  // a pitch the composer has fixed for this note is played whatever the rule says; the cell it falls in is reported as usual
  if(ctx.force!=null && isFinite(ctx.force)) return {pitch:ctx.force, cls:cl(ctx.force), fellBack:false, forced:true};
  const chosen=legal[0];
  return {pitch:chosen, cls:cl(chosen), fellBack, forced:false, nLegal:legal.length};
}

/* ---- the scored choice, for a note ---------------------------------------------------------------
   Every pitch the voice could take, with the cell it falls in, whether the rule allows it, and what each feature says about it
   (10-choice.js). The engine chooses among the legal ones; the inspector shows all of them. `all` keeps the illegal ones. */
function noteCandidates(cands, ctx, plan, all){
  plan = plan || choicePlan();
  const {prevPitch, tbl} = ctx, w=plan.vw, f=1200/NN, maxC=tableMax(tbl), out=[];
  const memo=new Map();
  const cl=(m)=>{ let v=memo.get(m); if(!v){ v=noteCell(m,ctx); memo.set(m,v); } return v; };
  for(const m of cands){
    const cell=cl(m), fi=vIdx(cell.kappa,cell.mu,cell.phi,cell.sigma,cell.gamma), legal=tbl.t[fi]===1;
    if(!legal && !all) continue;
    const cost=tbl.costs[fi], a=prevPitch==null?0:Math.abs(m-prevPitch)*f;
    const x={m, cell, fi, legal, cost, fav:1-cost/maxC,
      prox: prevPitch==null ? 0.5 : proxOf(a, plan.micro), shape:shapeOf(m,ctx,plan), harm:harmOf(m,cell,ctx), contr:CONTRARY_OF[cell.gamma]};
    x.util=w.favour*x.fav + w.step*x.prox + w.shape*x.shape + w.harm*x.harm + w.contrary*x.contr;
    x.h=hash4(plan.seed, (ctx.v|0)*65537+(ctx.step|0), m, 0xA11);
    x.noise=plan.Tv>0 ? plan.Tv*gumbelOf(x.h) : 0;
    x.score=x.util+x.noise;
    out.push(x);
  }
  return out;
}
function pickNoteScored(cands, ctx, plan){
  const {preferRoot, approachPc} = ctx;
  const all=noteCandidates(cands, ctx, plan, false);
  let legal=all, fellBack=false;
  if(!legal.length){ legal=noteCandidates(cands, ctx, plan, true); fellBack=true; }
  const approachScore = (m)=>approachScoreOf(m, approachPc, plan);
  legal.sort((a,b)=>{
    if(preferRoot!=null && plan.root){
      const ra=pcOf(a.m)===preferRoot?0:1, rb=pcOf(b.m)===preferRoot?0:1;
      if(ra!==rb) return ra-rb;
    }
    if(approachPc!=null){
      const sa=approachScore(a.m), sb=approachScore(b.m);
      if(sa!==sb) return sa-sb;
    }
    if(a.score!==b.score) return a.score>b.score?-1:1;
    if(a.h!==b.h) return a.h>b.h?-1:1;
    return a.m-b.m;
  });
  if(ctx.force!=null && isFinite(ctx.force)) return {pitch:ctx.force, cls:noteCell(ctx.force,ctx), fellBack:false, forced:true};
  const top=legal[0];
  return {pitch:top.m, cls:top.cell, fellBack, forced:false, nLegal:fellBack?0:legal.length};
}
function pickNote(cands, ctx){
  const plan=ctx.plan||choicePlan();
  if(ctx.veto && ctx.veto.length){ const rest=cands.filter(m=>ctx.veto.indexOf(m)<0); if(rest.length) cands=rest; }     // pitches the composer ruled out
  return plan.mode==='classic' ? pickNoteClassic(cands, ctx, plan) : pickNoteScored(cands, ctx, plan);
}
function deterministicShuffle(arr, seed){
  const o=arr.slice(); let h=seed>>>0;
  for(let i=o.length-1;i>0;i--){ h=(Math.imul(h,2654435761)+i)>>>0; const j=h%(i+1); const t=o[i]; o[i]=o[j]; o[j]=t; }
  return o;
}
function arpSequence(tones, pattern, seed){
  const s=[...new Set(tones)].sort((a,b)=>a-b);
  if(!s.length) return [6*NN];
  switch(pattern){
    case 'up': return s;
    case 'down': return s.slice().reverse();
    case 'updown': return s.concat(s.slice().reverse().slice(1,-1));
    case 'downup': return s.slice().reverse().concat(s.slice(1,-1));
    case 'scramble': return deterministicShuffle(s, seed);
    default: return s;
  }
}

// Every voice hears every other voice: at its new pitch if it attacks on this
// step, at the pitch it is still holding if not. (The first version let the
// melody hear nobody, so two of the five voice axes were constant for it, and
// let the middle and bass hear only voices that happened to attack on the same
// step.) Voices are also kept from crossing: the middle sits between bass and
// melody, the melody above whatever is held beneath it. A constraint that would
// leave no candidate at all yields.
function runVoiceWalk(chords){
  const tbl = voiceTable(), plan = choicePlan();
  const total = STATE.onsets[0].length, cf = 1200/NN;
  const held=[null,null,null];
  for(let v=0;v<3;v++) if(STATE.seed.voice[v]!=null) held[v]=STATE.seed.voice[v];
  // what each voice has just done, for the shape of the line it is drawing: the note before the last, the direction of the
  // last motion, whether it was a leap, and how many motions in a row went that way
  const hist=[0,1,2].map(()=>({before:null, dir:0, leap:false, run:0}));
  let arpGen=null, arpSeg=-1, arpI=0;
  const res=[];
  for(let step=0; step<total; step++){
    const g = Math.min(segOfStep(step), chords.length-1);
    const chord = chords[g], next = chords[Math.min(g+1, chords.length-1)];
    const scalePCs = scaleSteps(scaleForSeg(g)).map(o=>(STATE.root+o)%NN);
    const before = held.slice();
    const pitches=[null,null,null], deco=[false,false,false], fb=[false,false,false], cells=[null,null,null], forced=[false,false,false], nlegal=[null,null,null], look=[null,null,null];
    const hears=(v)=>{
      const o=[];
      for(let u=0;u<3;u++){
        if(u===v) continue;
        const now=pitches[u], p = now!=null ? now : held[u];
        if(p==null) continue;
        o.push({pitch:p, prevPitch: now!=null ? before[u] : p});
      }
      return o;
    };
    const cur=(u)=> pitches[u]!=null ? pitches[u] : held[u];
    const sound=(v, p)=>{                         // the voice sounds p: its history moves on
      const h=hist[v], old=held[v];
      if(old!=null){ const d=p-old, sg=d>0?1:d<0?-1:0; h.run = sg!==0 ? (sg===h.dir ? h.run+1 : 1) : 0; h.leap=Math.abs(d)*cf>plan.leap; h.dir=sg; h.before=old; }
      held[v]=p; pitches[v]=p;
    };
    const put=(v, r, ctx, cands)=>{ sound(v, r.pitch); deco[v]=r.cls.phi<2; fb[v]=r.fellBack; cells[v]=r.cls; forced[v]=!!r.forced; nlegal[v]=r.nLegal==null?null:r.nLegal; look[v]={ctx, cands}; };
    const pinAt=(v)=>{ const p=STATE.notePins && STATE.notePins[v+':'+step]; return typeof p==='number' ? p : null; };
    const vetoAt=(v)=>{ const x=STATE.vetoNote && STATE.vetoNote[v+':'+step]; return Array.isArray(x) ? x : null; };
    const context=(v, ear, extra)=>Object.assign({v, step, plan, prevPitch:held[v], prev2Pitch:hist[v].before, lastDir:hist[v].dir, lastLeap:hist[v].leap, run:hist[v].run,
      reg:{lo:REGISTERS[v].lo, hi:REGISTERS[v].hi}, others:ear, chordTones:chord.tones, scalePCs, tbl, structural:firstOnsetOfSeg(v,step,g), force:pinAt(v), veto:vetoAt(v)}, extra);

    if(STATE.onsets[0][step]){
      if(STATE.anchors[step]!=null){
        sound(0, STATE.anchors[step]);
      } else if(STATE.arp!=='none'){
        if(arpSeg!==g){ const t=chordTonesIn(chord.tones,REGISTERS[0].lo,REGISTERS[0].hi);
          arpGen=arpSequence(t.length?t:[6*NN], STATE.arp, chord.rootPc*17+g); arpSeg=g; arpI=0; }
        sound(0, arpGen[arpI++%arpGen.length]);
      } else {
        const beneath=[held[1],held[2]].filter(x=>x!=null);
        const lo = beneath.length ? Math.max.apply(null, beneath)+1 : 0;
        const ear=hears(0);
        const cands=filterParallels(bounded(rangeAll(REGISTERS[0].lo,REGISTERS[0].hi), lo, Infinity), held[0], ear);
        const ctx=context(0, ear);
        put(0, pickNote(cands, ctx), ctx, cands);
      }
    }
    if(STATE.onsets[2][step]){
      const first=firstOnsetOfSeg(2,step,g);
      const above=[cur(0),held[1]].filter(x=>x!=null);
      const hi = above.length ? Math.min.apply(null, above)-1 : Infinity;
      const ear=hears(2);
      const cands=filterParallels(bounded(rangeAll(REGISTERS[2].lo,REGISTERS[2].hi), 0, hi), held[2], ear);
      const walk = STATE.walkingBass && !first && lastOnsetOfSeg(2,step,g);
      const ctx=context(2, ear, {preferRoot:first?chord.rootPc:null, structural:first, approachPc:walk?next.rootPc:null});
      put(2, pickNote(cands, ctx), ctx, cands);
    }
    if(STATE.onsets[1][step]){
      const lo = cur(2)!=null ? cur(2)+1 : 0, hi = cur(0)!=null ? cur(0)-1 : Infinity;
      const ear=hears(1);
      const cands=filterParallels(bounded(rangeAll(REGISTERS[1].lo,REGISTERS[1].hi), lo, hi), held[1], ear);
      const ctx=context(1, ear);
      put(1, pickNote(cands, ctx), ctx, cands);
    }
    res.push({step, pitches, deco, fellBack:fb, cells, g, forced, nlegal, look});
  }
  return res;
}

function secondsPerStep(){ return (60/STATE.tempo)*(4/STATE.stepsPerBar); }

/* ---- rhythm ---- */
// A walking bass sounds on every beat; otherwise the bass sounds once per chord.
function defaultOnsets(v, total, spb, harm, walk){
  const g=new Array(total).fill(false);
  if(v===0){ const p=Math.max(1,Math.floor(spb/4)); for(let s=0;s<total;s+=p) g[s]=true; }
  else if(v===1){ const p=Math.max(1,Math.floor(spb/2)); for(let s=0;s<total;s+=p) g[s]=true; }
  else {
    const L = walk ? Math.max(1,Math.floor(spb/4)) : (harm==='bar' ? spb : Math.max(1,Math.floor(spb/2)));
    for(let s=0;s<total;s+=L) g[s]=true;
  }
  return g;
}
function euclid(steps,pulses){
  const p=new Array(steps).fill(false); let b=0;
  for(let i=0;i<steps;i++){ b+=pulses; if(b>=steps){ b-=steps; p[i]=true; } }
  return p;
}
// A lane the composer has not touched follows the defaults (so it re-flows when the
// grid, the chord rhythm or the walking bass changes); a lane they have painted keeps
// what they painted.
function ensureGrids(){
  const total = STATE.bars*STATE.stepsPerBar, walk=STATE.walkingBass;
  const fresh = (v)=>defaultOnsets(v,total,STATE.stepsPerBar,STATE.harmonic,walk);
  if(!STATE.onsets || STATE.stepsPerBar!==STATE.lastStepsPerBar){
    const changed = STATE.onsets && STATE.stepsPerBar!==STATE.lastStepsPerBar;
    STATE.onsets=[0,1,2].map(fresh);
    STATE.touched=[false,false,false];
    if(changed){ STATE.anchors={}; STATE.noteEnv={}; STATE.notePins={}; STATE.notePreset={}; STATE.vetoNote={}; STATE.selectedNote=null; }
    STATE.lastStepsPerBar=STATE.stepsPerBar;
    return;
  }
  STATE.onsets = STATE.onsets.map((old,v)=>{
    const def=fresh(v);
    if(!STATE.touched[v]) return def;
    const out=new Array(total);
    for(let s=0;s<total;s++) out[s] = s<old.length ? old[s] : def[s];
    return out;
  });
}
