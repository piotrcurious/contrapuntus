/* =====================================================================
   15 · INTERFACE
   ---------------------------------------------------------------------
   All the event wiring lives here; the drawing modules stay free of it.
   Three rules hold throughout:
     - a control writes STATE and then calls regenerate(); nothing else
       keeps a copy of a setting;
     - a gesture is one history step: continuous controls update while
       they move (coalesced to one recompute per frame) and commit when
       they are let go;
     - every pointer path has a keyboard path.
   ===================================================================== */

/* ---- recompute, history ------------------------------------------------------------ */
let REGEN_PENDING=false;
function regenerate(){
  HOVER.branch=null;
  compose(); attachNotes(STATE.composed);
  renderAll(); autosaveSoon();
}
function scheduleRegenerate(){
  if(REGEN_PENDING) return; REGEN_PENDING=true;
  requestAnimationFrame(()=>{ REGEN_PENDING=false; regenerate(); });
}

const HIST={undo:[], redo:[], cur:null, max:120};
let COMMIT_T=null;
function updateHistButtons(){ $('btnUndo').disabled=!HIST.undo.length; $('btnRedo').disabled=!HIST.redo.length; }
function histReset(){ HIST.undo=[]; HIST.redo=[]; HIST.cur=snapshot(); updateHistButtons(); }
function histCommit(){
  clearTimeout(COMMIT_T);
  const now=snapshot();
  if(HIST.cur===null){ HIST.cur=now; return; }
  if(now===HIST.cur) return;
  HIST.undo.push(HIST.cur); if(HIST.undo.length>HIST.max) HIST.undo.shift();
  HIST.cur=now; HIST.redo.length=0; updateHistButtons();
}
function commitSoon(){ clearTimeout(COMMIT_T); COMMIT_T=setTimeout(histCommit, 450); }
function applySnapshot(json){
  const keep={seg:STATE.selectedSeg, note:STATE.selectedNote, bar:STATE.selectedBar};
  const r=restoreState(JSON.parse(json)); if(!r.ok) return false;
  STATE.selectedSeg=keep.seg; STATE.selectedNote=keep.note; STATE.selectedBar=(keep.bar!=null&&keep.bar<STATE.bars)?keep.bar:null;
  afterRestore(); return true;
}
function undo(){ histCommit(); if(!HIST.undo.length) return; HIST.redo.push(HIST.cur); HIST.cur=HIST.undo.pop(); applySnapshot(HIST.cur); updateHistButtons(); }
function redo(){ if(!HIST.redo.length) return; HIST.undo.push(HIST.cur); HIST.cur=HIST.redo.pop(); applySnapshot(HIST.cur); updateHistButtons(); }
function act(fn){ return function(e){ fn(e); regenerate(); histCommit(); }; }
function on(id, ev, fn){ const e=$(id); if(e) e.addEventListener(ev, fn); return e; }

function afterRestore(){
  FRAME=null; TWEEN=null; LABEL_KEY=''; SPACE_KEY=''; HOVER.cell=null; HOVER.link=null; HOVER.branch=null; HOVER_NOTE.nt=null;
  INSPECT.pickChord=null; INSPECT.pickNote=null; INSPECT.hoverPitch=null; MAP.step=-1;
  buildProfiles(); refreshSpaceControls(); refreshSeedSelects(); syncControls(); syncChoiceControls(); updateProjButtons(); renderAxisModes(); renderLatKey(); renderRollKey(); paintProfiles();
  regenerate();
}

/* ---- controls reflect the state ------------------------------------------------------- */
const SHOW_TOGGLES=[['btnShowTails','tails'],['btnShowGhost','ghosts'],['btnShowSounding','sounding']];
function syncControls(){
  const set=(id,v)=>{ const e=$(id); if(e) e.value=String(v); };
  set('selBars',STATE.bars); set('selGrid',STATE.stepsPerBar);
  set('selHarm',STATE.harmonic); set('selArp',STATE.arp); set('selTuning',STATE.tuning);
  set('sTension',Math.round(STATE.tension*100)); $('nTension').textContent=fmt2(STATE.tension);
  set('sLamC',Math.round(STATE.lamC*100)); $('nLamC').textContent=fmt2(STATE.lamC);
  set('sLamV',Math.round(STATE.lamV*100)); $('nLamV').textContent=fmt2(STATE.lamV);
  $('chkExt').checked=!!STATE.extended; $('chkWalk').checked=!!STATE.walkingBass;
  set('tempo',STATE.tempo); $('tempoNum').textContent=String(STATE.tempo);
  for(const [id,key] of SHOW_TOGGLES) $(id).setAttribute('aria-pressed', String(!!STATE.show[key]));
  renderAnchorButtons(); renderTuningNote();
}
function updatePlayButton(){
  const b=$('btnPlay'); b.setAttribute('aria-pressed', STATE.playing?'true':'false');
  $('playIco').textContent=STATE.playing?'■':'▶'; $('playLbl').textContent=STATE.playing?'Stop':'Play';
}
const DEGREE_NAMES=['1','♭2','2','♭3','3','4','♭5','5','♭6','6','♭7','7'];
function renderTuningNote(){
  const el=$('tuningNote'); if(!el) return;
  if(NN!==12){ el.textContent=''; return; }
  const T=TUNINGS[STATE.tuning];
  if(STATE.tuning==='equal'){ el.textContent='Every pitch class sits on its equal-tempered key. The MIDI file carries no pitch bend.'; return; }
  const parts=T.cents.map((c,k)=>(T.fixed?NOTE_NAMES[k]:DEGREE_NAMES[k])+' '+signed(c));
  el.textContent='Cents from equal temperament, '+(T.fixed?'fixed to C':'measured from the root')+': '+parts.join(' · ')
    +'. Pitches stop being whole numbers, so the MIDI file carries the difference as pitch bend.';
}
function setLambdaC(lam){
  STATE.lamC=lam; $('sLamC').value=String(Math.round(lam*100)); $('nLamC').textContent=fmt2(lam);
  regenerate(); histCommit();
}

/* ---- the cost-surface editors ----------------------------------------------------------- */
const DEFAULTS=defaultProfiles();
function buildProfiles(){
  for(const [host,axes,set] of [[$('profC'),CHORD_AXES,'chord'],[$('profV'),VOICE_AXES,'voice']]){
    host.textContent='';
    for(const ax of axes){
      const wrap=mk('div','axis'); wrap.dataset.set=set; wrap.dataset.key=ax.key;
      const head=mk('div','head'); head.appendChild(mk('span','name',ax.label)); head.appendChild(mk('span','what',ax.what));
      const w=mk('input'); w.type='range'; w.min='0'; w.max='150'; w.title='how much this axis counts'; w.setAttribute('aria-label','How much '+ax.what+' counts');
      w.addEventListener('input', ()=>{ STATE.profiles[set][ax.key].w=(+w.value)/100; scheduleRegenerate(); });
      w.addEventListener('change', ()=>{ regenerate(); histCommit(); });
      head.appendChild(w);
      const bars=mk('div','bars'); bars.setAttribute('role','group'); bars.setAttribute('aria-label','How much each value of '+ax.what+' is favoured. Arrow keys move and change.');
      for(let i=0;i<ax.n;i++){
        const b=mk('div','b'); b.appendChild(mk('i')); b.setAttribute('role','slider'); b.setAttribute('aria-orientation','vertical');
        b.setAttribute('aria-valuemin','0'); b.setAttribute('aria-valuemax','100'); b.setAttribute('aria-label',ax.what+', '+ax.tick(i)); b.tabIndex=i===0?0:-1;
        bars.appendChild(b);
      }
      const marg=mk('div','marg'); for(let i=0;i<ax.n;i++){ const m=mk('i'); m.appendChild(mk('u')); marg.appendChild(m); }
      const ticks=mk('div','ticks'); for(let i=0;i<ax.n;i++) ticks.appendChild(mk('span',null,ax.tick(i)));
      wrap.append(head,bars,marg,ticks); host.appendChild(wrap);
      bindBars(bars,set,ax);
    }
  }
  paintProfiles();
}
function bindBars(bars,set,ax){
  let active=false;
  const apply=(ev)=>{
    const r=bars.getBoundingClientRect();
    const i=Math.max(0,Math.min(ax.n-1,Math.floor((ev.clientX-r.left)/(r.width/ax.n))));
    STATE.profiles[set][ax.key].aff[i]=Math.round(clamp01(1-(ev.clientY-r.top)/r.height)*20)/20;
    paintProfiles(); scheduleRegenerate();
  };
  bars.addEventListener('pointerdown', e=>{ if(e.button>0) return; active=true; bars.setPointerCapture(e.pointerId); apply(e); e.preventDefault();
    const r=bars.getBoundingClientRect(), bs=bars.querySelectorAll('.b'), i=Math.max(0,Math.min(ax.n-1,Math.floor((e.clientX-r.left)/(r.width/ax.n)))); takeFocus(bs[i]||bars); });
  bars.addEventListener('pointermove', e=>{ if(active) apply(e); });
  const end=()=>{ if(!active) return; active=false; regenerate(); histCommit(); };
  bars.addEventListener('pointerup', end); bars.addEventListener('pointercancel', end);
  bars.addEventListener('keydown', e=>{
    const bs=[...bars.querySelectorAll('.b')], i=Math.max(0,bs.indexOf(document.activeElement)), p=STATE.profiles[set][ax.key];
    let j=i, changed=false;
    if(e.key==='ArrowRight') j=Math.min(ax.n-1,i+1);
    else if(e.key==='ArrowLeft') j=Math.max(0,i-1);
    else if(e.key==='ArrowUp'||e.key==='ArrowDown'){ p.aff[i]=Math.round(clamp01(p.aff[i]+(e.shiftKey?0.2:0.05)*(e.key==='ArrowUp'?1:-1))*20)/20; changed=true; }
    else if(e.key==='Home'){ p.aff[i]=0; changed=true; }
    else if(e.key==='End'){ p.aff[i]=1; changed=true; }
    else return;
    e.preventDefault();
    bs.forEach((b,k)=>{ b.tabIndex=k===j?0:-1; }); bs[j].focus();
    if(changed){ paintProfiles(); scheduleRegenerate(); commitSoon(); }
  });
}
function paintProfiles(){
  document.querySelectorAll('.axis').forEach(wrap=>{
    const set=wrap.dataset.set, key=wrap.dataset.key, axes=set==='chord'?CHORD_AXES:VOICE_AXES, ax=axes.find(a=>a.key===key);
    const p=STATE.profiles[set][key], def=DEFAULTS[set][key];
    wrap.querySelectorAll('.bars .b').forEach((b,i)=>{
      b.firstChild.style.height=Math.round(p.aff[i]*100)+'%';
      b.classList.toggle('edited', Math.abs(p.aff[i]-def.aff[i])>0.001);
      b.setAttribute('aria-valuenow', String(Math.round(p.aff[i]*100)));
      b.setAttribute('aria-valuetext', ax.tick(i)+': '+Math.round(p.aff[i]*100)+'%');
    });
    const w=wrap.querySelector('.head input'); if(w && document.activeElement!==w) w.value=String(Math.round(p.w*100));
  });
}

/* ---- the seed ---------------------------------------------------------------------------- */
function refreshSeedSelects(){
  const v=baseVocab();
  if(STATE.seed.chordIdx>=v.length) STATE.seed.chordIdx=0;
  if(STATE.seed.prev2Idx>=v.length) STATE.seed.prev2Idx=-1;
  fill($('selSeedChord'), v.map((c,i)=>[String(i), c.roman]), STATE.seed.chordIdx);
  fill($('selSeedPrev'), [['-1','none']].concat(v.map((c,i)=>[String(i), c.roman])), STATE.seed.prev2Idx);
  $('selSeedEta').value=String(STATE.seed.eta);
  const host=$('seedVoices'); host.textContent='';
  const scale=scaleSteps(STATE.scaleName).map(o=>(STATE.root+o)%NN);
  for(let i=0;i<3;i++){
    const opts=[['','auto']], valid=new Set();
    for(let m=REGISTERS[i].lo;m<=REGISTERS[i].hi;m++) if(scale.includes(pcOf(m))){ opts.push([String(m), midiName(m)]); valid.add(m); }
    if(STATE.seed.voice[i]!=null && !valid.has(STATE.seed.voice[i])) STATE.seed.voice[i]=null;     // left over from another root or scale
    const sel=mk('select'); sel.style.flex='1'; sel.style.minWidth='0';
    fill(sel, opts, STATE.seed.voice[i]==null?'':STATE.seed.voice[i]);
    sel.title=VOICE_NAMES[i]+' starts on'; sel.setAttribute('aria-label', 'Starting pitch of the '+VOICE_NAMES[i]);
    sel.addEventListener('change', act(()=>{ STATE.seed.voice[i]=sel.value===''?null:+sel.value; }));
    host.appendChild(sel);
  }
}

/* ---- the plain controls ------------------------------------------------------------------- */
function pruneBeyondEnd(){
  const total=STATE.bars*STATE.stepsPerBar, segs=Math.ceil(total/segLen());
  for(const k of Object.keys(STATE.barOverrides)) if(+k>=STATE.bars) delete STATE.barOverrides[k];
  for(const k of Object.keys(STATE.anchors)) if(+k>=total) delete STATE.anchors[k];
  for(const m of [STATE.noteEnv, STATE.notePins, STATE.notePreset, STATE.vetoNote]) for(const k of Object.keys(m)) if(+k.split(':')[1]>=total) delete m[k];
  for(const m of [STATE.pins, STATE.vetoChord]) for(const k of Object.keys(m)) if(+k>=segs) delete m[k];
  if(STATE.selectedBar!=null && STATE.selectedBar>=STATE.bars) STATE.selectedBar=null;
  if(STATE.selectedNote && STATE.selectedNote.step>=total) STATE.selectedNote=null;
  if(STATE.selectedSeg>=segs) STATE.selectedSeg=Math.max(0,segs-1);
}
function bindControls(){
  fill($('selTuning'), TUNING_ORDER.map(k=>[k,TUNINGS[k].label]), STATE.tuning);
  on('selRoot','change', act(e=>{ STATE.root=+e.target.value; refreshSeedSelects(); }));
  on('selScale','change', act(e=>{ STATE.scaleName=e.target.value; refreshSeedSelects(); }));
  on('selBars','change', act(e=>{ STATE.bars=+e.target.value; pruneBeyondEnd(); }));
  on('selGrid','change', act(e=>{ STATE.stepsPerBar=+e.target.value; }));
  on('selHarm','change', act(e=>{
    STATE.harmonic=e.target.value;
    if(Object.keys(STATE.pins).length || Object.keys(STATE.vetoChord).length){ STATE.pins={}; STATE.vetoChord={}; toast('Pins and ruled-out moves point at chord positions, which just changed, so they were cleared.', 3800); }
    pruneBeyondEnd();
  }));
  on('selArp','change', act(e=>{ STATE.arp=e.target.value; }));
  on('selTuning','change', act(e=>{ STATE.tuning=e.target.value; renderTuningNote(); }));
  on('chkExt','change', act(e=>{ STATE.extended=e.target.checked; refreshSeedSelects(); }));
  on('chkWalk','change', act(e=>{ STATE.walkingBass=e.target.checked; }));
  on('selSeedChord','change', act(e=>{ STATE.seed.chordIdx=+e.target.value; }));
  on('selSeedEta','change', act(e=>{ STATE.seed.eta=+e.target.value; }));
  on('selSeedPrev','change', act(e=>{ STATE.seed.prev2Idx=+e.target.value; }));

  const slider=(id,numId,set)=>{
    const el=$(id), n=$(numId);
    el.addEventListener('input', ()=>{ set((+el.value)/100); n.textContent=fmt2((+el.value)/100); scheduleRegenerate(); });
    el.addEventListener('change', ()=>{ regenerate(); histCommit(); });
  };
  slider('sTension','nTension', v=>{ STATE.tension=v; });
  slider('sLamC','nLamC', v=>{ STATE.lamC=v; });
  slider('sLamV','nLamV', v=>{ STATE.lamV=v; });

  on('btnSetChord','click', ()=>setLatticeSet('chord'));
  on('btnSetVoice','click', ()=>setLatticeSet('voice'));
  on('btnProjGrid','click', ()=>setPreset('grid'));
  on('btnProjCycle','click', ()=>setPreset('cycle'));
  on('btnProjHyper','click', ()=>setPreset('hyper'));
  on('btnProjPot','click', ()=>setPreset('cost'));

  for(const [id,key] of SHOW_TOGGLES) on(id,'click', ()=>{ STATE.show[key]=!STATE.show[key]; $(id).setAttribute('aria-pressed', String(STATE.show[key])); drawRoll(); autosaveSoon(); });

  on('btnResetProfC','click', act(()=>{ STATE.profiles.chord=defaultProfiles().chord; paintProfiles(); }));
  on('btnResetProfV','click', act(()=>{ STATE.profiles.voice=defaultProfiles().voice; paintProfiles(); }));

  on('btnPlay','click', togglePlay);
  on('btnUndo','click', undo); on('btnRedo','click', redo);
  const tp=$('tempo');
  tp.addEventListener('input', ()=>{
    STATE.tempo=+tp.value; $('tempoNum').textContent=tp.value;
    refreshNotes(); drawRoll(); drawSeq(); drawEnv(); renderKeep(); autosaveSoon();
  });
  tp.addEventListener('change', histCommit);

  on('btnLifeStep','click', ()=>{ STATE.life.grid=stepLife(STATE.life.grid,STATE.life.w,STATE.life.h); drawLife(); });
  on('btnLifeSeed','click', ()=>{ STATE.life.grid=randomLife(STATE.life.w,STATE.life.h,0.3); drawLife(); });
}
function drawLife(){
  const el=$('life'); el.style.gridTemplateColumns='repeat('+STATE.life.w+',1fr)'; el.textContent='';
  for(let y=0;y<STATE.life.h;y++) for(let x=0;x<STATE.life.w;x++){
    const i=mk('i'); if(STATE.life.grid[y*STATE.life.w+x]) i.className='on';
    i.addEventListener('click', ()=>{ const k=y*STATE.life.w+x; STATE.life.grid[k]=STATE.life.grid[k]?0:1; drawLife(); });
    el.appendChild(i);
  }
  let p=0; for(let i=0;i<STATE.life.grid.length;i++) p+=STATE.life.grid[i];
  $('lifePop').textContent='population '+p+' of '+(STATE.life.w*STATE.life.h);
}

/* ---- the rule space ------------------------------------------------------------------------- */
function latticeTipLines(f){
  const sp=latticeSpec(), c=cellList(sp.dims)[f], maxCost=Math.max.apply(null, Array.from(sp.tbl.costs)), n=sp.counts.get(f)||0;
  return [ sp.axes.map((a,i)=>a.label+' '+a.tick(c[i])).join('  '),
    (sp.tbl.t[f]?'legal':'not legal')+' · cost '+fmt2(sp.tbl.costs[f]/Math.max(1e-9,maxCost))+(sp.flips[c.join(',')]!=null?' · flipped by you':''),
    (n?'used '+n+'× by this piece':'not used by this piece')+(sp.set==='chord'&&sp.reach&&!sp.reach[f]?' · never asked':'') ];
}
function flipCell(f){
  const sp=latticeSpec(), key=cellList(sp.dims)[f].join(',');
  if(sp.flips[key]!=null) delete sp.flips[key]; else sp.flips[key]=sp.tbl.t[f]?0:1;
  regenerate(); histCommit();
}
function latticeNav(dx,dy){
  const L=LAYOUT; if(!L) return;
  const pts=L.pts, N=pts.length/2, cur=HOVER.cell;
  if(cur==null){ const sp=latticeSpec(); HOVER.cell=sp.seq.length?sp.seq[0]:0; return; }
  const cx=pts[cur*2], cy=pts[cur*2+1]; let best=-1, bd=1e18;
  for(let f=0;f<N;f++){
    if(f===cur) continue;
    const vx=pts[f*2]-cx, vy=pts[f*2+1]-cy, d=Math.hypot(vx,vy); if(d<0.5) continue;
    const dot=(vx*dx+vy*dy)/d; if(dot<0.55) continue;
    const score=d*(2-dot); if(score<bd){ bd=score; best=f; }
  }
  if(best>=0) HOVER.cell=best;
}
function bindLattice(){
  const cv=$('latticeCanvas'), host=$('latticeLabels');
  const pos=e=>{ const r=cv.getBoundingClientRect(); return [e.clientX-r.left, e.clientY-r.top]; };
  cv.addEventListener('pointermove', e=>{
    if(DRAG.axis) return;
    const [mx,my]=pos(e), f=latticePick(mx,my);
    cv.style.cursor=f!=null?'pointer':'default';
    if(f!==HOVER.cell){ HOVER.cell=f; latticeReadout(f); drawLattice(); }
    if(f!=null) showTip(e.clientX,e.clientY,latticeTipLines(f)); else hideTip();
  });
  cv.addEventListener('pointerleave', ()=>{ if(DRAG.axis) return; hideTip(); if(document.activeElement!==cv && HOVER.cell!=null){ HOVER.cell=null; latticeReadout(null); drawLattice(); } });
  cv.addEventListener('click', e=>{ const [mx,my]=pos(e), f=latticePick(mx,my); if(f!=null) flipCell(f); });
  cv.addEventListener('keydown', e=>{
    const dir={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[e.key];
    if(dir){ latticeNav(dir[0],dir[1]); latticeReadout(HOVER.cell); drawLattice(); e.preventDefault(); }
    else if(e.key==='Enter' && HOVER.cell!=null){ flipCell(HOVER.cell); e.preventDefault(); }
    else if(e.key==='Escape'){ HOVER.cell=null; latticeReadout(null); drawLattice(); }
  });
  cv.addEventListener('focus', ()=>{ if(HOVER.cell==null){ latticeNav(0,0); latticeReadout(HOVER.cell); drawLattice(); } });
  cv.addEventListener('blur', ()=>{ HOVER.cell=null; latticeReadout(null); drawLattice(); });
  cv.addEventListener('dblclick', ()=>setPreset('grid'));

  const handleOf=(b)=>LAYOUT && LAYOUT.handles.find(h=>h.key===b.dataset.key);
  host.addEventListener('pointerdown', e=>{
    const b=e.target.closest && e.target.closest('.handle'); if(!b) return;
    const h=handleOf(b); if(!h) return;
    b.setPointerCapture(e.pointerId); b._h=h; handleDragStart(h); hideTip(); e.preventDefault();
  });
  host.addEventListener('pointermove', e=>{
    const b=e.target.closest && e.target.closest('.handle'); if(!b || !DRAG.axis || DRAG.axis!==b.dataset.key || !b._h) return;
    const [mx,my]=pos(e); handleDragMove(b._h,mx,my);
  });
  const up=()=>{ if(DRAG.axis){ handleDragEnd(); autosaveSoon(); } };
  host.addEventListener('pointerup', up); host.addEventListener('pointercancel', up);
  host.addEventListener('keydown', e=>{
    const b=e.target.closest && e.target.closest('.handle'); if(!b) return;
    const h=handleOf(b), d={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,-1],ArrowDown:[0,1]}[e.key]; if(!h||!d) return;
    const k=e.shiftKey?24:6; handleNudge(h,d[0]*k,d[1]*k); e.preventDefault();
    const nb=host.querySelector('.handle[data-key="'+h.key+'"]'); if(nb) nb.focus();
  });
}

/* ---- the score ---------------------------------------------------------------------------------- */
const ANCHOR={on:false, any:false};
function renderAnchorButtons(){
  const a=$('btnAnchor'), b=$('btnAnchorAny'); if(!a||!b) return;
  a.setAttribute('aria-pressed', String(ANCHOR.on)); b.setAttribute('aria-pressed', String(ANCHOR.any)); b.disabled=!ANCHOR.on;
  const cv=$('rollCanvas'); if(cv) cv.style.cursor=ANCHOR.on?'crosshair':'default';
}
function toggleAnchor(step, pitch){
  if(STATE.anchors[step]===pitch) delete STATE.anchors[step];
  else{
    STATE.anchors[step]=pitch;
    if(!STATE.onsets[0][step]){ STATE.onsets[0][step]=true; STATE.touched[0]=true; }
  }
  regenerate(); histCommit();
}
function bindRoll(){
  const cv=$('rollCanvas'), pos=e=>{ const r=cv.getBoundingClientRect(); return [e.clientX-r.left, e.clientY-r.top]; };
  cv.addEventListener('pointermove', e=>{
    if(e.pointerType==='touch') return;
    const [mx,my]=pos(e), nt=rollHover(mx,my);
    cv.style.cursor = nt ? 'pointer' : (ANCHOR.on && my>ROLL.TOP && my<rollGeom().rollH ? 'crosshair' : 'pointer');
    if(nt) showTip(e.clientX,e.clientY,[VOICE_NAMES[nt.v]+' · '+midiName(nt.pitch)+(Math.abs(nt.cents)>0.05?' '+signed(nt.cents)+'¢':''), 'gate '+nt.e.gate.toFixed(2)+' of '+nt.span+' steps'+(nt.anchored?' · anchored by you':'')+(nt.pinned?' · pinned by you':'')]); else hideTip();
  });
  cv.addEventListener('pointerleave', ()=>{ hideTip(); if(HOVER_NOTE.nt){ HOVER_NOTE.nt=null; HOVER.link=null; noteReadout(null); drawRoll(); if(STATE.lattice.set==='voice') drawLattice(); } });
  cv.addEventListener('click', e=>{
    const [mx,my]=pos(e), r=rollClickAt(mx,my,ANCHOR.any);
    if(!r) return;
    if(r.kind==='select') selectNote(STATE.selectedNote.v, STATE.selectedNote.step, false);
    else if(r.kind==='anchor'){
      if(ANCHOR.on) toggleAnchor(r.step, r.pitch);
      else{ const c=STATE.composed; if(c) selectSeg(Math.min(c.segments-1, segOfStep(r.step))); }      // an empty place picks the chord under it
    }
  });
  on('btnAnchor','click', ()=>{ ANCHOR.on=!ANCHOR.on; renderAnchorButtons(); });
  on('btnAnchorAny','click', ()=>{ ANCHOR.any=!ANCHOR.any; renderAnchorButtons(); });
  cv.addEventListener('keydown', e=>{
    const c=STATE.composed; if(!c||!c.notes) return;
    const cur=STATE.selectedNote||{v:0,step:-1};
    let v=cur.v, list=c.notes[v], i=list.findIndex(n=>n.step===cur.step);
    if(e.key==='ArrowRight') i=Math.min(list.length-1,i+1);
    else if(e.key==='ArrowLeft') i=Math.max(0,i-1);
    else if(e.key==='ArrowUp'||e.key==='ArrowDown'){
      const nv=Math.max(0,Math.min(2,v+(e.key==='ArrowUp'?-1:1))); if(nv===v || !c.notes[nv].length) return;
      const here=cur.step<0?0:cur.step; let best=0, bd=1e9;
      c.notes[nv].forEach((n,k)=>{ const d=Math.abs(n.step-here); if(d<bd){ bd=d; best=k; } });
      v=nv; list=c.notes[nv]; i=best;
    } else return;
    e.preventDefault(); if(!list.length) return;
    const nt=list[Math.max(0,i)]; selectNote(nt.v,nt.step,false); noteReadout(nt);
  });
}

/* ---- the sequencer --------------------------------------------------------------------------------- */
// a note that is switched off takes whatever was set for it with it; one switched on takes the envelope picked under "new notes take"
function clearNoteEdits(v,step){
  const k=v+':'+step;
  delete STATE.noteEnv[k]; delete STATE.notePreset[k]; delete STATE.notePins[k]; delete STATE.vetoNote[k];
  if(v===0) delete STATE.anchors[step];
}
function setOnset(v,step,value){
  STATE.onsets[v][step]=value; STATE.touched[v]=true;
  if(!value) clearNoteEdits(v,step);
  else if(STATE.envBrush>=0) STATE.notePreset[v+':'+step]=STATE.envBrush;
  else delete STATE.notePreset[v+':'+step];
}
function seqCursorText(){
  const k=SEQ.cursor, c=STATE.composed, el=$('seqRead'); if(!el||!c) return;
  const spb=STATE.stepsPerBar, bar=Math.floor(k.step/spb)+1, st=k.step%spb+1, on=STATE.onsets[k.v][k.step];
  const nt=c.notes[k.v].find(n=>n.step===k.step), pk=STATE.notePreset[k.v+':'+k.step];
  el.textContent=VOICE_NAMES[k.v]+' · bar '+bar+', step '+st+' · '+(on?(nt?'on: '+midiName(nt.pitch):'on'):'off')+(on && pk!=null?' · '+STATE.envBank[pk].name:'');
}
// what the pointer is over, in words
function seqTipLines(h){
  const c=STATE.composed; if(!c||!c.notes) return null;
  const spb=STATE.stepsPerBar, bar=Math.floor(h.step/spb), st=h.step%spb+1;
  if(h.kind==='bar'){
    const ov=STATE.barOverrides[bar], bits=[];
    if(ov && ov.scale) bits.push('scale '+(SCALE_LABELS[ov.scale]||ov.scale));
    if(ov && typeof ov.tension==='number') bits.push('aim '+fmt2(ov.tension));
    return ['bar '+(bar+1)+(STATE.selectedBar===bar?' · picked':''), bits.length ? 'its own '+bits.join(' · ')+'. Click to change it.' : 'Click to give this bar its own scale or tension aim.'];
  }
  const nt=c.notes[h.v].find(n=>n.step===h.step), on=STATE.onsets[h.v][h.step], head=VOICE_NAMES[h.v]+' · bar '+(bar+1)+', step '+st;
  if(h.kind==='env'){
    if(!nt) return null;
    const e=nt.e;
    return [head+' · '+midiName(nt.pitch), (e.preset>=0?STATE.envBank[e.preset].name:'the lane’s own envelope')+(e.custom?' · shaped by you':''), 'note-off at '+e.gate.toFixed(2)+' of '+nt.span+' step'+(nt.span===1?'':'s')+'. Click to edit.'];
  }
  return [head+(on&&nt?' · '+midiName(nt.pitch):''), on ? 'Click to switch off.' : 'Click to switch on'+(STATE.envBrush>=0?', with '+STATE.envBank[STATE.envBrush].name:'')+'.'];
}
// A canvas that handles pointerdown itself and cancels the default also cancels the move of keyboard focus,
// so a number typed into a field a moment ago would keep it (and Space would type instead of playing).
function takeFocus(el){
  try{
    if(el && el.hasAttribute && el.hasAttribute('tabindex')) el.focus({preventScroll:true});
    else{ const a=document.activeElement; if(a && a!==document.body && a.blur) a.blur(); }
  }catch(e){}
}
function bindSeq(){
  const cv=$('seqCanvas'); let paint=null, tap=null;
  cv.addEventListener('pointerdown', e=>{
    const h=seqHit(e); if(!h) return;
    takeFocus(cv); hideTip();
    if(h.kind==='bar'){ STATE.selectedBar=STATE.selectedBar===h.bar?null:h.bar; renderSeqBar(); drawSeq(); return; }
    if(h.kind==='env'){
      const c=STATE.composed; if(c && c.notes[h.v].some(n=>n.step===h.step)) selectNote(h.v,h.step,true);
      return;
    }
    SEQ.cursor.v=h.v; SEQ.cursor.step=h.step;
    if(e.pointerType==='touch'){ tap={v:h.v, step:h.step, x:e.clientX, y:e.clientY}; return; }      // a drag on a touch screen scrolls the page
    paint={v:h.v, value:!STATE.onsets[h.v][h.step], last:h.step}; cv.setPointerCapture(e.pointerId);
    setOnset(h.v,h.step,paint.value); scheduleRegenerate(); e.preventDefault();
  });
  cv.addEventListener('pointermove', e=>{
    if(paint){
      // a quick stroke jumps several steps between two events: the ones it passed are painted too, as long as it stayed
      // on one row (moving down to the next row paints only the step it lands on, not a whole row in between)
      const s=seqStepAt(e), per=seqLayout().perRow, a=Math.floor(paint.last/per)===Math.floor(s/per) ? paint.last : s;
      let changed=false;
      for(let i=Math.min(a,s); i<=Math.max(a,s); i++) if(STATE.onsets[paint.v][i]!==paint.value){ setOnset(paint.v,i,paint.value); changed=true; }
      paint.last=s; if(changed) scheduleRegenerate(); return;
    }
    if(e.pointerType==='touch') return;
    const h=seqHit(e), lines=h && seqTipLines(h);
    if(lines){ cv.style.cursor='pointer'; showTip(e.clientX,e.clientY,lines); } else { cv.style.cursor='default'; hideTip(); }
  });
  cv.addEventListener('pointerleave', hideTip);
  const end=e=>{
    if(paint){ paint=null; regenerate(); histCommit(); }
    else if(tap && e.type==='pointerup' && Math.hypot(e.clientX-tap.x,e.clientY-tap.y)<8){
      setOnset(tap.v,tap.step,!STATE.onsets[tap.v][tap.step]); regenerate(); histCommit();
    }
    tap=null;
  };
  cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
  cv.addEventListener('keydown', e=>{
    if(e.ctrlKey||e.metaKey||e.altKey) return;
    const k=SEQ.cursor, L=seqLayout(), total=L.total, spb=L.spb; let moved=true;
    if(e.key==='ArrowRight') k.step=Math.min(total-1,k.step+1);
    else if(e.key==='ArrowLeft') k.step=Math.max(0,k.step-1);
    else if(e.key==='ArrowDown'){ if(k.v<2) k.v++; else if(k.step+L.perRow<total){ k.v=0; k.step+=L.perRow; } else moved=false; }      // past the bass: the melody of the row below
    else if(e.key==='ArrowUp'){ if(k.v>0) k.v--; else if(k.step-L.perRow>=0){ k.v=2; k.step-=L.perRow; } else moved=false; }
    else if(e.key==='PageDown') k.step=Math.min(total-1, (Math.floor(k.step/spb)+1)*spb);          // the next bar
    else if(e.key==='PageUp') k.step=Math.max(0, (Math.ceil(k.step/spb)-1)*spb);                    // the start of this bar, or of the one before
    else if(e.key==='Home') k.step=0;
    else if(e.key==='End') k.step=total-1;
    else if(e.key==='Enter'){ setOnset(k.v,k.step,!STATE.onsets[k.v][k.step]); regenerate(); histCommit(); }
    else if(e.key==='e'||e.key==='E'){ const c=STATE.composed; if(c && c.notes[k.v].some(n=>n.step===k.step)) selectNote(k.v,k.step,true); }
    else if(/^[0-6]$/.test(e.key)){                      // the number on a note is its preset; 0 gives it back to its lane
      const key=k.v+':'+k.step;
      if(!STATE.onsets[k.v][k.step]){ toast('Switch the step on first (Enter).', 2200); }
      else{ if(e.key==='0') delete STATE.notePreset[key]; else givePreset([key], +e.key-1); afterEnvEdit(); }
    }
    else moved=false;
    if(!moved) return;
    e.preventDefault(); drawSeq(); seqCursorText(); seqVisible(k.step,k.v);
  });
  cv.addEventListener('focus', ()=>{ drawSeq(); seqCursorText(); }); cv.addEventListener('blur', drawSeq);
}

/* ---- the envelope ----------------------------------------------------------------------------------- */
function bindEnv(){
  const cv=$('envCanvas'); let id=null;
  const pos=e=>{ const r=cv.getBoundingClientRect(); return [e.clientX-r.left, e.clientY-r.top]; };
  cv.addEventListener('pointerdown', e=>{
    const [mx,my]=pos(e), h=envPick(mx,my); if(!h) return;
    takeFocus(cv);
    id=h; cv.setPointerCapture(e.pointerId); envDragStart(h); envDragMove(h,mx,my,e.altKey); e.preventDefault();
  });
  cv.addEventListener('pointermove', e=>{
    const [mx,my]=pos(e);
    if(id){ envDragMove(id,mx,my,e.altKey); return; }
    const h=envPick(mx,my); cv.style.cursor=h?'grab':'default';
    if(h!==ENVED.hover){ ENVED.hover=h; drawEnv(); }
  });
  const end=()=>{ if(!id) return; id=null; envDragEnd(); envCommit(); };
  cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);
  cv.addEventListener('pointerleave', ()=>{ if(!id && ENVED.hover){ ENVED.hover=null; drawEnv(); } });
  for(const [fid,f,k] of ENV_FIELDS){
    const el=$(fid); if(!el) continue;
    el.addEventListener('change', ()=>{ const x=parseFloat(el.value); if(!isFinite(x)){ drawEnv(); return; } envSetField(f, x/k); envCommit(); });
  }
  bindBank();
}

/* ---- the basin map ------------------------------------------------------------------------------------ */
function bindBasin(){
  const cv=$('basinCanvas');
  cv.addEventListener('pointermove', e=>{ const s=basinPick(e.clientX,e.clientY); cv.style.cursor=s?'pointer':'default'; if(s) basinTip(e.clientX,e.clientY,s); else hideTip(); });
  cv.addEventListener('pointerleave', hideTip);
  cv.addEventListener('click', e=>{
    const s=basinPick(e.clientX,e.clientY); if(!s) return;
    STATE.seed.chordIdx=s.chordIdx; STATE.seed.eta=s.eta; STATE.seed.prev2Idx=s.prev2Idx;
    refreshSeedSelects(); regenerate(); histCommit();
  });
}

/* ---- keeping ------------------------------------------------------------------------------------------- */
function openCodeBox(text, forLoad){
  const box=$('codeBox'); box.hidden=false; box.value=text||''; $('codeBtns').hidden=false;
  $('btnCodeApply').hidden=!forLoad; box.readOnly=!forLoad;
  box.focus(); if(!forLoad) box.select();
}
function closeCodeBox(){ $('codeBox').hidden=true; $('codeBtns').hidden=true; }
let DEFAULT_JSON='';
function loadStateText(text, what){
  const p=parseStateText(text); if(p.error){ toast(p.error, 4200); return false; }
  const r=restoreState(p.obj); if(!r.ok){ toast(r.error, 4200); return false; }
  afterRestore(); histCommit(); closeCodeBox();
  toast((what||'Loaded')+'.'+(r.warnings.length?' '+r.warnings.length+' value'+(r.warnings.length===1?' was':'s were')+' ignored.':''), 3000);
  return true;
}
function bindKeep(){
  on('btnMidi','click', saveMidi);
  on('btnJson','click', saveState);
  on('btnCopy','click', async()=>{
    const code=stateToCode(); let ok=false;
    try{ await navigator.clipboard.writeText(code); ok=true; }catch(e){}
    if(ok) toast('Code copied ('+code.length+' characters).');
    else{ openCodeBox(code,false); toast('Select the code and copy it by hand.', 3600); }
  });
  on('btnLoad','click', ()=>openCodeBox('',true));
  on('btnCodeApply','click', ()=>loadStateText($('codeBox').value,'Loaded the code'));
  on('btnCodeClose','click', closeCodeBox);
  const fileEl=$('fileState');
  on('btnOpen','click', ()=>fileEl.click());
  fileEl.addEventListener('change', ()=>{
    const f=fileEl.files&&fileEl.files[0]; if(!f) return;
    if(f.size>700000){ toast('That file is too big to be a state.', 3600); fileEl.value=''; return; }
    const rd=new FileReader();
    rd.onload=()=>{ loadStateText(String(rd.result),'Loaded '+f.name); fileEl.value=''; };
    rd.onerror=()=>{ toast('Could not read that file.', 3600); fileEl.value=''; };
    rd.readAsText(f);
  });
  on('btnResetAll','click', ()=>{ restoreState(JSON.parse(DEFAULT_JSON)); afterRestore(); histCommit(); toast('Back to the starting state. Undo brings your piece back.', 3600); });
}

/* ---- the page ----------------------------------------------------------------------------------------------- */
const RAIL_KEY='contrapunctus.rail';
function bindGlobal(){
  document.addEventListener('keydown', e=>{
    if(e.defaultPrevented) return;
    const t=e.target, tag=(t&&t.tagName)||'', typing=tag==='TEXTAREA'||(tag==='INPUT'&&/^(text|number|search)$/.test(t.type||'text'))||(t&&t.isContentEditable);
    if((e.ctrlKey||e.metaKey) && !e.altKey){
      const k=(e.key||'').toLowerCase();
      if(typing) return;
      if(k==='z'){ e.preventDefault(); if(e.shiftKey) redo(); else undo(); }
      else if(k==='y'){ e.preventDefault(); redo(); }
      return;
    }
    if(e.key===' ' && !typing && tag!=='BUTTON' && tag!=='SELECT' && tag!=='SUMMARY' && !(t.getAttribute&&t.getAttribute('role')==='slider') && tag!=='INPUT'){ e.preventDefault(); togglePlay(); }
  });
  const onTheme=()=>{ readTheme(); SEQ.key=''; SEQBAR_KEY=''; SPACE_KEY=''; renderLatKey(); renderRollKey(); renderAll(); };
  const mq=window.matchMedia&&window.matchMedia('(prefers-color-scheme: dark)');
  if(mq){ if(mq.addEventListener) mq.addEventListener('change', onTheme); else if(mq.addListener) mq.addListener(onTheme); }
  new MutationObserver(onTheme).observe(document.documentElement, {attributes:true, attributeFilter:['data-theme']});
  let lastW=0, raf=0;
  const refit=()=>{ fitHeader(); const w=Math.round($('stage').clientWidth); if(w===lastW) return; lastW=w; if(!raf) raf=requestAnimationFrame(()=>{ raf=0; renderAll(); }); };
  if(window.ResizeObserver){ const ro=new ResizeObserver(refit); ro.observe($('stage')); ro.observe($('masthead')); }
  else window.addEventListener('resize', refit);
  if(document.fonts && document.fonts.ready) document.fonts.ready.then(()=>{ readTheme(); renderAll(); });
  // the links of the page's own index scroll the plate into view under the sticky header (the plates carry a scroll margin for it)
  document.querySelectorAll('#jump a').forEach(a=>a.addEventListener('click', e=>{
    const t=document.getElementById((a.getAttribute('href')||'').slice(1)); if(!t) return;
    e.preventDefault();
    const calm=window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if(t.tagName==='DETAILS') t.open=true;
    t.scrollIntoView({behavior:calm?'auto':'smooth', block:'start'});
  }));
  // which groups of the rail were left open is remembered in this browser
  try{
    const saved=JSON.parse(localStorage.getItem(RAIL_KEY)||'null');
    document.querySelectorAll('#rail details.group').forEach(d=>{
      if(saved && typeof saved[d.id]==='boolean') d.open=saved[d.id];
      d.addEventListener('toggle', ()=>{ try{ const o={}; document.querySelectorAll('#rail details.group').forEach(x=>{ o[x.id]=x.open; }); localStorage.setItem(RAIL_KEY, JSON.stringify(o)); }catch(e){} });
    });
  }catch(e){}
  window.addEventListener('pagehide', ()=>{ try{ localStorage.setItem(AUTOSAVE_KEY, JSON.stringify(serializeState({view:true}))); }catch(e){} });
}
