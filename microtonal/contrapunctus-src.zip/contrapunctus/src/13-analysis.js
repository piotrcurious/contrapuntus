/* =====================================================================
   5 · DYNAMICS
   ---------------------------------------------------------------------
   The chord automaton is a map on a finite set of states
   (chord, momentum, chord two back), so every trajectory ends in a cycle and
   the whole state graph can be decomposed exactly, once: every state flows
   into one attractor, and the states that flow into the same one are its
   basin. Everything the "where this rule sits" panel says is read off that
   decomposition, so it describes the rule, not one lucky orbit.

   What is deliberately NOT claimed is chaos. A deterministic map on a few
   hundred states has no Lyapunov exponent and every orbit in it is short; the
   first version labelled 28 of 29 values of lambda "chaotic" because flipping
   a rule cell that the walk uses must change the walk, whatever the rule. What
   can be measured honestly:

     orbit        from the seed: how long it wanders, its period, and how that
                  compares with the length of the piece;
     seed memory  how many attractors there are, and how often changing one
                  seed control (chord, momentum, chord two back) lands in a
                  different one -- 0 means every seed ends in the same cycle;
     dependence   how many of the table's cells change the piece when flipped.
   ===================================================================== */

const ETA_NAMES = ['weak','neutral','strong'];
function baseVocab(){ return vocabFor(STATE.scaleName); }
function etaTable(){ const t=new Uint8Array(NN); for(let d=0;d<NN;d++) t[d]=etaOf(d); return t; }

// a state is (chord i, momentum e, chord two back p in -1..V-1)
function stateCoder(V){
  const P=V+1;
  return { V, P, N:V*3*P,
    enc:(i,e,p)=>(i*3+e)*P+(p+1),
    chordOf:(s)=>Math.floor(Math.floor(s/P)/3),
    etaOf:(s)=>Math.floor(s/P)%3,
    prevOf:(s)=>(s%P)-1 };
}
function seedIdx(vocab){
  const V=vocab.length, p=STATE.seed.prev2Idx;
  return { i:Math.min(Math.max(0,STATE.seed.chordIdx),V-1),
           e:Math.min(2,Math.max(0,STATE.seed.eta)),
           p:(p>=0&&p<V)?p:-1 };
}

// exact decomposition of a functional graph into attractors and basins
function decompose(succ, N){
  const color=new Uint8Array(N), pos=new Int32Array(N), attr=new Int32Array(N).fill(-1), trans=new Int32Array(N);
  const cycles=[], path=[];
  for(let s=0;s<N;s++){
    if(color[s]) continue;
    path.length=0; let x=s;
    while(color[x]===0){ color[x]=1; pos[x]=path.length; path.push(x); x=succ[x]; }
    if(color[x]===1){                                  // this walk closed a new cycle
      const st=pos[x], id=cycles.length;
      cycles.push({id, members:path.slice(st), period:path.length-st, size:0});
      for(let k=st;k<path.length;k++){ attr[path[k]]=id; trans[path[k]]=0; color[path[k]]=2; }
      for(let k=st-1;k>=0;k--){ attr[path[k]]=id; trans[path[k]]=st-k; color[path[k]]=2; }
    } else {                                           // it ran into a state already resolved
      const id=attr[x], t0=trans[x];
      for(let k=path.length-1;k>=0;k--){ attr[path[k]]=id; trans[path[k]]=t0+(path.length-k); color[path[k]]=2; }
    }
  }
  let meanT=0, maxT=0, H=0, longest=0;
  for(let s=0;s<N;s++){ cycles[attr[s]].size++; meanT+=trans[s]; if(trans[s]>maxT) maxT=trans[s]; }
  meanT/=N;
  for(const c of cycles){ const q=c.size/N; H-=q*Math.log2(q); if(c.period>longest) longest=c.period; }
  return {succ, N, attr, trans, cycles, meanT, maxT, H, longest};
}

// the successor of every seedable state under the rule at this lambda
function buildGraph(lambda, vocab){
  vocab = vocab || baseVocab();
  const C=stateCoder(vocab.length), V=C.V, enc=C.enc;
  const tbl=chordTable(lambda), kit=vocabKit(vocab, STATE.tension), eta=etaTable(), plan=choicePlan();
  const succ=new Int32Array(C.N);
  for(let i=0;i<V;i++) for(let p=-1;p<V;p++) for(let e=0;e<3;e++){
    const n=chordNext(i,p,e,tbl,kit,plan);
    succ[enc(i,e,p)] = enc(n, eta[kit.fall[i*V+n]], i);
  }
  const g=decompose(succ, C.N);
  g.C=C; g.vocab=vocab; g.tbl=tbl; g.lambda=lambda;
  return g;
}

// fraction of single-control seed changes (another chord, another momentum, another
// chord two back) that land in a different attractor
function seedMemory(g){
  if(g.cycles.length<2) return 0;
  const {V,enc}=g.C; let pairs=0, diff=0;
  for(let i=0;i<V;i++) for(let e=0;e<3;e++) for(let p=-1;p<V;p++){
    const a=g.attr[enc(i,e,p)];
    for(let i2=0;i2<V;i2++) if(i2!==i){ pairs++; if(g.attr[enc(i2,e,p)]!==a) diff++; }
    for(let e2=0;e2<3;e2++) if(e2!==e){ pairs++; if(g.attr[enc(i,e2,p)]!==a) diff++; }
    for(let p2=-1;p2<V;p2++) if(p2!==p){ pairs++; if(g.attr[enc(i,e,p2)]!==a) diff++; }
  }
  return pairs ? diff/pairs : 0;
}
function seedOrbit(g, i, e, p){
  const s=g.C.enc(i,e,p), c=g.cycles[g.attr[s]];
  return {state:s, transient:g.trans[s], period:c.period, cycle:c.id, basin:c.size};
}
// fixed: stands still. loop: goes round at least twice inside the piece.
// tour: the piece ends before the orbit has closed once.
function orbitClass(period, pieceChords){
  if(period<=1) return 'fixed';
  return period*2<=pieceChords ? 'loop' : 'tour';
}

// Everything that decides the chord automaton; the analyses are cached on it.
// (The first version left the "take" control out of the key, so the sweep and the
// basin map kept showing the previous stance after it was changed.)
function ruleKey(){
  return [NN, STATE.root, STATE.scaleName, STATE.extended?1:0, STATE.colour?1:0, STATE.tension.toFixed(4), chordChoiceSig(),
          profileSig(CHORD_AXES,STATE.profiles.chord), flipSig(STATE.cellFlips.chord)].join('|');
}

let SWEEP_CACHE=null;
function sweep(steps){
  const sd=STATE.seed, key=ruleKey()+'|'+[sd.chordIdx,sd.eta,sd.prev2Idx,steps].join(',');
  if(SWEEP_CACHE && SWEEP_CACHE.key===key) return SWEEP_CACHE.val;
  const vocab=baseVocab(), s0=seedIdx(vocab), out=[];
  for(let k=0;k<=steps;k++){
    const lam=k/steps, g=buildGraph(lam, vocab), o=seedOrbit(g, s0.i, s0.e, s0.p);
    out.push({lam, period:o.period, transient:o.transient, A:g.cycles.length, S:seedMemory(g),
              H:g.H, longest:g.longest, meanT:g.meanT, V:vocab.length});
  }
  SWEEP_CACHE={key, val:out};
  return out;
}

// the whole state graph at the current lambda, attractors ranked by basin size
let BASIN_CACHE=null;
function basins(){
  const key=ruleKey()+'|'+STATE.lamC.toFixed(4);
  if(BASIN_CACHE && BASIN_CACHE.key===key) return BASIN_CACHE.val;
  const vocab=baseVocab(), g=buildGraph(STATE.lamC, vocab), C=g.C;
  const list=g.cycles.slice().sort((a,b)=>b.size-a.size || a.id-b.id);
  const rank=new Map(); list.forEach((a,r)=>{ rank.set(a.id,r); a.rank=r; a.chords=a.members.map(m=>vocab[C.chordOf(m)]); });
  const val={vocab, V:C.V, P:C.P, N:C.N, enc:C.enc, succ:g.succ, attr:g.attr, trans:g.trans,
             list, rank, maxT:g.maxT, graph:g};
  BASIN_CACHE={key, val};
  return val;
}

// the orbit from the seed, and what the whole graph says about the rule
function currentDynamics(pieceChords){
  const b=basins(), g=b.graph, s0=seedIdx(b.vocab), o=seedOrbit(g, s0.i, s0.e, s0.p);
  const cyc=g.cycles[o.cycle];
  return {orbit:{transient:o.transient, period:o.period, cls:orbitClass(o.period, pieceChords),
                 chords:cyc.members.map(m=>b.vocab[g.C.chordOf(m)]), basin:o.basin},
          attractors:g.cycles.length, memory:seedMemory(g), entropy:g.H, meanT:g.meanT, maxT:g.maxT,
          longest:g.longest, V:b.V, N:g.N, pieceChords};
}

// How much of the rule the piece depends on: flip each cell of the table in turn and
// ask whether the first `horizon` chords from the seed change. Most cells are never
// consulted, so most flips change nothing; the cells that do matter are the ones the
// walk chose and the ones that would have beaten the choice. Unlike flipping only the
// cells the walk uses -- which cannot fail to change it -- this does not saturate.
function cellDependence(lambda, horizon){
  const vocab=baseVocab(), V=vocab.length, tbl=chordTable(lambda);
  const kit=vocabKit(vocab, STATE.tension), eta=etaTable(), plan=choicePlan(), s0=seedIdx(vocab);
  const H=Math.max(2, horizon|0);
  const run=(t)=>{
    const o=new Int16Array(H); let i=s0.i, e=s0.e, p=s0.p; o[0]=i;
    for(let k=1;k<H;k++){ const n=chordNext(i,p,e,t,kit,plan); e=eta[kit.fall[i*V+n]]; p=i; i=n; o[k]=i; }
    return o;
  };
  const base=run(tbl), alt={t:tbl.t.slice(), costs:tbl.costs}, cells=[];
  let first=H;
  for(let f=0; f<tbl.t.length; f++){
    alt.t[f]^=1;
    const w=run(alt); let d=-1;
    for(let k=0;k<H;k++) if(w[k]!==base[k]){ d=k; break; }
    alt.t[f]^=1;
    if(d>=0){ cells.push(f); if(d<first) first=d; }
  }
  return {changed:cells.length, size:tbl.t.length, fraction:cells.length/tbl.t.length, cells,
          first:cells.length?first:-1, horizon:H};
}

// Which of the table's cells can this piece ever consult? A cell is the coordinate of a move
// (root fall, tension bucket against the aim, kind of chord, incoming momentum), and a
// vocabulary of V chords has only V x V moves, so most of the table is never asked: with
// the diatonic seven at most 147 of the 540 cells. Flipping a cell outside this set is
// legal and does nothing. The momentum a move arrives with is bounded the same way: it is
// the seed's, or the class of some earlier root fall.
function cellReach(segments){
  const reach=new Uint8Array(CHORD_STR.size);
  const eta=etaTable();
  const s0=seedState();
  let etaSet=new Set([s0.eta]);
  const vocabAt=(g)=>vocabFor(scaleForSeg(g));
  for(let g=1; g<segments; g++){
    const A=vocabAt(g-1), B=vocabAt(g), target=targetForSeg(g);
    const seen=new Set();
    for(const a of A) for(const b of B){
      const d=rootFall(a.rootPc,b.rootPc), t=tensionBucket(b.tensionVal-target), key=d+','+t+','+b.ring;
      if(seen.has(key)) continue; seen.add(key);
      for(const e of etaSet) reach[cIdx(d,t,b.ring,e)]=1;
    }
    const next=new Set(etaSet);
    for(const k of seen) next.add(eta[+k.split(',')[0]]);
    etaSet=next;
  }
  return reach;
}

function detectSequence(chords){
  const d=[];
  for(let i=1;i<chords.length;i++) d.push(rootFall(chords[i-1].rootPc, chords[i].rootPc));
  let best=null;
  for(let k=2;k<=4;k++) for(let i=0;i+2*k<=d.length;i++){
    let ok=true;
    for(let j=0;j<k;j++) if(d[i+j]!==d[i+k+j]){ ok=false; break; }
    if(ok && (!best||k>best.k)) best={i,k};
  }
  return best;
}

/* =====================================================================
   6 · COMPOSE
   ===================================================================== */
function compose(){
  ensureGrids();
  const total = STATE.bars*STATE.stepsPerBar;
  const L = segLen();
  const segments = Math.ceil(total/L);

  const walk = runChordWalk(segments);
  const chords = walk.map(w=>w.chord);
  const voices = runVoiceWalk(chords);

  const pitches=[[],[],[]], deco=[[],[],[]], fell=[[],[],[]], look=[[],[],[]];
  for(let v=0;v<3;v++){ pitches[v]=new Array(total).fill(null); deco[v]=new Array(total).fill(false); fell[v]=new Array(total).fill(false); }
  const voiceCells=new Set(), voiceCellSeq=[], vcell=[0,1,2].map(()=>new Array(total).fill(null));
  for(const r of voices){
    for(let v=0;v<3;v++){
      pitches[v][r.step]=r.pitches[v]; deco[v][r.step]=r.deco[v]; fell[v][r.step]=r.fellBack[v]; look[v][r.step]=r.look[v];
      const c=r.cells[v];
      if(c){ const f=vIdx(c.kappa,c.mu,c.phi,c.sigma,c.gamma); voiceCells.add(f); voiceCellSeq.push(f); vcell[v][r.step]=f; }
    }
  }
  const chordCells=new Set(), chordCellSeq=[];
  for(const w of walk){
    if(!w.cell) continue;
    const f=cIdx(w.cell.d,w.cell.tau,w.cell.rho,w.cell.eta);
    chordCells.add(f); chordCellSeq.push(f);
  }

  const out = { total, segments, L, walk, chords, pitches, deco, fell, look,
    chordCells, chordCellSeq, voiceCells, voiceCellSeq, vcell, sequence: detectSequence(chords) };
  out.sweep = sweep(28);
  out.basin = basins();
  out.dyn = currentDynamics(segments);
  out.dep = cellDependence(STATE.lamC, segments);
  out.reach = cellReach(segments);
  out.cls = out.dyn.orbit.cls;

  if(STATE.selectedSeg >= segments) STATE.selectedSeg = Math.max(0, segments-1);
  STATE.composed = out;
  return out;
}

/* ---- reference Life ---- */
function randomLife(w,h,d){ const g=new Uint8Array(w*h); for(let i=0;i<g.length;i++) g[i]=Math.random()<d?1:0; return g; }
function stepLife(g,w,h){
  const n=new Uint8Array(w*h);
  for(let y=0;y<h;y++) for(let x=0;x<w;x++){
    let c=0;
    for(let dy=-1;dy<=1;dy++) for(let dx=-1;dx<=1;dx++){
      if(!dx&&!dy) continue;
      c+=g[((y+dy+h)%h)*w+((x+dx+w)%w)];
    }
    n[y*w+x] = g[y*w+x] ? ((c===2||c===3)?1:0) : (c===3?1:0);
  }
  return n;
}
