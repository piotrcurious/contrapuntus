/* =====================================================================
   10 · SCORE
   ---------------------------------------------------------------------
   Reads the notes resolved in 30-notes.js and nothing else, so what is drawn
   here is what the audio scheduler plays. Chord names, the playhead and the
   pitch gutter are DOM; only the notes themselves are painted.
   ===================================================================== */
let GL_ROLL=null;
const ROLL={LO:33, HI:88, TOP:36, SOUND:28, BASE:340};
const HOVER_NOTE={nt:null};

function rollGeom(){
  const c=STATE.composed, cv=$('rollCanvas'), W=cv.clientWidth||600, H=cv.clientHeight||ROLL.BASE;
  const soundH=STATE.show.sounding?ROLL.SOUND:0, rollH=H-soundH, plotH=rollH-ROLL.TOP;
  const total=c?c.total:STATE.bars*STATE.stepsPerBar;
  return {W,H,rollH,soundH,plotH,total, stepW:W/total,
    // the axis is in semitones whatever the division: a pitch (in steps) is placed by where it sounds, a height gives back a pitch in steps
    yOf:(m)=> ROLL.TOP + plotH*(1-(semis(m)-ROLL.LO)/(ROLL.HI-ROLL.LO)),
    mOf:(y)=> (ROLL.LO + (1-(y-ROLL.TOP)/plotH)*(ROLL.HI-ROLL.LO))*NN/12};
}
function scalePCsNow(){ return scaleSteps(STATE.scaleName).map(o=>(STATE.root+o)%NN); }

// the roots of the chords a what-if path would have played, as outlines in the bass register
function ghostBassOutlines(c, g){
  const b=(STATE.show.ghosts && HOVER.branch) ? HOVER.branch : null; if(!b) return [];
  const out=[];
  for(let k=0;k<b.chords.length;k++){
    const seg=STATE.selectedSeg+k; if(seg>=c.chords.length) break;
    const alt=b.chords[k], real=c.chords[seg];
    if(alt.key===real.key) continue;
    let ref=4*NN; for(let s=seg*c.L; s<Math.min(c.total,(seg+1)*c.L); s++){ if(c.pitches[2][s]!=null){ ref=c.pitches[2][s]; break; } }
    let best=null, bd=Infinity;
    for(let m=REGISTERS[2].lo;m<=REGISTERS[2].hi;m++) if(pcOf(m)===alt.rootPc && Math.abs(m-ref)<bd){ bd=Math.abs(m-ref); best=m; }
    if(best!=null) out.push({x0:seg*c.L*g.stepW, x1:Math.min(c.total,(seg+1)*c.L)*g.stepW, y:g.yOf(best)});
  }
  return out;
}
function outlineRect(P,x,y,w,h,col,t){
  P.rect(x,y,w,t,col); P.rect(x,y+h-t,w,t,col); P.rect(x,y,t,h,col); P.rect(x+w-t,y,t,h,col);
}
function drawRoll(){
  const c=STATE.composed; if(!c||!c.notes||!GL_ROLL) return;
  const g=rollGeom(), P=GL_ROLL;
  if(!P.begin()) return;
  const dark=THEME.dark, scalePCs=scalePCsNow();
  for(let m=REGISTERS[2].lo; m<=REGISTERS[0].hi; m++){
    if(!scalePCs.includes(pcOf(m))) continue;
    P.rect(0,g.yOf(m)-0.5,g.W,1, rgba(THEME.grid, pcOf(m)===STATE.root?0.42:0.18));
  }
  for(let b=0;b<=STATE.bars;b++) P.rect(b*STATE.stepsPerBar*g.stepW-0.5, ROLL.TOP-4, 1, g.rollH-ROLL.TOP+4, rgba(THEME.grid, b%4===0?0.5:0.26));
  const segW=c.L*g.stepW;
  for(let s=1;s<c.segments;s++) if((s*c.L)%STATE.stepsPerBar!==0) P.rect(s*segW-0.5, ROLL.TOP-4, 1, g.rollH-ROLL.TOP+4, rgba(THEME.grid,0.16));

  for(const o of ghostBassOutlines(c,g)) outlineRect(P, o.x0+1, o.y-3.5, Math.max(2,o.x1-o.x0-2), 7, rgba(THEME.ink,0.7), 1.2);

  const sel=STATE.selectedNote, hov=HOVER_NOTE.nt;
  for(let v=0; v<3; v++){
    const col=THEME.voice[v];
    for(const nt of c.notes[v]){
      const x=nt.step*g.stepW, y=g.yOf(nt.pitch), w=Math.max(2, nt.e.gate*g.stepW);
      const alpha = nt.fell ? 0.34 : (nt.deco ? 0.62 : 0.96);
      P.rect(x+0.5, y-3.5, w, 7, rgba(col,alpha));
      P.rect(x+0.5, y-4.5, 1.8, 9, rgba(col,Math.min(1,alpha+0.25)));
      if(STATE.show.tails && nt.tailSteps>0.02){
        const tw=nt.tailSteps*g.stepW, n=8;
        for(let i=0;i<n;i++){
          const t0=i/n, t1=(i+1)/n;
          P.rect(x+0.5+w+tw*t0, y-2, tw*(t1-t0)+0.6, 4, rgba(col, alpha*0.55*(1-t1)));
        }
      }
      if(nt.anchored || nt.pinned) P.disc(x+1.5, y, 5, rgba(THEME.hand,0.96), 0.55);
      if((sel && sel.v===nt.v && sel.step===nt.step)) outlineRect(P, x-1, y-6, w+3, 12, rgba(THEME.ink,0.95), 1.4);
      else if(hov===nt) outlineRect(P, x-1, y-6, w+3, 12, rgba(THEME.ink,0.55), 1);
    }
  }
  if(STATE.show.sounding){
    const top=g.rollH+2;
    P.rect(0,g.rollH,g.W,g.soundH, rgba(THEME.grid,0.08));
    for(let s=0;s<c.total;s++){
      const sd=c.sounding[s], h=4+18*clamp01(sd.voices/6);
      P.rect(s*g.stepW+0.5, top+(g.soundH-4)-h, Math.max(1,g.stepW-1), h, rgba(mix(THEME.permit, THEME.forbid, clamp01(sd.tension/0.55)), 0.85));
      if(sd.foreign>0) P.rect(s*g.stepW+0.5, top-1, Math.max(1,g.stepW-1), 2, rgba(THEME.forbid,0.95));
    }
  }
  P.end();
  syncRollLabels(c,g);
}

/* ---- chord names, pitch gutter, key -------------------------------------- */
function chordCellOf(w){ return (w && w.cell) ? cIdx(w.cell.d,w.cell.tau,w.cell.rho,w.cell.eta) : null; }
function syncRollLabels(c,g){
  const host=$('rollLabels'); host.textContent='';
  const gh=(STATE.show.ghosts && HOVER.branch) ? HOVER.branch : null;
  for(let s=0; s<c.chords.length; s++){
    const x=s*c.L*g.stepW, w=c.L*g.stepW;
    const nv=(STATE.vetoChord[s]||[]).length;
    const b=mk('button','seg'+(STATE.pins[s]?' pin':'')+(nv?' veto':'')+(s===STATE.selectedSeg?' sel':'')+(STATE.playing&&s===NOW.seg?' now':''));
    b.type='button'; b.style.left=x+'px'; b.style.width=Math.max(0,w-1)+'px';
    b.textContent=(STATE.pins[s]?'◆ ':'')+c.chords[s].roman;
    b.setAttribute('aria-label','Chord '+(s+1)+', '+c.chords[s].roman+(STATE.pins[s]?', pinned':'')+(nv?', '+nv+' move'+(nv===1?'':'s')+' ruled out':'')+'. Show what else the rule could have played.');
    const f=chordCellOf(c.walk[s]);
    b.addEventListener('click', ()=>selectSeg(s));
    b.addEventListener('mouseenter', ()=>{ if(f!=null){ HOVER.link={set:'chord', f}; if(STATE.lattice.set==='chord') drawLattice(); } });
    b.addEventListener('mouseleave', ()=>{ if(HOVER.link){ HOVER.link=null; drawLattice(); } });
    host.appendChild(b);
    if(gh && s>=STATE.selectedSeg && (s-STATE.selectedSeg)<gh.chords.length){
      const alt=gh.chords[s-STATE.selectedSeg];
      if(alt.key!==c.chords[s].key){
        const e=mk('div','seg ghost'); e.style.left=x+'px'; e.style.width=Math.max(0,w-1)+'px';
        e.textContent=alt.roman; host.appendChild(e);
      }
    }
  }
  if(STATE.show.sounding){
    const d=mk('div','note','what is ringing at the start of each step'); d.style.top=(g.rollH+3)+'px'; d.style.left='4px'; d.style.background='transparent';
    d.style.color=THEME.str.dim; host.appendChild(d);
  }
}
function renderRollGutter(){
  const host=$('rollGutter'); if(!host) return;
  host.textContent='';
  const g=rollGeom();
  for(let m=Math.ceil(ROLL.LO*NN/12); m<=Math.floor(ROLL.HI*NN/12); m++){
    if(pcOf(m)!==STATE.root) continue;
    const y=g.yOf(m);
    host.appendChild(mk('div','pl',midiName(m))).style.top=y+'px';
    const ln=mk('div','ln'); ln.style.top=y+'px'; host.appendChild(ln);
  }
}
function renderRollKey(){
  const el=$('rollKey'); if(!el) return;
  el.textContent='';
  const add=(cls,text,color)=>{ const s=mk('span'); const i=mk('i','sw '+cls); if(color) i.style.background=color; s.appendChild(i); s.appendChild(document.createTextNode(text)); el.appendChild(s); };
  add('', 'melody', THEME.str.voice[0]); add('', 'middle', THEME.str.voice[1]); add('', 'bass', THEME.str.voice[2]);
  add('ring hand', 'anchored or pinned by you');
  const p=mk('span','','paler bar = passing note, not a chord tone'); el.appendChild(p);
  const q=mk('span','','faint bar = the rule ran out of legal moves and fell back'); el.appendChild(q);
}

/* ---- the playhead is a DOM line, not a redraw ------------------------------ */
function setPlayhead(stepFloat){
  const on = stepFloat!=null && stepFloat>=0, total=STATE.bars*STATE.stepsPerBar;
  const rh=$('rollHead');
  if(rh){ rh.hidden=!on; if(on) rh.style.transform='translateX('+(stepFloat/total*$('rollWrap').clientWidth-1)+'px)'; }
  const sh=$('seqHead');
  if(sh){
    sh.hidden=!on;
    if(on){                         // the sequencer is wrapped into rows: the line is as tall as one row and moves down as the piece does
      const L=SEQ.L||seqLayout(), r=Math.max(0,Math.min(L.rows-1, Math.floor(stepFloat/L.perRow))), x=(stepFloat-r*L.perRow)*L.stepW-1;
      sh.style.top='0'; sh.style.bottom='auto'; sh.style.height=L.sysH+'px';
      sh.style.transform='translate('+x+'px,'+(r*L.pitch)+'px)';
    }
  }
}

/* ---- pointer: hover a note, click to select it, click empty space to anchor ---- */
function rollNoteAt(mx,my){
  const c=STATE.composed; if(!c||!c.notes) return null;
  const g=rollGeom(); let best=null, bd=1e9;
  for(let v=0;v<3;v++) for(const nt of c.notes[v]){
    const x0=nt.step*g.stepW-2, body=x0+2+Math.max(4,nt.e.gate*g.stepW), x1=body+(STATE.show.tails?nt.tailSteps*g.stepW:0), y=g.yOf(nt.pitch);
    if(mx<x0 || mx>x1 || Math.abs(my-y)>6.5) continue;
    // the key-down part counts for more than the fading tail, and where two notes overlap the one that began later wins (it is the one the pointer has just reached)
    const d=Math.abs(my-y)+(mx>body?4:0)+(mx<x0+2?3:0)-nt.step*1e-4;
    if(d<bd){ bd=d; best=nt; }
  }
  return best;
}
function noteReadout(nt){
  const el=$('rollRead'); if(!el) return;
  const c=STATE.composed;
  if(!nt){
    el.innerHTML='Hover a note to see the rule cell that chose it. Click a note to see, under the score, what else the rule could have played there.<br>&nbsp;';
    return;
  }
  const f=c.vcell[nt.v][nt.step];
  const bar=Math.floor(nt.step/STATE.stepsPerBar)+1, st=nt.step%STATE.stepsPerBar+1;
  const byHand=nt.anchored||nt.pinned;
  el.innerHTML='<b>'+VOICE_NAMES[nt.v]+'</b> · bar '+bar+', step '+st+' · <b>'+midiName(nt.pitch)+'</b>'+(Math.abs(nt.cents)>0.05?' '+signed(nt.cents)+'¢':'')
    + (nt.anchored?'   ·   <span class="hand">anchored by you</span>':'')
    + (nt.pinned?'   ·   <span class="hand">pinned by you</span>':'')
    + '<br>'+(f!=null && !byHand ? voiceCellWords(f)+(nt.fell?'   ·   <b>no legal move: fallback</b>':'') : (byHand?'placed by hand, not chosen by the rule':'figure note, not chosen by the rule'));
}
function rollHover(mx,my){
  const nt=rollNoteAt(mx,my);
  if(nt!==HOVER_NOTE.nt){
    HOVER_NOTE.nt=nt;
    noteReadout(nt);
    const c=STATE.composed, f=nt?c.vcell[nt.v][nt.step]:null;
    HOVER.link = (nt && f!=null) ? {set:'voice', f} : null;
    if(STATE.lattice.set==='voice') drawLattice();
    drawRoll();
  }
  return nt;
}
// any: a pitch anywhere in the division, not only a note of the scale
function rollClickAt(mx,my,any){
  const c=STATE.composed; if(!c) return;
  const g=rollGeom();
  const nt=rollNoteAt(mx,my);
  if(nt){ STATE.selectedNote={v:nt.v, step:nt.step}; return {kind:'select'}; }
  if(my>g.rollH) return null;
  const step=Math.floor(mx/g.stepW);
  if(step<0||step>=c.total) return null;
  const approx=g.mOf(my);
  if(approx < REGISTERS[0].lo-4*NN/12 || my<ROLL.TOP-2) return null;
  const pcs=scalePCsNow();
  let best=null, bd=1e9;
  for(let m=REGISTERS[0].lo;m<=REGISTERS[0].hi;m++){
    if(!any && !pcs.includes(pcOf(m))) continue;
    const d=Math.abs(m-approx); if(d<bd){ bd=d; best=m; }
  }
  if(best==null) return null;
  return {kind:'anchor', step, pitch:best};
}
