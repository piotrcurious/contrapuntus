/* =====================================================================
   11b · THE ENVELOPE BANK, AND WHAT THE SEQUENCER'S BAR OFFERS
   ---------------------------------------------------------------------
   Six envelopes (a name, A, D, S, R, and a note-off that is a fraction of
   the note's length) that the whole piece shares. A note is given one when it is
   painted into the sequencer (the brush: "new notes take") or later from the
   editor; a note with none follows its lane's own. Change a preset and every
   note that has it changes with it. A note can still be shaped by hand on top
   of its preset: that shaping is its own.

   Resolution, in 30-notes.js:  the note's own shaping  >  its preset  >  its lane.
   ===================================================================== */
const BANK = { mode:'note', k:0 };
const NAME_RE = /^[A-Za-z0-9][A-Za-z0-9 .+'-]{0,13}$/;
const SVGNS = 'http://www.w3.org/2000/svg';

function nominalSpan(){ return Math.max(1, STATE.stepsPerBar/4); }
// the editor's stand-in for a preset: a note one beat long, drawn with the preset's own values
function presetTarget(k){
  const b=STATE.envBank[k], sps=secondsPerStep(), span=nominalSpan(), e=resolveEnv(b, null, span, sps);
  const sel=STATE.selectedNote;
  return { v:sel?sel.v:1, step:-1, pitch:0, cents:0, e, span, tailSteps:e.tail/sps, isPreset:true, k };
}
function liveNoteKeys(obj){
  const out=[]; for(const k of Object.keys(obj)){ const [v,s]=k.split(':').map(Number); if(STATE.onsets && STATE.onsets[v] && STATE.onsets[v][s]) out.push(k); }
  return out;
}
function presetUsage(){
  const u=new Array(ENV_BANK_SIZE).fill(0);
  for(const k of liveNoteKeys(STATE.notePreset)){ const p=STATE.notePreset[k]; if(p>=0 && p<ENV_BANK_SIZE) u[p]++; }
  return u;
}

/* ---- a thumbnail of an envelope: the curve the audio would play, for a note one beat long -------------- */
function envThumb(base){
  const sps=secondsPerStep(), e=resolveEnv(base, null, nominalSpan(), sps);
  const T=Math.max(e.a+e.d, e.gateSec)+e.tail+0.02, N=28;
  let d='';
  for(let i=0;i<=N;i++){
    const t=T*i/N, y=15-envLevel(e,t,e.gateSec)*13.2;
    d+=(i?'L':'M')+(1+34*i/N).toFixed(1)+' '+y.toFixed(1);
  }
  const svg=document.createElementNS(SVGNS,'svg'); svg.setAttribute('viewBox','0 0 36 16'); svg.setAttribute('aria-hidden','true');
  const p=document.createElementNS(SVGNS,'path'); p.setAttribute('d',d); svg.appendChild(p);
  return svg;
}
function bankChip(o){
  const b=mk('button','bchip'+(o.assigned?' assigned':'')); b.type='button';
  b.setAttribute('aria-pressed', String(!!o.pressed)); if(o.title) b.title=o.title; if(o.fk) b.dataset.fk=o.fk;
  b.appendChild(envThumb(o.base)); b.appendChild(mk('span','k',o.key)); b.appendChild(mk('span','nmx',o.label));
  b.addEventListener('click', o.onClick);
  return b;
}
function focusKeyIn(host){ const a=document.activeElement; return (a && a.dataset && a.dataset.fk && host.contains(a)) ? a.dataset.fk : null; }
function restoreFocusIn(host, k){
  if(!k) return;
  const el=[...host.querySelectorAll('[data-fk]')].find(e=>e.dataset.fk===k);
  if(el) try{ el.focus({preventScroll:true}); }catch(e){}
}

/* ---- giving envelopes to notes ---------------------------------------------------------------------------- */
function givePreset(keys, k){
  for(const key of keys){ STATE.notePreset[key]=k; delete STATE.noteEnv[key]; }
}
function laneNoteKeys(vs){
  const out=[]; for(const v of vs) for(let s=0;s<STATE.onsets[v].length;s++) if(STATE.onsets[v][s]) out.push(v+':'+s);
  return out;
}
function selectedKey(){ const n=STATE.selectedNote; return n ? n.v+':'+n.step : null; }
function afterEnvEdit(){ refreshNotes(); drawSeq(); drawRoll(); drawEnv(); renderBank(); renderSeqBar(); envCommit(); }

function renderBank(){
  const host=$('envBank'); if(!host) return;
  const fk=focusKeyIn($('plateEnv'));
  document.querySelectorAll('#envMode button').forEach(b=>b.setAttribute('aria-pressed', String(b.dataset.mode===BANK.mode)));
  const sel=STATE.selectedNote, key=selectedKey(), have=key!=null ? STATE.notePreset[key] : undefined, use=presetUsage();
  host.textContent=''; host.classList.remove('inline');
  const tools=$('envTools'), note=$('envBankNote'), nameRow=$('rowEnvName');
  tools.textContent='';
  const tool=(label, title, fn, cls)=>{ const b=mk('button','tiny'+(cls?' '+cls:''),label); b.type='button'; b.title=title; b.dataset.fk='tool:'+label; b.addEventListener('click', fn); tools.appendChild(b); return b; };
  if(BANK.mode==='note'){
    $('lblBank').textContent=sel ? 'Give this note an envelope' : 'Select a note, then give it an envelope';
    nameRow.hidden=true;
    const own=sel ? STATE.voiceEnv[sel.v] : STATE.voiceEnv[0];
    const dis = !sel;
    const c0=bankChip({base:own, key:'–', label:'lane’s own', pressed:sel && have==null, title:'The envelope of the '+(sel?VOICE_NAMES[sel.v]:'lane')+' lane: no preset', fk:'bank:own',
      onClick:()=>{ if(!sel) return; delete STATE.notePreset[key]; afterEnvEdit(); }});
    c0.disabled=dis; host.appendChild(c0);
    STATE.envBank.forEach((b,k)=>{
      const c=bankChip({base:b, key:String(k+1), label:b.name, pressed:sel && have===k, assigned:false, title:b.name+(use[k]?' · on '+use[k]+' note'+(use[k]===1?'':'s'):'')+'. Click to give it to the selected note.', fk:'bank:'+k,
        onClick:()=>{ if(!sel) return; givePreset([key], k); afterEnvEdit(); }});
      c.disabled=dis; host.appendChild(c);
    });
    if(sel){
      tool('Make it the lane’s own','The lane’s own envelope becomes this note’s: the notes of the lane that have no preset follow', ()=>{ makeLaneDefault([sel.v]); });
      tool('All lanes’ own','Every lane’s own envelope becomes this note’s', ()=>{ makeLaneDefault([0,1,2]); });
      const t=tool('Reset this note','Take away the shaping and the preset: back to the lane’s own', ()=>{ delete STATE.noteEnv[key]; delete STATE.notePreset[key]; afterEnvEdit(); });
      t.disabled = STATE.noteEnv[key]==null && have==null;
    }
    note.textContent = sel
      ? 'A preset is shared: changing it later changes every note that has it. Dragging the envelope here shapes this note alone, on top of its preset.'
      : 'The bank is six envelopes shared by the whole piece. Select a note in the score or in the rhythm plate to give it one.';
  } else {
    $('lblBank').textContent='The six shared envelopes: pick one to edit';
    nameRow.hidden=false;
    STATE.envBank.forEach((b,k)=>{
      host.appendChild(bankChip({base:b, key:String(k+1), label:b.name, pressed:BANK.k===k, assigned:sel && have===k, title:b.name+(use[k]?' · on '+use[k]+' note'+(use[k]===1?'':'s'):' · no note has it yet'), fk:'bank:'+k,
        onClick:()=>{ BANK.k=k; drawEnv(); renderBank(); }}));
    });
    const nm=$('envName'); if(nm && document.activeElement!==nm){ nm.value=STATE.envBank[BANK.k].name; nm.removeAttribute('aria-invalid'); }
    const k=BANK.k, vn=sel?VOICE_NAMES[sel.v]:'';
    const t1=tool('Give to this note','Give '+STATE.envBank[k].name+' to the selected note', ()=>{ if(!sel) return; givePreset([key], k); afterEnvEdit(); }); t1.disabled=!sel;
    const t2=tool('Give to this lane','Give '+STATE.envBank[k].name+' to every note of the '+(vn||'selected')+' lane', ()=>{ if(!sel) return; givePreset(laneNoteKeys([sel.v]), k); afterEnvEdit(); }); t2.disabled=!sel;
    tool('Give to every note','Give '+STATE.envBank[k].name+' to every note of the piece', ()=>{ givePreset(laneNoteKeys([0,1,2]), k); afterEnvEdit(); });
    const t4=tool('Copy this note’s shape in','Make the preset what the selected note sounds like now', ()=>{
      const nt=envTargetNote(); if(!nt) return; const b=STATE.envBank[k], e=nt.e;
      b.a=e.a; b.d=e.d; b.s=e.s; b.r=e.r; b.gateRatio=Math.min(ENV_LIMITS.gateRatio[1], Math.max(ENV_LIMITS.gateRatio[0], e.gate/Math.max(1,nt.span)));
      afterEnvEdit();
    }); t4.disabled=!sel;
    const t5=tool('Reset preset','Back to the preset the page started with', ()=>{ STATE.envBank[k]=defaultEnvBank()[k]; afterEnvEdit(); });
    t5.disabled=BANK_FIELDS.every(f=>STATE.envBank[k][f]===defaultEnvBank()[k][f]);
    note.textContent='Editing '+STATE.envBank[k].name+': '+(use[k]?use[k]+' note'+(use[k]===1?'':'s')+' in the piece have it and will follow every change.':'no note has it yet; give it to some with the buttons, or paint with it in the rhythm plate.');
  }
  restoreFocusIn($('plateEnv'), fk);
}
function envTargetNote(){
  const n=STATE.selectedNote, c=STATE.composed;
  return (n && c && c.notes) ? (c.notes[n.v].find(x=>x.step===n.step)||null) : null;
}
function makeLaneDefault(vs){
  const nt=envTargetNote(); if(!nt) return;
  for(const v of vs){
    const b=STATE.voiceEnv[v];
    b.a=nt.e.a; b.d=nt.e.d; b.s=nt.e.s; b.r=nt.e.r; b.gateRatio=Math.min(ENV_LIMITS.gateRatio[1], Math.max(ENV_LIMITS.gateRatio[0], nt.e.gate/Math.max(1,nt.span)));
    for(const k of Object.keys(STATE.noteEnv)) if(k.startsWith(v+':')) delete STATE.noteEnv[k];
  }
  afterEnvEdit();
}
function bindBank(){
  document.querySelectorAll('#envMode button').forEach(b=>b.addEventListener('click', ()=>{
    BANK.mode=b.dataset.mode;
    if(BANK.mode==='bank'){ const key=selectedKey(), p=key!=null?STATE.notePreset[key]:undefined; if(p!=null) BANK.k=p; }
    ENVED.lock=null; drawEnv(); renderBank();
  }));
  const nm=$('envName');
  nm.addEventListener('input', ()=>{
    const v=nm.value.trim();
    if(NAME_RE.test(v)){ nm.removeAttribute('aria-invalid'); STATE.envBank[BANK.k].name=v; renderBank(); renderSeqBar(); drawEnv(); autosaveSoon(); }
    else nm.setAttribute('aria-invalid','true');
  });
  nm.addEventListener('change', ()=>{
    const v=nm.value.trim();
    if(!NAME_RE.test(v)){ nm.value=STATE.envBank[BANK.k].name; nm.removeAttribute('aria-invalid'); toast('A name starts with a letter or digit and has up to 14 letters, digits, spaces and . + ’ -', 3600); return; }
    envCommit();
  });
}

/* ---- the sequencer's bar: bars to a row, the brush, and the bar you picked ------------------------------------ */
let SEQBAR_KEY='';
function renderSeqBar(){
  const host=$('seqBar'); if(!host) return;
  const L=seqLayout(), sb=STATE.selectedBar, ov=sb!=null ? (STATE.barOverrides[sb]||{}) : null;
  const key=[STATE.seqBars, L.bars, L.per, STATE.envBrush, STATE.envBank.map(b=>[b.name,b.a,b.d,b.s,b.r,b.gateRatio].join(',')).join('|'), sb, ov?(ov.scale||''):'', scaleNames().join(','), NN, THEME.dark?1:0, secondsPerStep()].join('~');
  if(key===SEQBAR_KEY){
    const tn=host.querySelector('input[type=range]');
    if(tn && ov && document.activeElement!==tn) tn.value=String(Math.round((typeof ov.tension==='number'?ov.tension:STATE.tension)*100));
    return;
  }
  SEQBAR_KEY=key;
  const fk=focusKeyIn(host);
  host.textContent='';
  // how many bars to a row
  const g1=mk('div','grp'); g1.appendChild(mk('span','aside','Bars to a row'));
  const seg=mk('div','segctl'); seg.setAttribute('role','group'); seg.setAttribute('aria-label','Bars to a row');
  for(const p of [0].concat(SEQ_PER.filter(x=>x<=STATE.bars))){
    const b=mk('button',null,p===0?'auto':String(p)); b.type='button'; b.dataset.fk='per:'+p;
    b.setAttribute('aria-pressed', String(STATE.seqBars===p));
    b.title=p===0?'Fit as many bars to a row as are comfortable at this width (now '+L.per+')':p+' bar'+(p===1?'':'s')+' to a row';
    b.addEventListener('click', ()=>{ STATE.seqBars=p; SEQ.key=''; drawSeq(); renderSeqBar(); autosaveSoon(); });
    seg.appendChild(b);
  }
  g1.appendChild(seg); host.appendChild(g1);
  // the brush
  const g2=mk('div','grp'); g2.appendChild(mk('span','aside','New notes take'));
  const chips=mk('div','bank inline'); chips.setAttribute('role','group'); chips.setAttribute('aria-label','The envelope a note painted into the sequencer is given');
  chips.appendChild(bankChip({base:STATE.voiceEnv[STATE.lane==='all'?0:STATE.lane], key:'–', label:'lane’s own', pressed:STATE.envBrush<0, title:'No preset: the note follows its lane’s own envelope', fk:'brush:-1',
    onClick:()=>{ STATE.envBrush=-1; SEQBAR_KEY=''; renderSeqBar(); autosaveSoon(); histCommit(); }}));
  STATE.envBank.forEach((b,k)=>chips.appendChild(bankChip({base:b, key:String(k+1), label:b.name, pressed:STATE.envBrush===k, title:b.name+': a note you paint takes this envelope. Edit it under Envelopes.', fk:'brush:'+k,
    onClick:()=>{ STATE.envBrush=k; SEQBAR_KEY=''; renderSeqBar(); autosaveSoon(); histCommit(); }})));
  g2.appendChild(chips); host.appendChild(g2);
  // the bar picked in the ruler
  if(sb!=null){
    const g3=mk('div','grp'); g3.appendChild(mk('label',null,'bar '+(sb+1)));
    const sc=mk('select'); sc.setAttribute('aria-label','Scale for bar '+(sb+1));
    fill(sc, [['','same scale']].concat(scaleNames().map(k=>[k,SCALE_LABELS[k]||k])), ov.scale||'');
    sc.addEventListener('change', ()=>{
      const cur=Object.assign({}, STATE.barOverrides[sb]); if(sc.value) cur.scale=sc.value; else delete cur.scale;
      if(cur.scale||typeof cur.tension==='number') STATE.barOverrides[sb]=cur; else delete STATE.barOverrides[sb];
      regenerate(); histCommit();
    });
    g3.appendChild(sc);
    const tn=mk('input'); tn.type='range'; tn.min='0'; tn.max='100'; tn.style.width='96px'; tn.setAttribute('aria-label','Tension aim for bar '+(sb+1));
    tn.value=String(Math.round((typeof ov.tension==='number'?ov.tension:STATE.tension)*100));
    tn.title='tension aim for this bar: '+tn.value;
    tn.addEventListener('input', ()=>{ STATE.barOverrides[sb]=Object.assign({}, STATE.barOverrides[sb], {tension:(+tn.value)/100}); tn.title='tension aim for this bar: '+tn.value; scheduleRegenerate(); });
    tn.addEventListener('change', ()=>{ regenerate(); histCommit(); });
    g3.appendChild(tn);
    const cl=mk('button','tiny','reset bar'); cl.type='button'; cl.addEventListener('click', ()=>{ delete STATE.barOverrides[sb]; regenerate(); histCommit(); });
    g3.appendChild(cl);
    const dn=mk('button','tiny','done'); dn.type='button'; dn.title='Close this bar’s settings'; dn.addEventListener('click', ()=>{ STATE.selectedBar=null; renderSeqBar(); drawSeq(); });
    g3.appendChild(dn);
    host.appendChild(g3);
  }
  restoreFocusIn(host, fk);
}
// the heading's own tools: which lane, and the rhythm presets
function renderSeqTools(){
  const host=$('seqTools'); if(!host) return;
  const key=[STATE.lane].join('~');
  if(host.dataset.key===key && host.firstChild) return;
  host.dataset.key=key;
  const fk=focusKeyIn(host);
  host.textContent='';
  const lab=mk('span','aside','rhythm for'); lab.style.margin='0 2px 0 0'; host.appendChild(lab);
  const seg=mk('div','segctl'); seg.setAttribute('role','group'); seg.setAttribute('aria-label','Lane the rhythm presets apply to');
  for(const [val,label] of [['all','all'],[0,'melody'],[1,'middle'],[2,'bass']]){
    const b=mk('button',null,label); b.type='button'; b.dataset.fk='lane:'+val; b.setAttribute('aria-pressed', String(STATE.lane===val));
    b.addEventListener('click', ()=>{ STATE.lane=val; renderSeqTools(); renderSeqGutterState(); renderSeqBar(); drawSeq(); });
    seg.appendChild(b);
  }
  host.appendChild(seg);
  for(const [id,title,fn] of SEQ_PRESETS){
    const b=mk('button','tiny',id); b.type='button'; b.title=title; b.dataset.fk='rh:'+id;
    b.addEventListener('click', ()=>{ applyRhythm(fn); regenerate(); histCommit(); });
    host.appendChild(b);
  }
  const d=mk('button','tiny','chord rhythm'); d.type='button'; d.dataset.fk='rh:chord'; d.title='Go back to the rhythm that follows the chords and the grid';
  d.addEventListener('click', ()=>{ applyRhythm(null); regenerate(); histCommit(); }); host.appendChild(d);
  restoreFocusIn(host, fk);
}
