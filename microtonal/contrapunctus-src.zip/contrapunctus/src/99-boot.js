/* =====================================================================
   17 · BOOT
   ---------------------------------------------------------------------
   Order matters here: the fresh state is recorded (for "Start over")
   before anything is restored, and the first piece is composed only when
   every plate has a canvas to draw on.
   ===================================================================== */
function boot(){
  readTheme();
  STATE.life.grid=randomLife(STATE.life.w, STATE.life.h, 0.3);
  ensureGrids();
  DEFAULT_JSON=JSON.stringify(serializeState({view:true}));
  const restored=loadAutosave();

  GL_LAT=makePainter($('latticeCanvas')); GL_ROLL=makePainter($('rollCanvas'));
  GL_LAT.onRestore=drawLattice; GL_ROLL.onRestore=drawRoll;

  buildProfiles(); refreshSpaceControls(); bindControls(); bindSpace(); bindChoice(); bindStep();
  refreshSeedSelects(); syncControls(); syncChoiceControls(); updateProjButtons(); updatePlayButton();
  renderAxisModes(); renderLatKey(); renderRollKey(); renderSeqGutter(); renderSeqTools(); renderSeqBar(); renderBank();
  fillEssay(); drawLife();
  bindLattice(); bindRoll(); bindSeq(); bindEnv(); bindBasin(); bindKeep(); bindGlobal();
  $('sweep').addEventListener('keydown', sweepKeys);

  regenerate(); histReset();
  const keepNote=()=>{
    const n=$('keepNote'); if(!n) return;
    n.textContent='The state code holds every setting, seed and hand edit; loading it reproduces the piece note for note. '
      +(IO.dl ? 'Here, Save MIDI hands over a .zip with the .mid and the state in it, because this viewer takes only certain file types. ' : '')
      +'The piece you are working on is also kept in this browser'+(restored?' (and was restored from it just now)':'')+'.';
  };
  keepNote(); ioStart().then(keepNote);       // the wording follows what the viewer says it can do, whenever it says it

  if(window.__CP_DEBUG){          // a handle for the browser tests; absent in normal use
    window.__cp={ STATE, PROJ, AUD, THEME, TUNINGS, compose, regenerate, buildMidi, serializeState, restoreState, stateToCode, parseStateText,
      midiSummary, selectNote, selectSeg, setPreset, setLatticeSet, drawLattice, drawRoll, drawSeq, renderAll, play, stop, togglePlay, layoutLattice, snapshot,
      get LAYOUT(){ return LAYOUT; }, get GL_LAT(){ return GL_LAT; }, get GL_ROLL(){ return GL_ROLL; }, get HIST(){ return HIST; },
      get NN(){ return NN; }, get SP(){ return SP; },
      ENVED, SEQ, HOVER, ROLL, rollGeom, seqLayout, envTarget, secondsPerStep, envSchedule, envLevel, ENV_PEAK, ENV_FLOOR, soundingPitch, readTheme,
      switchSpace, setSpace, spaceFor, setDivisions, audition, scaleNames, DIV_CHOICES, TIMBRES, INSPECT, BANK, ANCHOR, MAP, SEQ_PER,
      chordInspect, noteInspect, pinChord, ruleOutChord, pinNote, ruleOutNote, clearEditsHere, renderInspector,
      givePreset, renderBank, renderSeqBar, renderSeqTools, setOnset, choosePreset, syncChoiceControls, handCount, presetUsage,
      forkFrom, undo, redo };
  }
}

if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot);
else boot();
