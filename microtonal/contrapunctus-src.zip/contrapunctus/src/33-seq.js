/* =====================================================================
   11 · SEQUENCER
   ---------------------------------------------------------------------
   Three lanes. In each, the upper strip switches a note on or off and the
   thin strip under it is that note's envelope: its bar runs from the onset to
   note-off, and the fainter run after it is the release that is still audible.
   Where the bar runs past the next onset the gate is longer than the space to
   the next note, which is how a held voice rubs against the next harmony.

   The bars are wrapped into systems, like a score: as many bars to a row as
   fit at a comfortable width, and the rows are stacked. Nothing scrolls. How
   many bars to a row is a choice (auto picks it from the width and the grid).
   ===================================================================== */
const SEQ={ruler:22, lane:44, onset:28, env:16, gap:12, comfort:12, hard:5, cursor:{v:0, step:0}, key:''};
const SEQ_PER=[1,2,4,8,16];

function seqLayout(){
  const inner=$('seqInner'), W=Math.max(200, (inner&&inner.clientWidth)||600);
  const bars=STATE.bars, spb=STATE.stepsPerBar, total=bars*spb;
  let per;
  if(STATE.seqBars>0){
    per=Math.min(bars, STATE.seqBars);
    while(per>1 && W/(per*spb)<SEQ.hard) per=SEQ_PER[Math.max(0,SEQ_PER.indexOf(per)-1)]||1;
  } else {
    per=1;
    for(const p of [16,12,8,6,4,3,2,1]){ if(p<=bars && bars%p===0 && W/(p*spb)>=SEQ.comfort){ per=p; break; } }
  }
  const rows=Math.ceil(bars/per), perRow=per*spb, stepW=W/perRow, sysH=SEQ.ruler+3*SEQ.lane, pitch=sysH+SEQ.gap;
  return {W, bars, spb, total, per, rows, perRow, stepW, sysH, pitch, h:rows*pitch-SEQ.gap, key:[bars,spb,per,rows,Math.round(W)].join('/')};
}
function sizeSeq(){
  const L=seqLayout(); SEQ.L=L;
  $('seqCanvas').style.height=L.h+'px';
  if(L.key!==SEQ.key){ SEQ.key=L.key; renderSeqGutter(L); renderSeqBar(); }
  return L;
}
function seqRowOf(L, step){ return Math.min(L.rows-1, Math.floor(step/L.perRow)); }
function renderSeqGutter(L){
  const host=$('seqGutter'); if(!host) return;
  L=L||seqLayout();
  host.textContent=''; host.style.height=L.h+'px';
  for(let r=0;r<L.rows;r++){
    const y0=r*L.pitch, b0=r*L.per+1, b1=Math.min(L.bars,(r+1)*L.per);
    const cap=mk('div','cap', L.rows===1 ? 'bars' : (b0===b1?'bar '+b0:'bars '+b0+'–'+b1)); cap.style.top=y0+'px'; cap.style.height=SEQ.ruler+'px'; host.appendChild(cap);
    for(let v=0;v<3;v++){
      const b=mk('button','lane'); b.type='button'; b.tabIndex=-1; b.setAttribute('aria-hidden','true');
      b.style.top=(y0+SEQ.ruler+v*SEQ.lane)+'px'; b.style.height=(SEQ.lane-2)+'px';
      const i=mk('i'); i.style.background=THEME.str.voice[v]; b.appendChild(i); b.appendChild(document.createTextNode(VOICE_NAMES[v]));
      b.setAttribute('data-lane', String(v));
      b.title='The rhythm presets apply to the '+VOICE_NAMES[v]+' lane';
      b.addEventListener('click', ()=>{ STATE.lane=v; renderSeqBar(); renderSeqGutterState(); drawSeq(); renderSeqTools(); });
      host.appendChild(b);
    }
  }
  renderSeqGutterState();
}
function renderSeqGutterState(){
  const host=$('seqGutter'); if(!host) return;
  host.querySelectorAll('button.lane').forEach(b=>b.setAttribute('aria-pressed', String(STATE.lane===+b.dataset.lane)));
}

/* ---- drawing ------------------------------------------------------------------------------------ */
// a run of steps [a, a+len) as a bar, wrapped across the rows it spans
function seqSpan(g, L, a, len, v, yIn, hgt, fill, opts){
  opts=opts||{};
  const end=a+len, r0=Math.min(L.rows-1, Math.floor(a/L.perRow)), r1=Math.min(L.rows-1, Math.floor((end-1e-9)/L.perRow));
  for(let r=r0;r<=r1;r++){
    const xs=Math.max(a, r*L.perRow)-r*L.perRow, xe=Math.min(end, (r+1)*L.perRow)-r*L.perRow;
    const x=xs*L.stepW+0.5, w=(xe-xs)*L.stepW-(r===r1?1:0), y=r*L.pitch+SEQ.ruler+v*SEQ.lane+yIn;
    g.fillStyle=fill; g.fillRect(x, y, Math.max(opts.minW||1.5, w), hgt);
  }
}
function seqPointAt(L, step){ const r=seqRowOf(L,step); return {r, x:(step-r*L.perRow)*L.stepW}; }
function drawSeq(){
  const c=STATE.composed; if(!c||!c.notes) return;
  const L=sizeSeq(), cv=$('seqCanvas');
  const {g,w,h}=ctx2d(cv);
  const total=L.total, stepW=L.stepW, spb=L.spb, S=THEME.str, beat=Math.max(1,spb/4), sel=STATE.selectedNote;
  g.font='10px '+THEME.font.mono; g.textBaseline='middle';

  for(let r=0;r<L.rows;r++){
    const y0=r*L.pitch, s0=r*L.perRow, s1=Math.min(total,s0+L.perRow), rowW=(s1-s0)*stepW;
    // ruler: bar numbers, and a dot for a bar that has its own scale or tension aim
    for(let s=s0; s<s1; s+=spb){
      const b=s/spb, x=(s-s0)*stepW;
      if(b===STATE.selectedBar){ g.fillStyle=css(THEME.grid,0.22); g.fillRect(x,y0,Math.min(spb*stepW,rowW-x),SEQ.ruler); }
      g.fillStyle=S.faint; g.textAlign='left'; g.fillText(String(b+1), x+4, y0+SEQ.ruler/2);
      const ov=STATE.barOverrides[b];
      if(ov && (ov.scale||typeof ov.tension==='number')){ g.fillStyle=S.hand; g.beginPath(); g.arc(x+Math.min(22,spb*stepW-8),y0+SEQ.ruler/2,2.8,0,7); g.fill(); }
    }
    g.strokeStyle=css(THEME.grid,0.4); g.lineWidth=1;
    g.beginPath(); g.moveTo(0,y0+SEQ.ruler+0.5); g.lineTo(rowW,y0+SEQ.ruler+0.5); g.stroke();

    for(let v=0; v<3; v++){
      const top=y0+SEQ.ruler+v*SEQ.lane, col=S.voice[v];
      if(STATE.lane===v){ g.fillStyle=css(THEME.ink,0.05); g.fillRect(0,top,rowW,SEQ.lane); }
      for(let s=s0;s<s1;s++){
        const x=(s-s0)*stepW, on=STATE.onsets[v][s], k=v+':'+s;
        g.fillStyle = on ? col : css(THEME.grid, s%spb===0?0.20:(s%beat===0?0.13:0.07));
        g.fillRect(x+0.5, top+3, Math.max(1,stepW-1), SEQ.onset-6);
        if(!on) continue;
        if(v===0 && STATE.anchors[s]!=null){ g.fillStyle=S.hand; g.fillRect(x+0.5, top+3, Math.max(1,stepW-1), 3); }
        if(STATE.notePins[k]!=null){ g.fillStyle=S.hand; g.beginPath(); g.arc(x+Math.max(3,stepW-4), top+7, 2.4, 0, 7); g.fill(); }
        const pk=STATE.notePreset[k];
        if(pk!=null && stepW>=11){ g.fillStyle=THEME.dark?'rgba(0,0,0,0.78)':'rgba(255,255,255,0.92)'; g.textAlign='center'; g.fillText(String(pk+1), x+stepW/2, top+SEQ.onset/2+1); }
      }
      const eTop=top+SEQ.onset;
      g.fillStyle=css(THEME.grid,0.09); g.fillRect(0,eTop,rowW,SEQ.env);
      g.strokeStyle=css(THEME.grid,0.28); g.lineWidth=1;
      g.beginPath(); g.moveTo(0,eTop+SEQ.env+1.5); g.lineTo(rowW,eTop+SEQ.env+1.5); g.stroke();
    }
    // bar lines
    for(let s=s0; s<=s1; s+=spb){
      const x=(s-s0)*stepW, b=s/spb;
      g.strokeStyle=css(THEME.grid, b%4===0?0.5:0.3); g.lineWidth=1;
      g.beginPath(); g.moveTo(x+0.5,y0+SEQ.ruler); g.lineTo(x+0.5,y0+L.sysH); g.stroke();
    }
  }
  // the envelope strips, wrapped across rows
  for(let v=0; v<3; v++){
    for(const nt of c.notes[v]){
      const fill = nt.e.custom ? S.hand : css(THEME.dim, 0.8);
      seqSpan(g, L, nt.step, nt.e.gate, v, SEQ.onset+5, 5, fill, {minW:1.5});
      if(nt.tailSteps>1/Math.max(1,stepW)) seqSpan(g, L, nt.step+nt.e.gate, nt.tailSteps, v, SEQ.onset+6, 3, css(nt.e.custom?THEME.hand:THEME.dim, 0.3));
      if(nt.e.gate > nt.span + 0.02){
        const pt=seqPointAt(L, Math.min(total-1e-6, nt.step+nt.e.gate-1e-6)), y=pt.r*L.pitch+SEQ.ruler+v*SEQ.lane+SEQ.onset;
        g.fillStyle=S.ink; g.fillRect(pt.x-1.5+(nt.step+nt.e.gate>=total?0:1), y+2, 2, 11);
      }
      if(sel && sel.v===v && sel.step===nt.step){
        const pt=seqPointAt(L, nt.step), y=pt.r*L.pitch+SEQ.ruler+v*SEQ.lane+SEQ.onset;
        g.strokeStyle=S.ink; g.lineWidth=1.4; g.strokeRect(pt.x+0.5, y+1.5, Math.max(4,Math.min(nt.e.gate*stepW, L.W-pt.x-1)), SEQ.env-3);
      }
    }
  }
  // the keyboard cursor, only while the canvas has focus
  if(document.activeElement===cv){
    const k=SEQ.cursor, pt=seqPointAt(L, Math.min(k.step,total-1)), y=pt.r*L.pitch+SEQ.ruler+k.v*SEQ.lane;
    g.strokeStyle=S.ink; g.lineWidth=2; g.strokeRect(pt.x+0.5, y+1.5, Math.max(3,stepW-1), SEQ.onset-3);
  }
}
function seqHit(e){
  const cv=$('seqCanvas'), rect=cv.getBoundingClientRect(), L=seqLayout();
  const k=L.W/Math.max(1,rect.width), x=(e.clientX-rect.left)*k, y=(e.clientY-rect.top)*k;
  const r=Math.floor(y/L.pitch), ly=y-r*L.pitch;
  if(r<0||r>=L.rows||ly>L.sysH) return null;
  const col=Math.floor(x/L.stepW), s=r*L.perRow+col;
  if(col<0||col>=L.perRow||s>=L.total) return null;
  if(ly<SEQ.ruler) return {kind:'bar', bar:Math.floor(s/L.spb), step:s};
  const v=Math.floor((ly-SEQ.ruler)/SEQ.lane);
  if(v<0||v>2) return null;
  const within=(ly-SEQ.ruler)-v*SEQ.lane;
  return {kind: within<SEQ.onset ? 'onset' : 'env', v, step:s};
}
// the step under the pointer while a stroke is painted: the row is the nearest one, so a stroke can run on into the next
function seqStepAt(e){
  const cv=$('seqCanvas'), rect=cv.getBoundingClientRect(), L=seqLayout();
  const k=L.W/Math.max(1,rect.width), x=(e.clientX-rect.left)*k, y=(e.clientY-rect.top)*k;
  const r=Math.max(0,Math.min(L.rows-1, Math.floor(y/L.pitch)));
  const col=Math.max(0,Math.min(L.perRow-1, Math.floor(x/L.stepW)));
  return Math.min(L.total-1, r*L.perRow+col);
}
function seqVisible(step, v){
  const cv=$('seqCanvas'), L=seqLayout(), r=seqRowOf(L,step);
  const top=cv.getBoundingClientRect().top+r*L.pitch, bottom=top+L.sysH, hdr=(parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--hdr'))||60)+(parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--stat'))||28)+8;
  if(top<hdr) window.scrollBy({top:top-hdr, behavior:'auto'});
  else if(bottom>window.innerHeight-8) window.scrollBy({top:bottom-window.innerHeight+8, behavior:'auto'});
}

/* ---- rhythm presets and per-bar settings ---------------------------------- */
const SEQ_PRESETS = [
  ['fill',  'every step',                 (t)=>new Array(t).fill(true)],
  ['clear', 'no notes',                   (t)=>new Array(t).fill(false)],
  ['3 / bar','three evenly spread onsets per bar',(t)=>{ const o=euclid(STATE.stepsPerBar,3); return Array.from({length:t},(_,i)=>o[i%STATE.stepsPerBar]); }],
  ['5 / bar','five evenly spread onsets per bar', (t)=>{ const o=euclid(STATE.stepsPerBar,5); return Array.from({length:t},(_,i)=>o[i%STATE.stepsPerBar]); }],
];
function laneList(){ return STATE.lane==='all' ? [0,1,2] : [STATE.lane]; }
// A pattern replaces the lane's onsets. A note that stays keeps what was set for it; one that is new takes the envelope picked under "new notes take";
// one that goes takes its edits with it.
function applyRhythm(fn){
  const total=STATE.bars*STATE.stepsPerBar;
  for(const v of laneList()){
    const before=STATE.onsets[v].slice();
    let after;
    if(fn===null){ STATE.touched[v]=false; after=defaultOnsets(v,total,STATE.stepsPerBar,STATE.harmonic,STATE.walkingBass); }       // back to following the chord rhythm
    else{ after=fn(total); STATE.onsets[v]=after; STATE.touched[v]=true; }
    for(let s=0;s<total;s++){
      if(!after[s]) clearNoteEdits(v,s);
      else if(!before[s] && fn!==null){ if(STATE.envBrush>=0) STATE.notePreset[v+':'+s]=STATE.envBrush; else delete STATE.notePreset[v+':'+s]; }
    }
  }
}
