/* =====================================================================
   0 · WHAT THE EAR DOES WITH AN INTERVAL
   ---------------------------------------------------------------------
   Carrying the twelve-tone rules over to another tuning is arithmetic;
   whether the result sounds good is not. Two things decide that, and they
   are different things:

   FUSION. Two tones whose frequencies stand in a simple ratio share
   partials and are heard as one sound with one pitch (a virtual
   fundamental). The ear is tolerant of this: a few cents either way and the
   fifth is still a fifth, which is why equal temperament works at all, but
   the tolerance is finite and the *simpler* the ratio the better the fusion.
   psyFusion(c) is how close an interval of c cents is to a simple ratio,
   weighted by how simple the ratio is (a Gaussian of 14 cents around each;
   7 cents around the unison and octave, which tolerate far less: two tones
   22 cents apart do not fuse, they beat).

   ROUGHNESS. Partials that fall within a critical band of each other beat,
   and beating faster than about 15 Hz is heard as roughness (Plomp and
   Levelt; the form below is Sethares's fit). A critical band is *wider in
   Hz* at low pitch, so the same interval is rougher low down: a third that
   is clean at C4 is mud at C2. psyRough(f, c) is the roughness that two
   harmonic tones add when one sits c cents above the other at f Hz, over
   what one such tone has by itself.

   Neither is enough alone. Roughness cannot tell a minor seventh from a
   minor third, and fusion cannot tell a third at C2 from one at C5. Here
   they are used for what each one knows: fusion says which intervals are
   consonances in whatever tuning is in force; roughness says whether a
   consonance can be used where the voices actually are.

   The scale of fusion is anchored to the twelve-tone table the first two
   versions used (unison 1, fifth .9, major third .75, minor third .65,
   second .25, tritone .15, semitone .05): psyCons(c) maps fusion onto that
   scale through the twelve twelve-tone interval classes, so in twelve-tone
   equal temperament it returns exactly those numbers and everywhere else
   it returns what the same ear would say.
   ===================================================================== */

// ratios [n, d, q]: q is how consonant the interval is when exactly in tune. An interval and its inversion share q,
// with one deliberate exception: the harmonic seventh 7/4 (.62: in 4:5:6:7 it is the seventh partial, and the chord
// fuses as one tone) and its inversion the septimal tone 8/7 (.30: two voices a whole tone apart, which is a second and
// grates like one). The table of interval classes (S.cons) folds every interval to the smaller of the pair, so it reads
// the septimal tone's .30; a chord that holds a 7/4 above its root is judged by 7/4's own .62 (see the colour chords in 10-core.js).
const PSY_RATIOS = [
  [3,2,.95],[4,3,.95], [5,4,.85],[8,5,.85], [6,5,.80],[5,3,.80],
  [7,4,.62],[8,7,.30], [7,6,.62],[12,7,.62], [9,7,.60],[14,9,.60], [11,9,.58],[18,11,.58], [11,8,.55],[16,11,.55],
  [7,5,.42],[10,7,.42], [9,8,.30],[16,9,.30], [10,9,.28],[9,5,.28], [45,32,.20],[64,45,.20], [16,15,.10],[15,8,.10],
];
const PSY_SIGMA = 14, PSY_SIGMA_UNISON = 7;
const PSY_PEAKS = (()=>{
  const o=[{c:0,q:1,s:PSY_SIGMA_UNISON},{c:1200,q:1,s:PSY_SIGMA_UNISON}];
  for(const [n,d,q] of PSY_RATIOS) o.push({c:1200*Math.log2(n/d), q, s:PSY_SIGMA, n, d});
  return o;
})();
function psyFusion(c){
  c=((c%1200)+1200)%1200;
  let best=0;
  for(const p of PSY_PEAKS){
    const z=(c-p.c)/p.s; if(z>4||z<-4) continue;
    const v=p.q*Math.exp(-0.5*z*z); if(v>best) best=v;
  }
  return best;
}
// the nearest listed ratio to c cents, and how far off it is
function psyNearest(c){
  c=((c%1200)+1200)%1200; let best=null, bd=1e9;
  for(const p of PSY_PEAKS){ if(p.n===undefined) continue; const d=Math.abs(c-p.c); if(d<bd){ bd=d; best=p; } }
  return {ratio:best.n+'/'+best.d, err:c-best.c};
}

const PSY_OLD = [1.0,0.05,0.25,0.65,0.75,0.9,0.15];          // the twelve-tone table, by interval class
const PSY_KNOTS = (()=>{
  const k=[]; for(let i=0;i<=6;i++) k.push([psyFusion(100*i), PSY_OLD[i]]);
  k.sort((a,b)=>a[0]-b[0]); return k;
})();
function psyScale(h){                                         // fusion -> the scale of the old table, monotone
  const K=PSY_KNOTS;
  if(h<=K[0][0]) return K[0][1]*h/K[0][0];
  for(let i=1;i<K.length;i++){
    if(h<=K[i][0]+1e-12){
      const [x0,y0]=K[i-1], [x1,y1]=K[i];
      if(Math.abs(h-x1)<1e-12) return y1;
      if(Math.abs(h-x0)<1e-12) return y0;
      return y0+(y1-y0)*(h-x0)/(x1-x0);
    }
  }
  return 1;
}
function psyCons(c){ return psyScale(psyFusion(c)); }
const PSY_YES = 0.5;                                           // a consonance is an interval that scores at least this

/* ---- roughness ---------------------------------------------------------------------------- */
const PSY_PARTIALS = 6, PSY_DECAY = 0.88;                      // the generic harmonic tone the model assumes
const PSY_ROUGH_GATE = 0.40;                                   // rougher than this, a consonance does not count as one
function psyPair(f1,a1,f2,a2){
  const fm=Math.min(f1,f2), df=Math.abs(f2-f1), s=0.24/(0.0207*fm+18.96);
  return a1*a2*(Math.exp(-3.51*s*df)-Math.exp(-5.75*s*df));
}
function psyRoughRaw(f, c){
  const r=Math.pow(2,c/1200); let sum=0;
  for(let i=1;i<=PSY_PARTIALS;i++) for(let j=1;j<=PSY_PARTIALS;j++)
    sum+=psyPair(f*i, Math.pow(PSY_DECAY,i-1), f*r*j, Math.pow(PSY_DECAY,j-1));
  return sum;
}
const PSY_BASE_CACHE = new Map();
function psyRough(f, c){
  const key=Math.round(f*4);
  let b=PSY_BASE_CACHE.get(key); if(b===undefined){ b=psyRoughRaw(key/4, 0); PSY_BASE_CACHE.set(key,b); }
  return Math.max(0, psyRoughRaw(f,c)-b);
}
// melodic motion smaller than this is heard as the same note a little out of tune, not as a step
const PSY_MICRO_CENTS = 45;
// a motion at least this long is a leap, not a step
const PSY_LEAP_CENTS = 250;
